package com.example.usbtools

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val actionPermission = "com.example.usbtools.USB_PERMISSION"
    private lateinit var usb: UsbManager
    private lateinit var info: TextView

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usb = getSystemService(USB_SERVICE) as UsbManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1C1C1E.toInt())
            setPadding(40, 120, 40, 40)
        }

        root.addView(TextView(this).apply {
            text = "USB TOOLS"
            textSize = 26f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 24)
        })

        root.addView(button("USB পারমিশন দাও") { requestAllPermissions() })
        root.addView(button("Developer Options খোলো") { openDeveloperOptions() })
        root.addView(button("রিফ্রেশ") { refresh() })

        info = TextView(this).apply {
            setTextColor(0xFFE0E0E0.toInt())
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setPadding(0, 24, 0, 0)
        }
        root.addView(ScrollView(this).apply { addView(info) })

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(actionPermission)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
        refresh()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun requestAllPermissions() {
        val devices = usb.deviceList.values
        if (devices.isEmpty()) {
            Toast.makeText(this, "আগে OTG দিয়ে একটা USB ডিভাইস লাগাও", Toast.LENGTH_SHORT).show()
            return
        }
        val flags = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val pi = PendingIntent.getBroadcast(
            this, 0, Intent(actionPermission).setPackage(packageName), flags
        )
        devices.filter { !usb.hasPermission(it) }.forEach { usb.requestPermission(it, pi) }
    }

    private fun openDeveloperOptions() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun refresh() {
        val sb = StringBuilder()

        // ---- সিস্টেম স্ট্যাটাস ----
        val host = packageManager.hasSystemFeature(PackageManager.FEATURE_USB_HOST)
        sb.appendLine("OTG / USB Host : ${if (host) "সাপোর্ট করে ✅" else "সাপোর্ট করে না ❌"}")

        val adb = Settings.Global.getInt(contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
        sb.appendLine("USB Debugging  : ${if (adb) "চালু" else "বন্ধ"}")

        // ---- ব্যাটারি / চার্জিং ----
        val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bat != null) {
            val level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val plugged = when (bat.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_AC -> "AC চার্জার"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "ওয়্যারলেস"
                else -> "প্লাগড নেই"
            }
            val temp = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
            val volt = bat.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
            sb.appendLine("ব্যাটারি       : ${level * 100 / scale}%")
            sb.appendLine("চার্জিং সোর্স  : $plugged")
            sb.appendLine("তাপমাত্রা      : $temp °C")
            sb.appendLine("ভোল্টেজ        : $volt mV")
        }

        // ---- কানেক্টেড USB ডিভাইস ----
        sb.appendLine()
        sb.appendLine("━━ কানেক্টেড USB ডিভাইস ━━")
        val devices = usb.deviceList.values
        if (devices.isEmpty()) {
            sb.appendLine("কোনো USB ডিভাইস কানেক্টেড নেই")
        } else {
            devices.forEachIndexed { index, d ->
                val cls = if (d.deviceClass != 0 || d.interfaceCount == 0) d.deviceClass
                else d.getInterface(0).interfaceClass
                sb.appendLine()
                sb.appendLine("#${index + 1}  ${d.deviceName}")
                sb.appendLine("  Vendor ID  : 0x%04X".format(d.vendorId))
                sb.appendLine("  Product ID : 0x%04X".format(d.productId))
                sb.appendLine("  Class      : ${className(cls)}")
                sb.appendLine("  Interfaces : ${d.interfaceCount}")
                val hasPerm = usb.hasPermission(d)
                sb.appendLine("  পারমিশন    : ${if (hasPerm) "আছে" else "নেই"}")
                runCatching { d.manufacturerName }.getOrNull()?.let { sb.appendLine("  Maker      : $it") }
                runCatching { d.productName }.getOrNull()?.let { sb.appendLine("  Product    : $it") }
                if (hasPerm) {
                    runCatching { d.serialNumber }.getOrNull()?.let { sb.appendLine("  Serial     : $it") }
                }
            }
        }

        info.text = sb.toString()
    }

    private fun className(c: Int) = when (c) {
        UsbConstants.USB_CLASS_AUDIO -> "Audio"
        UsbConstants.USB_CLASS_COMM -> "Communication"
        UsbConstants.USB_CLASS_HID -> "HID (কিবোর্ড/মাউস)"
        UsbConstants.USB_CLASS_PRINTER -> "Printer"
        UsbConstants.USB_CLASS_MASS_STORAGE -> "Mass Storage (পেনড্রাইভ)"
        UsbConstants.USB_CLASS_HUB -> "Hub"
        UsbConstants.USB_CLASS_CDC_DATA -> "CDC Data"
        UsbConstants.USB_CLASS_VIDEO -> "Video / Camera"
        UsbConstants.USB_CLASS_WIRELESS_CONTROLLER -> "Wireless"
        UsbConstants.USB_CLASS_VENDOR_SPEC -> "Vendor Specific"
        else -> "Class $c"
    }
}
