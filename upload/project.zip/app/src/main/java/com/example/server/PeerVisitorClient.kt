package com.example.server

import android.content.Context
import android.net.Uri
import com.example.data.local.FileItemEntity
import com.example.data.local.FolderEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

data class RemoteFolderSnapshot(
    val online: Boolean,
    val folder: FolderEntity?,
    val subfolders: List<FolderEntity>,
    val files: List<FileItemEntity>,
    val errorMessage: String? = null
)

class PeerVisitorClient(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private val visitorCacheDir: File by lazy {
        File(context.cacheDir, "visitor_streams").apply {
            if (!exists()) mkdirs()
        }
    }

    data class ParsedPeerLink(
        val baseUrl: String,
        val folderId: String
    )

    fun parseLink(rawInput: String, localFallbackBaseUrl: String): ParsedPeerLink? {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return null

        // Support raw folder ID or speedserver://share/<id> or http://<ip>:<port>/?share=<id>
        if (!trimmed.contains("://") && !trimmed.contains("/")) {
            return ParsedPeerLink(localFallbackBaseUrl.trimEnd('/'), trimmed)
        }
        val uri = runCatching { Uri.parse(trimmed) }.getOrNull() ?: return null
        if (uri.scheme.equals("speedserver", ignoreCase = true)) {
            val id = uri.getQueryParameter("share")
                ?: uri.pathSegments.lastOrNull()
                ?: return null
            val hostParam = uri.getQueryParameter("host")
            val base = if (!hostParam.isNullOrBlank()) hostParam.trimEnd('/') else localFallbackBaseUrl.trimEnd('/')
            return ParsedPeerLink(base, id)
        }
        val scheme = uri.scheme?.lowercase() ?: "http"
        val host = uri.host ?: return null
        val portPart = if (uri.port != -1) ":${uri.port}" else ""
        val baseUrl = "$scheme://$host$portPart"
        val shareId = uri.getQueryParameter("share")
            ?: uri.pathSegments.takeIf { it.size >= 2 && it[0] == "s" }?.get(1)
            ?: uri.fragment?.substringAfter("s=", "")?.takeIf { it.isNotBlank() }
            ?: return null
        return ParsedPeerLink(baseUrl, shareId)
    }

    suspend fun fetchFolder(baseUrl: String, folderId: String): RemoteFolderSnapshot =
        withContext(Dispatchers.IO) {
            try {
                val url = "${baseUrl.trimEnd('/')}/api/folder?id=${Uri.encode(folderId)}"
                val request = Request.Builder().url(url).get().build()
                client.newCall(request).execute().use { response ->
                    val bodyStr = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        val msg = runCatching { JSONObject(bodyStr).optString("error") }.getOrNull()
                        return@withContext RemoteFolderSnapshot(
                            online = false,
                            folder = null,
                            subfolders = emptyList(),
                            files = emptyList(),
                            errorMessage = msg?.ifBlank { null } ?: "Host Phone Is Currently Offline"
                        )
                    }
                    val json = JSONObject(bodyStr)
                    val online = json.optBoolean("online", false)
                    val fObj = json.optJSONObject("folder")
                    val folder = fObj?.let { parseFolderJson(it) }
                    val subArr = json.optJSONArray("subfolders")
                    val subfolders = buildList {
                        if (subArr != null) {
                            for (i in 0 until subArr.length()) {
                                add(parseFolderJson(subArr.getJSONObject(i)))
                            }
                        }
                    }
                    val filesArr = json.optJSONArray("files")
                    val files = buildList {
                        if (filesArr != null) {
                            for (i in 0 until filesArr.length()) {
                                add(parseFileJson(filesArr.getJSONObject(i)))
                            }
                        }
                    }
                    RemoteFolderSnapshot(
                        online = online,
                        folder = folder,
                        subfolders = subfolders,
                        files = files
                    )
                }
            } catch (e: Exception) {
                RemoteFolderSnapshot(
                    online = false,
                    folder = null,
                    subfolders = emptyList(),
                    files = emptyList(),
                    errorMessage = "Unable to reach host (${e.localizedMessage ?: "offline"})"
                )
            }
        }

    suspend fun streamFileToCache(
        baseUrl: String,
        shareRootId: String,
        file: FileItemEntity,
        onProgress: (Float) -> Unit
    ): File? = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl.trimEnd('/')}/api/file?id=${Uri.encode(file.id)}&share=${Uri.encode(shareRootId)}"
            val request = Request.Builder().url(url).get().build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                val body = response.body ?: return@withContext null
                val expected = body.contentLength().takeIf { it > 0 } ?: file.sizeBytes.coerceAtLeast(1L)
                val dest = File(visitorCacheDir, "${file.id}_${file.name.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                val buffer = ByteArray(32 * 1024)
                var totalRead = 0L
                body.byteStream().use { input ->
                    FileOutputStream(dest).use { output ->
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            totalRead += read
                            onProgress((totalRead.toFloat() / expected.toFloat()).coerceIn(0f, 1f))
                        }
                        output.flush()
                    }
                }
                onProgress(1f)
                dest
            }
        } catch (_: Exception) {
            null
        }
    }

    fun connectSse(
        baseUrl: String,
        roomId: String,
        peerId: String,
        onStatus: (online: Boolean, activePeers: Int) -> Unit
    ): okhttp3.Call {
        val url = "${baseUrl.trimEnd('/')}/api/events?roomId=${Uri.encode(roomId)}&peerId=${Uri.encode(peerId)}"
        val sseClient = client.newBuilder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()
        val request = Request.Builder().url(url).get().build()
        val call = sseClient.newCall(request)
        Thread {
            try {
                call.execute().use { response ->
                    val source = response.body?.source() ?: return@use
                    while (!call.isCanceled()) {
                        val line = source.readUtf8Line() ?: break
                        if (line.startsWith("data:")) {
                            val jsonStr = line.removePrefix("data:").trim()
                            runCatching {
                                val obj = JSONObject(jsonStr)
                                val online = obj.optBoolean("online", true)
                                val peers = obj.optInt("activePeers", 1)
                                onStatus(online, peers)
                            }
                        }
                    }
                }
            } catch (_: Exception) {
                onStatus(false, 0)
            }
        }.start()
        return call
    }

    private fun parseFolderJson(obj: JSONObject): FolderEntity {
        val tagsArr = obj.optJSONArray("tags")
        val tagList = buildList {
            if (tagsArr != null) {
                for (i in 0 until tagsArr.length()) {
                    add(tagsArr.optString(i))
                }
            }
        }
        return FolderEntity(
            id = obj.getString("id"),
            name = obj.getString("name"),
            parentId = if (obj.isNull("parentId")) null else obj.optString("parentId"),
            live = obj.optBoolean("live", false),
            tags = tagList.joinToString(","),
            contentType = obj.optString("contentType", "files"),
            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
        )
    }

    private fun parseFileJson(obj: JSONObject): FileItemEntity {
        return FileItemEntity(
            id = obj.getString("id"),
            folderId = obj.getString("folderId"),
            name = obj.getString("name"),
            mimeType = obj.optString("mimeType", "application/octet-stream"),
            sizeBytes = obj.optLong("sizeBytes", 0L),
            localPath = "",
            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
        )
    }
}
