package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

enum class FolderContentType(val key: String, val label: String) {
    PHOTOS("photos", "Photos"),
    VIDEOS("videos", "Videos"),
    FILES("files", "Files");

    companion object {
        fun fromKey(key: String?): FolderContentType =
            entries.firstOrNull { it.key.equals(key, ignoreCase = true) } ?: FILES
    }
}

enum class FilterMode(val label: String) {
    ALL("All Items"),
    FOLDERS("Folders Only"),
    PHOTOS("Photos Only"),
    VIDEOS("Videos Only"),
    FILES_HTML("Files & HTML")
}

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val parentId: String? = null,
    val live: Boolean = false,
    val tags: String = "",
    val contentType: String = FolderContentType.FILES.key,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun tagList(): List<String> =
        tags.split(",")
            .map { it.trim().removePrefix("#") }
            .filter { it.isNotEmpty() }
            .distinct()
}

@Entity(
    tableName = "files",
    indices = [Index(value = ["folderId"])]
)
data class FileItemEntity(
    @PrimaryKey val id: String,
    val folderId: String,
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val localPath: String,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isHtml: Boolean
        get() = name.endsWith(".html", ignoreCase = true) ||
            name.endsWith(".htm", ignoreCase = true) ||
            mimeType.equals("text/html", ignoreCase = true)

    val isImage: Boolean
        get() = mimeType.startsWith("image/", ignoreCase = true) ||
            name.substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic")

    val isVideo: Boolean
        get() = mimeType.startsWith("video/", ignoreCase = true) ||
            name.substringAfterLast('.', "").lowercase() in setOf("mp4", "webm", "mkv", "mov", "avi", "m4v")

    val isAudio: Boolean
        get() = mimeType.startsWith("audio/", ignoreCase = true) ||
            name.substringAfterLast('.', "").lowercase() in setOf("mp3", "wav", "ogg", "m4a", "flac", "aac")
}
