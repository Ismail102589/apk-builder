package com.example.server

import android.util.Log
import com.example.data.local.FileItemEntity
import com.example.data.local.FolderEntity
import com.example.data.repository.SpeedRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class SpeedHttpServer(
    private val repository: SpeedRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var serverSocket: ServerSocket? = null
    private var acceptExecutor: ExecutorService? = null
    private var clientExecutor: ExecutorService? = null
    private val running = AtomicBoolean(false)

    // peerId -> lastSeenTimestamp
    private val activeSsePeers = ConcurrentHashMap<String, Long>()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _port = MutableStateFlow(8080)
    val port: StateFlow<Int> = _port.asStateFlow()

    private val _localIp = MutableStateFlow("127.0.0.1")
    val localIp: StateFlow<String> = _localIp.asStateFlow()

    private val _activePeers = MutableStateFlow(0)
    val activePeers: StateFlow<Int> = _activePeers.asStateFlow()

    private val _bytesUploaded = MutableStateFlow(0L)
    val bytesUploaded: StateFlow<Long> = _bytesUploaded.asStateFlow()

    private val _publicUrl = MutableStateFlow<String?>(null)
    val publicUrl: StateFlow<String?> = _publicUrl.asStateFlow()

    private val _tunnelStatus = MutableStateFlow("Tunnel off")
    val tunnelStatus: StateFlow<String> = _tunnelStatus.asStateFlow()

    private val tunnel = TunnelManager(
        onUrl = { _publicUrl.value = it },
        onStatus = { _tunnelStatus.value = it }
    )

    /** 0 = HTTPS (localhost.run), 1 = HTTP (bore.pub), 2 = LOCAL Wi-Fi only (http://ip:port) */
    private val _tunnelMode = MutableStateFlow(0)
    val tunnelMode: StateFlow<Int> = _tunnelMode.asStateFlow()

    fun setTunnelMode(mode: Int) {
        _tunnelMode.value = mode
        tunnel.https = (mode == 0)
        if (running.get()) {
            if (mode == 2) {
                tunnel.stop()
                _tunnelStatus.value = "Local only"
            } else {
                tunnel.restart(_port.value, mode == 0)
            }
        }
    }

    fun getShareUrl(folderId: String): String {
        return "${getBaseUrl()}/?share=$folderId"
    }

    fun getFileUrl(file: com.example.data.local.FileItemEntity): String {
        val name = java.net.URLEncoder.encode(file.name, "UTF-8").replace("+", "%20")
        return "${getBaseUrl()}/f/${file.id}/$name"
    }

    fun getBaseUrl(): String {
        return _publicUrl.value ?: "http://${_localIp.value}:${_port.value}"
    }

    @Synchronized
    fun ensureStarted() {
        _localIp.value = detectLocalIpAddress()
        if (running.get()) return

        val candidatePorts = (8080..8099).toList() + listOf(0)
        var boundSocket: ServerSocket? = null
        for (p in candidatePorts) {
            try {
                boundSocket = ServerSocket(p, 50, InetAddress.getByName("0.0.0.0"))
                break
            } catch (_: Exception) {
                // try next port
            }
        }
        if (boundSocket == null) {
            Log.e(TAG, "Failed to bind SpeedHttpServer socket")
            return
        }

        serverSocket = boundSocket
        _port.value = boundSocket.localPort
        running.set(true)
        _isRunning.value = true
        if (_tunnelMode.value != 2) tunnel.start(boundSocket.localPort)
        else _tunnelStatus.value = "Local only"

        acceptExecutor = Executors.newSingleThreadExecutor()
        clientExecutor = Executors.newCachedThreadPool()

        acceptExecutor?.execute {
            while (running.get()) {
                try {
                    val socket = boundSocket.accept()
                    clientExecutor?.execute { handleClient(socket) }
                } catch (_: Exception) {
                    if (running.get()) {
                        Log.w(TAG, "Accept loop interrupted")
                    }
                }
            }
        }
    }

    @Synchronized
    fun stop() {
        if (!running.getAndSet(false)) return
        _isRunning.value = false
        tunnel.stop()
        activeSsePeers.clear()
        _activePeers.value = 0
        runCatching { serverSocket?.close() }
        serverSocket = null
        runCatching { acceptExecutor?.shutdownNow() }
        runCatching { clientExecutor?.shutdownNow() }
        acceptExecutor = null
        clientExecutor = null
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 30_000
                val input = BufferedInputStream(client.getInputStream())
                val output = BufferedOutputStream(client.getOutputStream())

                val requestLine = readLine(input) ?: return
                val parts = requestLine.split(" ")
                if (parts.size < 2) return
                val method = parts[0].uppercase()
                val rawTarget = parts[1]

                val headers = mutableMapOf<String, String>()
                while (true) {
                    val line = readLine(input) ?: break
                    if (line.isEmpty()) break
                    val colon = line.indexOf(':')
                    if (colon > 0) {
                        headers[line.substring(0, colon).trim().lowercase()] =
                            line.substring(colon + 1).trim()
                    }
                }

                if (method != "GET" && method != "HEAD") {
                    writeJsonResponse(output, 405, "Method Not Allowed", """{"error":"Method not allowed"}""")
                    return
                }

                val path = rawTarget.substringBefore('?')
                val query = parseQuery(rawTarget.substringAfter('?', ""))

                when {
                    path == "/api/health" -> {
                        val liveCount = kotlinx.coroutines.runBlocking {
                            repository.getAllFoldersSync().count { it.live }
                        }
                        val json = JSONObject()
                            .put("status", "ok")
                            .put("liveFolders", liveCount)
                            .put("activePeers", _activePeers.value)
                            .put("bytesUploaded", _bytesUploaded.value)
                            .toString()
                        writeJsonResponse(output, 200, "OK", json)
                    }

                    path == "/api/folder" -> {
                        val folderId = query["id"] ?: query["share"] ?: ""
                        handleFolderApi(output, folderId)
                    }

                    path == "/api/file" -> {
                        val fileId = query["id"] ?: ""
                        val shareRoot = query["share"] ?: ""
                        val rangeHeader = headers["range"]
                        val download = query["download"] == "1"
                        handleFileStream(output, fileId, shareRoot, rangeHeader, download, method == "HEAD")
                    }

                    path.startsWith("/f/") -> {
                        // Direct per-file link: /f/<fileId>/<fileName>
                        val fileId = path.removePrefix("/f/").substringBefore('/')
                        handleFileStream(output, fileId, "", headers["range"], query["download"] == "1", method == "HEAD")
                    }

                    path == "/api/events" -> {
                        val roomId = query["roomId"] ?: ""
                        val peerId = query["peerId"] ?: ("peer-" + System.nanoTime())
                        client.soTimeout = 0
                        handleSseStream(output, roomId, peerId)
                    }

                    path.startsWith("/s/") -> {
                        val folderId = path.removePrefix("/s/").substringBefore('/')
                        val html = buildVisitorWebHtml(folderId)
                        writeHtmlResponse(output, html)
                    }

                    path == "/" || path == "/index.html" -> {
                        val shareId = query["share"] ?: ""
                        val html = buildVisitorWebHtml(shareId)
                        writeHtmlResponse(output, html)
                    }

                    else -> {
                        writeJsonResponse(output, 404, "Not Found", """{"error":"Not found"}""")
                    }
                }
            } catch (e: Exception) {
                Log.d(TAG, "Client connection closed: ${e.message}")
            }
        }
    }

    private fun handleFolderApi(output: OutputStream, folderId: String) {
        if (folderId.isBlank()) {
            writeJsonResponse(output, 400, "Bad Request", """{"error":"Missing folder id"}""")
            return
        }
        val allFolders = kotlinx.coroutines.runBlocking { repository.getAllFoldersSync() }
        val folder = allFolders.firstOrNull { it.id == folderId }
        if (folder == null || !repository.isEffectivelyLive(folderId, allFolders)) {
            writeJsonResponse(
                output,
                404,
                "Not Found",
                """{"error":"Folder offline or not found","online":false}"""
            )
            return
        }
        val subfolders = allFolders.filter { it.parentId == folderId }
        val files = kotlinx.coroutines.runBlocking { repository.getFilesByFolderSync(folderId) }

        val json = JSONObject().apply {
            put("online", true)
            put("folder", folderToJson(folder))
            put("subfolders", JSONArray().apply {
                subfolders.forEach { put(folderToJson(it)) }
            })
            put("files", JSONArray().apply {
                files.forEach { put(fileToJson(it)) }
            })
        }.toString()

        writeJsonResponse(output, 200, "OK", json)
    }

    private fun handleFileStream(
        output: OutputStream,
        fileId: String,
        shareRoot: String,
        rangeHeader: String?,
        forceDownload: Boolean,
        headOnly: Boolean
    ) {
        val fileEntity = kotlinx.coroutines.runBlocking { repository.getFileByIdSync(fileId) }
        val allFolders = kotlinx.coroutines.runBlocking { repository.getAllFoldersSync() }
        if (fileEntity == null || !repository.isEffectivelyLive(fileEntity.folderId, allFolders)) {
            writeJsonResponse(output, 404, "Not Found", """{"error":"File offline or not found"}""")
            return
        }
        if (shareRoot.isNotBlank() && !repository.isDescendantOf(fileEntity.folderId, shareRoot, allFolders)) {
            writeJsonResponse(output, 403, "Forbidden", """{"error":"File outside shared folder scope"}""")
            return
        }

        val diskFile = File(fileEntity.localPath)
        if (!diskFile.exists()) {
            writeJsonResponse(output, 404, "Not Found", """{"error":"Blob missing on host"}""")
            return
        }

        val totalLength = diskFile.length()
        var start = 0L
        var end = (totalLength - 1).coerceAtLeast(0L)
        var isPartial = false

        if (!rangeHeader.isNullOrBlank() && rangeHeader.startsWith("bytes=")) {
            val rangeSpec = rangeHeader.removePrefix("bytes=").substringBefore(',')
            val dash = rangeSpec.indexOf('-')
            if (dash >= 0) {
                val startStr = rangeSpec.substring(0, dash).trim()
                val endStr = rangeSpec.substring(dash + 1).trim()
                if (startStr.isNotEmpty()) {
                    start = startStr.toLongOrNull()?.coerceIn(0L, (totalLength - 1).coerceAtLeast(0L)) ?: 0L
                    end = if (endStr.isNotEmpty()) {
                        endStr.toLongOrNull()?.coerceIn(start, (totalLength - 1).coerceAtLeast(0L)) ?: end
                    } else {
                        end
                    }
                    isPartial = true
                }
            }
        }

        val contentLength = if (totalLength == 0L) 0L else (end - start + 1)
        val status = if (isPartial) "206 Partial Content" else "200 OK"
        val dispositionType = if (forceDownload) "attachment" else "inline"
        val safeName = fileEntity.name.replace("\"", "_")

        val headerBuilder = StringBuilder().apply {
            append("HTTP/1.1 $status\r\n")
            append("Content-Type: ${fileEntity.mimeType}\r\n")
            append("Content-Length: $contentLength\r\n")
            append("Accept-Ranges: bytes\r\n")
            if (isPartial) {
                append("Content-Range: bytes $start-$end/$totalLength\r\n")
            }
            append("Content-Disposition: $dispositionType; filename=\"$safeName\"\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n\r\n")
        }
        output.write(headerBuilder.toString().toByteArray(StandardCharsets.UTF_8))

        if (!headOnly && contentLength > 0) {
            val chunk = ByteArray(CHUNK_SIZE_BYTES)
            var remaining = contentLength
            FileInputStream(diskFile).use { fis ->
                if (start > 0) {
                    var skipped = 0L
                    while (skipped < start) {
                        val s = fis.skip(start - skipped)
                        if (s <= 0) break
                        skipped += s
                    }
                }
                while (remaining > 0) {
                    val toRead = minOf(chunk.size.toLong(), remaining).toInt()
                    val read = fis.read(chunk, 0, toRead)
                    if (read <= 0) break
                    output.write(chunk, 0, read)
                    remaining -= read
                    _bytesUploaded.value = _bytesUploaded.value + read
                }
            }
        }
        output.flush()
    }

    private fun handleSseStream(output: OutputStream, roomId: String, peerId: String) {
        activeSsePeers[peerId] = System.currentTimeMillis()
        updatePeerCount()

        val headers = buildString {
            append("HTTP/1.1 200 OK\r\n")
            append("Content-Type: text/event-stream\r\n")
            append("Cache-Control: no-cache\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Connection: keep-alive\r\n\r\n")
        }
        output.write(headers.toByteArray(StandardCharsets.UTF_8))
        output.flush()

        try {
            while (running.get()) {
                val allFolders = kotlinx.coroutines.runBlocking { repository.getAllFoldersSync() }
                val isOnline = roomId.isBlank() || repository.isEffectivelyLive(roomId, allFolders)
                val statusJson = JSONObject()
                    .put("type", "host-status")
                    .put("online", isOnline)
                    .put("activePeers", _activePeers.value)
                    .toString()
                val event = "event: host-status\ndata: $statusJson\n\n"
                output.write(event.toByteArray(StandardCharsets.UTF_8))
                output.flush()
                activeSsePeers[peerId] = System.currentTimeMillis()
                updatePeerCount()
                Thread.sleep(4000)
            }
        } catch (_: Exception) {
            // Peer disconnected
        } finally {
            activeSsePeers.remove(peerId)
            updatePeerCount()
        }
    }

    private fun updatePeerCount() {
        val now = System.currentTimeMillis()
        activeSsePeers.entries.removeIf { now - it.value > 20_000L }
        _activePeers.value = activeSsePeers.size
    }

    private fun folderToJson(f: FolderEntity): JSONObject = JSONObject().apply {
        put("id", f.id)
        put("name", f.name)
        put("parentId", f.parentId ?: JSONObject.NULL)
        put("live", f.live)
        put("tags", JSONArray(f.tagList()))
        put("contentType", f.contentType)
        put("createdAt", f.createdAt)
    }

    private fun fileToJson(f: FileItemEntity): JSONObject = JSONObject().apply {
        put("id", f.id)
        put("folderId", f.folderId)
        put("name", f.name)
        put("mimeType", f.mimeType)
        put("sizeBytes", f.sizeBytes)
        put("isHtml", f.isHtml)
        put("isImage", f.isImage)
        put("isVideo", f.isVideo)
        put("isAudio", f.isAudio)
        put("createdAt", f.createdAt)
    }

    private fun writeJsonResponse(output: OutputStream, code: Int, reason: String, json: String) {
        val bytes = json.toByteArray(StandardCharsets.UTF_8)
        val headers = buildString {
            append("HTTP/1.1 $code $reason\r\n")
            append("Content-Type: application/json; charset=utf-8\r\n")
            append("Content-Length: ${bytes.size}\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n\r\n")
        }
        output.write(headers.toByteArray(StandardCharsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun writeHtmlResponse(output: OutputStream, html: String) {
        val bytes = html.toByteArray(StandardCharsets.UTF_8)
        val headers = buildString {
            append("HTTP/1.1 200 OK\r\n")
            append("Content-Type: text/html; charset=utf-8\r\n")
            append("Content-Length: ${bytes.size}\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n\r\n")
        }
        output.write(headers.toByteArray(StandardCharsets.UTF_8))
        output.write(bytes)
        output.flush()
    }

    private fun readLine(input: BufferedInputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) {
                return sb.toString().trimEnd('\r')
            }
            sb.append(b.toChar())
        }
    }

    private fun parseQuery(qs: String): Map<String, String> {
        if (qs.isBlank()) return emptyMap()
        return qs.split('&').mapNotNull { pair ->
            val idx = pair.indexOf('=')
            if (idx <= 0) null
            else {
                val k = URLDecoder.decode(pair.substring(0, idx), "UTF-8")
                val v = URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
                k to v
            }
        }.toMap()
    }

    fun detectLocalIpAddress(): String {
        return try {
            val interfaces = NetworkInterface.getNetworkInterfaces().toList()
            val candidates = interfaces
                .filter { it.isUp && !it.isLoopback }
                .flatMap { iface ->
                    iface.inetAddresses.toList()
                        .filterIsInstance<Inet4Address>()
                        .filter { !it.isLoopbackAddress && !it.isLinkLocalAddress }
                        .map { iface.name to it.hostAddress }
                }
            val wifi = candidates.firstOrNull { (name, _) ->
                name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("eth")
            }?.second
            wifi ?: candidates.firstOrNull()?.second ?: "127.0.0.1"
        } catch (_: Exception) {
            "127.0.0.1"
        }
    }

    private fun buildVisitorWebHtml(initialShareId: String): String {
        val escapedId = initialShareId.replace("\"", "").replace("<", "").replace(">", "")
        return """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
<title>Speed Server — Live P2P Visitor</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; font-family: system-ui, -apple-system, sans-serif;
    background: #0d0820; color: #f8fafc; display: flex; justify-content: center;
    background-image:
      radial-gradient(circle at 18% 14%, rgba(255,79,163,0.48), transparent 45%),
      radial-gradient(circle at 86% 20%, rgba(34,211,238,0.40), transparent 45%),
      radial-gradient(circle at 70% 62%, rgba(139,92,246,0.48), transparent 50%),
      radial-gradient(circle at 14% 78%, rgba(251,191,36,0.30), transparent 45%),
      radial-gradient(circle at 92% 92%, rgba(52,211,153,0.30), transparent 45%);
  }
  .wrap { width: 100%; max-width: 520px; padding: 16px; }
  .glass {
    background: rgba(255,255,255,0.09); backdrop-filter: blur(22px) saturate(170%);
    border: 1px solid rgba(255,255,255,0.2); border-radius: 20px;
    box-shadow: inset 0 1px 0 rgba(255,255,255,0.22), 0 16px 40px rgba(0,0,0,0.4);
  }
  .header { padding: 14px 16px; display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 14px; }
  .title { font-weight: 700; font-size: 18px; background: linear-gradient(90deg, #fff, #fbcfe8, #a5f3fc); -webkit-background-clip: text; color: transparent; }
  .pill { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 999px; font-size: 12px; font-weight: 600; background: rgba(16,185,129,0.18); border: 1px solid rgba(52,211,153,0.4); color: #6ee7b7; }
  .pill.off { background: rgba(251,113,133,0.18); border-color: rgba(251,113,133,0.4); color: #fda4af; }
  .dot { width: 8px; height: 8px; border-radius: 50%; background: #34d399; animation: pulse 1.5s infinite; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.4} }
  .banner { padding: 14px 16px; margin-bottom: 14px; display: flex; align-items: center; justify-content: space-between; gap: 12px; background: linear-gradient(135deg, rgba(255,79,163,0.22), rgba(34,211,238,0.18)); }
  .btn { border: 0; border-radius: 999px; padding: 9px 16px; font-weight: 700; color: #fff; cursor: pointer; background: linear-gradient(90deg, #8b5cf6, #ec4899, #f59e0b); }
  .grid { display: grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap: 12px; }
  .card { padding: 12px 10px; border-radius: 18px; text-align: center; cursor: pointer; transition: transform .15s; }
  .card:active { transform: scale(0.96); }
  .thumb { width: 100%; aspect-ratio: 1; border-radius: 12px; object-fit: cover; background: rgba(255,255,255,0.06); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 12px; position: relative; overflow: hidden; }
  .badge { position: absolute; top: 6px; right: 6px; padding: 2px 7px; border-radius: 999px; font-size: 10px; font-weight: 700; background: #ec4899; color: #fff; }
  .name { margin-top: 8px; font-size: 12px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .meta { font-size: 10px; color: #cbd5e1; margin-top: 2px; }
  .modal { position: fixed; inset: 0; background: rgba(10,6,26,0.92); backdrop-filter: blur(20px); display: none; flex-direction: column; z-index: 50; }
  .modal.open { display: flex; }
  .modal-bar { padding: 12px 16px; display: flex; align-items: center; justify-content: space-between; gap: 8px; border-bottom: 1px solid rgba(255,255,255,0.15); }
  .tab { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #fff; padding: 6px 12px; border-radius: 999px; font-size: 12px; cursor: pointer; }
  .tab.active { background: linear-gradient(90deg, #8b5cf6, #ec4899); border-color: transparent; }
  iframe { border: 0; background: #fff; margin: auto; transition: width .2s; height: 100%; }
  pre { margin: 0; padding: 16px; overflow: auto; flex: 1; font-family: ui-monospace, monospace; font-size: 12px; color: #e2e8f0; }
</style>
</head>
<body>
<div class="wrap">
  <div class="glass header">
    <div>
      <div class="title" id="folderTitle">Speed Server</div>
      <div class="meta" id="folderTags">Direct On-Device Host Stream</div>
    </div>
    <div class="pill" id="statusPill"><span class="dot"></span><span id="statusText">Connecting</span></div>
  </div>
  <div id="crumbs" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;"></div>
  <div id="htmlBanner"></div>
  <div id="progressBar" class="meta" style="margin-bottom:10px;"></div>
  <div class="grid" id="grid"></div>
</div>
<div class="modal" id="runnerModal">
  <div class="modal-bar">
    <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;">
      <button class="tab" onclick="closeRunner()">Close</button>
      <button class="tab active" id="btnLive" onclick="setRunnerMode('live')">Live Webpage</button>
      <button class="tab" id="btnSrc" onclick="setRunnerMode('source')">Source</button>
      <button class="tab" onclick="setViewport('390px')">Mobile</button>
      <button class="tab" onclick="setViewport('768px')">Tablet</button>
      <button class="tab" onclick="setViewport('100%')">Full</button>
      <button class="tab" onclick="reloadRunner()">Reload</button>
    </div>
    <a id="downloadHtmlLink" class="tab" download>Download</a>
  </div>
  <iframe id="htmlFrame" sandbox="allow-scripts allow-modals allow-forms allow-same-origin allow-popups" style="width:100%;flex:1;"></iframe>
  <pre id="htmlSource" style="display:none;"></pre>
</div>
<div class="modal" id="mediaModal">
  <div class="modal-bar">
    <span id="mediaTitle" style="font-weight:600;font-size:14px;"></span>
    <div style="display:flex;gap:8px;">
      <a id="mediaDownload" class="tab" download>Download</a>
      <button class="tab" onclick="closeMedia()">Close</button>
    </div>
  </div>
  <div id="mediaBody" style="flex:1;display:flex;align-items:center;justify-content:center;padding:16px;overflow:auto;"></div>
</div>
<script>
const rootShareId = new URLSearchParams(location.search).get('share') || "$escapedId";
let currentFolderId = rootShareId;
let stack = [];
let currentHtmlText = "";
let currentFileUrl = "";
const peerId = "web-" + Math.random().toString(36).slice(2, 10);

function fmt(b){ if(b<1024)return b+" B"; if(b<1048576)return (b/1024).toFixed(1)+" KB"; return (b/1048576).toFixed(1)+" MB"; }

async function loadFolder(id, push=false) {
  if(!id){ document.getElementById('statusPill').className='pill off'; document.getElementById('statusText').textContent='No Share ID'; return; }
  if(push) stack.push(currentFolderId);
  currentFolderId = id;
  try {
    const res = await fetch('/api/folder?id=' + encodeURIComponent(id));
    const data = await res.json();
    if(!res.ok || !data.online) {
      document.getElementById('statusPill').className='pill off';
      document.getElementById('statusText').textContent='Host Phone Offline';
      document.getElementById('grid').innerHTML = '';
      document.getElementById('htmlBanner').innerHTML = '';
      return;
    }
    document.getElementById('statusPill').className='pill';
    document.getElementById('statusText').textContent='Live';
    document.getElementById('folderTitle').textContent = data.folder.name;
    document.getElementById('folderTags').textContent = (data.folder.tags||[]).map(t=>'#'+t).join(' ') || 'Live Host Folder';
    renderCrumbs();
    renderHtmlBanner(data.files||[]);
    renderGrid(data.subfolders||[], data.files||[]);
  } catch(e) {
    document.getElementById('statusPill').className='pill off';
    document.getElementById('statusText').textContent='Offline';
  }
}

function renderCrumbs() {
  const el = document.getElementById('crumbs');
  el.innerHTML = stack.length ? '<button class="tab" onclick="goBack()">← Back</button>' : '';
}
function goBack(){ if(stack.length){ loadFolder(stack.pop(), false); } }

function renderHtmlBanner(files) {
  const htmlFiles = files.filter(f => f.isHtml);
  if(!htmlFiles.length){ document.getElementById('htmlBanner').innerHTML=''; return; }
  const target = htmlFiles.find(f => f.name.toLowerCase()==='index.html') || htmlFiles[0];
  document.getElementById('htmlBanner').innerHTML =
    '<div class="glass banner"><div><div style="font-weight:700;font-size:14px;">Direct Web App Execution</div><div class="meta">'+target.name+' ready to launch</div></div><button class="btn" onclick=\'launchHtml('+JSON.stringify(target)+')\'>Launch App</button></div>';
}

function renderGrid(subfolders, files) {
  const g = document.getElementById('grid');
  g.innerHTML = '';
  subfolders.forEach(sf => {
    const d = document.createElement('div');
    d.className = 'glass card';
    d.innerHTML = '<div class="thumb" style="font-size:28px;">📁</div><div class="name"></div><div class="meta">Folder</div>';
    d.querySelector('.name').textContent = sf.name;
    d.onclick = () => loadFolder(sf.id, true);
    g.appendChild(d);
  });
  files.forEach(f => {
    const d = document.createElement('div');
    d.className = 'glass card';
    const url = '/api/file?id=' + encodeURIComponent(f.id) + '&share=' + encodeURIComponent(rootShareId);
    let inner = '';
    if(f.isImage) inner = '<img class="thumb" src="'+url+'" />';
    else if(f.isVideo) inner = '<div class="thumb">▶ VIDEO</div>';
    else if(f.isAudio) inner = '<div class="thumb">♫ AUDIO</div>';
    else if(f.isHtml) inner = '<div class="thumb">HTML<span class="badge">HTML</span></div>';
    else inner = '<div class="thumb">FILE</div>';
    d.innerHTML = inner + '<div class="name"></div><div class="meta">'+fmt(f.sizeBytes)+'</div>';
    d.querySelector('.name').textContent = f.name;
    d.onclick = () => openFile(f);
    const lb = document.createElement('button');
    lb.className = 'tab';
    lb.textContent = '🔗 Copy link';
    lb.onclick = (ev) => { ev.stopPropagation(); copyLink(location.origin + '/f/' + encodeURIComponent(f.id) + '/' + encodeURIComponent(f.name)); };
    d.appendChild(lb);
    g.appendChild(d);
  });
}

async function openFile(f) {
  if(f.isHtml) return launchHtml(f);
  const url = '/api/file?id=' + encodeURIComponent(f.id) + '&share=' + encodeURIComponent(rootShareId);
  const dlUrl = url + '&download=1';
  if(f.isImage || f.isVideo || f.isAudio) {
    document.getElementById('mediaTitle').textContent = f.name;
    document.getElementById('mediaDownload').href = dlUrl;
    const body = document.getElementById('mediaBody');
    if(f.isImage) body.innerHTML = '<img src="'+url+'" style="max-width:100%;max-height:85vh;border-radius:16px;" />';
    else if(f.isVideo) body.innerHTML = '<video src="'+url+'" controls autoplay playsinline style="max-width:100%;max-height:85vh;border-radius:16px;"></video>';
    else body.innerHTML = '<audio src="'+url+'" controls autoplay style="width:100%;max-width:420px;"></audio>';
    document.getElementById('mediaModal').classList.add('open');
  } else {
    const a = document.createElement('a'); a.href = dlUrl; a.download = f.name; a.click();
  }
}
function copyLink(u){
  if(navigator.clipboard && window.isSecureContext){ navigator.clipboard.writeText(u).then(()=>alert('Link copied')); }
  else { window.prompt('Copy this link:', u); }
}
function closeMedia(){ document.getElementById('mediaBody').innerHTML=''; document.getElementById('mediaModal').classList.remove('open'); }

async function launchHtml(f) {
  const url = '/api/file?id=' + encodeURIComponent(f.id) + '&share=' + encodeURIComponent(rootShareId);
  currentFileUrl = url;
  const res = await fetch(url);
  currentHtmlText = await res.text();
  document.getElementById('htmlFrame').srcdoc = currentHtmlText;
  document.getElementById('htmlSource').textContent = currentHtmlText;
  document.getElementById('downloadHtmlLink').href = url + '&download=1';
  setRunnerMode('live');
  document.getElementById('runnerModal').classList.add('open');
}
function setRunnerMode(m) {
  document.getElementById('btnLive').classList.toggle('active', m==='live');
  document.getElementById('btnSrc').classList.toggle('active', m==='source');
  document.getElementById('htmlFrame').style.display = m==='live' ? 'block' : 'none';
  document.getElementById('htmlSource').style.display = m==='source' ? 'block' : 'none';
}
function setViewport(w){ document.getElementById('htmlFrame').style.width = w; }
function reloadRunner(){ document.getElementById('htmlFrame').srcdoc = currentHtmlText; }
function closeRunner(){ document.getElementById('runnerModal').classList.remove('open'); document.getElementById('htmlFrame').srcdoc=''; }

if(rootShareId) {
  const es = new EventSource('/api/events?roomId=' + encodeURIComponent(rootShareId) + '&peerId=' + peerId);
  es.addEventListener('host-status', (ev) => {
    const d = JSON.parse(ev.data);
    if(!d.online) {
      document.getElementById('statusPill').className='pill off';
      document.getElementById('statusText').textContent='Host Phone Offline';
    }
  });
  loadFolder(rootShareId);
}
</script>
</body>
</html>
        """.trimIndent()
    }

    companion object {
        private const val TAG = "SpeedHttpServer"
        private const val CHUNK_SIZE_BYTES = 32 * 1024
    }
}
