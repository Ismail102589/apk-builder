package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.TabletAndroid
import androidx.compose.material.icons.rounded.Web
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.components.glassSurface
import com.example.ui.theme.DeepInk
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonMint
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.FileViewerItem
import java.nio.charset.StandardCharsets

private enum class RunnerTab { LIVE, SOURCE }
private enum class RunnerViewport(val label: String) { MOBILE("390px"), TABLET("768px"), FULL("Full") }

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LiveHtmlRunnerScreen(
    fileItem: FileViewerItem,
    onExportHtml: () -> Unit,
    onClose: () -> Unit
) {
    BackHandler { onClose() }

    val clipboard = LocalClipboardManager.current
    val htmlSource = remember(fileItem.localFile.absolutePath) {
        runCatching { fileItem.localFile.readText(StandardCharsets.UTF_8) }
            .getOrElse { "<!-- Unable to decode HTML file -->" }
    }

    var activeTab by remember { mutableStateOf(RunnerTab.LIVE) }
    var viewport by remember { mutableStateOf(RunnerViewport.FULL) }
    var reloadKey by remember { mutableIntStateOf(0) }
    var fullscreen by remember { mutableStateOf(false) }
    var copiedFeedback by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepInk)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        if (!fullscreen) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassSurface(shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose, modifier = Modifier.testTag("runner_close")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = fileItem.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Live HTML Execution Sandbox",
                            fontSize = 11.sp,
                            color = NeonMint
                        )
                    }
                    IconButton(onClick = { reloadKey++ }, modifier = Modifier.testTag("runner_reload")) {
                        Icon(Icons.Rounded.Refresh, contentDescription = "Reload Page", tint = NeonCyan)
                    }
                    IconButton(onClick = onExportHtml, modifier = Modifier.testTag("runner_download")) {
                        Icon(Icons.Rounded.Download, contentDescription = "Export HTML", tint = TextPrimary)
                    }
                    IconButton(onClick = { fullscreen = true }, modifier = Modifier.testTag("runner_fullscreen")) {
                        Icon(Icons.Rounded.Fullscreen, contentDescription = "Fullscreen", tint = TextPrimary)
                    }
                }

                Spacer(Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RunnerChip(
                        active = activeTab == RunnerTab.LIVE,
                        icon = Icons.Rounded.Web,
                        label = "Live Webpage",
                        onClick = { activeTab = RunnerTab.LIVE },
                        modifier = Modifier.testTag("runner_tab_live")
                    )
                    RunnerChip(
                        active = activeTab == RunnerTab.SOURCE,
                        icon = Icons.Rounded.Code,
                        label = "Source",
                        onClick = { activeTab = RunnerTab.SOURCE },
                        modifier = Modifier.testTag("runner_tab_source")
                    )

                    if (activeTab == RunnerTab.LIVE) {
                        Spacer(Modifier.width(4.dp))
                        RunnerChip(
                            active = viewport == RunnerViewport.MOBILE,
                            icon = Icons.Rounded.PhoneAndroid,
                            label = "390dp",
                            onClick = { viewport = RunnerViewport.MOBILE },
                            modifier = Modifier.testTag("runner_vp_mobile")
                        )
                        RunnerChip(
                            active = viewport == RunnerViewport.TABLET,
                            icon = Icons.Rounded.TabletAndroid,
                            label = "768dp",
                            onClick = { viewport = RunnerViewport.TABLET },
                            modifier = Modifier.testTag("runner_vp_tablet")
                        )
                        RunnerChip(
                            active = viewport == RunnerViewport.FULL,
                            icon = Icons.Rounded.DesktopWindows,
                            label = "Full",
                            onClick = { viewport = RunnerViewport.FULL },
                            modifier = Modifier.testTag("runner_vp_full")
                        )
                    } else {
                        RunnerChip(
                            active = copiedFeedback,
                            icon = Icons.Rounded.ContentCopy,
                            label = if (copiedFeedback) "Copied" else "Copy Code",
                            onClick = {
                                clipboard.setText(AnnotatedString(htmlSource))
                                copiedFeedback = true
                            },
                            modifier = Modifier.testTag("runner_copy_source")
                        )
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            if (activeTab == RunnerTab.LIVE) {
                val frameModifier = when (viewport) {
                    RunnerViewport.MOBILE -> Modifier.widthInOrFill(390)
                    RunnerViewport.TABLET -> Modifier.widthInOrFill(768)
                    RunnerViewport.FULL -> Modifier.fillMaxWidth()
                }
                Box(
                    modifier = frameModifier
                        .fillMaxHeight()
                        .padding(if (fullscreen || viewport == RunnerViewport.FULL) 0.dp else 10.dp)
                        .clip(RoundedCornerShape(if (fullscreen || viewport == RunnerViewport.FULL) 0.dp else 16.dp))
                        .border(
                            width = if (fullscreen || viewport == RunnerViewport.FULL) 0.dp else 1.dp,
                            color = GlassBorder,
                            shape = RoundedCornerShape(if (fullscreen || viewport == RunnerViewport.FULL) 0.dp else 16.dp)
                        )
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.allowFileAccess = false
                                settings.allowContentAccess = false
                                settings.useWideViewPort = true
                                settings.loadWithOverviewMode = true
                                settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                webChromeClient = WebChromeClient()
                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(
                                        view: WebView?,
                                        request: WebResourceRequest?
                                    ): Boolean = false
                                }
                                loadDataWithBaseURL(
                                    "https://speedserver.local/",
                                    htmlSource,
                                    "text/html",
                                    "UTF-8",
                                    null
                                )
                                tag = reloadKey
                            }
                        },
                        update = { webView ->
                            if (webView.tag != reloadKey) {
                                webView.tag = reloadKey
                                webView.loadDataWithBaseURL(
                                    "https://speedserver.local/",
                                    htmlSource,
                                    "text/html",
                                    "UTF-8",
                                    null
                                )
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF090518))
                        .verticalScroll(rememberScrollState())
                        .horizontalScroll(rememberScrollState())
                        .padding(16.dp)
                ) {
                    Text(
                        text = htmlSource,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = Color(0xFFE2E8F0)
                    )
                }
            }

            if (fullscreen) {
                IconButton(
                    onClick = { fullscreen = false },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.65f))
                        .testTag("runner_exit_fullscreen")
                ) {
                    Icon(Icons.Rounded.FullscreenExit, contentDescription = "Exit Fullscreen", tint = Color.White)
                }
            }
        }
    }
}

private fun Modifier.widthInOrFill(maxDp: Int): Modifier =
    this.widthIn(max = maxDp.dp).fillMaxWidth()

@Composable
private fun RunnerChip(
    active: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(CircleShape)
            .background(
                if (active) Brush.horizontalGradient(listOf(NeonViolet, NeonPink))
                else Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.10f)))
            )
            .border(1.dp, if (active) Color.Transparent else GlassBorder, CircleShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}
