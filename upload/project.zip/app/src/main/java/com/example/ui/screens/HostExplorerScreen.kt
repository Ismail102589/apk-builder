package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Label
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FileItemEntity
import com.example.data.local.FilterMode
import com.example.data.local.FolderContentType
import com.example.data.local.FolderEntity
import com.example.data.repository.SpeedRepository
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.DeviceTelemetryModal
import com.example.ui.components.DualToneFolderIcon
import com.example.ui.components.FileThumbnailArtwork
import com.example.ui.components.FilterBottomSheet
import com.example.ui.components.FolderConfigBottomSheet
import com.example.ui.components.GlassTextInputDialog
import com.example.ui.components.IridescentBackdrop
import com.example.ui.components.glassSurface
import com.example.ui.components.tactilePressScale
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMint
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.PlusJakartaSansFontFamily
import com.example.ui.theme.SheetGlassBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.HostScreenUiState
import com.example.viewmodel.SpeedServerViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HostExplorerScreen(
    uiState: HostScreenUiState,
    viewModel: SpeedServerViewModel
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val haptic = LocalHapticFeedback.current

    BackHandler(enabled = uiState.isSelectionMode || uiState.currentFolderId != null) {
        if (uiState.isSelectionMode) {
            viewModel.clearSelection()
        } else {
            viewModel.navigateUp()
        }
    }

    // Zero-permission Photo Picker & SAF Document Picker configured by folder.contentType
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(25)
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.importFiles(uris)
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.importFiles(uris)
    }

    // Auto-clear toast after 2.6 seconds
    LaunchedEffect(uiState.toastMessage) {
        if (uiState.toastMessage != null) {
            delay(2600)
            viewModel.clearToast()
        }
    }

    IridescentBackdrop {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxSize()
                    .statusBarsPadding()
            ) {
                // 1. Sticky Glass Header
                HostStickyHeader(
                    uiState = uiState,
                    onBack = {
                        if (uiState.isSelectionMode) viewModel.clearSelection()
                        else viewModel.navigateUp()
                    },
                    onSelectAll = { viewModel.selectAllVisible() },
                    onOpenTelemetry = { viewModel.openTelemetryModal(true) },
                    onOpenPeerConnect = { viewModel.openPeerConnectModal(true) },
                    onOpenFilter = { viewModel.openFilterSheet(true) },
                    onOpenNewFolder = { viewModel.openNewFolderModal(true) }
                )

                // 2. Clickable Breadcrumb Bar when inside nested folders
                if (uiState.breadcrumbs.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.08f))
                                .clickable { viewModel.navigateToFolder(null) }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .testTag("crumb_home"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Home, contentDescription = "Home", tint = NeonCyan, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Home", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                        }
                        uiState.breadcrumbs.forEach { crumb ->
                            Text(" / ", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 2.dp))
                            val isCurrent = crumb.id == uiState.currentFolderId
                            Text(
                                text = crumb.name,
                                fontSize = 12.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                color = if (isCurrent) Color.White else TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(if (isCurrent) NeonViolet.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.06f))
                                    .clickable { viewModel.navigateToFolder(crumb.id) }
                                    .padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                // 3. 3-Column Folder & File Grid (or inviting empty state)
                val isEmpty = uiState.visibleSubfolders.isEmpty() && uiState.visibleFiles.isEmpty()
                if (isEmpty) {
                    EmptyExplorerState(
                        isInsideFolder = uiState.currentFolderId != null,
                        filterMode = uiState.filterMode,
                        onCreateFolder = { viewModel.openNewFolderModal(true) },
                        onResetFilter = { viewModel.setFilterMode(FilterMode.ALL) },
                        modifier = Modifier.weight(1f)
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentPadding = PaddingValues(
                            start = 14.dp,
                            end = 14.dp,
                            top = 10.dp,
                            bottom = 124.dp
                        ),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(uiState.visibleSubfolders, key = { "folder_${it.id}" }) { folder ->
                            val selected = folder.id in uiState.selectedFolderIds
                            val effectivelyLive = viewModel.isEffectivelyLive(folder.id)
                            FolderGridItem(
                                folder = folder,
                                isLive = effectivelyLive,
                                isSelectionMode = uiState.isSelectionMode,
                                isSelected = selected,
                                onTap = {
                                    if (uiState.isSelectionMode) {
                                        viewModel.toggleFolderSelection(folder.id)
                                    } else {
                                        viewModel.navigateToFolder(folder.id)
                                    }
                                },
                                onLongPress = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.toggleFolderSelection(folder.id, triggerHaptic = true)
                                }
                            )
                        }

                        items(uiState.visibleFiles, key = { "file_${it.id}" }) { file ->
                            val selected = file.id in uiState.selectedFileIds
                            FileGridItem(
                                file = file,
                                isSelectionMode = uiState.isSelectionMode,
                                isSelected = selected,
                                onTap = {
                                    if (uiState.isSelectionMode) {
                                        viewModel.toggleFileSelection(file.id)
                                    } else {
                                        viewModel.openHostFile(file)
                                    }
                                },
                                onLongPress = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.toggleFileSelection(file.id, triggerHaptic = true)
                                }
                            )
                        }
                    }
                }
            }

            // Floating Share-Link Popup when turning a folder LIVE
            AnimatedVisibility(
                visible = uiState.sharePopupUrl != null,
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut() + slideOutVertically { it / 2 },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .widthIn(max = 500.dp)
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 92.dp)
            ) {
                val url = uiState.sharePopupUrl.orEmpty()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .glassSurface(
                            shape = RoundedCornerShape(20.dp),
                            fill = SheetGlassBg,
                            borderColor = NeonMint.copy(alpha = 0.55f)
                        )
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Live Server Ready", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NeonMint)
                        Text(
                            text = url,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 11.sp,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    IconButton(
                        onClick = {
                            clipboard.setText(AnnotatedString(url))
                            viewModel.dismissSharePopup()
                        },
                        modifier = Modifier.testTag("popup_copy_share")
                    ) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy Link", tint = NeonCyan)
                    }
                    IconButton(
                        onClick = {
                            viewModel.dismissSharePopup()
                            viewModel.openVisitorByLink(url)
                        },
                        modifier = Modifier.testTag("popup_open_visitor")
                    ) {
                        Icon(Icons.Rounded.OpenInBrowser, contentDescription = "Open Visitor", tint = NeonPink)
                    }
                    IconButton(onClick = { viewModel.dismissSharePopup() }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Dismiss", tint = TextSecondary)
                    }
                }
            }

            // Toast Notification Pill
            AnimatedVisibility(
                visible = uiState.toastMessage != null,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 68.dp, start = 20.dp, end = 20.dp)
            ) {
                Box(
                    modifier = Modifier
                        .glassSurface(
                            shape = CircleShape,
                            fill = SheetGlassBg,
                            borderColor = NeonCyan.copy(alpha = 0.45f)
                        )
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                ) {
                    Text(
                        text = uiState.toastMessage.orEmpty(),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                }
            }

            // Floating File Upload CTA inside any folder (when not in selection mode)
            AnimatedVisibility(
                visible = uiState.currentFolder != null && !uiState.isSelectionMode,
                enter = fadeIn() + slideInVertically { it },
                exit = fadeOut() + slideOutVertically { it },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 18.dp)
            ) {
                val folderType = FolderContentType.fromKey(uiState.currentFolder?.contentType)
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(
                            Brush.horizontalGradient(
                                listOf(NeonViolet, NeonPink, NeonAmber)
                            )
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                        .clickable(enabled = !uiState.isUploading) {
                            when (folderType) {
                                FolderContentType.PHOTOS -> mediaPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                                FolderContentType.VIDEOS -> mediaPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                                FolderContentType.FILES -> documentPickerLauncher.launch(arrayOf("*/*"))
                            }
                        }
                        .padding(horizontal = 24.dp, vertical = 14.dp)
                        .testTag("file_upload_cta")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (uiState.isUploading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Rounded.CloudUpload,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(Modifier.width(9.dp))
                        Text(
                            text = if (uiState.isUploading) "Storing on device..." else "File upload",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Floating 6-Action Selection Bottom Bar
            AnimatedVisibility(
                visible = uiState.isSelectionMode,
                enter = fadeIn() + slideInVertically { it },
                exit = fadeOut() + slideOutVertically { it },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .widthIn(max = 520.dp)
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 12.dp)
            ) {
                val totalSelected = uiState.selectedFolderIds.size + uiState.selectedFileIds.size
                val singleFolderSelected = uiState.selectedFolderIds.size == 1 && uiState.selectedFileIds.isEmpty()
                val singleItemSelected = totalSelected == 1
                val hasFoldersSelected = uiState.selectedFolderIds.isNotEmpty()

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .glassSurface(
                            shape = RoundedCornerShape(24.dp),
                            fill = SheetGlassBg,
                            borderColor = GlassBorder
                        )
                        .padding(horizontal = 6.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ActionBarButton(
                        icon = Icons.Rounded.DriveFileRenameOutline,
                        label = "Rename",
                        enabled = singleItemSelected,
                        onClick = { viewModel.requestRenameSelected() },
                        modifier = Modifier.testTag("action_rename")
                    )
                    ActionBarButton(
                        icon = Icons.Rounded.Delete,
                        label = "Delete",
                        tint = NeonCoral,
                        enabled = totalSelected > 0,
                        onClick = { viewModel.requestDeleteSelection() },
                        modifier = Modifier.testTag("action_delete")
                    )
                    ActionBarButton(
                        icon = Icons.Rounded.PowerSettingsNew,
                        label = "Server",
                        tint = NeonMint,
                        enabled = hasFoldersSelected,
                        onClick = { viewModel.toggleServerForSelection() },
                        modifier = Modifier.testTag("action_server")
                    )
                    ActionBarButton(
                        icon = Icons.Rounded.Label,
                        label = "Tags",
                        tint = NeonCyan,
                        enabled = hasFoldersSelected,
                        onClick = { viewModel.openTagsForSelection() },
                        modifier = Modifier.testTag("action_tags")
                    )
                    ActionBarButton(
                        icon = Icons.Rounded.Share,
                        label = "Share",
                        tint = NeonAmber,
                        enabled = singleFolderSelected,
                        onClick = {
                            val id = uiState.selectedFolderIds.first()
                            val folder = uiState.allFolders.firstOrNull { it.id == id }
                            if (folder != null) {
                                if (!viewModel.isEffectivelyLive(folder.id)) {
                                    viewModel.setFolderLive(folder.id, true)
                                }
                                val link = viewModel.getShareUrl(folder.id)
                                clipboard.setText(AnnotatedString(link))
                                viewModel.shareUrlExternally(context, link, folder.name)
                            }
                        },
                        modifier = Modifier.testTag("action_share")
                    )
                    ActionBarButton(
                        icon = Icons.Rounded.MoreHoriz,
                        label = "More",
                        enabled = singleFolderSelected,
                        onClick = {
                            val id = uiState.selectedFolderIds.first()
                            val folder = uiState.allFolders.firstOrNull { it.id == id }
                            viewModel.openConfigSheet(folder)
                        },
                        modifier = Modifier.testTag("action_more")
                    )
                }
            }
        }
    }

    // --- Modals & Bottom Sheets ---
    if (uiState.showTelemetryModal) {
        DeviceTelemetryModal(
            telemetry = uiState.telemetry,
            isServerRunning = uiState.isServerRunning,
            serverBaseUrl = uiState.serverBaseUrl,
            activePeers = uiState.activePeers,
            bytesUploaded = uiState.bytesUploaded,
            onCopyBaseUrl = {
                clipboard.setText(AnnotatedString(uiState.serverBaseUrl))
            },
            onOpenPeerConnect = {
                viewModel.openTelemetryModal(false)
                viewModel.openPeerConnectModal(true)
            },
            onDismiss = { viewModel.openTelemetryModal(false) }
        )
    }

    if (uiState.showFilterSheet) {
        FilterBottomSheet(
            currentFilter = uiState.filterMode,
            onSelectFilter = { viewModel.setFilterMode(it) },
            onDismiss = { viewModel.openFilterSheet(false) }
        )
    }

    if (uiState.showNewFolderModal) {
        GlassTextInputDialog(
            title = "New Folder",
            subtitle = "Stored strictly on this device. Duplicate names auto-number.",
            initialValue = "",
            placeholder = "e.g. Vacation Reels or My WebApp",
            confirmLabel = "Create",
            testTagPrefix = "new_folder",
            onDismiss = { viewModel.openNewFolderModal(false) },
            onConfirm = { name -> viewModel.createFolder(name) }
        )
    }

    if (uiState.showPeerConnectModal) {
        GlassTextInputDialog(
            title = "Connect to Peer",
            subtitle = "Paste a Speed Server link (http://ip:port/?share=...) or local live folder ID",
            initialValue = "",
            placeholder = "http://192.168.1.12:8080/?share=...",
            confirmLabel = "Connect",
            testTagPrefix = "peer_connect",
            onDismiss = { viewModel.openPeerConnectModal(false) },
            onConfirm = { link -> viewModel.openVisitorByLink(link) }
        )
    }

    uiState.renameFolder?.let { folder ->
        GlassTextInputDialog(
            title = "Rename Folder",
            initialValue = folder.name,
            placeholder = "Folder name",
            confirmLabel = "Save",
            testTagPrefix = "rename",
            onDismiss = { viewModel.dismissRename() },
            onConfirm = { newName -> viewModel.confirmRenameFolder(folder.id, newName) }
        )
    }

    uiState.renameFile?.let { file ->
        GlassTextInputDialog(
            title = "Rename File",
            initialValue = file.name,
            placeholder = "File name",
            confirmLabel = "Save",
            testTagPrefix = "rename",
            onDismiss = { viewModel.dismissRename() },
            onConfirm = { newName -> viewModel.confirmRenameFile(file.id, newName) }
        )
    }

    uiState.tagsTargetFolderIds?.let { targetIds ->
        val firstFolder = uiState.allFolders.firstOrNull { it.id == targetIds.firstOrNull() }
        val initial = if (targetIds.size == 1 && firstFolder != null) {
            firstFolder.tagList().joinToString(" ") { "#$it" }
        } else ""
        GlassTextInputDialog(
            title = "Folder Tags",
            subtitle = "Separate tags with spaces, commas, or #hashtags",
            initialValue = initial,
            placeholder = "#photos #demo #2026",
            confirmLabel = "Apply Tags",
            testTagPrefix = "tags",
            onDismiss = { viewModel.dismissTags() },
            onConfirm = { raw -> viewModel.saveTags(targetIds, raw) }
        )
    }

    if (uiState.confirmDeleteFolderIds != null || uiState.confirmDeleteFileIds != null) {
        DeleteConfirmDialog(
            folderCount = uiState.confirmDeleteFolderIds?.size ?: 0,
            fileCount = uiState.confirmDeleteFileIds?.size ?: 0,
            onDismiss = { viewModel.dismissDeleteConfirmation() },
            onConfirm = { viewModel.executeConfirmedDelete() }
        )
    }

    uiState.configSheetFolder?.let { folder ->
        val ancestor = viewModel.hasLiveAncestor(folder.id)
        val effectiveLive = viewModel.isEffectivelyLive(folder.id)
        val shareUrl = viewModel.getShareUrl(folder.id)
        FolderConfigBottomSheet(
            folder = folder,
            isEffectivelyLive = effectiveLive,
            liveAncestorName = ancestor?.name,
            shareUrl = shareUrl,
            onToggleLive = { desired -> viewModel.setFolderLive(folder.id, desired) },
            onCopyLink = { clipboard.setText(AnnotatedString(shareUrl)) },
            onShareLink = { viewModel.shareUrlExternally(context, shareUrl, folder.name) },
            onPreviewVisitor = { viewModel.openLocalFolderAsVisitor(folder.id) },
            onContentTypeSelected = { type -> viewModel.setFolderContentType(folder.id, type) },
            onRename = {
                viewModel.openConfigSheet(null)
                viewModel.openRenameFolder(folder)
            },
            onEditTags = {
                viewModel.openConfigSheet(null)
                viewModel.openTagsForFolder(folder)
            },
            onDelete = { viewModel.requestDeleteSingleFolder(folder.id) },
            onDismiss = { viewModel.openConfigSheet(null) }
        )
    }
}

@Composable
private fun HostStickyHeader(
    uiState: HostScreenUiState,
    onBack: () -> Unit,
    onSelectAll: () -> Unit,
    onOpenTelemetry: () -> Unit,
    onOpenPeerConnect: () -> Unit,
    onOpenFilter: () -> Unit,
    onOpenNewFolder: () -> Unit
) {
    val pulseTransition = rememberInfiniteTransition(label = "liveDotPulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(tween(950), RepeatMode.Reverse),
        label = "pulseAlpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .glassSurface(shape = RoundedCornerShape(22.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (uiState.isSelectionMode || uiState.currentFolder != null) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("header_back")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
        }

        val totalSel = uiState.selectedFolderIds.size + uiState.selectedFileIds.size
        val titleText = when {
            uiState.isSelectionMode -> "$totalSel selected"
            uiState.currentFolder != null -> uiState.currentFolder.name
            else -> "Speed Server"
        }

        Text(
            text = titleText,
            style = TextStyle(
                fontFamily = PlusJakartaSansFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 19.sp,
                brush = Brush.horizontalGradient(
                    listOf(Color.White, Color(0xFFFBCFE8), Color(0xFFA5F3FC))
                )
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 6.dp)
        )

        if (uiState.isSelectionMode) {
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(NeonViolet.copy(alpha = 0.35f))
                    .border(1.dp, NeonCyan.copy(alpha = 0.5f), CircleShape)
                    .clickable(onClick = onSelectAll)
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("header_select_all")
            ) {
                Text("Select All", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        } else {
            // Live Status & Telemetry Pill
            val anyLive = uiState.telemetry.liveFolderCount > 0
            Row(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(
                        if (anyLive) NeonEmerald.copy(alpha = 0.22f)
                        else Color.White.copy(alpha = 0.08f)
                    )
                    .border(
                        1.dp,
                        if (anyLive) NeonMint.copy(alpha = 0.55f) else GlassBorder,
                        CircleShape
                    )
                    .clickable(onClick = onOpenTelemetry)
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .testTag("telemetry_pill"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .alpha(if (anyLive) pulseAlpha else 0.45f)
                        .clip(CircleShape)
                        .background(if (anyLive) NeonMint else TextMuted)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = if (anyLive) "${uiState.activePeers} online" else "Standby",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (anyLive) NeonMint else TextSecondary
                )
            }

            IconButton(
                onClick = onOpenPeerConnect,
                modifier = Modifier.size(40.dp).testTag("header_peer_connect")
            ) {
                Icon(Icons.Rounded.Link, contentDescription = "Connect to Peer", tint = NeonCyan, modifier = Modifier.size(20.dp))
            }

            Box {
                IconButton(
                    onClick = onOpenFilter,
                    modifier = Modifier.size(40.dp).testTag("header_filter")
                ) {
                    Icon(Icons.Rounded.FilterList, contentDescription = "Filter", tint = TextPrimary, modifier = Modifier.size(20.dp))
                }
                if (uiState.filterMode != FilterMode.ALL) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(7.dp)
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(NeonCyan)
                    )
                }
            }

            IconButton(
                onClick = onOpenNewFolder,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NeonViolet, NeonPink)))
                    .testTag("header_new_folder")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "New Folder", tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderGridItem(
    folder: FolderEntity,
    isLive: Boolean,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = Modifier
            .tactilePressScale(interactionSource)
            .glassSurface(
                shape = RoundedCornerShape(18.dp),
                fill = if (isSelected) NeonViolet.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.09f),
                borderColor = if (isSelected) NeonCyan else GlassBorder,
                borderWidth = if (isSelected) 1.5.dp else 1.dp
            )
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onTap,
                onLongClick = onLongPress
            )
            .padding(horizontal = 8.dp, vertical = 10.dp)
            .testTag("folder_card_${folder.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.1f),
            contentAlignment = Alignment.Center
        ) {
            DualToneFolderIcon(
                folderId = folder.id,
                modifier = Modifier
                    .fillMaxWidth(0.76f)
                    .aspectRatio(1.15f)
            )

            if (isLive) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(NeonEmerald, NeonCyan)))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "LIVE",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF041C15)
                    )
                }
            }

            if (isSelectionMode) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) NeonCyan else Color.Black.copy(alpha = 0.45f))
                        .border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(Icons.Rounded.Check, contentDescription = null, tint = Color(0xFF0D0820), modifier = Modifier.size(13.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        Text(
            text = folder.name,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
        val tagPreview = folder.tagList().take(2).joinToString(" ") { "#$it" }
        if (tagPreview.isNotEmpty()) {
            Text(
                text = tagPreview,
                fontSize = 10.sp,
                color = NeonCyan,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileGridItem(
    file: FileItemEntity,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onTap: () -> Unit,
    onLongPress: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    Column(
        modifier = Modifier
            .tactilePressScale(interactionSource)
            .glassSurface(
                shape = RoundedCornerShape(18.dp),
                fill = if (isSelected) NeonViolet.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.09f),
                borderColor = if (isSelected) NeonCyan else GlassBorder,
                borderWidth = if (isSelected) 1.5.dp else 1.dp
            )
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onTap,
                onLongClick = onLongPress
            )
            .padding(horizontal = 8.dp, vertical = 10.dp)
            .testTag("file_card_${file.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1.1f)
        ) {
            FileThumbnailArtwork(
                file = file,
                modifier = Modifier.fillMaxSize()
            )
            if (isSelectionMode) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(4.dp)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) NeonCyan else Color.Black.copy(alpha = 0.55f))
                        .border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(Icons.Rounded.Check, contentDescription = null, tint = Color(0xFF0D0820), modifier = Modifier.size(13.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = file.name,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
        Text(
            text = SpeedRepository.formatBytes(file.sizeBytes),
            fontSize = 10.sp,
            color = TextMuted,
            maxLines = 1,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun ActionBarButton(
    icon: ImageVector,
    label: String,
    tint: Color = TextPrimary,
    enabled: Boolean = true,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.35f)
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(2.dp))
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Medium, color = tint, maxLines = 1)
    }
}

@Composable
private fun EmptyExplorerState(
    isInsideFolder: Boolean,
    filterMode: FilterMode,
    onCreateFolder: () -> Unit,
    onResetFilter: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(84.dp)
                .glassSurface(shape = RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.CreateNewFolder,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(40.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            text = when {
                filterMode != FilterMode.ALL -> "No ${filterMode.label}"
                isInsideFolder -> "Empty Folder"
                else -> "Your Phone Is the Server"
            },
            style = MaterialTheme.typography.headlineSmall,
            color = TextPrimary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = when {
                filterMode != FilterMode.ALL -> "Switch back to All Items to see everything stored here."
                isInsideFolder -> "Tap File upload below to store photos, videos, or .html web apps directly on this device, or create a subfolder."
                else -> "Zero cloud storage. Create a folder, add files or HTML apps, and toggle Server ON to serve peers straight from this device."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(18.dp))
        if (filterMode != FilterMode.ALL) {
            Button(
                onClick = onResetFilter,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = NeonViolet)
            ) {
                Text("Show All Items")
            }
        } else if (!isInsideFolder) {
            Button(
                onClick = onCreateFolder,
                modifier = Modifier.testTag("empty_create_folder"),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = NeonViolet)
            ) {
                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Create First Folder", fontWeight = FontWeight.Bold)
            }
        }
    }
}
