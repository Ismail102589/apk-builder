package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.os.StatFs
import android.provider.OpenableColumns
import com.example.data.local.FileItemEntity
import com.example.data.local.FolderContentType
import com.example.data.local.FolderEntity
import com.example.data.local.SpeedDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.UUID

sealed class ToggleServerResult {
    data class Updated(
        val turnedLiveFolderId: String?,
        val liveCount: Int
    ) : ToggleServerResult()

    data class BlockedByLiveAncestor(val ancestorName: String) : ToggleServerResult()
}

data class StorageTelemetry(
    val storageUsedBytes: Long,
    val availableDeviceBytes: Long,
    val fileCount: Int,
    val folderCount: Int,
    val liveFolderCount: Int,
    val estimatedRamBufferBytes: Long
)

class SpeedRepository(
    private val context: Context,
    private val dao: SpeedDao
) {
    private val blobsDir: File by lazy {
        File(context.filesDir, "speed_server_blobs").apply {
            if (!exists()) mkdirs()
        }
    }

    val allFolders: Flow<List<FolderEntity>> = dao.observeAllFolders()
    val allFiles: Flow<List<FileItemEntity>> = dao.observeAllFiles()

    suspend fun getAllFoldersSync(): List<FolderEntity> = dao.getAllFoldersSync()

    suspend fun getFolderByIdSync(id: String): FolderEntity? = dao.getFolderByIdSync(id)

    suspend fun getFilesByFolderSync(folderId: String): List<FileItemEntity> =
        dao.getFilesByFolderSync(folderId)

    suspend fun getFileByIdSync(id: String): FileItemEntity? = dao.getFileByIdSync(id)

    fun findLiveAncestor(folderId: String, folders: List<FolderEntity>): FolderEntity? {
        val byId = folders.associateBy { it.id }
        var current = byId[folderId]?.parentId?.let { byId[it] }
        val visited = mutableSetOf<String>()
        while (current != null && visited.add(current.id)) {
            if (current.live) return current
            current = current.parentId?.let { byId[it] }
        }
        return null
    }

    fun isEffectivelyLive(folderId: String, folders: List<FolderEntity>): Boolean {
        val byId = folders.associateBy { it.id }
        val folder = byId[folderId] ?: return false
        if (folder.live) return true
        return findLiveAncestor(folderId, folders) != null
    }

    fun isDescendantOf(candidateId: String, ancestorId: String, folders: List<FolderEntity>): Boolean {
        if (candidateId == ancestorId) return true
        val byId = folders.associateBy { it.id }
        var current = byId[candidateId]
        val visited = mutableSetOf<String>()
        while (current != null && visited.add(current.id)) {
            if (current.id == ancestorId) return true
            current = current.parentId?.let { byId[it] }
        }
        return false
    }

    suspend fun createFolder(
        rawName: String,
        parentId: String?,
        contentType: FolderContentType = FolderContentType.FILES
    ): FolderEntity = withContext(Dispatchers.IO) {
        val existingNames = dao.getAllFoldersSync()
            .filter { it.parentId == parentId }
            .map { it.name }
            .toSet()

        val uniqueName = resolveUniqueName(rawName.trim().ifEmpty { "New Folder" }, existingNames)
        val folder = FolderEntity(
            id = UUID.randomUUID().toString().replace("-", "").take(12),
            name = uniqueName,
            parentId = parentId,
            live = false,
            tags = "",
            contentType = contentType.key,
            createdAt = System.currentTimeMillis()
        )
        dao.insertFolder(folder)
        folder
    }

    suspend fun renameFolder(folderId: String, newRawName: String): FolderEntity? =
        withContext(Dispatchers.IO) {
            val all = dao.getAllFoldersSync()
            val target = all.firstOrNull { it.id == folderId } ?: return@withContext null
            val siblingNames = all
                .filter { it.parentId == target.parentId && it.id != folderId }
                .map { it.name }
                .toSet()
            val unique = resolveUniqueName(newRawName.trim().ifEmpty { target.name }, siblingNames)
            val updated = target.copy(name = unique)
            dao.updateFolder(updated)
            updated
        }

    suspend fun renameFile(fileId: String, newRawName: String): FileItemEntity? =
        withContext(Dispatchers.IO) {
            val target = dao.getFileByIdSync(fileId) ?: return@withContext null
            val siblings = dao.getFilesByFolderSync(target.folderId)
                .filter { it.id != fileId }
                .map { it.name }
                .toSet()
            val unique = resolveUniqueName(newRawName.trim().ifEmpty { target.name }, siblings)
            val updated = target.copy(name = unique)
            dao.updateFile(updated)
            updated
        }

    suspend fun updateFolderContentType(folderId: String, type: FolderContentType) =
        withContext(Dispatchers.IO) {
            val folder = dao.getFolderByIdSync(folderId) ?: return@withContext
            dao.updateFolder(folder.copy(contentType = type.key))
        }

    suspend fun updateTags(folderIds: Set<String>, rawTagInput: String) =
        withContext(Dispatchers.IO) {
            val parsed = parseTags(rawTagInput).joinToString(",")
            val all = dao.getAllFoldersSync()
            val toUpdate = all
                .filter { it.id in folderIds }
                .map { it.copy(tags = parsed) }
            if (toUpdate.isNotEmpty()) {
                dao.updateFolders(toUpdate)
            }
        }

    suspend fun toggleServerForFolders(folderIds: Set<String>): ToggleServerResult =
        withContext(Dispatchers.IO) {
            val all = dao.getAllFoldersSync()
            val selected = all.filter { it.id in folderIds }
            if (selected.isEmpty()) return@withContext ToggleServerResult.Updated(null, 0)

            for (folder in selected) {
                val liveAncestor = findLiveAncestor(folder.id, all)
                if (liveAncestor != null) {
                    return@withContext ToggleServerResult.BlockedByLiveAncestor(liveAncestor.name)
                }
            }

            // If any selected folder is currently offline, turn all selected ON; otherwise turn all OFF
            val targetLive = selected.any { !it.live }
            val updatedList = selected.map { it.copy(live = targetLive) }
            dao.updateFolders(updatedList)

            // If turning a parent ON, ensure children don't stay redundantly flagged as standalone live
            if (targetLive) {
                val allAfter = dao.getAllFoldersSync()
                val redundantChildren = allAfter.filter { candidate ->
                    candidate.live &&
                        candidate.id !in folderIds &&
                        selected.any { parent ->
                            parent.id != candidate.id && isDescendantOf(candidate.id, parent.id, allAfter)
                        }
                }.map { it.copy(live = false) }
                if (redundantChildren.isNotEmpty()) {
                    dao.updateFolders(redundantChildren)
                }
            }

            val finalLiveCount = dao.getAllFoldersSync().count { it.live }
            val firstTurnedLive = if (targetLive) selected.firstOrNull()?.id else null
            ToggleServerResult.Updated(firstTurnedLive, finalLiveCount)
        }

    suspend fun setFolderLive(folderId: String, live: Boolean): ToggleServerResult =
        withContext(Dispatchers.IO) {
            val all = dao.getAllFoldersSync()
            val target = all.firstOrNull { it.id == folderId }
                ?: return@withContext ToggleServerResult.Updated(null, all.count { it.live })
            val liveAncestor = findLiveAncestor(folderId, all)
            if (liveAncestor != null) {
                return@withContext ToggleServerResult.BlockedByLiveAncestor(liveAncestor.name)
            }
            dao.updateFolder(target.copy(live = live))
            val finalLiveCount = dao.getAllFoldersSync().count { it.live }
            ToggleServerResult.Updated(if (live) folderId else null, finalLiveCount)
        }

    suspend fun deleteFoldersRecursively(folderIds: Set<String>) = withContext(Dispatchers.IO) {
        if (folderIds.isEmpty()) return@withContext
        val allFolders = dao.getAllFoldersSync()
        val idsToDelete = mutableSetOf<String>()
        val queue = ArrayDeque(folderIds)
        while (queue.isNotEmpty()) {
            val current = queue.removeFirst()
            if (idsToDelete.add(current)) {
                allFolders.filter { it.parentId == current }.forEach { child ->
                    queue.addLast(child.id)
                }
            }
        }
        val idList = idsToDelete.toList()
        idList.forEach { fId ->
            dao.getFilesByFolderSync(fId).forEach { file ->
                runCatching { File(file.localPath).delete() }
            }
        }
        dao.deleteFilesByFolderIds(idList)
        dao.deleteFoldersByIds(idList)
    }

    suspend fun deleteFiles(fileIds: Set<String>) = withContext(Dispatchers.IO) {
        if (fileIds.isEmpty()) return@withContext
        fileIds.forEach { id ->
            dao.getFileByIdSync(id)?.let { file ->
                runCatching { File(file.localPath).delete() }
            }
        }
        dao.deleteFilesByIds(fileIds.toList())
    }

    suspend fun importFilesFromUris(folderId: String, uris: List<Uri>): List<FileItemEntity> =
        withContext(Dispatchers.IO) {
            if (uris.isEmpty()) return@withContext emptyList()
            val existingNames = dao.getFilesByFolderSync(folderId).map { it.name }.toMutableSet()
            val imported = mutableListOf<FileItemEntity>()
            val buffer = ByteArray(32 * 1024)

            for (uri in uris) {
                val rawName = queryDisplayName(uri) ?: "file_${System.currentTimeMillis()}"
                val uniqueName = resolveUniqueName(rawName, existingNames)
                existingNames.add(uniqueName)

                val fileId = UUID.randomUUID().toString().replace("-", "").take(14)
                val destFile = File(blobsDir, "${fileId}_${sanitizeFilename(uniqueName)}")
                var totalBytes = 0L

                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        while (true) {
                            val read = input.read(buffer)
                            if (read <= 0) break
                            output.write(buffer, 0, read)
                            totalBytes += read
                        }
                        output.flush()
                    }
                } ?: continue

                val mime = resolveMimeType(uri, uniqueName)
                val entity = FileItemEntity(
                    id = fileId,
                    folderId = folderId,
                    name = uniqueName,
                    mimeType = mime,
                    sizeBytes = totalBytes,
                    localPath = destFile.absolutePath,
                    createdAt = System.currentTimeMillis()
                )
                imported.add(entity)
            }

            if (imported.isNotEmpty()) {
                dao.insertFiles(imported)
            }
            imported
        }

    fun computeTelemetry(
        folders: List<FolderEntity>,
        files: List<FileItemEntity>
    ): StorageTelemetry {
        val usedBytes = files.sumOf { it.sizeBytes }
        val statFs = StatFs(context.filesDir.absolutePath)
        val availBytes = statFs.availableBytes
        // Estimate active RAM buffer (~32KB per chunk stream + lightweight metadata footprint)
        val estimatedRam = (folders.size * 512L) + (files.size * 1024L) + (64 * 1024L)
        return StorageTelemetry(
            storageUsedBytes = usedBytes,
            availableDeviceBytes = availBytes,
            fileCount = files.size,
            folderCount = folders.size,
            liveFolderCount = folders.count { it.live },
            estimatedRamBufferBytes = estimatedRam
        )
    }

    private fun queryDisplayName(uri: Uri): String? {
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) return cursor.getString(idx)
                    }
                }
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun resolveMimeType(uri: Uri, filename: String): String {
        val ext = filename.substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext == "html" || ext == "htm") return "text/html"
        if (ext == "css") return "text/css"
        if (ext == "js") return "application/javascript"
        if (ext == "json") return "application/json"
        if (ext == "svg") return "image/svg+xml"
        val resolverType = context.contentResolver.getType(uri)
        if (!resolverType.isNullOrBlank() && resolverType != "application/octet-stream") {
            return resolverType
        }
        return when (ext) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "webp" -> "image/webp"
            "gif" -> "image/gif"
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            "mov" -> "video/quicktime"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "ogg" -> "audio/ogg"
            "m4a" -> "audio/mp4"
            "pdf" -> "application/pdf"
            "txt", "md", "log" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    private fun sanitizeFilename(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(64)

    companion object {
        fun resolveUniqueName(desired: String, existing: Set<String>): String {
            if (desired !in existing) return desired
            val dotIdx = desired.lastIndexOf('.')
            val hasExt = dotIdx > 0 && dotIdx < desired.length - 1
            val base = if (hasExt) desired.substring(0, dotIdx) else desired
            val ext = if (hasExt) desired.substring(dotIdx) else ""
            var counter = 1
            while (true) {
                val candidate = "$base ($counter)$ext"
                if (candidate !in existing) return candidate
                counter++
            }
        }

        fun parseTags(input: String): List<String> =
            input.split(Regex("[,\\s]+"))
                .map { it.trim().removePrefix("#") }
                .filter { it.isNotEmpty() }
                .distinct()

        fun formatBytes(bytes: Long): String {
            if (bytes < 1024L) return "$bytes B"
            val kb = bytes / 1024.0
            if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
            val mb = kb / 1024.0
            if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
            val gb = mb / 1024.0
            return String.format(Locale.US, "%.2f GB", gb)
        }
    }
}
