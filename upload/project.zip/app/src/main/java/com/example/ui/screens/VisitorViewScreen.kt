package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.FileItemEntity
import com.example.data.repository.SpeedRepository
import com.example.ui.components.DualToneFolderIcon
import com.example.ui.components.FileThumbnailArtwork
import com.example.ui.components.IridescentBackdrop
import com.example.ui.components.glassSurface
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMint
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.VisitorUiState
import kotlin.math.roundToInt

@Composable
fun VisitorViewScreen(
    state: VisitorUiState,
    onBack: () -> Unit,
    onCloseVisitor: () -> Unit,
    onRefresh: () -> Unit,
    onOpenSubfolder: (String) -> Unit,
    onOpenFile: (FileItemEntity) -> Unit
) {
    BackHandler { onBack() }

    val pulseTransition = rememberInfiniteTransition(label = "visitorPulse")
    val pulseAlpha by pulseTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.35f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "visitorPulseAlpha"
    )

    IridescentBackdrop {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .glassSurface(shape = RoundedCornerShape(22.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("visitor_back")) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = state.folder?.name ?: "Speed Server Visitor",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val tags = state.folder?.tagList()?.joinToString(" ") { "#$it" }.orEmpty()
                        Text(
                            text = tags.ifEmpty { "Direct Peer Stream" },
                            fontSize = 11.sp,
                            color = NeonCyan,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(
                                if (state.isOnline) NeonEmerald.copy(alpha = 0.22f)
                                else NeonCoral.copy(alpha = 0.22f)
                            )
                            .border(
                                1.dp,
                                if (state.isOnline) NeonMint.copy(alpha = 0.5f) else NeonCoral.copy(alpha = 0.5f),
                                CircleShape
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .alpha(if (state.isOnline) pulseAlpha else 1f)
                                .clip(CircleShape)
                                .background(if (state.isOnline) NeonMint else NeonCoral)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = when {
                                state.isLoading -> "Connecting"
                                state.isOnline -> "Live"
                                else -> "Offline"
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.isOnline) NeonMint else NeonCoral
                        )
                    }
                    IconButton(onClick = onCloseVisitor, modifier = Modifier.testTag("visitor_close")) {
                        Icon(Icons.Rounded.Close, contentDescription = "Exit Visitor", tint = TextSecondary)
                    }
                }

                // Real-time chunk streaming progress bar
                if (state.streamingFileName != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 4.dp)
                            .glassSurface(shape = RoundedCornerShape(16.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Streaming ${state.streamingFileName}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "${(state.streamingProgress * 100f).roundToInt()}%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { state.streamingProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape),
                            color = NeonPink,
                            trackColor = Color.White.copy(alpha = 0.14f)
                        )
                    }
                }

                when {
                    state.isLoading -> {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = NeonCyan)
                                Spacer(Modifier.height(12.dp))
                                Text("Connecting to host phone...", color = TextSecondary, fontSize = 14.sp)
                            }
                        }
                    }

                    !state.isOnline || state.folder == null -> {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Column(
                                modifier = Modifier
                                    .padding(24.dp)
                                    .glassSurface(shape = RoundedCornerShape(24.dp))
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Rounded.WifiOff, contentDescription = null, tint = NeonCoral, modifier = Modifier.size(44.dp))
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    text = "Host Phone Is Currently Offline",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = state.errorMessage ?: "Ask the host to keep Speed Server live on their phone.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = TextSecondary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(Modifier.height(16.dp))
                                Button(
                                    onClick = onRefresh,
                                    shape = CircleShape,
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonViolet)
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Retry Connection")
                                }
                            }
                        }
                    }

                    else -> {
                        val htmlFiles = state.files.filter { it.isHtml }
                        val primaryHtml = htmlFiles.firstOrNull { it.name.equals("index.html", ignoreCase = true) }
                            ?: htmlFiles.firstOrNull()

                        if (primaryHtml != null) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(NeonPink.copy(alpha = 0.28f), NeonCyan.copy(alpha = 0.22f))
                                        )
                                    )
                                    .border(1.dp, GlassBorder, RoundedCornerShape(20.dp))
                                    .padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Direct Web App Execution",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "${primaryHtml.name} ready to run live",
                                        fontSize = 11.sp,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(Brush.horizontalGradient(listOf(NeonViolet, NeonPink, NeonAmber)))
                                        .clickable { onOpenFile(primaryHtml) }
                                        .padding(horizontal = 14.dp, vertical = 9.dp)
                                        .testTag("visitor_launch_app")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Rounded.RocketLaunch, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                        Spacer(Modifier.width(5.dp))
                                        Text("Launch App", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        LazyVerticalGrid(
                            columns = GridCells.Fixed(3),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentPadding = PaddingValues(14.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(state.subfolders, key = { "vsf_${it.id}" }) { sf ->
                                Column(
                                    modifier = Modifier
                                        .glassSurface(shape = RoundedCornerShape(18.dp))
                                        .clickable { onOpenSubfolder(sf.id) }
                                        .padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    DualToneFolderIcon(
                                        folderId = sf.id,
                                        modifier = Modifier
                                            .fillMaxWidth(0.75f)
                                            .aspectRatio(1.15f)
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = sf.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            items(state.files, key = { "vf_${it.id}" }) { file ->
                                Column(
                                    modifier = Modifier
                                        .glassSurface(shape = RoundedCornerShape(18.dp))
                                        .clickable { onOpenFile(file) }
                                        .padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    FileThumbnailArtwork(
                                        file = file,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .aspectRatio(1.1f)
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = file.name,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = SpeedRepository.formatBytes(file.sizeBytes),
                                        fontSize = 10.sp,
                                        color = TextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
