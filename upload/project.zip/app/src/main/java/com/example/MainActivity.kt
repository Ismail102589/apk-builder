package com.example

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.HostExplorerScreen
import com.example.ui.screens.LiveHtmlRunnerScreen
import com.example.ui.screens.MediaLightboxScreen
import com.example.ui.screens.VisitorViewScreen
import com.example.ui.theme.SpeedServerTheme
import com.example.viewmodel.SpeedServerViewModel

class MainActivity : ComponentActivity() {
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private fun requestKeepAlivePermissions() {
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            runCatching {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private val viewModel: SpeedServerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestKeepAlivePermissions()
        handleDeepLink(intent)

        setContent {
            SpeedServerTheme {
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()
                val visitorState by viewModel.visitorState.collectAsStateWithLifecycle()

                when {
                    uiState.activeHtmlFile != null -> {
                        val htmlItem = uiState.activeHtmlFile!!
                        LiveHtmlRunnerScreen(
                            fileItem = htmlItem,
                            onExportHtml = { viewModel.shareFileExternally(this@MainActivity, htmlItem) },
                            onClose = { viewModel.closeHtmlRunner() }
                        )
                    }

                    uiState.activeMediaFile != null -> {
                        val mediaItem = uiState.activeMediaFile!!
                        MediaLightboxScreen(
                            fileItem = mediaItem,
                            onExportFile = { viewModel.shareFileExternally(this@MainActivity, mediaItem) },
                            onClose = { viewModel.closeMediaLightbox() }
                        )
                    }

                    visitorState != null -> {
                        val vs = visitorState!!
                        VisitorViewScreen(
                            state = vs,
                            onBack = { viewModel.visitorNavigateBack() },
                            onCloseVisitor = { viewModel.closeVisitorMode() },
                            onRefresh = { viewModel.loadVisitorFolder(vs.currentFolderId, pushStack = false) },
                            onOpenSubfolder = { subId -> viewModel.loadVisitorFolder(subId, pushStack = true) },
                            onOpenFile = { file -> viewModel.openVisitorFile(file) }
                        )
                    }

                    else -> {
                        HostExplorerScreen(
                            uiState = uiState,
                            viewModel = viewModel
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleDeepLink(intent)
    }

    private fun handleDeepLink(intent: Intent?) {
        val data = intent?.dataString
        if (!data.isNullOrBlank() && (data.startsWith("speedserver://") || data.contains("share="))) {
            viewModel.openVisitorByLink(data)
        }
    }
}
