package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.FileItemEntity
import com.example.ui.theme.FolderHues
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import java.io.File
import kotlin.math.abs

fun deterministicFolderHue(folderId: String): Float {
    val hash = folderId.fold(0) { acc, c -> acc * 31 + c.code }
    val index = abs(hash) % FolderHues.size
    return FolderHues[index]
}

@Composable
fun DualToneFolderIcon(
    folderId: String,
    modifier: Modifier = Modifier
) {
    val hue = remember(folderId) { deterministicFolderHue(folderId) }
    val backStart = Color.hsl(hue, 0.85f, 0.48f)
    val backEnd = Color.hsl((hue + 24f) % 360f, 0.85f, 0.36f)
    val frontStart = Color.hsl(hue, 0.92f, 0.66f)
    val frontEnd = Color.hsl((hue + 18f) % 360f, 0.88f, 0.50f)

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Back tab + body
        val backPath = Path().apply {
            val r = w * 0.12f
            moveTo(0f, h * 0.22f)
            quadraticTo(0f, h * 0.10f, r, h * 0.10f)
            lineTo(w * 0.38f, h * 0.10f)
            lineTo(w * 0.48f, h * 0.22f)
            lineTo(w - r, h * 0.22f)
            quadraticTo(w, h * 0.22f, w, h * 0.34f)
            lineTo(w, h * 0.85f)
            quadraticTo(w, h * 0.95f, w - r, h * 0.95f)
            lineTo(r, h * 0.95f)
            quadraticTo(0f, h * 0.95f, 0f, h * 0.85f)
            close()
        }
        drawPath(
            path = backPath,
            brush = Brush.linearGradient(
                colors = listOf(backStart, backEnd),
                start = Offset.Zero,
                end = Offset(w, h)
            )
        )

        // Subtle inner paper peek
        drawRoundRect(
            color = Color.White.copy(alpha = 0.28f),
            topLeft = Offset(w * 0.09f, h * 0.26f),
            size = Size(w * 0.82f, h * 0.14f),
            cornerRadius = CornerRadius(w * 0.05f, w * 0.05f)
        )

        // Front luminous glass flap
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(frontStart, frontEnd),
                start = Offset(0f, h * 0.30f),
                end = Offset(w, h * 0.96f)
            ),
            topLeft = Offset(0f, h * 0.31f),
            size = Size(w, h * 0.64f),
            cornerRadius = CornerRadius(w * 0.13f, w * 0.13f)
        )

        // Crisp top specular highlight on front flap
        drawLine(
            color = Color.White.copy(alpha = 0.45f),
            start = Offset(w * 0.10f, h * 0.325f),
            end = Offset(w * 0.90f, h * 0.325f),
            strokeWidth = 2f
        )
    }
}

@Composable
fun FileThumbnailArtwork(
    file: FileItemEntity,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.07f)),
        contentAlignment = Alignment.Center
    ) {
        when {
            file.isImage && file.localPath.isNotBlank() -> {
                AsyncImage(
                    model = ImageRequest.Builder(context)
                        .data(File(file.localPath))
                        .crossfade(true)
                        .build(),
                    contentDescription = file.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            file.isVideo -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(NeonViolet.copy(alpha = 0.38f), NeonCyan.copy(alpha = 0.32f))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Video file",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
            file.isAudio -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(NeonAmber.copy(alpha = 0.34f), NeonPink.copy(alpha = 0.32f))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AudioFile,
                        contentDescription = "Audio file",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
            file.isHtml -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(NeonPink.copy(alpha = 0.36f), NeonViolet.copy(alpha = 0.38f))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Code,
                        contentDescription = "HTML web app",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(5.dp)
                            .clip(RoundedCornerShape(50))
                            .background(NeonPink)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "HTML",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            else -> {
                val ext = file.name.substringAfterLast('.', "FILE").uppercase().take(4)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.linearGradient(
                                listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.05f))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Description,
                        contentDescription = file.name,
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = ext,
                        color = NeonCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 5.dp)
                    )
                }
            }
        }
    }
}
