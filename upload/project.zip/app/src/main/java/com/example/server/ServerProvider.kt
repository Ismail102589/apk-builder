package com.example.server

import android.content.Context
import com.example.data.local.SpeedDatabase
import com.example.data.repository.SpeedRepository

/** Process-wide singletons so the server survives the Activity/ViewModel being destroyed. */
object ServerProvider {
    @Volatile private var repo: SpeedRepository? = null
    @Volatile private var srv: SpeedHttpServer? = null

    @Synchronized
    fun repository(context: Context): SpeedRepository {
        val app = context.applicationContext
        return repo ?: SpeedRepository(app, SpeedDatabase.getInstance(app).speedDao()).also { repo = it }
    }

    @Synchronized
    fun server(context: Context): SpeedHttpServer {
        return srv ?: SpeedHttpServer(repository(context)).also { srv = it }
    }
}
