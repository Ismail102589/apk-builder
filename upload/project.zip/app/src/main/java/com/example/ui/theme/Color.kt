package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepInk = Color(0xFF0D0820)
val DeepIndigoSurface = Color(0xFF171036)
val SheetGlassBg = Color(0xE028165C)

// 5-stop ambient radial mesh colors
val MeshPink = Color(0x9EFF4FA3)
val MeshCyan = Color(0x8022D3EE)
val MeshViolet = Color(0x9E8B5CF6)
val MeshAmber = Color(0x61FBBF24)
val MeshMint = Color(0x5C34D399)

// Frosted glass tokens
val GlassFill = Color(0x17FFFFFF)
val GlassFillElevated = Color(0x22FFFFFF)
val GlassBorder = Color(0x33FFFFFF)
val GlassHighlightTop = Color(0x38FFFFFF)

// Vibrant iridescent accents
val NeonPink = Color(0xFFFF4FA3)
val NeonCyan = Color(0xFF22D3EE)
val NeonViolet = Color(0xFF8B5CF6)
val NeonAmber = Color(0xFFFBBF24)
val NeonMint = Color(0xFF34D399)
val NeonEmerald = Color(0xFF10B981)
val NeonCoral = Color(0xFFFB7185)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)

// Deterministic hues matching spec: [330, 265, 195, 150, 40, 8]
val FolderHues = floatArrayOf(330f, 265f, 195f, 150f, 40f, 8f)
