package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DeepInk
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassFill
import com.example.ui.theme.GlassHighlightTop
import com.example.ui.theme.MeshAmber
import com.example.ui.theme.MeshCyan
import com.example.ui.theme.MeshMint
import com.example.ui.theme.MeshPink
import com.example.ui.theme.MeshViolet
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun IridescentBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val transition = rememberInfiniteTransition(label = "meshDrift")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 18_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "meshPhase"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepInk)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val dx1 = cos(phase) * w * 0.05f
            val dy1 = sin(phase) * h * 0.04f
            val dx2 = sin(phase * 0.8f) * w * 0.06f
            val dy2 = cos(phase * 0.7f) * h * 0.05f

            // Stop 1: Pink at (18%, 14%)
            val p1 = Offset(w * 0.18f + dx1, h * 0.14f + dy1)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(MeshPink, Color.Transparent),
                    center = p1,
                    radius = w * 0.72f
                ),
                center = p1,
                radius = w * 0.72f
            )

            // Stop 2: Cyan at (86%, 20%)
            val p2 = Offset(w * 0.86f - dx2, h * 0.20f + dy2)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(MeshCyan, Color.Transparent),
                    center = p2,
                    radius = w * 0.68f
                ),
                center = p2,
                radius = w * 0.68f
            )

            // Stop 3: Violet at (70%, 62%)
            val p3 = Offset(w * 0.70f + dx2, h * 0.62f - dy1)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(MeshViolet, Color.Transparent),
                    center = p3,
                    radius = w * 0.78f
                ),
                center = p3,
                radius = w * 0.78f
            )

            // Stop 4: Amber at (14%, 78%)
            val p4 = Offset(w * 0.14f - dx1, h * 0.78f + dy2)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(MeshAmber, Color.Transparent),
                    center = p4,
                    radius = w * 0.65f
                ),
                center = p4,
                radius = w * 0.65f
            )

            // Stop 5: Mint at (92%, 92%)
            val p5 = Offset(w * 0.92f + dx1, h * 0.92f - dy2)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(MeshMint, Color.Transparent),
                    center = p5,
                    radius = w * 0.62f
                ),
                center = p5,
                radius = w * 0.62f
            )
        }

        content()
    }
}

fun Modifier.glassSurface(
    shape: Shape = RoundedCornerShape(20.dp),
    fill: Color = GlassFill,
    borderColor: Color = GlassBorder,
    borderWidth: Dp = 1.dp
): Modifier = this
    .clip(shape)
    .background(fill, shape)
    .border(borderWidth, borderColor, shape)
    .drawWithContent {
        drawContent()
        // Subtle inner top highlight matching inset 0 1px 0 rgba(255,255,255,0.22)
        drawLine(
            color = GlassHighlightTop,
            start = Offset(16f, 1.5f),
            end = Offset(size.width - 16f, 1.5f),
            strokeWidth = 1.5f
        )
    }

@Composable
fun Modifier.tactilePressScale(interactionSource: MutableInteractionSource): Modifier {
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1f,
        animationSpec = spring(stiffness = 600f),
        label = "tactileScale"
    )
    return this.graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}
