package com.example.server

import android.util.Log
import com.jcraft.jsch.ChannelShell
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session

/**
 * Opens a public https URL for the local server using an SSH reverse tunnel (localhost.run).
 * Auto-reconnects. [onUrl] gets the public URL, or null while disconnected.
 */
class TunnelManager(private val onUrl: (String?) -> Unit) {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var session: Session? = null

    @Synchronized
    fun start(localPort: Int) {
        if (running) return
        running = true
        thread = Thread {
            while (running) {
                try {
                    runOnce(localPort)
                } catch (e: Exception) {
                    Log.w(TAG, "Tunnel error: ${e.message}")
                }
                onUrl(null)
                if (running) runCatching { Thread.sleep(5000) }
            }
        }.also {
            it.isDaemon = true
            it.name = "speed-tunnel"
            it.start()
        }
    }

    @Synchronized
    fun stop() {
        running = false
        runCatching { session?.disconnect() }
        session = null
        thread?.interrupt()
        thread = null
        onUrl(null)
    }

    private fun runOnce(localPort: Int) {
        val s = JSch().getSession("nokey", "localhost.run", 22)
        s.setConfig("StrictHostKeyChecking", "no")
        s.setServerAliveInterval(30_000)
        s.setServerAliveCountMax(3)
        s.connect(15_000)
        session = s
        s.setPortForwardingR(80, "127.0.0.1", localPort)

        val ch = s.openChannel("shell") as ChannelShell
        val reader = ch.inputStream.bufferedReader()
        ch.connect(10_000)

        val regex = Regex("https://[a-z0-9-]+\\.lhr\\.life")
        while (running) {
            val line = reader.readLine() ?: break
            regex.find(line)?.let {
                Log.i(TAG, "Public URL: ${it.value}")
                onUrl(it.value)
            }
        }
        runCatching { s.disconnect() }
    }

    private companion object {
        const val TAG = "TunnelManager"
    }
}
