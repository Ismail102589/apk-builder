package com.example.server

import android.util.Log
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Makes the local server reachable from the internet. Tries, in rotation:
 *  1) bore.pub (plain TCP tunnel -> http://bore.pub:PORT)
 *  2) localhost.run over SSH port 22  (-> https://xxx.lhr.life)
 *  3) localhost.run over SSH port 443
 * Auto-reconnects. [onUrl] gets the public URL (or null while disconnected),
 * [onStatus] gets a human-readable status / last error.
 */
class TunnelManager(
    private val onUrl: (String?) -> Unit,
    private val onStatus: (String) -> Unit
) {
    @Volatile private var running = false
    private var attempt = 0
    private var thread: Thread? = null
    private var session: Session? = null
    @Volatile private var control: Socket? = null

    /** true = https via localhost.run (SSH); false = http via bore.pub */
    @Volatile var https: Boolean = true
    @Volatile private var gen = 0

    @Synchronized
    fun start(localPort: Int) {
        if (running) return
        running = true
        val g = ++gen
        thread = Thread {
            while (running && gen == g) {
                // https mode: ssh:22 -> ssh:443 -> loca.lt (all give https links); http mode: bore
                val method = if (https) (attempt++ % 3) else 3
                val name = when (method) { 0 -> "ssh:22"; 1 -> "ssh:443"; 2 -> "loca.lt"; else -> "bore" }
                try {
                    onStatus("Connecting ($name)...")
                    when (method) {
                        0 -> runSsh(localPort, 22)
                        1 -> runSsh(localPort, 443)
                        2 -> runLocalTunnel(localPort)
                        else -> runBore(localPort)
                    }
                    if (gen == g) onStatus("$name disconnected")
                } catch (e: Exception) {
                    Log.w(TAG, "$name failed: ${e.message}")
                    if (gen == g) onStatus("$name failed: ${e.javaClass.simpleName}: ${e.message}")
                }
                if (gen == g) onUrl(null)
                if (running && gen == g) runCatching { Thread.sleep(2000) }
            }
        }.also {
            it.isDaemon = true
            it.name = "speed-tunnel"
            it.start()
        }
    }

    /** Switch mode and reconnect. */
    @Synchronized
    fun restart(localPort: Int, useHttps: Boolean) {
        https = useHttps
        attempt = 0
        stop()
        start(localPort)
    }

    @Synchronized
    fun stop() {
        running = false
        runCatching { session?.disconnect() }
        runCatching { control?.close() }
        session = null
        control = null
        thread?.interrupt()
        thread = null
        onUrl(null)
    }

    // ---------------- bore.pub ----------------
    private fun runBore(localPort: Int) {
        val ctrl = Socket()
        ctrl.connect(InetSocketAddress(BORE_HOST, BORE_PORT), 8_000)
        ctrl.soTimeout = 20_000
        control = ctrl
        val out = ctrl.getOutputStream()
        val inp = ctrl.getInputStream()
        sendMsg(out, "{\"Hello\":0}")

        while (running) {
            val msg = readMsg(inp) ?: break
            when {
                msg.startsWith("{\"Hello\"") -> {
                    val port = Regex("\\d+").find(msg)?.value
                        ?: throw IllegalStateException("bad hello: $msg")
                    val url = "http://$BORE_HOST:$port"
                    Log.i(TAG, "Public URL: $url")
                    onStatus("Online (bore)")
                    onUrl(url)
                }
                msg.contains("Heartbeat") -> { /* keep-alive */ }
                msg.startsWith("{\"Connection\"") -> {
                    val id = Regex("\"Connection\"\\s*:\\s*\"([^\"]+)\"").find(msg)?.groupValues?.get(1)
                    if (id != null) Thread { handleBoreConnection(id, localPort) }.start()
                }
                msg.startsWith("{\"Error\"") -> throw IllegalStateException(msg)
                msg.startsWith("{\"Challenge\"") -> throw IllegalStateException("server needs secret")
            }
        }
        runCatching { ctrl.close() }
    }

    private fun handleBoreConnection(id: String, localPort: Int) {
        var remote: Socket? = null
        var local: Socket? = null
        try {
            remote = Socket()
            remote.connect(InetSocketAddress(BORE_HOST, BORE_PORT), 8_000)
            sendMsg(remote.getOutputStream(), "{\"Accept\":\"$id\"}")
            local = Socket("127.0.0.1", localPort)
            val r = remote
            val l = local
            val t = Thread { pipe(r.getInputStream(), l.getOutputStream()); runCatching { l.close() } }
            t.start()
            pipe(l.getInputStream(), r.getOutputStream())
            runCatching { r.close() }
            t.join(2000)
        } catch (_: Exception) {
        } finally {
            runCatching { remote?.close() }
            runCatching { local?.close() }
        }
    }

    private fun pipe(src: InputStream, dst: java.io.OutputStream) {
        val buf = ByteArray(16 * 1024)
        try {
            while (true) {
                val n = src.read(buf)
                if (n < 0) break
                dst.write(buf, 0, n)
                dst.flush()
            }
        } catch (_: Exception) {
        }
    }

    private fun sendMsg(out: java.io.OutputStream, json: String) {
        out.write(json.toByteArray(Charsets.UTF_8))
        out.write(0)
        out.flush()
    }

    private fun readMsg(inp: InputStream): String? {
        val sb = java.io.ByteArrayOutputStream()
        while (true) {
            val b = inp.read()
            if (b < 0) return null
            if (b == 0) return sb.toString("UTF-8")
            sb.write(b)
        }
    }

    // ---------------- localtunnel (https://xxx.loca.lt) ----------------
    private fun runLocalTunnel(localPort: Int) {
        val conn = java.net.URL("https://localtunnel.me/?new").openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        val body = conn.inputStream.bufferedReader().readText()
        val port = Regex("\"port\"\\s*:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toInt()
            ?: throw IllegalStateException("bad reply: ${body.take(60)}")
        val url = Regex("\"url\"\\s*:\\s*\"([^\"]+)\"").find(body)?.groupValues?.get(1)?.replace("\\/", "/")
            ?: throw IllegalStateException("no url in reply")
        val max = (Regex("\"max_conn_count\"\\s*:\\s*(\\d+)").find(body)?.groupValues?.get(1)?.toInt() ?: 2)
            .coerceIn(1, 10)
        val host = conn.url.host
        onStatus("Online (loca.lt)")
        onUrl(url)

        val active = java.util.concurrent.atomic.AtomicInteger(0)
        val fails = java.util.concurrent.atomic.AtomicInteger(0)
        while (running) {
            if (active.get() < max) {
                active.incrementAndGet()
                Thread {
                    try {
                        val remote = Socket()
                        remote.connect(InetSocketAddress(host, port), 8_000)
                        fails.set(0)
                        serveLocalTunnelSocket(remote, localPort)
                    } catch (_: Exception) {
                        fails.incrementAndGet()
                    } finally {
                        active.decrementAndGet()
                    }
                }.start()
            }
            if (fails.get() > 6) throw IllegalStateException("loca.lt workers failing")
            Thread.sleep(400)
        }
    }

    private fun serveLocalTunnelSocket(remote: Socket, localPort: Int) {
        var local: Socket? = null
        try {
            val first = remote.getInputStream().read()
            if (first < 0) return
            local = Socket("127.0.0.1", localPort)
            val l = local
            l.getOutputStream().write(first)
            l.getOutputStream().flush()
            val t = Thread { pipe(l.getInputStream(), remote.getOutputStream()); runCatching { remote.close() } }
            t.start()
            pipe(remote.getInputStream(), l.getOutputStream())
            runCatching { l.close() }
            t.join(2000)
        } finally {
            runCatching { remote.close() }
            runCatching { local?.close() }
        }
    }

    // ---------------- localhost.run (SSH) ----------------
    private fun enableBouncyCastleAlgorithms() {
        // Android lacks Ed25519/X25519 in its JCE; use BouncyCastle implementations if present.
        val map = mapOf(
            "ssh-ed25519" to "com.jcraft.jsch.bc.SignatureEd25519",
            "keypairgen.eddsa" to "com.jcraft.jsch.bc.KeyPairGenEdDSA",
            "xdh" to "com.jcraft.jsch.bc.XDH",
            "keypairgen.xdh" to "com.jcraft.jsch.bc.KeyPairGenXDH"
        )
        for ((k, cls) in map) {
            runCatching {
                Class.forName(cls)
                JSch.setConfig(k, cls)
            }
        }
    }

    private fun runSsh(localPort: Int, sshPort: Int) {
        enableBouncyCastleAlgorithms()
        val s = JSch().getSession("nokey", "localhost.run", sshPort)
        s.setConfig("StrictHostKeyChecking", "no")
        s.setConfig("server_host_key", "ssh-ed25519,rsa-sha2-512,rsa-sha2-256,ssh-rsa,ecdsa-sha2-nistp256,ecdsa-sha2-nistp384,ecdsa-sha2-nistp521")
        s.setConfig("PreferredAuthentications", "none,keyboard-interactive,password,publickey")
        s.setServerAliveInterval(30_000)
        s.setServerAliveCountMax(3)
        s.connect(10_000)
        session = s
        s.setPortForwardingR(80, "127.0.0.1", localPort)

        // localhost.run prints the public address on the session channel. Use exec with
        // "--output json" (documented) and never block on the channel-request reply:
        // some servers answer late, which made ChannelShell.connect() time out.
        val ch = s.openChannel("exec") as ChannelExec
        ch.setCommand("--output json")
        ch.setPty(false)
        val reader = ch.inputStream.bufferedReader()
        s.setTimeout(0)
        Thread { runCatching { ch.connect() } }.also { it.isDaemon = true }.start()

        val gotUrl = java.util.concurrent.atomic.AtomicBoolean(false)
        Thread {
            runCatching { Thread.sleep(30_000) }
            if (!gotUrl.get()) runCatching { s.disconnect() }
        }.also { it.isDaemon = true }.start()

        val plain = Regex("https://[a-z0-9-]+\\.(lhr\\.life|localhost\\.run)")
        val addr = Regex("\"address\"\\s*:\\s*\"([^\"]+)\"")
        while (running) {
            val line = reader.readLine() ?: break
            Log.i(TAG, "ssh> $line")
            var url: String? = null
            if (line.contains("tcpip-forward")) {
                addr.find(line)?.groupValues?.get(1)?.let {
                    url = if (it.startsWith("http")) it else "https://$it"
                }
            }
            if (url == null) {
                plain.find(line)?.let { if (!it.value.contains("//admin.")) url = it.value }
            }
            url?.let {
                gotUrl.set(true)
                Log.i(TAG, "Public URL: $it")
                onStatus("Online (ssh)")
                onUrl(it)
            }
        }
        runCatching { s.disconnect() }
        if (!gotUrl.get()) throw IllegalStateException("no URL from localhost.run")
    }

    private companion object {
        const val TAG = "TunnelManager"
        const val BORE_HOST = "bore.pub"
        const val BORE_PORT = 7835
    }
}
