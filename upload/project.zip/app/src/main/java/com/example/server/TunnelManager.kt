package com.example.server

import android.util.Log
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Makes the local server reachable from the internet. Tries, in rotation:
 *  1) bore.pub (plain TCP tunnel -> http://bore.pub:PORT)
 *  2) pinggy / serveo over SSH (-> https links)
 * Auto-reconnects. [onUrl] gets the public URL (or null while disconnected),
 * [onStatus] gets a human-readable status / last error.
 */
class TunnelManager(
    private val onUrl: (String?) -> Unit,
    private val onStatus: (String) -> Unit
) {
    @Volatile private var running = false
    private var attempt = 0
    private var thread: Thread? = null
    private var session: Session? = null
    @Volatile private var control: Socket? = null

    /** true = https via localhost.run (SSH); false = http via bore.pub */
    @Volatile var https: Boolean = true
    @Volatile private var gen = 0

    @Synchronized
    fun start(localPort: Int) {
        if (running) return
        running = true
        val g = ++gen
        thread = Thread {
            while (running && gen == g) {
                // https mode rotates pinggy -> serveo (both give https links);
                // http mode uses bore.pub
                val method = if (https) (attempt++ % 2) else 2
                val name = when (method) { 0 -> "pinggy"; 1 -> "serveo"; else -> "bore" }
                try {
                    onStatus("Connecting ($name)...")
                    when (method) {
                        0 -> runSsh("a.pinggy.io", 443, "free", 0, localPort, false)
                        1 -> runSsh("serveo.net", 22, "serveo", 80, localPort, false)
                        else -> runBore(localPort)
                    }
                    if (gen == g) onStatus("$name disconnected")
                } catch (e: Exception) {
                    Log.w(TAG, "$name failed: ${e.message}")
                    if (gen == g) onStatus("$name failed: ${e.javaClass.simpleName}: ${e.message}")
                }
                if (gen == g) onUrl(null)
                if (running && gen == g) runCatching { Thread.sleep(2000) }
            }
        }.also {
            it.isDaemon = true
            it.name = "speed-tunnel"
            it.start()
        }
    }

    /** Switch mode and reconnect. */
    @Synchronized
    fun restart(localPort: Int, useHttps: Boolean) {
        https = useHttps
        attempt = 0
        stop()
        start(localPort)
    }

    @Synchronized
    fun stop() {
        running = false
        runCatching { session?.disconnect() }
        runCatching { control?.close() }
        session = null
        control = null
        thread?.interrupt()
        thread = null
        onUrl(null)
    }

    // ---------------- bore.pub ----------------
    private fun runBore(localPort: Int) {
        val ctrl = Socket()
        ctrl.connect(InetSocketAddress(BORE_HOST, BORE_PORT), 8_000)
        ctrl.soTimeout = 20_000
        control = ctrl
        val out = ctrl.getOutputStream()
        val inp = ctrl.getInputStream()
        sendMsg(out, "{\"Hello\":0}")

        while (running) {
            val msg = readMsg(inp) ?: break
            when {
                msg.startsWith("{\"Hello\"") -> {
                    val port = Regex("\\d+").find(msg)?.value
                        ?: throw IllegalStateException("bad hello: $msg")
                    val url = "http://$BORE_HOST:$port"
                    Log.i(TAG, "Public URL: $url")
                    onStatus("Online (bore)")
                    onUrl(url)
                }
                msg.contains("Heartbeat") -> { /* keep-alive */ }
                msg.startsWith("{\"Connection\"") -> {
                    val id = Regex("\"Connection\"\\s*:\\s*\"([^\"]+)\"").find(msg)?.groupValues?.get(1)
                    if (id != null) Thread { handleBoreConnection(id, localPort) }.start()
                }
                msg.startsWith("{\"Error\"") -> throw IllegalStateException(msg)
                msg.startsWith("{\"Challenge\"") -> throw IllegalStateException("server needs secret")
            }
        }
        runCatching { ctrl.close() }
    }

    private fun handleBoreConnection(id: String, localPort: Int) {
        var remote: Socket? = null
        var local: Socket? = null
        try {
            remote = Socket()
            remote.connect(InetSocketAddress(BORE_HOST, BORE_PORT), 8_000)
            sendMsg(remote.getOutputStream(), "{\"Accept\":\"$id\"}")
            local = Socket("127.0.0.1", localPort)
            val r = remote
            val l = local
            val t = Thread { pipe(r.getInputStream(), l.getOutputStream()); runCatching { l.close() } }
            t.start()
            pipe(l.getInputStream(), r.getOutputStream())
            runCatching { r.close() }
            t.join(2000)
        } catch (_: Exception) {
        } finally {
            runCatching { remote?.close() }
            runCatching { local?.close() }
        }
    }

    private fun pipe(src: InputStream, dst: java.io.OutputStream) {
        val buf = ByteArray(16 * 1024)
        try {
            while (true) {
                val n = src.read(buf)
                if (n < 0) break
                dst.write(buf, 0, n)
                dst.flush()
            }
        } catch (_: Exception) {
        }
    }

    private fun sendMsg(out: java.io.OutputStream, json: String) {
        out.write(json.toByteArray(Charsets.UTF_8))
        out.write(0)
        out.flush()
    }

    private fun readMsg(inp: InputStream): String? {
        val sb = java.io.ByteArrayOutputStream()
        while (true) {
            val b = inp.read()
            if (b < 0) return null
            if (b == 0) return sb.toString("UTF-8")
            sb.write(b)
        }
    }

    // ---------------- localhost.run (SSH) ----------------
    private fun enableBouncyCastleAlgorithms() {
        // Android lacks Ed25519/X25519 in its JCE; use BouncyCastle implementations if present.
        val map = mapOf(
            "ssh-ed25519" to "com.jcraft.jsch.bc.SignatureEd25519",
            "keypairgen.eddsa" to "com.jcraft.jsch.bc.KeyPairGenEdDSA",
            "xdh" to "com.jcraft.jsch.bc.XDH",
            "keypairgen.xdh" to "com.jcraft.jsch.bc.KeyPairGenXDH"
        )
        for ((k, cls) in map) {
            runCatching {
                Class.forName(cls)
                JSch.setConfig(k, cls)
            }
        }
    }

    private val ansi = Regex("\u001B\\[[;?0-9]*[A-Za-z]")
    private val anyUrl = Regex("https?://[A-Za-z0-9.-]+")
    private val badHosts = listOf("admin.", "docs.", "www.", "//localhost.run", "//pinggy.io", "//serveo.net")

    private fun runSsh(
        host: String,
        sshPort: Int,
        user: String,
        remotePort: Int,
        localPort: Int,
        tryJsonExec: Boolean
    ) {
        enableBouncyCastleAlgorithms()
        val s = JSch().getSession(user, host, sshPort)
        s.setConfig("StrictHostKeyChecking", "no")
        s.setConfig("server_host_key", "ssh-ed25519,rsa-sha2-512,rsa-sha2-256,ssh-rsa,ecdsa-sha2-nistp256,ecdsa-sha2-nistp384,ecdsa-sha2-nistp521")
        s.setConfig("PreferredAuthentications", "none,keyboard-interactive,password,publickey")
        s.setServerAliveInterval(30_000)
        s.setServerAliveCountMax(3)
        s.connect(12_000)
        session = s
        s.setTimeout(0)
        s.setPortForwardingR(remotePort, "127.0.0.1", localPort)

        val gotUrl = java.util.concurrent.atomic.AtomicBoolean(false)
        val raw = StringBuffer()
        val chanErr = StringBuffer()

        fun handle(lineIn: String) {
            val line = lineIn.replace(ansi, "").trim()
            if (line.isEmpty()) return
            if (raw.length < 400) raw.append(line.take(120)).append(" | ")
            Log.i(TAG, "ssh> $line")
            var url: String? = null
            if (line.contains("tcpip-forward")) {
                Regex("\"address\"\\s*:\\s*\"([^\"]+)\"").find(line)?.groupValues?.get(1)?.let {
                    url = if (it.startsWith("http")) it else "https://$it"
                }
            }
            if (url == null) {
                val found = anyUrl.findAll(line).map { it.value }
                    .filter { u -> badHosts.none { u.contains(it) } && !u.contains("localhost:") }
                    .toList()
                url = found.firstOrNull { it.startsWith("https") } ?: found.firstOrNull()
            }
            url?.let {
                if (gotUrl.compareAndSet(false, true) || true) {
                    Log.i(TAG, "Public URL: $it")
                    onStatus("Online")
                    onUrl(it)
                }
            }
        }

        fun pump(ins: InputStream?) {
            if (ins == null) return
            Thread {
                runCatching { ins.bufferedReader().forEachLine { handle(it) } }
            }.also { it.isDaemon = true }.start()
        }

        // Channel A: interactive shell with a PTY, exactly like `ssh -R ... host`.
        runCatching {
            val sh = s.openChannel("shell") as com.jcraft.jsch.ChannelShell
            sh.setPty(true)
            sh.setPtyType("xterm-256color")
            sh.setPtySize(120, 40, 0, 0)
            pump(sh.inputStream)
            pump(sh.extInputStream)
            Thread {
                runCatching { sh.connect(60_000) }.onFailure { chanErr.append("shell:${it.message} ") }
            }.also { it.isDaemon = true }.start()
        }.onFailure { chanErr.append("shell-open:${it.message} ") }

        // Channel B (localhost.run only): documented machine-readable output.
        if (tryJsonExec) {
            runCatching {
                val ex = s.openChannel("exec") as ChannelExec
                ex.setCommand("--output json")
                ex.setPty(false)
                pump(ex.inputStream)
                pump(ex.extInputStream)
                Thread {
                    runCatching { ex.connect(60_000) }.onFailure { chanErr.append("exec:${it.message} ") }
                }.also { it.isDaemon = true }.start()
            }.onFailure { chanErr.append("exec-open:${it.message} ") }
        }

        // Wait for a URL (max 45s), then stay connected until the session drops.
        val start = System.currentTimeMillis()
        while (running && s.isConnected) {
            if (!gotUrl.get() && System.currentTimeMillis() - start > 45_000) break
            Thread.sleep(300)
        }
        runCatching { s.disconnect() }
        if (!gotUrl.get()) {
            throw IllegalStateException("no URL. out=[${raw.toString().take(160)}] err=[${chanErr.toString().take(120)}]")
        }
    }

    private companion object {
        const val TAG = "TunnelManager"
        const val BORE_HOST = "bore.pub"
        const val BORE_PORT = 7835
    }
}
