package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val SpeedDarkColorScheme = darkColorScheme(
    primary = NeonViolet,
    onPrimary = Color.White,
    secondary = NeonCyan,
    onSecondary = DeepInk,
    tertiary = NeonPink,
    onTertiary = Color.White,
    background = DeepInk,
    onBackground = TextPrimary,
    surface = DeepIndigoSurface,
    onSurface = TextPrimary,
    surfaceVariant = Color(0xFF23184A),
    onSurfaceVariant = TextSecondary,
    error = NeonCoral,
    onError = Color.White,
    outline = GlassBorder
)

@Composable
fun SpeedServerTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = SpeedDarkColorScheme,
        typography = SpeedTypography,
        content = content
    )
}
