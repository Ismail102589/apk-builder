package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.FileItemEntity
import com.example.data.local.FilterMode
import com.example.data.local.FolderContentType
import com.example.data.local.FolderEntity
import com.example.data.local.SpeedDatabase
import com.example.data.repository.SpeedRepository
import com.example.data.repository.StorageTelemetry
import com.example.data.repository.ToggleServerResult
import com.example.server.PeerVisitorClient
import com.example.server.KeepAliveService
import com.example.server.ServerProvider
import com.example.server.SpeedHttpServer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import okhttp3.Call
import java.io.File
import java.util.UUID

data class FileViewerItem(
    val id: String,
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val localFile: File,
    val isHtml: Boolean,
    val isImage: Boolean,
    val isVideo: Boolean,
    val isAudio: Boolean
)

data class VisitorUiState(
    val baseUrl: String,
    val rootShareId: String,
    val currentFolderId: String,
    val stack: List<String> = emptyList(),
    val isLoading: Boolean = true,
    val isOnline: Boolean = false,
    val folder: FolderEntity? = null,
    val subfolders: List<FolderEntity> = emptyList(),
    val files: List<FileItemEntity> = emptyList(),
    val streamingFileName: String? = null,
    val streamingProgress: Float = 0f,
    val errorMessage: String? = null
)

data class ModalUiState(
    val currentFolderId: String? = null,
    val filterMode: FilterMode = FilterMode.ALL,
    val selectedFolderIds: Set<String> = emptySet(),
    val selectedFileIds: Set<String> = emptySet(),
    val showTelemetryModal: Boolean = false,
    val showFilterSheet: Boolean = false,
    val showNewFolderModal: Boolean = false,
    val showPeerConnectModal: Boolean = false,
    val renameFolder: FolderEntity? = null,
    val renameFile: FileItemEntity? = null,
    val tagsTargetFolderIds: Set<String>? = null,
    val confirmDeleteFolderIds: Set<String>? = null,
    val confirmDeleteFileIds: Set<String>? = null,
    val configSheetFolderId: String? = null,
    val sharePopupUrl: String? = null,
    val toastMessage: String? = null,
    val isUploading: Boolean = false,
    val activeHtmlFile: FileViewerItem? = null,
    val activeMediaFile: FileViewerItem? = null
)

data class HostScreenUiState(
    val currentFolderId: String? = null,
    val currentFolder: FolderEntity? = null,
    val breadcrumbs: List<FolderEntity> = emptyList(),
    val allFolders: List<FolderEntity> = emptyList(),
    val visibleSubfolders: List<FolderEntity> = emptyList(),
    val visibleFiles: List<FileItemEntity> = emptyList(),
    val filterMode: FilterMode = FilterMode.ALL,
    val selectedFolderIds: Set<String> = emptySet(),
    val selectedFileIds: Set<String> = emptySet(),
    val isSelectionMode: Boolean = false,
    val telemetry: StorageTelemetry = StorageTelemetry(0, 0, 0, 0, 0, 0),
    val isServerRunning: Boolean = false,
    val serverBaseUrl: String = "http://127.0.0.1:8080",
    val activePeers: Int = 0,
    val bytesUploaded: Long = 0L,
    val showTelemetryModal: Boolean = false,
    val showFilterSheet: Boolean = false,
    val showNewFolderModal: Boolean = false,
    val showPeerConnectModal: Boolean = false,
    val renameFolder: FolderEntity? = null,
    val renameFile: FileItemEntity? = null,
    val tagsTargetFolderIds: Set<String>? = null,
    val confirmDeleteFolderIds: Set<String>? = null,
    val confirmDeleteFileIds: Set<String>? = null,
    val configSheetFolder: FolderEntity? = null,
    val sharePopupUrl: String? = null,
    val toastMessage: String? = null,
    val isUploading: Boolean = false,
    val activeHtmlFile: FileViewerItem? = null,
    val activeMediaFile: FileViewerItem? = null
)

class SpeedServerViewModel(application: Application) : AndroidViewModel(application) {

    private val db = SpeedDatabase.getInstance(application)
    val repository = ServerProvider.repository(application)
    val server = ServerProvider.server(application)
    val visitorClient = PeerVisitorClient(application)

    private val modalState = MutableStateFlow(ModalUiState())
    private val _visitorState = MutableStateFlow<VisitorUiState?>(null)
    val visitorState: StateFlow<VisitorUiState?> = _visitorState

    private var activeSseCall: Call? = null
    private val visitorPeerId = "android-" + UUID.randomUUID().toString().take(8)

    private val serverMetricsFlow = combine(
        server.isRunning,
        server.localIp,
        server.port,
        server.activePeers,
        server.bytesUploaded
    ) { running, ip, port, peers, bytes ->
        ServerMetrics(running, "http://$ip:$port", peers, bytes)
    }

    private data class ServerMetrics(
        val running: Boolean,
        val baseUrl: String,
        val activePeers: Int,
        val bytesUploaded: Long
    )

    val uiState: StateFlow<HostScreenUiState> = combine(
        repository.allFolders,
        repository.allFiles,
        modalState,
        serverMetricsFlow
    ) { folders, files, modals, metrics ->
        val byId = folders.associateBy { it.id }
        val currentFolder = modals.currentFolderId?.let { byId[it] }

        // If current folder was deleted, return safely to root
        val effectiveFolderId = if (modals.currentFolderId != null && currentFolder == null) {
            null
        } else {
            modals.currentFolderId
        }

        val crumbs = buildList {
            var cursor = effectiveFolderId?.let { byId[it] }
            val seen = mutableSetOf<String>()
            while (cursor != null && seen.add(cursor.id)) {
                add(cursor)
                cursor = cursor.parentId?.let { byId[it] }
            }
        }.reversed()

        val rawSubfolders = folders.filter { it.parentId == effectiveFolderId }
        val rawFiles = if (effectiveFolderId == null) emptyList() else files.filter { it.folderId == effectiveFolderId }

        val visibleSubfolders = when (modals.filterMode) {
            FilterMode.ALL, FilterMode.FOLDERS -> rawSubfolders
            else -> emptyList()
        }
        val visibleFiles = when (modals.filterMode) {
            FilterMode.ALL -> rawFiles
            FilterMode.FOLDERS -> emptyList()
            FilterMode.PHOTOS -> rawFiles.filter { it.isImage }
            FilterMode.VIDEOS -> rawFiles.filter { it.isVideo }
            FilterMode.FILES_HTML -> rawFiles.filter { !it.isImage && !it.isVideo }
        }

        val selectionMode = modals.selectedFolderIds.isNotEmpty() || modals.selectedFileIds.isNotEmpty()
        val telemetry = repository.computeTelemetry(folders, files)

        HostScreenUiState(
            currentFolderId = effectiveFolderId,
            currentFolder = currentFolder,
            breadcrumbs = crumbs,
            allFolders = folders,
            visibleSubfolders = visibleSubfolders,
            visibleFiles = visibleFiles,
            filterMode = modals.filterMode,
            selectedFolderIds = modals.selectedFolderIds,
            selectedFileIds = modals.selectedFileIds,
            isSelectionMode = selectionMode,
            telemetry = telemetry,
            isServerRunning = metrics.running,
            serverBaseUrl = metrics.baseUrl,
            activePeers = metrics.activePeers,
            bytesUploaded = metrics.bytesUploaded,
            showTelemetryModal = modals.showTelemetryModal,
            showFilterSheet = modals.showFilterSheet,
            showNewFolderModal = modals.showNewFolderModal,
            showPeerConnectModal = modals.showPeerConnectModal,
            renameFolder = modals.renameFolder,
            renameFile = modals.renameFile,
            tagsTargetFolderIds = modals.tagsTargetFolderIds,
            confirmDeleteFolderIds = modals.confirmDeleteFolderIds,
            confirmDeleteFileIds = modals.confirmDeleteFileIds,
            configSheetFolder = modals.configSheetFolderId?.let { byId[it] },
            sharePopupUrl = modals.sharePopupUrl,
            toastMessage = modals.toastMessage,
            isUploading = modals.isUploading,
            activeHtmlFile = modals.activeHtmlFile,
            activeMediaFile = modals.activeMediaFile
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HostScreenUiState()
    )

    init {
        viewModelScope.launch {
            repository.allFolders.collect { folders ->
                syncServer(folders.any { it.live })
            }
        }
    }

    private fun syncServer(on: Boolean) {
        val ctx = getApplication<Application>()
        if (on) {
            server.ensureStarted()
            KeepAliveService.start(ctx)
        } else {
            server.stop()
            KeepAliveService.stop(ctx)
        }
    }

    fun getShareUrl(folderId: String): String = server.getShareUrl(folderId)

    fun isEffectivelyLive(folderId: String): Boolean {
        return repository.isEffectivelyLive(folderId, uiState.value.allFolders)
    }

    fun hasLiveAncestor(folderId: String): FolderEntity? {
        return repository.findLiveAncestor(folderId, uiState.value.allFolders)
    }

    fun navigateToFolder(folderId: String?) {
        modalState.update {
            it.copy(
                currentFolderId = folderId,
                selectedFolderIds = emptySet(),
                selectedFileIds = emptySet()
            )
        }
    }

    fun navigateUp(): Boolean {
        val current = uiState.value.currentFolder
        return if (current != null) {
            navigateToFolder(current.parentId)
            true
        } else {
            false
        }
    }

    fun toggleFolderSelection(folderId: String, triggerHaptic: Boolean = false) {
        if (triggerHaptic) vibratePulse()
        modalState.update { state ->
            val updated = if (folderId in state.selectedFolderIds) {
                state.selectedFolderIds - folderId
            } else {
                state.selectedFolderIds + folderId
            }
            state.copy(selectedFolderIds = updated)
        }
    }

    fun toggleFileSelection(fileId: String, triggerHaptic: Boolean = false) {
        if (triggerHaptic) vibratePulse()
        modalState.update { state ->
            val updated = if (fileId in state.selectedFileIds) {
                state.selectedFileIds - fileId
            } else {
                state.selectedFileIds + fileId
            }
            state.copy(selectedFileIds = updated)
        }
    }

    fun selectAllVisible() {
        val state = uiState.value
        val allVisibleFolders = state.visibleSubfolders.map { it.id }.toSet()
        val allVisibleFiles = state.visibleFiles.map { it.id }.toSet()
        val alreadyAll = state.selectedFolderIds == allVisibleFolders && state.selectedFileIds == allVisibleFiles
        modalState.update {
            if (alreadyAll) {
                it.copy(selectedFolderIds = emptySet(), selectedFileIds = emptySet())
            } else {
                it.copy(selectedFolderIds = allVisibleFolders, selectedFileIds = allVisibleFiles)
            }
        }
    }

    fun clearSelection() {
        modalState.update { it.copy(selectedFolderIds = emptySet(), selectedFileIds = emptySet()) }
    }

    fun setFilterMode(mode: FilterMode) {
        modalState.update { it.copy(filterMode = mode, showFilterSheet = false) }
    }

    fun openTelemetryModal(show: Boolean) = modalState.update { it.copy(showTelemetryModal = show) }
    fun openFilterSheet(show: Boolean) = modalState.update { it.copy(showFilterSheet = show) }
    fun openNewFolderModal(show: Boolean) = modalState.update { it.copy(showNewFolderModal = show) }
    fun openPeerConnectModal(show: Boolean) = modalState.update { it.copy(showPeerConnectModal = show) }
    fun openConfigSheet(folder: FolderEntity?) = modalState.update { it.copy(configSheetFolderId = folder?.id) }
    fun dismissSharePopup() = modalState.update { it.copy(sharePopupUrl = null) }
    fun clearToast() = modalState.update { it.copy(toastMessage = null) }

    fun createFolder(name: String) {
        val parentId = uiState.value.currentFolderId
        viewModelScope.launch {
            repository.createFolder(name, parentId)
            modalState.update { it.copy(showNewFolderModal = false) }
        }
    }

    fun requestRenameSelected() {
        val state = uiState.value
        when {
            state.selectedFolderIds.size == 1 && state.selectedFileIds.isEmpty() -> {
                val target = state.allFolders.firstOrNull { it.id == state.selectedFolderIds.first() }
                modalState.update { it.copy(renameFolder = target) }
            }
            state.selectedFileIds.size == 1 && state.selectedFolderIds.isEmpty() -> {
                val target = state.visibleFiles.firstOrNull { it.id == state.selectedFileIds.first() }
                modalState.update { it.copy(renameFile = target) }
            }
        }
    }

    fun openRenameFolder(folder: FolderEntity) = modalState.update { it.copy(renameFolder = folder) }
    fun dismissRename() = modalState.update { it.copy(renameFolder = null, renameFile = null) }

    fun confirmRenameFolder(folderId: String, newName: String) {
        viewModelScope.launch {
            repository.renameFolder(folderId, newName)
            modalState.update { it.copy(renameFolder = null, selectedFolderIds = emptySet()) }
        }
    }

    fun confirmRenameFile(fileId: String, newName: String) {
        viewModelScope.launch {
            repository.renameFile(fileId, newName)
            modalState.update { it.copy(renameFile = null, selectedFileIds = emptySet()) }
        }
    }

    fun openTagsForSelection() {
        val ids = uiState.value.selectedFolderIds
        if (ids.isNotEmpty()) {
            modalState.update { it.copy(tagsTargetFolderIds = ids) }
        }
    }

    fun openTagsForFolder(folder: FolderEntity) {
        modalState.update { it.copy(tagsTargetFolderIds = setOf(folder.id)) }
    }

    fun dismissTags() = modalState.update { it.copy(tagsTargetFolderIds = null) }

    fun saveTags(folderIds: Set<String>, rawTags: String) {
        viewModelScope.launch {
            repository.updateTags(folderIds, rawTags)
            modalState.update { it.copy(tagsTargetFolderIds = null, selectedFolderIds = emptySet()) }
        }
    }

    fun setFolderContentType(folderId: String, type: FolderContentType) {
        viewModelScope.launch {
            repository.updateFolderContentType(folderId, type)
        }
    }

    fun toggleServerForSelection() {
        val ids = uiState.value.selectedFolderIds
        if (ids.isEmpty()) return
        viewModelScope.launch {
            when (val res = repository.toggleServerForFolders(ids)) {
                is ToggleServerResult.BlockedByLiveAncestor -> {
                    modalState.update {
                        it.copy(toastMessage = "Inherited live status from parent \"${res.ancestorName}\"")
                    }
                }
                is ToggleServerResult.Updated -> {
                    syncServer(res.liveCount > 0)
                    val shareUrl = res.turnedLiveFolderId?.let { server.getShareUrl(it) }
                    modalState.update {
                        it.copy(
                            selectedFolderIds = emptySet(),
                            sharePopupUrl = shareUrl,
                            toastMessage = if (shareUrl != null) "Folder is now LIVE" else "Server turned OFF"
                        )
                    }
                }
            }
        }
    }

    fun setFolderLive(folderId: String, live: Boolean) {
        viewModelScope.launch {
            when (val res = repository.setFolderLive(folderId, live)) {
                is ToggleServerResult.BlockedByLiveAncestor -> {
                    modalState.update {
                        it.copy(toastMessage = "Inherited live status from parent \"${res.ancestorName}\"")
                    }
                }
                is ToggleServerResult.Updated -> {
                    syncServer(res.liveCount > 0)
                    val shareUrl = res.turnedLiveFolderId?.let { server.getShareUrl(it) }
                    modalState.update {
                        it.copy(
                            sharePopupUrl = shareUrl,
                            toastMessage = if (live) "Folder is now LIVE" else "Server turned OFF"
                        )
                    }
                }
            }
        }
    }

    fun requestDeleteSelection() {
        val state = uiState.value
        if (state.selectedFolderIds.isEmpty() && state.selectedFileIds.isEmpty()) return
        modalState.update {
            it.copy(
                confirmDeleteFolderIds = state.selectedFolderIds.takeIf { s -> s.isNotEmpty() },
                confirmDeleteFileIds = state.selectedFileIds.takeIf { s -> s.isNotEmpty() }
            )
        }
    }

    fun requestDeleteSingleFolder(folderId: String) {
        modalState.update { it.copy(confirmDeleteFolderIds = setOf(folderId), configSheetFolderId = null) }
    }

    fun dismissDeleteConfirmation() {
        modalState.update { it.copy(confirmDeleteFolderIds = null, confirmDeleteFileIds = null) }
    }

    fun executeConfirmedDelete() {
        val folderIds = modalState.value.confirmDeleteFolderIds.orEmpty()
        val fileIds = modalState.value.confirmDeleteFileIds.orEmpty()
        viewModelScope.launch {
            if (folderIds.isNotEmpty()) repository.deleteFoldersRecursively(folderIds)
            if (fileIds.isNotEmpty()) repository.deleteFiles(fileIds)
            modalState.update {
                it.copy(
                    confirmDeleteFolderIds = null,
                    confirmDeleteFileIds = null,
                    selectedFolderIds = emptySet(),
                    selectedFileIds = emptySet(),
                    toastMessage = "Deleted from device storage"
                )
            }
        }
    }

    fun importFiles(uris: List<Uri>) {
        val folderId = uiState.value.currentFolderId ?: return
        if (uris.isEmpty()) return
        viewModelScope.launch {
            modalState.update { it.copy(isUploading = true) }
            val imported = repository.importFilesFromUris(folderId, uris)
            modalState.update {
                it.copy(
                    isUploading = false,
                    toastMessage = if (imported.isNotEmpty()) {
                        "Stored ${imported.size} file${if (imported.size > 1) "s" else ""} on device"
                    } else {
                        "Could not read selected file(s)"
                    }
                )
            }
        }
    }

    fun openHostFile(file: FileItemEntity) {
        val diskFile = File(file.localPath)
        if (!diskFile.exists()) {
            modalState.update { it.copy(toastMessage = "File not found on device") }
            return
        }
        val viewerItem = FileViewerItem(
            id = file.id,
            name = file.name,
            mimeType = file.mimeType,
            sizeBytes = file.sizeBytes,
            localFile = diskFile,
            isHtml = file.isHtml,
            isImage = file.isImage,
            isVideo = file.isVideo,
            isAudio = file.isAudio
        )
        if (file.isHtml) {
            modalState.update { it.copy(activeHtmlFile = viewerItem) }
        } else {
            modalState.update { it.copy(activeMediaFile = viewerItem) }
        }
    }

    fun closeHtmlRunner() = modalState.update { it.copy(activeHtmlFile = null) }
    fun closeMediaLightbox() = modalState.update { it.copy(activeMediaFile = null) }

    fun shareFileExternally(context: Context, item: FileViewerItem) {
        runCatching {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                item.localFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = item.mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share ${item.name}"))
        }.onFailure {
            modalState.update { m -> m.copy(toastMessage = "Unable to export file") }
        }
    }

    fun shareUrlExternally(context: Context, url: String, title: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, url)
        }
        context.startActivity(Intent.createChooser(intent, "Share Speed Server Link"))
    }

    // --- Visitor Mode Actions ---

    fun openLocalFolderAsVisitor(folderId: String) {
        server.ensureStarted()
        val url = server.getShareUrl(folderId)
        openVisitorByLink(url)
    }

    fun openVisitorByLink(rawLink: String) {
        val parsed = visitorClient.parseLink(rawLink, server.getBaseUrl())
        if (parsed == null) {
            modalState.update { it.copy(toastMessage = "Invalid share URL or folder ID") }
            return
        }
        modalState.update { it.copy(showPeerConnectModal = false, showTelemetryModal = false, configSheetFolderId = null) }
        activeSseCall?.cancel()
        _visitorState.value = VisitorUiState(
            baseUrl = parsed.baseUrl,
            rootShareId = parsed.folderId,
            currentFolderId = parsed.folderId,
            isLoading = true
        )
        activeSseCall = visitorClient.connectSse(
            baseUrl = parsed.baseUrl,
            roomId = parsed.folderId,
            peerId = visitorPeerId
        ) { online, _ ->
            _visitorState.update { current ->
                current?.copy(isOnline = online)
            }
        }
        loadVisitorFolder(parsed.folderId, pushStack = false)
    }

    fun loadVisitorFolder(folderId: String, pushStack: Boolean) {
        val current = _visitorState.value ?: return
        val newStack = if (pushStack) current.stack + current.currentFolderId else current.stack
        _visitorState.value = current.copy(
            currentFolderId = folderId,
            stack = newStack,
            isLoading = true,
            errorMessage = null
        )
        viewModelScope.launch {
            val snap = visitorClient.fetchFolder(current.baseUrl, folderId)
            _visitorState.update { state ->
                state?.copy(
                    isLoading = false,
                    isOnline = snap.online,
                    folder = snap.folder,
                    subfolders = snap.subfolders,
                    files = snap.files,
                    errorMessage = snap.errorMessage
                )
            }
        }
    }

    fun visitorNavigateBack(): Boolean {
        val state = _visitorState.value ?: return false
        if (state.stack.isNotEmpty()) {
            val prev = state.stack.last()
            _visitorState.value = state.copy(stack = state.stack.dropLast(1))
            loadVisitorFolder(prev, pushStack = false)
            return true
        }
        closeVisitorMode()
        return true
    }

    fun closeVisitorMode() {
        activeSseCall?.cancel()
        activeSseCall = null
        _visitorState.value = null
    }

    fun openVisitorFile(file: FileItemEntity) {
        val state = _visitorState.value ?: return
        viewModelScope.launch {
            _visitorState.update { it?.copy(streamingFileName = file.name, streamingProgress = 0f) }
            val downloaded = visitorClient.streamFileToCache(
                baseUrl = state.baseUrl,
                shareRootId = state.rootShareId,
                file = file
            ) { progress ->
                _visitorState.update { it?.copy(streamingProgress = progress) }
            }
            _visitorState.update { it?.copy(streamingFileName = null, streamingProgress = 0f) }
            if (downloaded == null) {
                modalState.update { it.copy(toastMessage = "Failed to stream ${file.name}") }
                return@launch
            }
            val viewerItem = FileViewerItem(
                id = file.id,
                name = file.name,
                mimeType = file.mimeType,
                sizeBytes = file.sizeBytes,
                localFile = downloaded,
                isHtml = file.isHtml,
                isImage = file.isImage,
                isVideo = file.isVideo,
                isAudio = file.isAudio
            )
            if (file.isHtml) {
                modalState.update { it.copy(activeHtmlFile = viewerItem) }
            } else {
                modalState.update { it.copy(activeMediaFile = viewerItem) }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun vibratePulse() {
        val ctx = getApplication<Application>()
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    v?.vibrate(20)
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        activeSseCall?.cancel()
        // Server intentionally NOT stopped here: KeepAliveService keeps it alive.
    }
}
