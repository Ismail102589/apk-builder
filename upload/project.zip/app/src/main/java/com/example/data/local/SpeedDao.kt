package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SpeedDao {
    @Query("SELECT * FROM folders ORDER BY createdAt ASC")
    fun observeAllFolders(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM files ORDER BY createdAt DESC")
    fun observeAllFiles(): Flow<List<FileItemEntity>>

    @Query("SELECT * FROM folders")
    suspend fun getAllFoldersSync(): List<FolderEntity>

    @Query("SELECT * FROM folders WHERE id = :id LIMIT 1")
    suspend fun getFolderByIdSync(id: String): FolderEntity?

    @Query("SELECT * FROM files WHERE folderId = :folderId ORDER BY createdAt DESC")
    suspend fun getFilesByFolderSync(folderId: String): List<FileItemEntity>

    @Query("SELECT * FROM files WHERE id = :id LIMIT 1")
    suspend fun getFileByIdSync(id: String): FileItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: FolderEntity)

    @Update
    suspend fun updateFolder(folder: FolderEntity)

    @Update
    suspend fun updateFolders(folders: List<FolderEntity>)

    @Query("DELETE FROM folders WHERE id IN (:ids)")
    suspend fun deleteFoldersByIds(ids: List<String>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFiles(files: List<FileItemEntity>)

    @Update
    suspend fun updateFile(file: FileItemEntity)

    @Query("DELETE FROM files WHERE id IN (:ids)")
    suspend fun deleteFilesByIds(ids: List<String>)

    @Query("DELETE FROM files WHERE folderId IN (:folderIds)")
    suspend fun deleteFilesByFolderIds(folderIds: List<String>)
}
