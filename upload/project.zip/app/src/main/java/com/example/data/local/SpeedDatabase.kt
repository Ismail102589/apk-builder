package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [FolderEntity::class, FileItemEntity::class],
    version = 1,
    exportSchema = false
)
abstract class SpeedDatabase : RoomDatabase() {
    abstract fun speedDao(): SpeedDao

    companion object {
        @Volatile
        private var INSTANCE: SpeedDatabase? = null

        fun getInstance(context: Context): SpeedDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SpeedDatabase::class.java,
                    "speed_server_local.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
