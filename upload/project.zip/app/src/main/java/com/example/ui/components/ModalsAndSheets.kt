package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Label
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.OpenInBrowser
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.FilterMode
import com.example.data.local.FolderContentType
import com.example.data.local.FolderEntity
import com.example.data.repository.SpeedRepository
import com.example.data.repository.StorageTelemetry
import com.example.ui.theme.DeepInk
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCoral
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonMint
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.SheetGlassBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GlassTextInputDialog(
    title: String,
    subtitle: String? = null,
    initialValue: String = "",
    placeholder: String,
    confirmLabel: String,
    testTagPrefix: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember(initialValue) { mutableStateOf(initialValue) }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 460.dp)
                .glassSurface(
                    shape = RoundedCornerShape(24.dp),
                    fill = SheetGlassBg,
                    borderColor = GlassBorder
                )
                .padding(20.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text(placeholder, color = TextMuted) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("${testTagPrefix}_input"),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = GlassBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = NeonPink
                )
            )
            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("${testTagPrefix}_cancel")
                ) {
                    Text("Cancel", color = TextSecondary)
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = { onConfirm(text) },
                    modifier = Modifier.testTag("${testTagPrefix}_confirm"),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonViolet)
                ) {
                    Text(confirmLabel, color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun DeleteConfirmDialog(
    folderCount: Int,
    fileCount: Int,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 440.dp)
                .glassSurface(
                    shape = RoundedCornerShape(24.dp),
                    fill = SheetGlassBg,
                    borderColor = NeonCoral.copy(alpha = 0.45f)
                )
                .padding(20.dp)
        ) {
            Text(
                text = "Delete from Device?",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary
            )
            Spacer(Modifier.height(8.dp))
            val summary = buildList {
                if (folderCount > 0) add("$folderCount folder${if (folderCount > 1) "s" else ""} (including nested subfolders & files)")
                if (fileCount > 0) add("$fileCount file${if (fileCount > 1) "s" else ""}")
            }.joinToString(" and ")
            Text(
                text = "This will permanently erase $summary from your phone's local storage.",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(onClick = onDismiss, modifier = Modifier.testTag("delete_cancel")) {
                    Text("Cancel", color = TextSecondary)
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = onConfirm,
                    modifier = Modifier.testTag("delete_confirm"),
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCoral)
                ) {
                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DeviceTelemetryModal(
    telemetry: StorageTelemetry,
    isServerRunning: Boolean,
    serverBaseUrl: String,
    activePeers: Int,
    bytesUploaded: Long,
    onCopyBaseUrl: () -> Unit,
    onOpenPeerConnect: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 480.dp)
                .glassSurface(
                    shape = RoundedCornerShape(26.dp),
                    fill = SheetGlassBg,
                    borderColor = GlassBorder
                )
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Storage,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Device Server Telemetry",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.testTag("telemetry_close")) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(Modifier.height(10.dp))

            // Stat Grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TelemetryMetricTile(
                    label = "Phone Storage Used",
                    value = SpeedRepository.formatBytes(telemetry.storageUsedBytes),
                    accent = NeonPink,
                    modifier = Modifier.weight(1f)
                )
                TelemetryMetricTile(
                    label = "Files Stored",
                    value = "${telemetry.fileCount} (${telemetry.folderCount} dirs)",
                    accent = NeonCyan,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TelemetryMetricTile(
                    label = "RAM Buffer (Est.)",
                    value = SpeedRepository.formatBytes(telemetry.estimatedRamBufferBytes),
                    accent = NeonViolet,
                    modifier = Modifier.weight(1f)
                )
                TelemetryMetricTile(
                    label = "Active Peers",
                    value = "$activePeers online",
                    accent = NeonMint,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TelemetryMetricTile(
                    label = "Uploaded (Session)",
                    value = SpeedRepository.formatBytes(bytesUploaded),
                    accent = NeonAmber,
                    modifier = Modifier.weight(1f)
                )
                TelemetryMetricTile(
                    label = "Device Free Space",
                    value = SpeedRepository.formatBytes(telemetry.availableDeviceBytes),
                    accent = NeonEmerald,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(14.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassSurface(
                        shape = RoundedCornerShape(16.dp),
                        fill = Color.Black.copy(alpha = 0.25f)
                    )
                    .padding(12.dp)
            ) {
                Text(
                    text = if (isServerRunning) "LIVE HTTP & SSE ENDPOINT" else "HOST SERVER STANDBY",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isServerRunning) NeonMint else TextMuted
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isServerRunning) serverBaseUrl else "Toggle any folder LIVE to start",
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (isServerRunning) {
                        IconButton(onClick = onCopyBaseUrl, modifier = Modifier.testTag("copy_base_url")) {
                            Icon(Icons.Rounded.ContentCopy, contentDescription = "Copy URL", tint = NeonCyan, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onOpenPeerConnect,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("telemetry_connect_peer"),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.buttonColors(containerColor = NeonViolet)
            ) {
                Icon(Icons.Rounded.Link, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Connect to a Peer Link", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun TelemetryMetricTile(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .glassSurface(
                shape = RoundedCornerShape(16.dp),
                fill = Color.White.copy(alpha = 0.06f)
            )
            .padding(12.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = value,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterBottomSheet(
    currentFilter: FilterMode,
    onSelectFilter: (FilterMode) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SheetGlassBg,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Filter View",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary
            )
            Spacer(Modifier.height(12.dp))
            FilterMode.entries.forEach { mode ->
                val selected = mode == currentFilter
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (selected) NeonViolet.copy(alpha = 0.30f) else Color.Transparent)
                        .clickable { onSelectFilter(mode) }
                        .padding(horizontal = 14.dp, vertical = 14.dp)
                        .testTag("filter_${mode.name.lowercase()}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = mode.label,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        color = if (selected) Color.White else TextSecondary
                    )
                    if (selected) {
                        Icon(Icons.Rounded.Check, contentDescription = "Selected", tint = NeonCyan)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FolderConfigBottomSheet(
    folder: FolderEntity,
    isEffectivelyLive: Boolean,
    liveAncestorName: String?,
    shareUrl: String,
    onToggleLive: (Boolean) -> Unit,
    onCopyLink: () -> Unit,
    onShareLink: () -> Unit,
    onPreviewVisitor: () -> Unit,
    onContentTypeSelected: (FolderContentType) -> Unit,
    onRename: () -> Unit,
    onEditTags: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val selectedContentType = FolderContentType.fromKey(folder.contentType)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SheetGlassBg,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DualToneFolderIcon(
                    folderId = folder.id,
                    modifier = Modifier.size(44.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = folder.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = folder.tagList().joinToString(" ") { "#$it" }.ifEmpty { "No tags yet" },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Server Switch Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassSurface(shape = RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Live Peer Server",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = when {
                            liveAncestorName != null -> "Inherited live from \"$liveAncestorName\""
                            isEffectivelyLive -> "Serving directly from phone storage"
                            else -> "Private on-device folder (offline)"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (isEffectivelyLive) NeonMint else TextMuted
                    )
                }
                Switch(
                    checked = isEffectivelyLive,
                    onCheckedChange = { desired -> onToggleLive(desired) },
                    enabled = liveAncestorName == null,
                    modifier = Modifier.testTag("config_server_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = NeonEmerald,
                        uncheckedThumbColor = TextSecondary,
                        uncheckedTrackColor = Color.White.copy(alpha = 0.14f)
                    )
                )
            }

            // Copyable Live Share Link Box
            if (isEffectivelyLive) {
                Spacer(Modifier.height(12.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .glassSurface(
                            shape = RoundedCornerShape(16.dp),
                            fill = Color.Black.copy(alpha = 0.28f),
                            borderColor = NeonMint.copy(alpha = 0.35f)
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = "LIVE SHARE LINK",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonMint
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = shareUrl,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallPillAction(
                            icon = Icons.Rounded.ContentCopy,
                            label = "Copy",
                            onClick = onCopyLink,
                            modifier = Modifier.testTag("config_copy_link")
                        )
                        SmallPillAction(
                            icon = Icons.Rounded.Share,
                            label = "Share",
                            onClick = onShareLink,
                            modifier = Modifier.testTag("config_share_link")
                        )
                        SmallPillAction(
                            icon = Icons.Rounded.OpenInBrowser,
                            label = "Visitor View",
                            onClick = onPreviewVisitor,
                            modifier = Modifier.testTag("config_preview_visitor")
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text(
                text = "This folder holds",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )
            Spacer(Modifier.height(8.dp))

            // Segmented Selector: photos | videos | files
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .glassSurface(shape = RoundedCornerShape(14.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    Triple(FolderContentType.PHOTOS, "Photos", Icons.Rounded.PhotoLibrary),
                    Triple(FolderContentType.VIDEOS, "Videos", Icons.Rounded.Videocam),
                    Triple(FolderContentType.FILES, "Files", Icons.Rounded.InsertDriveFile)
                ).forEach { (type, label, icon) ->
                    val active = selectedContentType == type
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (active) Brush.horizontalGradient(listOf(NeonViolet, NeonPink))
                                else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                            .clickable { onContentTypeSelected(type) }
                            .padding(vertical = 10.dp)
                            .testTag("holds_${type.key}"),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (active) Color.White else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                            color = if (active) Color.White else TextSecondary
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = GlassBorder)
            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SheetActionTile(
                    icon = Icons.Rounded.DriveFileRenameOutline,
                    label = "Rename",
                    tint = TextPrimary,
                    onClick = onRename,
                    modifier = Modifier.weight(1f).testTag("config_rename")
                )
                SheetActionTile(
                    icon = Icons.Rounded.Label,
                    label = "Tags",
                    tint = NeonCyan,
                    onClick = onEditTags,
                    modifier = Modifier.weight(1f).testTag("config_tags")
                )
                SheetActionTile(
                    icon = Icons.Rounded.Delete,
                    label = "Delete",
                    tint = NeonCoral,
                    onClick = onDelete,
                    modifier = Modifier.weight(1f).testTag("config_delete")
                )
            }
        }
    }
}

@Composable
private fun SmallPillAction(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.14f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}

@Composable
private fun SheetActionTile(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = tint)
    }
}
