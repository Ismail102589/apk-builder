package com.ismail.zipapk

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

class Resp(val code: Int, val text: String) {
    val ok: Boolean get() = code in 200..299
    fun json(): JSONObject = JSONObject(text)
    fun arr(): JSONArray = JSONArray(text)
    fun msg(): String = try { JSONObject(text).optString("message", "HTTP $code") } catch (e: Exception) { "HTTP $code" }
}

class RunInfo(val id: Long, val sha: String, val event: String, val status: String, val conclusion: String, val url: String, val attempt: Int)

object Gh {
    fun repo(): String = "/repos/${Cfg.owner}/${Cfg.repo}"
    fun webUrl(path: String = ""): String = "https://github.com/${Cfg.owner}/${Cfg.repo}$path"

    private fun open(url: String, method: String, accept: String, auth: Boolean = true): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000; c.readTimeout = 40000
        c.useCaches = false; c.instanceFollowRedirects = false
        c.setRequestProperty("Accept", accept)
        c.setRequestProperty("User-Agent", "ZipToApk")
        if (auth && Cfg.token.isNotEmpty()) c.setRequestProperty("Authorization", "Bearer ${Cfg.token}")
        return c
    }
    private fun full(p: String): String = if (p.startsWith("http")) p else "https://api.github.com$p"

    fun call(method: String, path: String, body: String? = null, accept: String = "application/vnd.github+json"): Resp {
        var last: IOException? = null
        for (k in 0 until 6) {
            try {
                val c = open(full(path), method, accept)
                if (body != null) {
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.outputStream.use { it.write(body.toByteArray()) }
                }
                val code = c.responseCode
                val st = if (code >= 400) c.errorStream else c.inputStream
                val text = st?.bufferedReader()?.use { it.readText() } ?: ""
                c.disconnect()
                return Resp(code, text)
            } catch (e: IOException) { last = e; Thread.sleep(1500L * (k + 1)) }
        }
        throw last ?: IOException("network")
    }
    fun get(path: String): Resp = call("GET", path)

    fun download(path: String, dest: File, accept: String = "application/vnd.github+json", onProgress: (Int) -> Unit = {}) {
        var last: Exception? = null
        for (k in 0 until 4) {
            try {
                var c = open(full(path), "GET", accept)
                var code = c.responseCode
                var guard = 0
                while (code in 300..399 && guard++ < 4) {
                    val loc = c.getHeaderField("Location") ?: throw IOException("redirect")
                    c.disconnect()
                    c = open(loc, "GET", "*/*", auth = false)
                    code = c.responseCode
                }
                if (code !in 200..299) throw IOException("HTTP $code")
                val total = c.contentLengthLong
                c.inputStream.use { i ->
                    dest.outputStream().use { o ->
                        val buf = ByteArray(65536); var n: Int; var sum = 0L; var lp = -1
                        while (i.read(buf).also { n = it } > 0) {
                            o.write(buf, 0, n); sum += n
                            if (total > 0) { val p = (sum * 100 / total).toInt(); if (p != lp) { lp = p; onProgress(p) } }
                        }
                    }
                }
                c.disconnect()
                return
            } catch (e: Exception) { last = e; Thread.sleep(3000L * (k + 1)) }
        }
        throw IOException(last?.message ?: "download failed")
    }

    fun blobSha(f: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update("blob ${f.length()}\u0000".toByteArray())
        f.inputStream().use { i -> val b = ByteArray(65536); var n: Int; while (i.read(b).also { n = it } > 0) md.update(b, 0, n) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun toRun(o: JSONObject) = RunInfo(o.optLong("id"), o.str("head_sha"), o.str("event"), o.str("status"),
        o.str("conclusion"), o.str("html_url"), o.optInt("run_attempt", 1))

    fun runs(): List<RunInfo> {
        val r = get("${repo()}/actions/runs?per_page=30")
        if (!r.ok) throw IOException("রান তালিকা পাওয়া যায়নি (${r.code})")
        val a = r.json().optJSONArray("workflow_runs") ?: JSONArray()
        return (0 until a.length()).map { toRun(a.getJSONObject(it)) }
    }
    fun run(id: Long): RunInfo {
        val r = get("${repo()}/actions/runs/$id")
        if (!r.ok) throw IOException("রান পাওয়া যায়নি (${r.code})")
        return toRun(r.json())
    }
    fun dispatch(): Resp = call("POST", "${repo()}/actions/workflows/build.yml/dispatches", JSONObject().put("ref", "main").toString())
    fun jobLogText(jobId: Long): String {
        val f = File(Store.ctx.cacheDir, "joblog_$jobId.txt")
        download("${repo()}/actions/jobs/$jobId/logs", f)
        val t = f.readText(); f.delete(); return t
    }
}

object Logs {
    private val ts = Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z ")
    private val trans = Regex("Could not (resolve|GET|HEAD|download)|timed out|Timeout|Connection (reset|refused)|Premature end|Received status code 5|SSLHandshake|Remote host terminated|Network is unreachable|Temporary failure|503 Service|502 Bad Gateway|Unable to (download|resolve)", RegexOption.IGNORE_CASE)
    fun tail(t: String): String {
        val lines = t.lines().map { it.replace(ts, "") }
        var i = lines.indexOfFirst { it.contains("What went wrong") }
        if (i < 0) i = lines.indexOfFirst { it.contains("##[error]") }
        val s = if (i >= 0) maxOf(0, i - 3) else maxOf(0, lines.size - 40)
        return lines.subList(s, minOf(lines.size, s + 40)).joinToString("\n").take(5000)
    }
    fun transient(t: String): Boolean = trans.containsMatchIn(t)
    fun hint(t: String): String? = when {
        t.contains("E_NO_BASE") -> "এটা শুধু কয়েকটা ফাইলের প্যাচ, কিন্তু এই প্রজেক্টের পুরো কপি আগে বিল্ড করা নেই। আগে পুরো প্রজেক্ট ZIP একবার বিল্ড করুন।"
        t.contains("E_NOT_PROJECT") -> "ZIP-এ Android প্রজেক্ট বা সোর্স ফাইল পাওয়া যায়নি।"
        t.contains("Unsupported class file major version") -> "প্রজেক্টের Java ভার্সন আর বিল্ড মেশিনের Java মিলছে না। লগ দেখুন।"
        else -> null
    }
}
