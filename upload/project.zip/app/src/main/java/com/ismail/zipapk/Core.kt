package com.ismail.zipapk

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Resources
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

fun dp(v: Int): Int = (v * Resources.getSystem().displayMetrics.density + 0.5f).toInt()
fun dpf(v: Float): Float = v * Resources.getSystem().displayMetrics.density
fun dpf(v: Int): Float = v * Resources.getSystem().displayMetrics.density
fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

object Bg {
    val pool = Executors.newCachedThreadPool()
    val main = Handler(Looper.getMainLooper())
    fun run(f: () -> Unit) { pool.execute { try { f() } catch (e: Throwable) { android.util.Log.e("ZipToApk", "bg", e) } } }
    fun ui(f: () -> Unit) { main.post { f() } }
}

object Fmt {
    fun size(b: Long): String = when {
        b <= 0L -> "0 KB"
        b >= 1048576L -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> "${maxOf(1L, b / 1024)} KB"
    }
    fun dur(s: Long): String = "${s / 60}:${(s % 60).toString().padStart(2, '0')}"
    fun date(ms: Long): String = try { SimpleDateFormat("d MMM, h:mm a", Locale("bn", "BD")).format(Date(ms)) } catch (e: Exception) { "" }
    fun iso(s: String): Long = try {
        val f = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US); f.timeZone = java.util.TimeZone.getTimeZone("UTC"); f.parse(s)?.time ?: 0L
    } catch (e: Exception) { 0L }
}

class Palette(val a: Int, val b: Int, val c: Int, val bg: Int)
object Pal {
    val list = listOf(
        Palette(0xFF7C5CFF.toInt(), 0xFFFF4FA3.toInt(), 0xFF22E6D4.toInt(), 0xFF0A0620.toInt()),
        Palette(0xFFFF7A3D.toInt(), 0xFFFF3D81.toInt(), 0xFFFFD24A.toInt(), 0xFF190612.toInt()),
        Palette(0xFF1FB5FF.toInt(), 0xFF2DE2A6.toInt(), 0xFF6C7BFF.toInt(), 0xFF03111E.toInt()),
        Palette(0xFFFF6AD5.toInt(), 0xFF9B6BFF.toInt(), 0xFF6BE3FF.toInt(), 0xFF140A26.toInt()),
        Palette(0xFF18C76B.toInt(), 0xFFE6C84A.toInt(), 0xFF2DD4E6.toInt(), 0xFF041A10.toInt()),
        Palette(0xFFFF4D6D.toInt(), 0xFFC77DFF.toInt(), 0xFFFFD166.toInt(), 0xFF1C0612.toInt()))
    val names = listOf("অরোরা", "সানসেট", "সাগর", "ক্যান্ডি", "বন", "গোলাপ")
    var idx = 0
    val p: Palette get() = list[idx.coerceIn(0, list.size - 1)]
}

object Cfg {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("cfg", 0); Pal.idx = theme }
    private fun s(k: String, d: String): String = sp.getString(k, d) ?: d
    private fun ps(k: String, v: String) { sp.edit().putString(k, v).apply() }
    private fun b(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    private fun pb(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    var token: String
        get() = s("token", "")
        set(v) = ps("token", v.trim())
    var owner: String
        get() = s("owner", "Ismail102589")
        set(v) = ps("owner", v.trim())
    var repo: String
        get() = s("repo", "apk-builder")
        set(v) = ps("repo", v.trim())
    var wfv: String
        get() = s("wfv", "")
        set(v) = ps("wfv", v)
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply(); Pal.idx = v }
    var haptic: Boolean
        get() = b("haptic", true)
        set(v) = pb("haptic", v)
    var autoInstall: Boolean
        get() = b("autoInstall", true)
        set(v) = pb("autoInstall", v)
    var confetti: Boolean
        get() = b("confetti", true)
        set(v) = pb("confetti", v)
    var reduceMotion: Boolean
        get() = b("reduceMotion", false)
        set(v) = pb("reduceMotion", v)
    var keepScreen: Boolean
        get() = b("keepScreen", true)
        set(v) = pb("keepScreen", v)
    var notify: Boolean
        get() = b("notify", true)
        set(v) = pb("notify", v)
    var autoRetry: Boolean
        get() = b("autoRetry", true)
        set(v) = pb("autoRetry", v)
}

class Bld(val id: String) {
    var name = ""; var t = 0L; var s = "run"; var step = 0; var pct = 0.0; var label = ""
    var url = ""; var run = 0L; var art = 0L; var att = 0; var t2 = 0L; var dur = 0L
    var err = ""; var log = ""; var dlf = false; var retries = 0; var src = "build"
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name).put("t", t).put("s", s).put("step", step)
        .put("pct", pct).put("label", label).put("url", url).put("run", run).put("art", art).put("att", att)
        .put("t2", t2).put("dur", dur).put("err", err).put("log", log.take(3000)).put("dlf", dlf)
        .put("retries", retries).put("src", src)
    companion object {
        fun from(o: JSONObject): Bld {
            val b = Bld(o.optString("id"))
            b.name = o.optString("name"); b.t = o.optLong("t"); b.s = o.optString("s", "run"); b.step = o.optInt("step")
            b.pct = o.optDouble("pct", 0.0); b.label = o.optString("label"); b.url = o.optString("url")
            b.run = o.optLong("run"); b.art = o.optLong("art"); b.att = o.optInt("att"); b.t2 = o.optLong("t2")
            b.dur = o.optLong("dur"); b.err = o.optString("err"); b.log = o.optString("log")
            b.dlf = o.optBoolean("dlf"); b.retries = o.optInt("retries"); b.src = o.optString("src", "build")
            return b
        }
    }
}

object Store {
    lateinit var ctx: Context
    val builds = CopyOnWriteArrayList<Bld>()
    private var lastId = 0L
    @Synchronized fun newId(): String { var t = System.currentTimeMillis(); if (t <= lastId) t = lastId + 1; lastId = t; return t.toString() }
    fun init(c: Context) {
        if (::ctx.isInitialized) return
        ctx = c.applicationContext; Cfg.init(ctx); load()
    }
    private fun prefs(): SharedPreferences = ctx.getSharedPreferences("store", 0)
    @Synchronized fun load() {
        builds.clear()
        try {
            val a = JSONArray(prefs().getString("builds", "[]"))
            for (i in 0 until a.length()) builds.add(Bld.from(a.getJSONObject(i)))
        } catch (e: Exception) { }
    }
    @Synchronized fun save() {
        val a = JSONArray()
        builds.take(80).forEach { a.put(it.toJson()) }
        prefs().edit().putString("builds", a.toString()).apply()
    }
    fun find(id: String?): Bld? = builds.firstOrNull { it.id == id }
    val apkDir: File get() = File(ctx.filesDir, "apks").also { it.mkdirs() }
    fun apk(id: String): File = File(apkDir, id.filter { it.isDigit() } + ".apk")
    fun hasApk(id: String): Boolean = apk(id).exists()
    fun apkBytes(): Long = (apkDir.listFiles() ?: emptyArray<File>()).sumOf { it.length() }
    fun apkCount(): Int = (apkDir.listFiles() ?: emptyArray<File>()).count { it.name.endsWith(".apk") }
}

class ApkMeta(val label: String, val pkg: String, val ver: String, val icon: android.graphics.drawable.Drawable?)
object Apks {
    private val cache = HashMap<String, ApkMeta?>()
    fun forget(id: String) { synchronized(cache) { cache.remove(id) } }
    fun meta(id: String): ApkMeta? {
        synchronized(cache) { if (cache.containsKey(id)) return cache[id] }
        val m = load(id)
        synchronized(cache) { cache[id] = m }
        return m
    }
    private fun load(id: String): ApkMeta? {
        try {
            val pm = Store.ctx.packageManager
            val f = Store.apk(id)
            if (!f.exists()) return null
            val pi = pm.getPackageArchiveInfo(f.path, 0) ?: return null
            val ai = pi.applicationInfo ?: return null
            ai.sourceDir = f.path; ai.publicSourceDir = f.path
            return ApkMeta(ai.loadLabel(pm).toString(), pi.packageName ?: "", pi.versionName ?: "", ai.loadIcon(pm))
        } catch (e: Exception) { return null }
    }
}
