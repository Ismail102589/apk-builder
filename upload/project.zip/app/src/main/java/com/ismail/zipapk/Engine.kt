package com.ismail.zipapk

import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.zip.ZipInputStream

object Engine {
    const val WF_VER = "v5"
    val listeners = ArrayList<(Bld?, String) -> Unit>()
    private val uploadLock = Any()
    private val active = java.util.Collections.synchronizedSet(HashSet<String>())
    private fun runTracked(b: Bld, f: () -> Unit) {
        if (!active.add(b.id)) return
        Bg.run { try { f() } catch (e: Throwable) { fin(b, false, e.message ?: "অজানা সমস্যা") } finally { active.remove(b.id) } }
    }

    fun notify(b: Bld?, ev: String = "update") { Bg.ui { listeners.toList().forEach { it(b, ev) } } }
    fun running(): Int = Store.builds.count { it.s == "run" }
    private fun sync() { Bg.ui { if (running() > 0) BuildService.start(Store.ctx, running()) else BuildService.stop(Store.ctx) } }

    fun upd(b: Bld, step: Int, label: String, pct: Double) {
        b.step = step; b.label = label; b.pct = pct; Store.save(); notify(b)
    }

    fun fin(b: Bld, ok: Boolean, msg: String) {
        b.s = if (ok) "ok" else "fail"; b.err = msg
        if (ok) { b.dlf = false; b.step = 4; b.pct = 100.0 }
        b.label = if (ok) "রেডি!" else msg.lines().first()
        b.dur = (System.currentTimeMillis() - b.t) / 1000
        Store.save(); sync(); notify(b, if (ok) "ok" else "fail")
        Notifier.done(b, ok)
    }

    /** must be called on the main thread */
    fun start(file: File, name: String): Bld {
        val b = Bld(Store.newId())
        b.name = name; b.t = System.currentTimeMillis(); b.label = "শুরু হচ্ছে…"
        Store.builds.add(0, b); Store.save(); sync(); notify(b)
        runTracked(b) { try { work(b, file) } finally { file.delete() } }
        return b
    }

    private fun work(b: Bld, file: File) {
        upd(b, 0, "ZIP পড়া হচ্ছে…", 4.0)
        val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
        upd(b, 0, "আপলোড হচ্ছে…", 8.0)
        val prev = try { Gh.runs().maxOfOrNull { it.id } ?: 0L } catch (e: Exception) { 0L }
        val csha = upload(b.name, file, b64)
        upd(b, 1, "বিল্ডের সারিতে…", 22.0)
        var run: RunInfo? = null
        var disp = false
        if (csha == null) { Gh.dispatch(); disp = true }
        var i = 0; var fails = 0
        while (run == null && i < 110) {
            Thread.sleep(3000)
            try {
                val rs = Gh.runs(); fails = 0
                run = if (disp) rs.filter { it.id > prev && it.event == "workflow_dispatch" && Store.builds.none { x -> x.run == it.id } }.minByOrNull { it.id }
                      else rs.firstOrNull { it.sha == csha && it.event == "push" }
            } catch (e: Exception) { if (++fails > 20) throw IOException("ইন্টারনেট সমস্যা") }
            if (run == null && !disp && i >= 59) { Gh.dispatch(); disp = true }
            i++
        }
        if (run == null) throw IOException("বিল্ড শুরু হয়নি। রিপোর Actions ট্যাব দেখুন")
        b.run = run.id; b.url = run.url; b.t2 = System.currentTimeMillis(); Store.save()
        track(b)
    }

    private fun upload(name: String, f: File, b64: String): String? = synchronized(uploadLock) {
        try { ensureWorkflow(false) } catch (e: Exception) { }
        val local = Gh.blobSha(f)
        var last = ""
        for (k in 0 until 4) {
            val g = Gh.get("${Gh.repo()}/contents/upload/project.zip?ref=main")
            var sha: String? = null
            if (g.ok) sha = g.json().optString("sha")
            if (sha != null && sha == local) return@synchronized null
            val body = JSONObject().put("message", "build $name").put("content", b64).put("branch", "main")
            if (sha != null) body.put("sha", sha)
            val p = Gh.call("PUT", "${Gh.repo()}/contents/upload/project.zip", body.toString())
            if (p.ok) return@synchronized p.json().getJSONObject("commit").getString("sha")
            last = p.msg()
            if (p.code != 409 && p.code != 422) throw IOException("আপলোড ফেল: $last")
            Thread.sleep(2000)
        }
        throw IOException("আপলোড ফেল: $last")
    }

    fun ensureWorkflow(force: Boolean) {
        if (!force && Cfg.wfv == WF_VER) return
        val want = Store.ctx.assets.open("build.yml").bufferedReader().use { it.readText() }
        val g = Gh.get("${Gh.repo()}/contents/.github/workflows/build.yml?ref=main")
        var sha: String? = null
        var cur = ""
        if (g.ok) { val j = g.json(); sha = j.optString("sha"); cur = String(Base64.decode(j.optString("content"), Base64.DEFAULT)) }
        if (cur != want) {
            val body = JSONObject().put("message", "update build workflow")
                .put("content", Base64.encodeToString(want.toByteArray(), Base64.NO_WRAP)).put("branch", "main")
            if (sha != null) body.put("sha", sha)
            val p = Gh.call("PUT", "${Gh.repo()}/contents/.github/workflows/build.yml", body.toString())
            if (!p.ok) throw IOException(p.msg())
        }
        Cfg.wfv = WF_VER
    }

    fun track(b: Bld) {
        if (b.t2 == 0L) b.t2 = System.currentTimeMillis()
        var fails = 0
        while (true) {
            val r = try { Gh.run(b.run) } catch (e: Exception) {
                if (++fails > 40) throw IOException("ইন্টারনেট সমস্যা")
                Thread.sleep(4000); continue
            }
            fails = 0
            val el = (System.currentTimeMillis() - b.t2) / 1000
            if (r.status == "completed" && !(b.att > 0 && r.attempt <= b.att)) {
                b.att = r.attempt
                if (r.conclusion == "success") { finishOk(b); return }
                if (handleFailure(b)) continue
                return
            }
            upd(b, 2, "বিল্ড চলছে… ${Fmt.dur(el)}", 28 + 57 * (1 - Math.exp(-el / 90.0)))
            if (el > 2700) throw IOException("বিল্ড অনেক সময় নিচ্ছে, লগ দেখুন")
            Thread.sleep(4000)
        }
    }

    private fun finishOk(b: Bld) {
        val a = Gh.get("${Gh.repo()}/actions/runs/${b.run}/artifacts")
        val arr = if (a.ok) a.json().optJSONArray("artifacts") else null
        if (arr == null || arr.length() == 0) throw IOException("বিল্ড হয়েছে কিন্তু APK পাওয়া যায়নি")
        b.art = arr.getJSONObject(0).getLong("id"); Store.save()
        downloadApk(b)
    }

    fun downloadApk(b: Bld) {
        b.s = "run"; b.dlf = false; upd(b, 3, "APK নামছে…", 85.0); sync()
        try {
            fetchApk(b.art, b.id) { p -> b.pct = 85 + p * 0.13; b.label = "APK নামছে… $p%"; notify(b) }
            Apks.forget(b.id)
            fin(b, true, "")
        } catch (e: Exception) {
            b.dlf = true
            fin(b, false, "নেট সমস্যায় APK নামেনি। নেট এলে নিজেই আবার চেষ্টা করবে।")
        }
    }

    fun fetchApk(art: Long, id: String, onProgress: (Int) -> Unit) {
        val dir = Store.apkDir
        val digits = id.filter { it.isDigit() }
        val zip = File(dir, "$digits.zip")
        Gh.download("${Gh.repo()}/actions/artifacts/$art/zip", zip, onProgress = onProgress)
        var found = false
        ZipInputStream(zip.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null && !found) {
                if (e.name.endsWith(".apk")) { File(dir, "$digits.apk").outputStream().use { o -> z.copyTo(o) }; found = true }
                e = z.nextEntry
            }
        }
        zip.delete()
        if (!found) throw IOException("APK ZIP-এর ভেতরে নেই")
    }

    private fun handleFailure(b: Bld): Boolean {
        upd(b, 2, "কারণ খোঁজা হচ্ছে…", b.pct)
        var stepName = ""; var full = ""
        try {
            val j = Gh.get("${Gh.repo()}/actions/runs/${b.run}/jobs").json().optJSONArray("jobs")?.optJSONObject(0)
            if (j != null) {
                val steps = j.optJSONArray("steps")
                if (steps != null) for (i in 0 until steps.length()) {
                    val s = steps.getJSONObject(i)
                    if (s.str("conclusion") == "failure") { stepName = s.optString("name"); break }
                }
                full = Gh.jobLogText(j.optLong("id"))
            }
        } catch (e: Exception) { }
        b.log = Logs.tail(full)
        if (Cfg.autoRetry && b.retries < 2 && stepName != "Build debug APK" && Logs.transient(full) && Logs.hint(full) == null) {
            val rr = Gh.call("POST", "${Gh.repo()}/actions/runs/${b.run}/rerun-failed-jobs")
            if (rr.ok) {
                b.retries++; b.t2 = System.currentTimeMillis()
                upd(b, 2, "নেট সমস্যা, নিজে আবার চেষ্টা (${b.retries}/২)…", 30.0)
                return true
            }
        }
        val hint = Logs.hint(full)
        fin(b, false, hint ?: ("বিল্ড ফেল" + if (stepName.isNotEmpty()) ", ধাপ: $stepName" else ""))
        return false
    }

    fun rerun(b: Bld) {
        if (b.run == 0L) return
        runTracked(b) {
            val r = Gh.call("POST", "${Gh.repo()}/actions/runs/${b.run}/rerun")
            if (!r.ok) { Bg.ui { Toasts.show("ব্যর্থ: " + r.msg()) }; return@runTracked }
            b.s = "run"; b.err = ""; b.log = ""; b.retries = 0; b.dlf = false; b.t = System.currentTimeMillis(); b.t2 = b.t
            upd(b, 2, "আবার চালু হচ্ছে…", 30.0); sync()
            track(b)
        }
    }

    fun redownload(b: Bld) {
        if (b.art == 0L) return
        runTracked(b) { downloadApk(b) }
    }

    fun importArtifact(art: Long, name: String, created: Long): Bld {
        val b = Bld(Store.newId())
        b.name = name; b.t = System.currentTimeMillis(); b.art = art; b.src = "artifact"; b.label = "APK নামছে…"
        Store.builds.add(0, b); Store.save(); sync(); notify(b)
        runTracked(b) { downloadApk(b) }
        return b
    }

    fun resume() {
        Store.builds.filter { it.s == "run" }.forEach { b ->
            runTracked(b) {
                when {
                    b.run > 0 && Cfg.token.isNotEmpty() -> track(b)
                    b.art > 0 -> downloadApk(b)
                    else -> fin(b, false, "অ্যাপ বন্ধ হয়ে যাওয়ায় থেমে গেছে")
                }
            }
        }
        autoDl()
    }

    fun autoDl() {
        Store.builds.filter { it.s == "fail" && it.dlf && it.art > 0 && !Store.hasApk(it.id) }.forEach { redownload(it) }
    }
}
