package com.ismail.zipapk

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

object Notifier {
    private const val CH_DONE = "done"
    private const val CH_RUN = "run"
    private fun small(): Int {
        val id = Store.ctx.resources.getIdentifier("ic_stat", "drawable", Store.ctx.packageName)
        return if (id != 0) id else Store.ctx.applicationInfo.icon
    }
    private fun nm(): NotificationManager = Store.ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private fun channels() {
        if (Build.VERSION.SDK_INT >= 26) {
            nm().createNotificationChannel(NotificationChannel(CH_DONE, "বিল্ড শেষ", NotificationManager.IMPORTANCE_DEFAULT))
            nm().createNotificationChannel(NotificationChannel(CH_RUN, "বিল্ড চলছে", NotificationManager.IMPORTANCE_LOW))
        }
    }
    @Suppress("DEPRECATION")
    private fun builder(ch: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(Store.ctx, ch) else Notification.Builder(Store.ctx)
    private fun open(): PendingIntent {
        val i = Intent(Store.ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(Store.ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }
    fun ongoing(n: Int): Notification {
        channels()
        return builder(CH_RUN).setSmallIcon(small()).setContentTitle("ZIP → APK")
            .setContentText("$n টি বিল্ড চলছে…").setOngoing(true).setContentIntent(open()).build()
    }
    fun done(b: Bld, ok: Boolean) {
        if (!Cfg.notify) return
        if (Build.VERSION.SDK_INT >= 33 && Store.ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return
        try {
            channels()
            val n = builder(CH_DONE).setSmallIcon(small())
                .setContentTitle(if (ok) "APK তৈরি হয়েছে" else "বিল্ড ফেল হয়েছে").setContentText(b.name)
                .setAutoCancel(true).setContentIntent(open()).build()
            nm().notify(b.id.takeLast(6).toInt(), n)
        } catch (e: Exception) { }
    }
}

class BuildService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        Store.init(applicationContext)
        val n = i?.getIntExtra("n", 1) ?: 1
        try {
            val notif = Notifier.ongoing(n)
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(1, notif)
        } catch (e: Exception) { stopSelf() }
        return START_NOT_STICKY
    }
    companion object {
        fun start(c: Context, n: Int) {
            try {
                val i = Intent(c, BuildService::class.java).putExtra("n", n)
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
            } catch (e: Exception) { }
        }
        fun stop(c: Context) { try { c.stopService(Intent(c, BuildService::class.java)) } catch (e: Exception) { } }
    }
}

/** Minimal FileProvider: content://<pkg>.fp/apk/<name>  and  content://<pkg>.fp/share/<name> */
class FileProv : android.content.ContentProvider() {
    override fun onCreate(): Boolean = true
    private fun fileFor(u: Uri): File? {
        val seg = u.pathSegments
        if (seg.size < 2) return null
        val name = File(seg[1]).name
        return when (seg[0]) {
            "apk" -> File(File(context!!.filesDir, "apks"), name)
            "share" -> File(File(context!!.cacheDir, "share"), name)
            else -> null
        }
    }
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val f = fileFor(uri) ?: throw java.io.FileNotFoundException(uri.toString())
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun query(uri: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? {
        val f = fileFor(uri) ?: return null
        val c = MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE))
        c.addRow(arrayOf<Any>(f.name, f.length()))
        return c
    }
    override fun getType(uri: Uri): String? =
        if (uri.lastPathSegment?.endsWith(".apk") == true) "application/vnd.android.package-archive" else "application/octet-stream"
    override fun insert(uri: Uri, v: android.content.ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<out String>?): Int = 0
    override fun update(uri: Uri, v: android.content.ContentValues?, s: String?, a: Array<out String>?): Int = 0
    companion object {
        fun uriFor(c: Context, kind: String, f: File): Uri = Uri.parse("content://${c.packageName}.fp/$kind/${Uri.encode(f.name)}")
    }
}
