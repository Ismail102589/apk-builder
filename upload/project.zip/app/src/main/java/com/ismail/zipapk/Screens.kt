package com.ismail.zipapk

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.animation.ValueAnimator
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import kotlin.math.max

class ZipInfo(val count: Int, val gradle: Boolean, val wrapper: Boolean, val manifest: Boolean, val src: Int, val names: List<String>)
object ZipScan {
    fun scan(f: File): ZipInfo? {
        try {
            java.util.zip.ZipFile(f).use { z ->
                val names = ArrayList<String>(); var g = false; var w = false; var m = false; var s = 0
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement(); if (e.isDirectory) continue
                    names.add(e.name)
                    val base = e.name.substringAfterLast('/')
                    if (base.startsWith("settings.gradle")) g = true
                    if (base == "gradlew") w = true
                    if (base == "AndroidManifest.xml") m = true
                    if (base.endsWith(".kt") || base.endsWith(".java")) s++
                }
                return ZipInfo(names.size, g, w, m, s, names)
            }
        } catch (e: Exception) { return null }
    }
}
class Picked(val file: File, val name: String, val info: ZipInfo?)
class BState { var viewId: String? = null; val picked = ArrayList<Picked>() }

fun apkName(b: Bld): String = b.name.removeSuffix(".zip").removeSuffix(".ZIP") + ".apk"

fun page(c: Context): Pair<ScrollView, Col> {
    val sv = ScrollView(c)
    sv.isVerticalScrollBarEnabled = false; sv.clipToPadding = false; sv.overScrollMode = View.OVER_SCROLL_NEVER
    sv.setPadding(dp(14), dp(4), dp(14), dp(20))
    val col = Col(c, 620)
    sv.addView(col, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER_HORIZONTAL))
    return Pair(sv, col)
}
fun card(c: Context, pad: Int = 16): LinearLayout {
    val l = LinearLayout(c); l.orientation = LinearLayout.VERTICAL; l.background = glass(24); l.setPadding(dp(pad), dp(pad), dp(pad), dp(pad)); return l
}
fun pill(c: Context, text: String, kind: Int = 0): TextView {
    val t = tv(c, text, 11.5f)
    t.setPadding(dp(10), dp(5), dp(10), dp(5))
    val bgc = when (kind) { 1 -> withAlpha(0xFF22E6A0.toInt(), 0x44); 2 -> withAlpha(0xFFFF4D4D.toInt(), 0x55); else -> withAlpha(Color.WHITE, 0x26) }
    t.background = solid(bgc, 14); return t
}
fun title(c: Context, text: String): TextView { val t = tv(c, text, 13f, Color.WHITE, true, 0.65f); t.setPadding(dp(4), 0, 0, 0); return t }
fun iconBtn(c: Context, kind: Int, tint: Int = Color.WHITE, onClick: () -> Unit): FrameLayout {
    val f = FrameLayout(c)
    f.addView(IconView(c, kind, 20, tint), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
    f.background = glass(12, 0x22, 0x0A, 0x33)
    f.pressable(onClick)
    return f
}
fun emptyState(c: Context, icon: Int, text: String): LinearLayout {
    val l = LinearLayout(c); l.orientation = LinearLayout.VERTICAL; l.gravity = Gravity.CENTER; l.setPadding(dp(20), dp(44), dp(20), dp(44))
    l.addView(IconView(c, icon, 40, withAlpha(Color.WHITE, 0x99)), LinearLayout.LayoutParams(dp(40), dp(40)))
    val t = tv(c, text, 14f, Color.WHITE, false, 0.7f); t.gravity = Gravity.CENTER
    l.addView(t, lp(MATCH, WRAP, 0, 12, 0, 0)); l.enter(0); return l
}

class Bar(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var v = 0f
    fun set(x: Float) {
        val to = x.coerceIn(0f, 100f)
        if (Cfg.reduceMotion) { v = to; invalidate(); return }
        ValueAnimator.ofFloat(v, to).apply { duration = 500; addUpdateListener { v = it.animatedValue as Float; invalidate() }; start() }
    }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(MeasureSpec.getSize(w), dp(6)) }
    override fun onDraw(cv: Canvas) {
        p.shader = null; p.color = withAlpha(Color.WHITE, 0x26)
        val r = dpf(3)
        cv.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), r, r, p)
        p.shader = LinearGradient(0f, 0f, max(width, 1).toFloat(), 0f, Pal.p.c, Pal.p.b, Shader.TileMode.CLAMP)
        cv.drawRoundRect(RectF(0f, 0f, width * v / 100f, height.toFloat()), r, r, p)
    }
}

// ================================================================ BUILD
class BuildScreen(private val act: MainActivity, private val st: BState) {
    private val pg = page(act)
    val view: View = pg.first
    private val col = pg.second
    private var ring: Ring? = null
    private var status: TextView? = null
    private var dots: List<StepDot> = emptyList()
    private var shown = ""
    private val strip = HashMap<String, Pair<TextView, Bar>>()
    private val steps = listOf("আপলোড", "সারিতে", "বিল্ড", "ডাউনলোড", "রেডি")
    init { render() }

    fun render() {
        col.removeAllViews(); strip.clear(); ring = null; status = null
        val b = Store.find(st.viewId)
        if (b != null) detail(b) else picker()
    }

    private fun picker() {
        var d = 0L
        val running = Store.builds.filter { it.s == "run" }
        if (running.isNotEmpty()) {
            col.addView(title(act, "চলমান বিল্ড"), lp(MATCH, WRAP, 2, 4, 0, 8))
            running.forEach { b ->
                val c = card(act, 14)
                val top = LinearLayout(act); top.gravity = Gravity.CENTER_VERTICAL
                top.addView(IconView(act, I.BOLT, 20, Pal.p.c), LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(10) })
                val nm = tv(act, b.name, 15f, Color.WHITE, true); nm.maxLines = 1; nm.ellipsize = TextUtils.TruncateAt.END
                top.addView(nm, LinearLayout.LayoutParams(0, WRAP, 1f))
                c.addView(top, lp())
                val lb = tv(act, b.label, 12.5f, Color.WHITE, false, 0.75f)
                c.addView(lb, lp(MATCH, WRAP, 0, 6, 0, 8))
                val bar = Bar(act); bar.set(b.pct.toFloat()); c.addView(bar, lp())
                c.pressable { st.viewId = b.id; render() }
                strip[b.id] = Pair(lb, bar)
                col.addView(c, lp(MATCH, WRAP, 0, 0, 0, 10)); c.enter(d); d += 60
            }
        }
        val drop = card(act, 22); drop.gravity = Gravity.CENTER_HORIZONTAL
        drop.addView(BobIcon(act, I.ZIP, 46, Pal.p.c), LinearLayout.LayoutParams(dp(46), dp(46)))
        val t1 = tv(act, "ZIP ফাইল বাছুন", 18f, Color.WHITE, true); t1.gravity = Gravity.CENTER
        drop.addView(t1, lp(MATCH, WRAP, 0, 14, 0, 4))
        val t2 = tv(act, "একসাথে একাধিক ZIP বাছা যায়। ফাইল ম্যানেজার থেকে শেয়ার করলে বা ড্রপ করলেও আসবে।", 12.5f, Color.WHITE, false, 0.65f)
        t2.gravity = Gravity.CENTER; drop.addView(t2, lp())
        drop.pressable { act.pickZips() }
        col.addView(drop, lp(MATCH, WRAP, 0, 0, 0, 12)); drop.enter(d); d += 60

        st.picked.forEachIndexed { idx, pk ->
            val c = card(act, 14)
            val top = LinearLayout(act); top.gravity = Gravity.CENTER_VERTICAL
            top.addView(IconView(act, I.ZIP, 22, Pal.p.c), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(10) })
            val col2 = LinearLayout(act); col2.orientation = LinearLayout.VERTICAL
            val nm = tv(act, pk.name, 14.5f, Color.WHITE, true); nm.maxLines = 1; nm.ellipsize = TextUtils.TruncateAt.END
            col2.addView(nm); col2.addView(tv(act, Fmt.size(pk.file.length()), 12f, Color.WHITE, false, 0.6f))
            top.addView(col2, LinearLayout.LayoutParams(0, WRAP, 1f))
            top.addView(iconBtn(act, I.CROSS) { st.picked.removeAt(idx); render() }, LinearLayout.LayoutParams(dp(36), dp(36)))
            c.addView(top, lp())
            val z = pk.info
            if (z != null) {
                val fl = Flow(act); fl.setPadding(0, dp(10), 0, 0)
                fl.addView(pill(act, "${z.count}টি ফাইল"))
                fl.addView(pill(act, if (z.gradle) "settings.gradle আছে" else "settings.gradle নেই", if (z.gradle) 1 else 2))
                fl.addView(pill(act, if (z.manifest) "AndroidManifest আছে" else "AndroidManifest নেই", if (z.manifest) 1 else 2))
                fl.addView(pill(act, if (z.wrapper) "gradlew আছে" else "gradlew নেই"))
                c.addView(fl, lp())
                if (!z.gradle) {
                    val w = tv(act, "পুরো প্রজেক্ট নয়। আগে জমানো একই প্যাকেজের প্রজেক্টের ওপর প্যাচ হিসেবে বসানো হবে।", 12f, 0xFFFFB4B4.toInt())
                    c.addView(w, lp(MATCH, WRAP, 0, 8, 0, 0))
                }
                c.pressable { fileList(pk) }
            }
            col.addView(c, lp(MATCH, WRAP, 0, 0, 0, 10)); c.enter(d); d += 60
        }
        val go = GButton(act, "APK বানান" + if (st.picked.isNotEmpty()) " (${st.picked.size})" else "", I.BOLT)
        go.isEnabled = st.picked.isNotEmpty()
        go.onTap { startAll() }
        col.addView(go, lp(MATCH, WRAP, 0, 4, 0, 10)); go.enter(d)
    }

    fun startAll() {
        if (st.picked.isEmpty()) return
        if (Cfg.token.isEmpty()) { act.toast("আগে সেটিংসে GitHub টোকেন বসান"); act.goTab(3); return }
        act.askNotif()
        var first: Bld? = null
        st.picked.toList().forEach { pk ->
            val tmp = File(Store.ctx.cacheDir, "run_" + System.nanoTime() + ".zip")
            try { pk.file.copyTo(tmp, true) } catch (e: Exception) { return@forEach }
            pk.file.delete()
            val b = Engine.start(tmp, pk.name)
            if (first == null) first = b
        }
        st.picked.clear()
        st.viewId = first?.id
        render()
    }

    private fun fileList(pk: Picked) {
        val z = pk.info ?: return
        Sheet(act).show(pk.name) { box, _ ->
            val sv = ScrollView(act)
            val l = LinearLayout(act); l.orientation = LinearLayout.VERTICAL
            val shown = z.names.take(150)
            shown.forEach { n -> val t = tv(act, n, 12f, Color.WHITE, false, 0.85f); t.typeface = Typeface.MONOSPACE; t.setPadding(0, dp(3), 0, dp(3)); l.addView(t) }
            if (z.names.size > shown.size) l.addView(tv(act, "… আরও ${z.names.size - shown.size}টি", 12f, Color.WHITE, false, 0.6f))
            sv.addView(l)
            box.addView(sv, lp(MATCH, dp(320)))
        }
    }

    private fun detail(b: Bld) {
        shown = b.s
        val back = LinearLayout(act); back.gravity = Gravity.CENTER_VERTICAL
        back.addView(IconView(act, I.BACK, 20), LinearLayout.LayoutParams(dp(20), dp(20)))
        back.addView(tv(act, "সব বিল্ড", 14f, Color.WHITE, true, 0.85f), lp(WRAP, WRAP, 6, 0, 0, 0))
        back.setPadding(dp(4), dp(8), dp(12), dp(8))
        back.pressable { st.viewId = null; render() }
        col.addView(back, lp(WRAP, WRAP, 0, 0, 0, 4))
        val nm = tv(act, b.name, 19f, Color.WHITE, true); nm.maxLines = 2; nm.ellipsize = TextUtils.TruncateAt.END
        col.addView(nm, lp(MATCH, WRAP, 4, 0, 4, 12))

        val pc = card(act, 18); pc.gravity = Gravity.CENTER_HORIZONTAL
        val r = Ring(act); ring = r
        pc.addView(r, LinearLayout.LayoutParams(dp(180), dp(180)))
        val s = tv(act, b.label, 15f, Color.WHITE, true); s.gravity = Gravity.CENTER; status = s
        pc.addView(s, lp(MATCH, WRAP, 0, 6, 0, 14))
        val ds = ArrayList<StepDot>()
        steps.forEachIndexed { i, name ->
            val row = LinearLayout(act); row.gravity = Gravity.CENTER_VERTICAL
            val d = StepDot(act); ds.add(d)
            row.addView(d, LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(14) })
            row.addView(tv(act, name, 15f, Color.WHITE, i == b.step && b.s == "run"))
            pc.addView(row, lp(MATCH, WRAP, 6, 4, 0, 4))
        }
        dots = ds
        col.addView(pc, lp(MATCH, WRAP, 0, 0, 0, 12)); pc.enter(0)
        update(b)

        if (b.s != "run") {
            val rc = card(act, 16)
            if (b.s == "ok") okCard(rc, b) else failCard(rc, b)
            col.addView(rc, lp(MATCH, WRAP, 0, 0, 0, 12)); rc.enter(80)
        }
        val nw = GButton(act, "নতুন অ্যাপ বানান", I.PLUS, b.s != "run")
        nw.onTap { st.viewId = null; render() }
        col.addView(nw, lp(MATCH, WRAP, 0, 4, 0, 10))
    }

    private fun okCard(rc: LinearLayout, b: Bld) {
        val has = Store.hasApk(b.id)
        val meta = if (has) Apks.meta(b.id) else null
        val top = LinearLayout(act); top.gravity = Gravity.CENTER_VERTICAL
        if (meta?.icon != null) {
            val iv = ImageView(act); iv.setImageDrawable(meta.icon); iv.scaleType = ImageView.ScaleType.FIT_CENTER
            top.addView(iv, LinearLayout.LayoutParams(dp(52), dp(52)).apply { rightMargin = dp(14) })
        } else top.addView(IconView(act, I.CUBE, 34, Pal.p.c), LinearLayout.LayoutParams(dp(34), dp(34)).apply { rightMargin = dp(14) })
        val c2 = LinearLayout(act); c2.orientation = LinearLayout.VERTICAL
        c2.addView(tv(act, meta?.label ?: b.name, 16f, Color.WHITE, true))
        val sub = if (meta != null) "${meta.pkg} · v${meta.ver} · ${Fmt.size(Store.apk(b.id).length())}" else "APK আর ফোনে নেই"
        c2.addView(tv(act, sub, 12f, Color.WHITE, false, 0.65f))
        top.addView(c2, LinearLayout.LayoutParams(0, WRAP, 1f))
        rc.addView(top, lp(MATCH, WRAP, 0, 0, 0, 14))
        if (has) {
            val inst = GButton(act, "ইনস্টল করুন", I.PHONE); inst.onTap { act.installApk(b.id) }
            rc.addView(inst, lp(MATCH, WRAP, 0, 0, 0, 10))
            val row = LinearLayout(act)
            val sh = GButton(act, "শেয়ার", I.SHARE, false); sh.onTap { act.shareApk(b.id, apkName(b)) }
            val sv = GButton(act, "সেভ", I.SAVE, false); sv.onTap { act.saveApk(b.id, apkName(b)) }
            row.addView(sh, lp(0, WRAP, 0, 0, 5, 0).also { it.weight = 1f }); row.addView(sv, lp(0, WRAP, 5, 0, 0, 0).also { it.weight = 1f })
            rc.addView(row, lp())
        } else if (b.art > 0) {
            val dl = GButton(act, "আবার ডাউনলোড", I.DOWN); dl.onTap { Engine.redownload(b) }
            rc.addView(dl, lp())
        }
        if (b.url.isNotEmpty()) {
            val g = GButton(act, "GitHub-এ দেখুন", I.EXT, false); g.onTap { act.openUrl(b.url) }
            rc.addView(g, lp(MATCH, WRAP, 0, 10, 0, 0))
        }
    }

    private fun failCard(rc: LinearLayout, b: Bld) {
        val top = LinearLayout(act); top.gravity = Gravity.CENTER_VERTICAL
        top.addView(IconView(act, I.WARN, 26, 0xFFFF8A8A.toInt()), LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(12) })
        top.addView(tv(act, b.err.ifEmpty { "বিল্ড ফেল হয়েছে" }, 14.5f, 0xFFFFB4B4.toInt(), true), LinearLayout.LayoutParams(0, WRAP, 1f))
        rc.addView(top, lp(MATCH, WRAP, 0, 0, 0, 12))
        if (b.log.isNotEmpty()) {
            val lg = tv(act, b.log.lines().takeLast(14).joinToString("\n"), 11f, Color.WHITE, false, 0.8f)
            lg.typeface = Typeface.MONOSPACE; lg.maxLines = 14; lg.ellipsize = TextUtils.TruncateAt.END
            lg.setPadding(dp(12), dp(10), dp(12), dp(10)); lg.background = solid(withAlpha(Color.BLACK, 0x66), 14)
            lg.pressable { fullLog(b) }
            rc.addView(lg, lp(MATCH, WRAP, 0, 0, 0, 12))
        }
        if (b.dlf && b.art > 0) {
            val dl = GButton(act, "আবার ডাউনলোড", I.DOWN); dl.onTap { Engine.redownload(b) }
            rc.addView(dl, lp(MATCH, WRAP, 0, 0, 0, 10))
        } else if (b.run > 0) {
            val rt = GButton(act, "আবার চেষ্টা", I.RETRY); rt.onTap { Engine.rerun(b) }
            rc.addView(rt, lp(MATCH, WRAP, 0, 0, 0, 10))
        }
        val row = LinearLayout(act)
        if (b.log.isNotEmpty()) {
            val cp = GButton(act, "লগ কপি", I.COPY, false); cp.onTap { act.copyText(b.log); act.toast("লগ কপি হয়েছে") }
            row.addView(cp, lp(0, WRAP, 0, 0, 5, 0).also { it.weight = 1f })
        }
        if (b.url.isNotEmpty()) {
            val g = GButton(act, "GitHub-এ দেখুন", I.EXT, false); g.onTap { act.openUrl(b.url) }
            row.addView(g, lp(0, WRAP, if (b.log.isNotEmpty()) 5 else 0, 0, 0, 0).also { it.weight = 1f })
        }
        rc.addView(row, lp())
    }

    private fun fullLog(b: Bld) {
        Sheet(act).show("বিল্ড লগ") { box, _ ->
            val sv = ScrollView(act)
            val t = tv(act, b.log, 11.5f, Color.WHITE, false, 0.9f); t.typeface = Typeface.MONOSPACE; t.setTextIsSelectable(true)
            sv.addView(t); box.addView(sv, lp(MATCH, dp(340)))
        }
    }

    private fun update(b: Bld) {
        ring?.set(b.pct.toFloat(), b.s == "fail")
        status?.text = b.label
        dots.forEachIndexed { i, d -> d.set(if (b.s == "ok" || i < b.step) 2 else if (i == b.step && b.s == "run") 1 else 0) }
    }

    fun onEngine(b: Bld?, ev: String) {
        if (b == null) return
        if (st.viewId == b.id) {
            if (b.s != shown) render() else update(b)
        } else if (st.viewId == null) {
            val row = strip[b.id]
            if (row != null && b.s == "run") { row.first.text = b.label; row.second.set(b.pct.toFloat()) } else render()
        }
    }
}

// ================================================================ HISTORY
class HistoryScreen(private val act: MainActivity) {
    private val pg = page(act)
    val view: View = pg.first
    private val col = pg.second
    private var flt = "all"
    private var q = ""
    private val list = LinearLayout(act)
    private val stats = LinearLayout(act)
    private val chips = ArrayList<Chip>()
    init {
        stats.background = glass(24); stats.setPadding(dp(8), dp(16), dp(8), dp(16)); stats.gravity = Gravity.CENTER
        col.addView(stats, lp(MATCH, WRAP, 0, 0, 0, 12))
        val sf = field(act, "নাম দিয়ে খুঁজুন", "")
        sf.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { q = s?.toString()?.trim() ?: ""; renderList() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        col.addView(sf, lp(MATCH, WRAP, 0, 0, 0, 10))
        val hs = HorizontalScrollView(act); hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(act)
        listOf("all" to "সব", "ok" to "সফল", "fail" to "ফেল", "run" to "চলছে").forEach { (k, name) ->
            val c = Chip(act, name); c.select(k == flt)
            c.pressable { flt = k; chips.forEach { x -> x.select(x === c) }; renderList() }
            chips.add(c); row.addView(c, lp(WRAP, WRAP, 0, 0, 8, 0))
        }
        hs.addView(row); col.addView(hs, lp(MATCH, WRAP, 0, 0, 0, 12))
        list.orientation = LinearLayout.VERTICAL
        col.addView(list, lp())
        refresh()
    }
    fun refresh() { renderStats(); renderList() }
    fun onEngine(b: Bld?, ev: String) { if (act.tab == 1) refresh() }

    private fun renderStats() {
        stats.removeAllViews()
        val all = Store.builds
        val ok = all.count { it.s == "ok" }; val fl = all.count { it.s == "fail" }
        val d = all.filter { it.dur > 0 }.map { it.dur }
        val avg = if (d.isEmpty()) "–" else Fmt.dur(d.sum() / d.size)
        listOf(all.size.toString() to "মোট", ok.toString() to "সফল", fl.toString() to "ফেল", avg to "গড় সময়").forEach { (v, l) ->
            val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL; c.gravity = Gravity.CENTER
            c.addView(tv(act, v, 21f, Color.WHITE, true)); c.addView(tv(act, l, 11.5f, Color.WHITE, false, 0.65f))
            stats.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
    }

    private fun renderList() {
        list.removeAllViews()
        val items = Store.builds.filter { (flt == "all" || it.s == flt) && (q.isEmpty() || it.name.contains(q, true)) }
        if (items.isEmpty()) { list.addView(emptyState(act, I.FILE, "এখানে কিছু নেই")); return }
        items.forEachIndexed { i, b ->
            val has = b.s == "ok" && Store.hasApk(b.id)
            val row = LinearLayout(act); row.gravity = Gravity.CENTER_VERTICAL
            row.background = glass(20); row.setPadding(dp(12), dp(12), dp(10), dp(12))
            val meta = if (has) Apks.meta(b.id) else null
            if (meta?.icon != null) {
                val iv = ImageView(act); iv.setImageDrawable(meta.icon)
                row.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) })
            } else {
                val f = FrameLayout(act)
                val kind = if (b.s == "ok") I.CHECK else if (b.s == "fail") I.CROSS else I.BOLT
                val tint = if (b.s == "ok") Pal.p.c else if (b.s == "fail") 0xFFFF7A7A.toInt() else Pal.p.b
                f.background = solid(withAlpha(tint, 0x30), 14)
                f.addView(IconView(act, kind, 22, tint), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
                row.addView(f, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(12) })
            }
            val c2 = LinearLayout(act); c2.orientation = LinearLayout.VERTICAL
            val nm = tv(act, meta?.label ?: b.name, 15f, Color.WHITE, true); nm.maxLines = 1; nm.ellipsize = TextUtils.TruncateAt.END
            val stt = when (b.s) { "run" -> b.label; "ok" -> if (has) "APK সেভ আছে · " + Fmt.size(Store.apk(b.id).length()) else "APK মুছে ফেলা"; else -> "ফেল" }
            val sub = tv(act, stt + (if (b.dur > 0) " · " + Fmt.dur(b.dur) else "") + " · " + Fmt.date(b.t), 11.5f, Color.WHITE, false, 0.62f)
            sub.maxLines = 1; sub.ellipsize = TextUtils.TruncateAt.END
            c2.addView(nm); c2.addView(sub)
            row.addView(c2, LinearLayout.LayoutParams(0, WRAP, 1f))
            if (has) {
                row.addView(iconBtn(act, I.PHONE) { act.installApk(b.id) }, lp(dp(36), dp(36), 6, 0, 0, 0))
                row.addView(iconBtn(act, I.SHARE) { act.shareApk(b.id, apkName(b)) }, lp(dp(36), dp(36), 6, 0, 0, 0))
                row.addView(iconBtn(act, I.TRASH, 0xFFFF8A8A.toInt()) {
                    confirm(act, "APK মুছবেন?", b.name, "মুছুন") { Store.apk(b.id).delete(); Apks.forget(b.id); refresh() }
                }, lp(dp(36), dp(36), 6, 0, 0, 0))
            } else if (b.s != "run") {
                row.addView(iconBtn(act, I.CROSS) { Store.builds.remove(b); Store.save(); refresh() }, lp(dp(36), dp(36), 6, 0, 0, 0))
            }
            row.pressable { act.openBuild(b.id) }
            list.addView(row, lp(MATCH, WRAP, 0, 0, 0, 10))
            if (i < 14) row.enter(i * 45L)
        }
    }
}

// ================================================================ FILES (GitHub)
class FItem(val title: String, val sub: String, val icon: Int, val tap: () -> Unit)

class FilesScreen(private val act: MainActivity) {
    private val pg = page(act)
    val view: View = pg.first
    private val col = pg.second
    private val body = LinearLayout(act)
    private val chips = ArrayList<Chip>()
    private var seg = 0
    private var path = ""
    private var token = 0
    private var loaded = false
    init {
        val top = LinearLayout(act); top.gravity = Gravity.CENTER_VERTICAL
        val hs = HorizontalScrollView(act); hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(act)
        listOf("APK", "রিপো ফাইল", "ZIP ইতিহাস", "জমানো প্রজেক্ট").forEachIndexed { i, name ->
            val c = Chip(act, name); c.select(i == seg)
            c.pressable { seg = i; path = ""; chips.forEach { x -> x.select(x === c) }; load() }
            chips.add(c); row.addView(c, lp(WRAP, WRAP, 0, 0, 8, 0))
        }
        hs.addView(row)
        top.addView(hs, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(iconBtn(act, I.RETRY) { load() }, lp(dp(40), dp(40), 8, 0, 0, 0))
        col.addView(top, lp(MATCH, WRAP, 0, 0, 0, 12))
        body.orientation = LinearLayout.VERTICAL
        col.addView(body, lp())
    }
    fun onShow() { if (!loaded) load() }

    fun load() {
        loaded = true
        token++; val my = token
        body.removeAllViews()
        if (Cfg.token.isEmpty()) { body.addView(emptyState(act, I.KEY, "আগে সেটিংসে GitHub টোকেন বসান")); return }
        val l = LinearLayout(act); l.gravity = Gravity.CENTER; l.setPadding(0, dp(50), 0, 0)
        l.addView(Spinner(act)); body.addView(l)
        Bg.run {
            try {
                val items = when (seg) { 0 -> artifacts(); 1 -> repoFiles(); 2 -> zipHistory(); else -> bases() }
                Bg.ui { if (my == token) show(items) }
            } catch (e: Exception) { Bg.ui { if (my == token) { body.removeAllViews(); body.addView(emptyState(act, I.WARN, "লোড হয়নি: " + (e.message ?: "নেট বা টোকেন দেখুন"))) } } }
        }
    }

    private fun show(items: List<FItem>) {
        body.removeAllViews()
        if (items.isEmpty()) {
            body.addView(emptyState(act, I.FILE, if (seg == 3) "সফল বিল্ডের পর প্রজেক্ট এখানে জমা হবে" else "কিছু নেই")); return
        }
        items.forEachIndexed { i, it ->
            val row = LinearLayout(act); row.gravity = Gravity.CENTER_VERTICAL
            row.background = glass(20); row.setPadding(dp(14), dp(13), dp(12), dp(13))
            val f = FrameLayout(act); f.background = solid(withAlpha(Pal.p.a, 0x40), 14)
            f.addView(IconView(act, it.icon, 22, Color.WHITE), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            row.addView(f, LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(12) })
            val c2 = LinearLayout(act); c2.orientation = LinearLayout.VERTICAL
            val nm = tv(act, it.title, 14.5f, Color.WHITE, true); nm.maxLines = 1; nm.ellipsize = TextUtils.TruncateAt.END
            val sb = tv(act, it.sub, 11.5f, Color.WHITE, false, 0.62f); sb.maxLines = 1; sb.ellipsize = TextUtils.TruncateAt.END
            c2.addView(nm); c2.addView(sb)
            row.addView(c2, LinearLayout.LayoutParams(0, WRAP, 1f))
            row.addView(IconView(act, I.TUNE, 18, withAlpha(Color.WHITE, 0x88)), LinearLayout.LayoutParams(dp(18), dp(18)))
            row.pressable(it.tap)
            body.addView(row, lp(MATCH, WRAP, 0, 0, 0, 10))
            if (i < 14) row.enter(i * 40L)
        }
    }

    private fun enc(p: String): String = p.split("/").filter { it.isNotEmpty() }.joinToString("/") { Uri.encode(it) }

    private fun add(box: LinearLayout, row: LinearLayout) { box.addView(row, lp(MATCH, WRAP, 0, 0, 0, 8)) }

    private fun dl(api: String, accept: String, name: String, then: (File) -> Unit) {
        act.toast("নামছে…")
        Bg.run {
            try {
                val dir = File(Store.ctx.cacheDir, "share"); dir.mkdirs()
                val f = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                Gh.download(api, f, accept)
                Bg.ui { then(f) }
            } catch (e: Exception) { Bg.ui { act.toast("ডাউনলোড হয়নি: " + (e.message ?: "")) } }
        }
    }

    private fun del(what: String, call: () -> Resp) {
        confirm(act, "মুছবেন?", what, "মুছুন") {
            Bg.run {
                val r = try { call() } catch (e: Exception) { null }
                Bg.ui { act.toast(if (r != null && r.ok) "মুছে ফেলা হয়েছে" else "মোছা যায়নি"); load() }
            }
        }
    }

    // ---- APK artifacts
    private fun artifacts(): List<FItem> {
        val r = Gh.get("${Gh.repo()}/actions/artifacts?per_page=50")
        if (!r.ok) throw IOException(r.msg())
        val a = r.json().optJSONArray("artifacts") ?: JSONArray()
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val id = o.getLong("id"); val run = o.optJSONObject("workflow_run")?.optLong("id") ?: 0L
            val size = o.optLong("size_in_bytes"); val exp = o.optBoolean("expired"); val t = Fmt.iso(o.str("created_at"))
            FItem(o.optString("name") + " #" + (a.length() - i), Fmt.size(size) + " · " + Fmt.date(t) + (if (exp) " · মেয়াদ শেষ" else ""), I.CUBE) { artSheet(id, run, t, exp) }
        }
    }
    private fun artSheet(id: Long, run: Long, t: Long, exp: Boolean) {
        Sheet(act).show("APK ফাইল") { box, sh ->
            val have = Store.builds.firstOrNull { it.art == id && Store.hasApk(it.id) }
            if (have != null) {
                add(box, sheetRow(act, I.PHONE, "ইনস্টল করুন") { sh.dismiss(); act.installApk(have.id) })
                add(box, sheetRow(act, I.SHARE, "শেয়ার করুন") { sh.dismiss(); act.shareApk(have.id, apkName(have)) })
                add(box, sheetRow(act, I.SAVE, "ফোনে সেভ করুন") { sh.dismiss(); act.saveApk(have.id, apkName(have)) })
            } else if (!exp) {
                add(box, sheetRow(act, I.DOWN, "ডাউনলোড করে ইতিহাসে রাখুন") {
                    sh.dismiss(); val b = Engine.importArtifact(id, "GitHub APK #$run", t); act.toast("নামছে…"); act.openBuild(b.id)
                })
            }
            add(box, sheetRow(act, I.EXT, "GitHub-এ খুলুন") { sh.dismiss(); act.openUrl(Gh.webUrl("/actions/runs/$run")) })
            add(box, sheetRow(act, I.TRASH, "মুছুন", true) { sh.dismiss(); del("এই আর্টিফ্যাক্ট GitHub থেকে মুছে যাবে") { Gh.call("DELETE", "${Gh.repo()}/actions/artifacts/$id") } })
        }
    }

    // ---- repo tree
    private fun repoFiles(): List<FItem> {
        val r = Gh.get("${Gh.repo()}/contents/${enc(path)}?ref=main")
        if (!r.ok) throw IOException(r.msg())
        val arr = r.arr()
        val out = ArrayList<FItem>()
        if (path.isNotEmpty()) out.add(FItem("..", "উপরের ফোল্ডার", I.BACK) { path = path.substringBeforeLast('/', ""); load() })
        val items = (0 until arr.length()).map { arr.getJSONObject(it) }
            .sortedWith(compareBy<JSONObject>({ it.optString("type") != "dir" }, { it.optString("name").lowercase() }))
        items.forEach { o ->
            val name = o.optString("name")
            if (o.optString("type") == "dir") out.add(FItem(name, "ফোল্ডার", I.FOLDER) { path = if (path.isEmpty()) name else "$path/$name"; load() })
            else out.add(FItem(name, Fmt.size(o.optLong("size")), if (name.endsWith(".zip")) I.ZIP else I.FILE) { fileSheet(o) })
        }
        return out
    }
    private fun fileSheet(o: JSONObject) {
        val name = o.optString("name"); val fp = o.optString("path"); val sha = o.optString("sha"); val url = o.str("html_url")
        Sheet(act).show(name) { box, sh ->
            add(box, sheetRow(act, I.SHARE, "ডাউনলোড ও শেয়ার") { sh.dismiss(); dl("${Gh.repo()}/contents/${enc(fp)}?ref=main", "application/vnd.github.raw", name) { f -> act.shareFile(f, "application/octet-stream") } })
            add(box, sheetRow(act, I.SAVE, "ফোনে সেভ করুন") { sh.dismiss(); dl("${Gh.repo()}/contents/${enc(fp)}?ref=main", "application/vnd.github.raw", name) { f -> act.saveFile(f, name, "application/octet-stream") } })
            if (url.isNotEmpty()) add(box, sheetRow(act, I.EXT, "GitHub-এ খুলুন") { sh.dismiss(); act.openUrl(url) })
            add(box, sheetRow(act, I.TRASH, "মুছুন", true) {
                sh.dismiss()
                del("$fp মুছলে বিল্ড বন্ধ হয়ে যেতে পারে, যদি এটা workflow বা upload ফাইল হয়") {
                    Gh.call("DELETE", "${Gh.repo()}/contents/${enc(fp)}", JSONObject().put("message", "delete $name").put("sha", sha).put("branch", "main").toString())
                }
            })
        }
    }

    // ---- uploaded ZIP history
    private fun zipHistory(): List<FItem> {
        val r = Gh.get("${Gh.repo()}/commits?path=upload/project.zip&per_page=30")
        if (!r.ok) throw IOException(r.msg())
        val a = r.arr()
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val sha = o.optString("sha"); val c = o.getJSONObject("commit")
            val msg = c.optString("message").lines().first()
            val name = msg.removePrefix("build ").ifEmpty { "project.zip" }
            val t = Fmt.iso(c.optJSONObject("committer")?.str("date") ?: "")
            FItem(name, Fmt.date(t) + " · " + sha.take(7), I.ZIP) { zipSheet(sha, name, o.str("html_url")) }
        }
    }
    private fun zipSheet(sha: String, name: String, url: String) {
        val api = "${Gh.repo()}/contents/upload/project.zip?ref=$sha"
        Sheet(act).show(name) { box, sh ->
            add(box, sheetRow(act, I.BOLT, "এই ZIP আবার বিল্ড করুন") { sh.dismiss(); dl(api, "application/vnd.github.raw", name) { f -> val b = Engine.start(f, name); act.openBuild(b.id) } })
            add(box, sheetRow(act, I.SHARE, "ডাউনলোড ও শেয়ার") { sh.dismiss(); dl(api, "application/vnd.github.raw", name) { f -> act.shareFile(f, "application/zip") } })
            add(box, sheetRow(act, I.SAVE, "ফোনে সেভ করুন") { sh.dismiss(); dl(api, "application/vnd.github.raw", name) { f -> act.saveFile(f, name, "application/zip") } })
            if (url.isNotEmpty()) add(box, sheetRow(act, I.EXT, "GitHub-এ খুলুন") { sh.dismiss(); act.openUrl(url) })
        }
    }

    // ---- saved project bases (release assets)
    private fun bases(): List<FItem> {
        val r = Gh.get("${Gh.repo()}/releases/tags/bases")
        if (r.code == 404) return emptyList()
        if (!r.ok) throw IOException(r.msg())
        val a = r.json().optJSONArray("assets") ?: JSONArray()
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val id = o.getLong("id"); val name = o.optString("name")
            FItem(name.removePrefix("base-").removeSuffix(".zip"), Fmt.size(o.optLong("size")) + " · " + Fmt.date(Fmt.iso(o.str("updated_at"))), I.CUBE) { baseSheet(id, name) }
        }
    }
    private fun baseSheet(id: Long, name: String) {
        val api = "${Gh.repo()}/releases/assets/$id"
        Sheet(act).show(name) { box, sh ->
            add(box, sheetRow(act, I.SHARE, "ডাউনলোড ও শেয়ার") { sh.dismiss(); dl(api, "application/octet-stream", name) { f -> act.shareFile(f, "application/zip") } })
            add(box, sheetRow(act, I.SAVE, "ফোনে সেভ করুন") { sh.dismiss(); dl(api, "application/octet-stream", name) { f -> act.saveFile(f, name, "application/zip") } })
            add(box, sheetRow(act, I.TRASH, "মুছুন", true) { sh.dismiss(); del("এই জমানো প্রজেক্ট মুছে গেলে প্যাচ ZIP আর বসানো যাবে না") { Gh.call("DELETE", api) } })
        }
    }
}

// ================================================================ SETTINGS
class SettingsScreen(private val act: MainActivity) {
    private val pg = page(act)
    val view: View = pg.first
    private val col = pg.second
    private var d = 0L
    init { build() }

    private fun put(v: View) { col.addView(v, lp(MATCH, WRAP, 0, 0, 0, 12)); v.enter(d); d += 55 }
    private fun lab(t: String): TextView = tv(act, t, 12.5f, Color.WHITE, false, 0.7f)

    private fun head(icon: Int, text: String): LinearLayout {
        val h = LinearLayout(act); h.gravity = Gravity.CENTER_VERTICAL
        h.addView(IconView(act, icon, 20, Pal.p.c), LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(10) })
        h.addView(tv(act, text, 16f, Color.WHITE, true)); return h
    }

    private fun toggle(icon: Int, name: String, sub: String, get: Boolean, set: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(act); row.gravity = Gravity.CENTER_VERTICAL; row.setPadding(0, dp(8), 0, dp(8))
        row.addView(IconView(act, icon, 21, withAlpha(Color.WHITE, 0xCC)), LinearLayout.LayoutParams(dp(21), dp(21)).apply { rightMargin = dp(14) })
        val c = LinearLayout(act); c.orientation = LinearLayout.VERTICAL
        c.addView(tv(act, name, 14.5f, Color.WHITE, true)); if (sub.isNotEmpty()) c.addView(tv(act, sub, 11.5f, Color.WHITE, false, 0.6f))
        row.addView(c, LinearLayout.LayoutParams(0, WRAP, 1f))
        val t = Toggle(act); t.set(get, false); t.onChange = { set(it) }
        row.addView(t, LinearLayout.LayoutParams(dp(52), dp(30)))
        return row
    }

    private fun watch(e: android.widget.EditText, on: (String) -> Unit) {
        e.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { on(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun build() {
        // --- GitHub connection
        val g = card(act, 18)
        g.addView(head(I.KEY, "GitHub সংযোগ"), lp(MATCH, WRAP, 0, 0, 0, 12))
        g.addView(lab("টোকেন"), lp(MATCH, WRAP, 2, 0, 0, 6))
        val tk = field(act, "github_pat_…", Cfg.token, true); watch(tk) { Cfg.token = it }
        val trow = LinearLayout(act); trow.gravity = Gravity.CENTER_VERTICAL
        trow.addView(tk, LinearLayout.LayoutParams(0, WRAP, 1f))
        var vis = false
        trow.addView(iconBtn(act, I.EYE) {
            vis = !vis
            tk.inputType = if (vis) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            tk.setSelection(tk.text.length)
        }, lp(dp(46), dp(46), 8, 0, 0, 0))
        g.addView(trow, lp())
        g.addView(lab("ইউজারনেম"), lp(MATCH, WRAP, 2, 12, 0, 6))
        val ow = field(act, "ইউজারনেম", Cfg.owner); watch(ow) { Cfg.owner = it }; g.addView(ow, lp())
        g.addView(lab("রিপো"), lp(MATCH, WRAP, 2, 12, 0, 6))
        val rp = field(act, "রিপো", Cfg.repo); watch(rp) { Cfg.repo = it }; g.addView(rp, lp())
        val r1 = LinearLayout(act)
        val paste = GButton(act, "পেস্ট", I.COPY, false)
        paste.onTap {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim() ?: ""
            if (t.isEmpty()) act.toast("ক্লিপবোর্ড খালি") else { tk.setText(t); act.toast("টোকেন বসানো হয়েছে") }
        }
        val test = GButton(act, "টেস্ট", I.CHECK, true)
        test.onTap {
            if (Cfg.token.isEmpty()) { act.toast("আগে টোকেন দিন"); return@onTap }
            Bg.run {
                try {
                    val r = Gh.get(Gh.repo())
                    val msg = if (r.ok) { if (r.json().optJSONObject("permissions")?.optBoolean("push") == true) "সংযোগ ঠিক আছে" else "রিপো পাওয়া গেছে, কিন্তু লেখার অনুমতি নেই" } else "ব্যর্থ: " + r.msg()
                    Toasts.show(msg)
                } catch (e: Exception) { Toasts.show("ইন্টারনেট বা সংযোগ সমস্যা") }
            }
        }
        r1.addView(paste, lp(0, WRAP, 0, 0, 5, 0).also { it.weight = 1f }); r1.addView(test, lp(0, WRAP, 5, 0, 0, 0).also { it.weight = 1f })
        g.addView(r1, lp(MATCH, WRAP, 0, 16, 0, 0))
        val r2 = LinearLayout(act)
        val wf = GButton(act, "workflow আপডেট", I.GIT, false)
        wf.onTap {
            if (Cfg.token.isEmpty()) { act.toast("আগে টোকেন দিন"); return@onTap }
            Bg.run { try { Engine.ensureWorkflow(true); Toasts.show("workflow আপডেট হয়েছে") } catch (e: Exception) { Toasts.show("workflow আপডেট হয়নি: " + (e.message ?: "")) } }
        }
        val ac = GButton(act, "Actions খুলুন", I.EXT, false); ac.onTap { act.openUrl(Gh.webUrl("/actions")) }
        r2.addView(wf, lp(0, WRAP, 0, 0, 5, 0).also { it.weight = 1f }); r2.addView(ac, lp(0, WRAP, 5, 0, 0, 0).also { it.weight = 1f })
        g.addView(r2, lp(MATCH, WRAP, 0, 10, 0, 0))
        put(g)

        // --- theme
        val th = card(act, 18)
        th.addView(head(I.PALETTE, "থিম"), lp(MATCH, WRAP, 0, 0, 0, 14))
        val fl = Flow(act, 14)
        Pal.list.forEachIndexed { i, p ->
            val box = LinearLayout(act); box.orientation = LinearLayout.VERTICAL; box.gravity = Gravity.CENTER
            val dot = FrameLayout(act)
            val gd = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, intArrayOf(p.a, p.b, p.c))
            gd.shape = android.graphics.drawable.GradientDrawable.OVAL
            if (i == Pal.idx) gd.setStroke(dp(3), Color.WHITE)
            dot.background = gd
            box.addView(dot, LinearLayout.LayoutParams(dp(50), dp(50)))
            box.addView(tv(act, Pal.names[i], 11f, Color.WHITE, i == Pal.idx, if (i == Pal.idx) 1f else 0.65f), lp(WRAP, WRAP, 0, 5, 0, 0))
            box.pressable { Cfg.theme = i; act.rebuildUi() }
            fl.addView(box)
        }
        th.addView(fl, lp())
        put(th)

        // --- behaviour
        val bh = card(act, 18)
        bh.addView(head(I.TUNE, "আচরণ"), lp(MATCH, WRAP, 0, 0, 0, 6))
        bh.addView(toggle(I.VIBRATE, "ভাইব্রেশন", "বাটন চাপলে হালকা কাঁপুনি", Cfg.haptic) { Cfg.haptic = it })
        bh.addView(toggle(I.PHONE, "বিল্ড শেষে নিজে ইনস্টল", "APK তৈরি হলেই ইনস্টল স্ক্রিন খুলবে", Cfg.autoInstall) { Cfg.autoInstall = it })
        bh.addView(toggle(I.SPARK, "কনফেটি", "সফল হলে রঙিন উৎসব", Cfg.confetti) { Cfg.confetti = it })
        bh.addView(toggle(I.BELL, "নোটিফিকেশন", "বিল্ড শেষ হলে জানাবে", Cfg.notify) { Cfg.notify = it; if (it) act.askNotif() })
        bh.addView(toggle(I.RETRY, "নিজে আবার চেষ্টা", "নেট বা ডাউনলোড সমস্যায় বিল্ড আবার চালাবে", Cfg.autoRetry) { Cfg.autoRetry = it })
        bh.addView(toggle(I.PHONE, "স্ক্রিন জাগিয়ে রাখা", "বিল্ড চলার সময় স্ক্রিন বন্ধ হবে না", Cfg.keepScreen) { Cfg.keepScreen = it })
        bh.addView(toggle(I.WAVE, "কম অ্যানিমেশন", "ধীর ফোনে বা ব্যাটারি বাঁচাতে", Cfg.reduceMotion) { Cfg.reduceMotion = it; act.rebuildUi() })
        put(bh)

        // --- storage
        val sg = card(act, 18)
        sg.addView(head(I.DISK, "সংরক্ষণ"), lp(MATCH, WRAP, 0, 0, 0, 10))
        sg.addView(tv(act, "${Store.apkCount()}টি APK ফোনে সেভ আছে · ${Fmt.size(Store.apkBytes())}", 14f, Color.WHITE, false, 0.85f), lp(MATCH, WRAP, 2, 0, 0, 14))
        val r3 = LinearLayout(act)
        val c1 = GButton(act, "সব APK মুছুন", I.TRASH, false)
        c1.onTap { confirm(act, "সব APK মুছবেন?", "ফোনে সেভ করা সব APK মুছে যাবে।", "মুছুন") { Store.apkDir.listFiles()?.forEach { f -> f.delete() }; Apks.forget("*"); act.rebuildUi() } }
        val c2 = GButton(act, "ইতিহাস মুছুন", I.CROSS, false)
        c2.onTap { confirm(act, "ইতিহাস মুছবেন?", "সব বিল্ডের তালিকা মুছে যাবে।", "মুছুন") { Store.builds.removeAll { it.s != "run" }; Store.save(); act.rebuildUi() } }
        r3.addView(c1, lp(0, WRAP, 0, 0, 5, 0).also { it.weight = 1f }); r3.addView(c2, lp(0, WRAP, 5, 0, 0, 0).also { it.weight = 1f })
        sg.addView(r3, lp())
        put(sg)

        // --- about
        val ab = card(act, 18)
        ab.addView(head(I.INFO, "অ্যাপ সম্পর্কে"), lp(MATCH, WRAP, 0, 0, 0, 10))
        val ver = try { act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        ab.addView(tv(act, "ZIP → APK · ভার্সন $ver\nZIP দিন, GitHub-এ বিল্ড হবে, APK নিন।", 13f, Color.WHITE, false, 0.75f), lp(MATCH, WRAP, 2, 0, 0, 12))
        val rb = GButton(act, "GitHub রিপো খুলুন", I.GIT, false); rb.onTap { act.openUrl(Gh.webUrl()) }
        ab.addView(rb, lp())
        put(ab)
    }

    fun refresh() { col.removeAllViews(); d = 0; build() }
}
