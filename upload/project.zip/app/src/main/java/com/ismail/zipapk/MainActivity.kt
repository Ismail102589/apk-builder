package com.ismail.zipapk

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.DragEvent
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import java.io.File

class MainActivity : Activity() {
    var tab = 0
    private val bstate = BState()
    private lateinit var root: FrameLayout
    private lateinit var main: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var nav: NavBar
    private lateinit var pager: Pager
    private lateinit var buildScr: BuildScreen
    private lateinit var histScr: HistoryScreen
    private lateinit var filesScr: FilesScreen
    private lateinit var setScr: SettingsScreen
    private lateinit var confettiV: ConfettiView
    private var wide: Boolean? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var pendingSave: File? = null
    private var dropPerm: Any? = null
    private val listener: (Bld?, String) -> Unit = { b, ev -> onEngine(b, ev) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Store.init(this)
        buildUi()
        Engine.listeners.add(listener)
        watchNet()
        handleIntent(intent)
        Engine.resume()
    }

    override fun onDestroy() {
        Engine.listeners.remove(listener)
        try { netCb?.let { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } } catch (e: Exception) { }
        super.onDestroy()
    }

    override fun onResume() { super.onResume(); Engine.autoDl() }
    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c) }

    private fun watchNet() {
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() { override fun onAvailable(n: Network) { Engine.autoDl() } }
            cm.registerDefaultNetworkCallback(cb); netCb = cb
        } catch (e: Exception) { }
    }

    // ------------------------------------------------------------ UI
    fun buildUi() {
        window.statusBarColor = Pal.p.bg; window.navigationBarColor = Pal.p.bg
        val r = FrameLayout(this)
        r.addView(AuroraView(this), FrameLayout.LayoutParams(MATCH, MATCH))
        main = LinearLayout(this)
        r.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))
        buildScr = BuildScreen(this, bstate); histScr = HistoryScreen(this); filesScr = FilesScreen(this); setScr = SettingsScreen(this)
        pager = Pager(this, listOf(buildScr.view, histScr.view, filesScr.view, setScr.view))
        nav = NavBar(this, listOf(Pair(I.BOLT, "বিল্ড"), Pair(I.HIST, "ইতিহাস"), Pair(I.CLOUD, "ফাইল"), Pair(I.TUNE, "সেটিংস"))) { goTab(it) }
        content = LinearLayout(this); content.orientation = LinearLayout.VERTICAL
        content.addView(header(), lp(MATCH, WRAP))
        content.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))
        confettiV = ConfettiView(this)
        val th = ToastHost(this); Toasts.host = th
        r.addView(confettiV, FrameLayout.LayoutParams(MATCH, MATCH))
        r.addView(th, FrameLayout.LayoutParams(MATCH, MATCH))
        root = r
        setContentView(r)
        wide = null
        arrange(resources.displayMetrics.widthPixels)
        pager.show(tab); nav.select(tab, false)
        r.addOnLayoutChangeListener { _, l, _, rr, _, _, _, _, _ -> val w = rr - l; r.post { arrange(w) } }
        r.setOnDragListener { _, e -> onDrag(e) }
        updateKeepScreen()
    }

    fun rebuildUi() { buildUi() }

    private fun header(): View {
        val h = LinearLayout(this); h.gravity = Gravity.CENTER_VERTICAL; h.setPadding(dp(18), dp(12), dp(18), dp(8))
        val id = resources.getIdentifier("logo", "drawable", packageName)
        if (id != 0) {
            val iv = ImageView(this); iv.setImageResource(id); iv.scaleType = ImageView.ScaleType.FIT_CENTER
            h.addView(iv, LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(12) }); iv.enter(0)
        }
        val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL
        val t = GradText(this); t.text = "ZIP → APK"; t.textSize = 24f; t.typeface = Typeface.DEFAULT_BOLD; t.setTextColor(Color.WHITE)
        c.addView(t); c.addView(tv(this, "কোড ZIP দিন, APK নিন", 12.5f, Color.WHITE, false, 0.7f))
        h.addView(c)
        return h
    }

    private fun arrange(w: Int) {
        val isWide = w >= dp(720)
        if (wide == isWide) return
        wide = isWide
        main.removeAllViews()
        if (isWide) {
            main.orientation = LinearLayout.HORIZONTAL; nav.setVertical(true)
            main.addView(nav, lp(dp(92), MATCH, 12, 12, 0, 12))
            main.addView(content, LinearLayout.LayoutParams(0, MATCH, 1f))
        } else {
            main.orientation = LinearLayout.VERTICAL; nav.setVertical(false)
            main.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
            main.addView(nav, lp(MATCH, dp(76), 12, 4, 12, 12))
        }
    }

    fun goTab(i: Int) {
        tab = i; pager.show(i); nav.select(i, true)
        if (i == 1) histScr.refresh()
        if (i == 2) filesScr.onShow()
    }

    fun openBuild(id: String) { bstate.viewId = id; buildScr.render(); goTab(0) }
    fun toast(m: String) { Toasts.show(m) }

    private fun updateKeepScreen() {
        if (Cfg.keepScreen && Engine.running() > 0) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun onEngine(b: Bld?, ev: String) {
        updateKeepScreen()
        buildScr.onEngine(b, ev); histScr.onEngine(b, ev)
        if (b == null) return
        val watching = tab == 0 && bstate.viewId == b.id
        if (ev == "ok") {
            if (watching) { if (Cfg.confetti) confettiV.burst(); if (Cfg.autoInstall) installApk(b.id) }
            else toast("APK তৈরি হয়েছে: ${b.name}")
        } else if (ev == "fail" && !watching) toast("বিল্ড ফেল: ${b.name}")
    }

    // ------------------------------------------------------------ input
    fun pickZips() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        try { startActivityForResult(i, REQ_PICK) } catch (e: Exception) { toast("ফাইল বাছাই খোলা যায়নি") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        if (res != RESULT_OK || d == null) return
        if (req == REQ_PICK) {
            val uris = ArrayList<Uri>()
            val cd = d.clipData
            if (cd != null) {
                for (i in 0 until cd.itemCount) { val u = cd.getItemAt(i).uri; if (u != null) uris.add(u) }
            } else { val u = d.data; if (u != null) uris.add(u) }
            importUris(uris)
        } else if (req == REQ_SAVE) {
            val uri = d.data; val f = pendingSave
            if (uri != null && f != null) Bg.run {
                try { contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }; Toasts.show("ফোনে সেভ হয়েছে") }
                catch (e: Exception) { Toasts.show("সেভ হয়নি") }
            }
        }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_SEND -> {
                val u = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                if (u != null) uris.add(u)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val l = if (Build.VERSION.SDK_INT >= 33) i.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                if (l != null) uris.addAll(l)
            }
            Intent.ACTION_VIEW -> { val u = i.data; if (u != null) uris.add(u) }
        }
        if (uris.isNotEmpty()) { i.action = null; importUris(uris) }
    }

    private fun onDrag(e: DragEvent): Boolean {
        if (e.action == DragEvent.ACTION_DROP) {
            val cd = e.clipData ?: return false
            dropPerm = try { requestDragAndDropPermissions(e) } catch (x: Exception) { null }
            val uris = ArrayList<Uri>()
            for (i in 0 until cd.itemCount) { val u = cd.getItemAt(i).uri; if (u != null) uris.add(u) }
            importUris(uris)
        }
        return true
    }

    fun importUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        toast("ফাইল পড়া হচ্ছে…")
        Bg.run {
            val out = ArrayList<Picked>()
            for (u in uris) {
                try {
                    var name = "project.zip"
                    contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                        if (c.moveToFirst()) name = c.getString(0) ?: name
                        Unit
                    }
                    val dir = File(cacheDir, "picks"); dir.mkdirs()
                    val f = File(dir, System.nanoTime().toString() + "_" + name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
                    contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                    out.add(Picked(f, name, ZipScan.scan(f)))
                } catch (e: Exception) { }
            }
            Bg.ui {
                bstate.picked.addAll(out); bstate.viewId = null; goTab(0); buildScr.render()
                toast(if (out.isEmpty()) "ফাইল পড়া যায়নি" else "${out.size}টি ZIP যোগ হয়েছে")
            }
        }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && e.isCtrlPressed) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_O -> { pickZips(); return true }
                KeyEvent.KEYCODE_B -> { buildScr.startAll(); return true }
                KeyEvent.KEYCODE_1 -> { goTab(0); return true }
                KeyEvent.KEYCODE_2 -> { goTab(1); return true }
                KeyEvent.KEYCODE_3 -> { goTab(2); return true }
                KeyEvent.KEYCODE_4 -> { goTab(3); return true }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (tab != 0) goTab(0)
        else if (bstate.viewId != null) { bstate.viewId = null; buildScr.render() }
        else super.onBackPressed()
    }

    // ------------------------------------------------------------ output
    fun openUrl(u: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { toast("ব্রাউজার খোলা যায়নি") } }
    fun copyText(t: String) { (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("log", t)) }
    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && Cfg.notify && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7)
    }

    fun installApk(id: String) {
        val f = Store.apk(id)
        if (!f.exists()) { toast("এই APK আর নেই"); return }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))) } catch (e: Exception) { }
            toast("অনুমতি দিয়ে ফিরে এসে আবার ইনস্টল চাপুন"); return
        }
        val uri = FileProv.uriFor(this, "apk", f)
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) { toast("ইনস্টল স্ক্রিন খোলা যায়নি") }
    }

    fun shareApk(id: String, name: String) {
        val f = Store.apk(id)
        if (!f.exists()) { toast("এই APK আর নেই"); return }
        Bg.run {
            val dir = File(cacheDir, "share"); dir.mkdirs()
            val out = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "app.apk" })
            f.copyTo(out, true)
            Bg.ui { shareFile(out, "application/vnd.android.package-archive") }
        }
    }

    fun shareFile(f: File, mime: String) {
        try {
            val dir = File(cacheDir, "share"); dir.mkdirs()
            val src = if (f.parentFile?.absolutePath == dir.absolutePath) f else File(dir, f.name).also { f.copyTo(it, true) }
            val uri = FileProv.uriFor(this, "share", src)
            val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "শেয়ার"))
        } catch (e: Exception) { toast("শেয়ার করা যায়নি") }
    }

    fun saveApk(id: String, name: String) {
        val f = Store.apk(id)
        if (!f.exists()) { toast("এই APK আর নেই"); return }
        saveFile(f, name, "application/vnd.android.package-archive")
    }

    fun saveFile(f: File, name: String, mime: String) {
        pendingSave = f
        try {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE, name), REQ_SAVE)
        } catch (e: Exception) { toast("সেভ স্ক্রিন খোলা যায়নি") }
    }

    companion object { const val REQ_PICK = 11; const val REQ_SAVE = 12 }
}
