package com.ismail.zipapk

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pageReady = false
    private var sharedName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val base = Color.parseColor("#0A0620")
        window.statusBarColor = base
        window.navigationBarColor = base
        web = WebView(this)
        web.setBackgroundColor(base)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.keepScreenOn = true
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                pageReady = true
                announce()
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val f = File(cacheDir, "shared.zip")
                if (request.url.toString().startsWith("https://shared.local/zip") && f.exists()) {
                    return WebResourceResponse(
                        "application/zip", null, 200, "OK",
                        mapOf("Access-Control-Allow-Origin" to "*"), FileInputStream(f)
                    )
                }
                return null
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                val i = Intent(Intent.ACTION_GET_CONTENT)
                    .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                startActivityForResult(Intent.createChooser(i, "ZIP"), 1)
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        takeShared(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        takeShared(intent)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        if (r == 1) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d))
            chooser = null
        } else super.onActivityResult(r, res, d)
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    private fun takeShared(i: Intent?) {
        if (i == null) return
        val u: Uri? = when (i.action) {
            Intent.ACTION_SEND ->
                if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (u == null) return
        Thread {
            try {
                var name = "project.zip"
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0) ?: name
                    Unit
                }
                contentResolver.openInputStream(u)!!.use { a ->
                    File(cacheDir, "shared.zip").outputStream().use { o -> a.copyTo(o) }
                }
                sharedName = name
                runOnUiThread { announce() }
            } catch (e: Exception) {
                js("toast('ফাইল পড়া যায়নি')")
            }
        }.start()
    }

    private fun announce() {
        val n = sharedName
        if (pageReady && n != null) {
            sharedName = null
            web.evaluateJavascript("onShared(" + JSONObject.quote(n) + ")", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface fun openUrl(u: String) {
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        }

        @JavascriptInterface fun haptic() {
            runOnUiThread { web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
        }

        @JavascriptInterface fun install(bid: String) { runOnUiThread { installApk(bid) } }

        @JavascriptInterface fun hasApk(bid: String): Boolean = apkFile(bid).exists()

        @JavascriptInterface fun deleteApk(bid: String) { apkFile(bid).delete() }

        @JavascriptInterface fun workflow(): String =
            try { assets.open("build.yml").bufferedReader().use { it.readText() } } catch (e: Exception) { "" }

        @JavascriptInterface fun copy(t: String) {
            runOnUiThread {
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("log", t))
            }
        }

        @JavascriptInterface fun fetchLog(token: String, owner: String, repo: String, job: String, bid: String) {
            val id = bid.filter { it.isDigit() }
            Thread {
                var out = ""
                try {
                    val c = URL("https://api.github.com/repos/$owner/$repo/actions/jobs/" + job.filter { it.isDigit() } + "/logs")
                        .openConnection() as HttpURLConnection
                    c.instanceFollowRedirects = false
                    c.connectTimeout = 20000
                    c.readTimeout = 30000
                    c.setRequestProperty("Authorization", "Bearer $token")
                    c.setRequestProperty("Accept", "application/vnd.github+json")
                    val loc = c.getHeaderField("Location") ?: throw IOException("HTTP ${c.responseCode}")
                    c.disconnect()
                    val ts = Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z ")
                    val lines = URL(loc).readText().lines().map { it.replace(ts, "") }
                    var i = lines.indexOfFirst { it.contains("What went wrong") }
                    if (i < 0) i = lines.indexOfFirst { it.contains("##[error]") }
                    val start = if (i >= 0) maxOf(0, i - 3) else maxOf(0, lines.size - 40)
                    out = lines.subList(start, minOf(lines.size, start + 40)).joinToString("\n")
                } catch (e: Exception) {
                }
                js("onLog('$id'," + JSONObject.quote(out) + ")")
            }.start()
        }

        @JavascriptInterface fun download(token: String, owner: String, repo: String, art: String, bid: String) {
            val id = bid.filter { it.isDigit() }
            Thread {
                var err: Exception? = null
                var ok = false
                var tries = 0
                while (!ok && tries < 3) {
                    tries++
                    try {
                        fetchApk(token, owner, repo, art, id)
                        ok = true
                    } catch (e: Exception) {
                        err = e
                        Thread.sleep(2500)
                    }
                }
                if (ok) js("onDone('$id')")
                else js("onErr('$id'," + JSONObject.quote(err?.message ?: "ডাউনলোড ফেল") + ")")
            }.start()
        }
    }

    private fun fetchApk(token: String, owner: String, repo: String, art: String, id: String) {
        val c = URL("https://api.github.com/repos/$owner/$repo/actions/artifacts/$art/zip")
            .openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        val loc = c.getHeaderField("Location")
        if (c.responseCode !in 300..399 || loc == null) throw IOException("HTTP ${c.responseCode}")
        c.disconnect()
        val d = URL(loc).openConnection() as HttpURLConnection
        d.connectTimeout = 20000
        d.readTimeout = 30000
        val total = d.contentLengthLong
        val dir = File(filesDir, "apks")
        dir.mkdirs()
        val zip = File(dir, "$id.zip")
        d.inputStream.use { i ->
            zip.outputStream().use { o ->
                val buf = ByteArray(65536)
                var n: Int
                var sum = 0L
                var last = -1
                while (i.read(buf).also { n = it } > 0) {
                    o.write(buf, 0, n); sum += n
                    if (total > 0) {
                        val p = (sum * 100 / total).toInt()
                        if (p != last) { last = p; js("onDl('$id',$p)") }
                    }
                }
            }
        }
        var found = false
        ZipInputStream(zip.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null && !found) {
                if (e.name.endsWith(".apk")) {
                    File(dir, "$id.apk").outputStream().use { z.copyTo(it) }
                    found = true
                }
                e = z.nextEntry
            }
        }
        zip.delete()
        if (!found) throw IOException("APK ZIP-এর ভেতরে নেই")
    }

    private fun apkFile(bid: String) = File(filesDir, "apks/" + bid.filter { it.isDigit() } + ".apk")

    private fun installApk(bid: String) {
        val f = apkFile(bid)
        if (!f.exists()) { js("toast('এই APK আর নেই')"); return }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            js("toast('অনুমতি দিয়ে ফিরে এসে আবার ইনস্টল চাপুন')")
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
