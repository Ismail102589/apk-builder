package com.ismail.zipapk

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val base = Color.parseColor("#0A0620")
        window.statusBarColor = base
        window.navigationBarColor = base
        web = WebView(this)
        web.setBackgroundColor(base)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                chooser?.onReceiveValue(null)
                chooser = cb
                val i = Intent(Intent.ACTION_GET_CONTENT)
                    .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
                startActivityForResult(Intent.createChooser(i, "ZIP"), 1)
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        if (r == 1) {
            chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d))
            chooser = null
        } else super.onActivityResult(r, res, d)
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    inner class Bridge {
        @JavascriptInterface fun openUrl(u: String) {
            runOnUiThread { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        }

        @JavascriptInterface fun haptic() {
            runOnUiThread { web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
        }

        @JavascriptInterface fun install() { runOnUiThread { installApk() } }

        @JavascriptInterface fun download(token: String, owner: String, repo: String, id: String) {
            Thread {
                try {
                    val c = URL("https://api.github.com/repos/$owner/$repo/actions/artifacts/$id/zip")
                        .openConnection() as HttpURLConnection
                    c.instanceFollowRedirects = false
                    c.setRequestProperty("Authorization", "Bearer $token")
                    c.setRequestProperty("Accept", "application/vnd.github+json")
                    val loc = c.getHeaderField("Location")
                    if (c.responseCode !in 300..399 || loc == null) throw IOException("HTTP ${c.responseCode}")
                    c.disconnect()
                    val d = URL(loc).openConnection() as HttpURLConnection
                    val total = d.contentLengthLong
                    val dir = File(cacheDir, "apk")
                    dir.deleteRecursively(); dir.mkdirs()
                    val zip = File(dir, "a.zip")
                    d.inputStream.use { i ->
                        zip.outputStream().use { o ->
                            val buf = ByteArray(65536)
                            var n: Int
                            var sum = 0L
                            var last = -1
                            while (i.read(buf).also { n = it } > 0) {
                                o.write(buf, 0, n); sum += n
                                if (total > 0) {
                                    val p = (sum * 100 / total).toInt()
                                    if (p != last) { last = p; js("onDl($p)") }
                                }
                            }
                        }
                    }
                    var found = false
                    ZipInputStream(zip.inputStream()).use { z ->
                        var e = z.nextEntry
                        while (e != null && !found) {
                            if (e.name.endsWith(".apk")) {
                                File(dir, "app.apk").outputStream().use { z.copyTo(it) }
                                found = true
                            }
                            e = z.nextEntry
                        }
                    }
                    zip.delete()
                    if (!found) throw IOException("APK ZIP-এর ভেতরে নেই")
                    js("onDone()")
                } catch (e: Exception) {
                    js("onErr(" + JSONObject.quote(e.message ?: "ডাউনলোড ফেল") + ")")
                }
            }.start()
        }
    }

    private fun installApk() {
        val f = File(cacheDir, "apk/app.apk")
        if (!f.exists()) { js("toast('আগে একটা বিল্ড করুন')"); return }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            js("toast('অনুমতি দিয়ে ফিরে এসে আবার ইনস্টল চাপুন')")
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
