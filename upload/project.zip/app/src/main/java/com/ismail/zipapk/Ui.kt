package com.ismail.zipapk

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun tv(c: Context, text: CharSequence, sp: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false, alpha: Float = 1f): TextView {
    val t = TextView(c)
    t.text = text; t.textSize = sp
    t.setTextColor(withAlpha(color, (alpha * 255).toInt()))
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    t.setLineSpacing(0f, 1.18f)
    return t
}

object Hap { fun tap(v: View) { if (Cfg.haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) } }

fun glass(r: Int = 22, a1: Int = 0x3A, a2: Int = 0x10, stroke: Int = 0x55): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(withAlpha(Color.WHITE, a1), withAlpha(Color.WHITE, a2)))
    g.cornerRadius = dpf(r); g.setStroke(dp(1), withAlpha(Color.WHITE, stroke)); return g
}
fun solid(color: Int, r: Int): GradientDrawable { val g = GradientDrawable(); g.setColor(color); g.cornerRadius = dpf(r); return g }

fun View.pressable(onClick: () -> Unit) {
    isClickable = true
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.95f).scaleY(0.95f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(2.2f)).start()
        }
        false
    }
    setOnClickListener { Hap.tap(it); onClick() }
}

fun View.enter(delay: Long = 0, dy: Float = 18f) {
    if (Cfg.reduceMotion) return
    alpha = 0f; translationY = dpf(dy)
    animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(420).setInterpolator(DecelerateInterpolator(1.8f)).start()
}

fun lp(w: Int = MATCH, h: Int = WRAP, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h); p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p
}

fun field(c: Context, hint: String, value: String, password: Boolean = false): EditText {
    val e = EditText(c)
    e.hint = hint; e.setText(value); e.setTextColor(Color.WHITE); e.setHintTextColor(withAlpha(Color.WHITE, 0x77)); e.textSize = 14.5f
    e.background = glass(16, 0x22, 0x0A, 0x44); e.setPadding(dp(14), dp(12), dp(14), dp(12)); e.isSingleLine = true
    e.inputType = if (password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
    return e
}

// ---------------------------------------------------------------- icons
object I {
    const val HOME = 0; const val HIST = 1; const val TUNE = 2; const val FOLDER = 3; const val ZIP = 4; const val BOLT = 5
    const val DOWN = 6; const val UP = 7; const val SHARE = 8; const val PHONE = 9; const val TRASH = 10; const val RETRY = 11
    const val CHECK = 12; const val CROSS = 13; const val EXT = 14; const val COPY = 15; const val KEY = 16; const val PALETTE = 17
    const val VIBRATE = 18; const val SPARK = 19; const val WAVE = 20; const val SEARCH = 21; const val PLUS = 22; const val WARN = 23
    const val INFO = 24; const val BELL = 25; const val CUBE = 26; const val DISK = 27; const val FILE = 28; const val EYE = 29
    const val BACK = 30; const val GIT = 31; const val SAVE = 32; const val CLOUD = 33
}

object Ic {
    fun draw(cv: Canvas, k: Int, p: Paint) {
        val path = Path()
        fun poly(close: Boolean, vararg v: Float) {
            path.reset(); path.moveTo(v[0], v[1])
            var i = 2
            while (i + 1 < v.size) { path.lineTo(v[i], v[i + 1]); i += 2 }
            if (close) path.close()
            cv.drawPath(path, p)
        }
        fun line(a: Float, b: Float, c: Float, d: Float) { cv.drawLine(a, b, c, d, p) }
        fun circ(x: Float, y: Float, r: Float) { cv.drawCircle(x, y, r, p) }
        fun rr(l: Float, t: Float, r: Float, b: Float, rad: Float) { cv.drawRoundRect(RectF(l, t, r, b), rad, rad, p) }
        fun dot(x: Float, y: Float, r: Float) { p.style = Paint.Style.FILL; cv.drawCircle(x, y, r, p); p.style = Paint.Style.STROKE }
        when (k) {
            I.HOME -> { poly(false, 3f, 11.5f, 12f, 3.5f, 21f, 11.5f); poly(false, 5.5f, 10f, 5.5f, 20.5f, 18.5f, 20.5f, 18.5f, 10f); poly(false, 10f, 20.5f, 10f, 14.5f, 14f, 14.5f, 14f, 20.5f) }
            I.HIST -> { circ(12f, 12f, 9f); poly(false, 12f, 7f, 12f, 12.2f, 15.5f, 14f) }
            I.TUNE -> {
                line(4f, 6f, 6.8f, 6f); line(11.2f, 6f, 20f, 6f); circ(9f, 6f, 2.2f)
                line(4f, 12f, 12.8f, 12f); line(17.2f, 12f, 20f, 12f); circ(15f, 12f, 2.2f)
                line(4f, 18f, 5.8f, 18f); line(10.2f, 18f, 20f, 18f); circ(8f, 18f, 2.2f)
            }
            I.FOLDER -> poly(true, 3f, 6.5f, 9.5f, 6.5f, 11.5f, 9f, 21f, 9f, 21f, 19f, 3f, 19f)
            I.ZIP -> { rr(4.5f, 3f, 19.5f, 21f, 3f); line(12f, 3f, 12f, 9f); line(10.5f, 5f, 13.5f, 5f); line(10.5f, 7.5f, 13.5f, 7.5f); rr(10f, 11f, 14f, 16f, 1.2f) }
            I.BOLT -> poly(true, 13f, 2.5f, 5f, 13.5f, 11f, 13.5f, 10f, 21.5f, 19f, 10f, 13f, 10f)
            I.DOWN -> { line(12f, 4f, 12f, 15f); poly(false, 7f, 10.5f, 12f, 15.5f, 17f, 10.5f); line(5f, 20f, 19f, 20f) }
            I.UP -> { line(12f, 16f, 12f, 5f); poly(false, 7f, 9.5f, 12f, 4.5f, 17f, 9.5f); line(5f, 20f, 19f, 20f) }
            I.SHARE -> { circ(6f, 12f, 2.6f); circ(18f, 6f, 2.6f); circ(18f, 18f, 2.6f); line(8.3f, 10.8f, 15.7f, 7.2f); line(8.3f, 13.2f, 15.7f, 16.8f) }
            I.PHONE -> { rr(7f, 2.5f, 17f, 21.5f, 2.5f); line(12f, 8f, 12f, 14f); poly(false, 9.2f, 11.5f, 12f, 14.3f, 14.8f, 11.5f); line(11f, 19f, 13f, 19f) }
            I.TRASH -> { line(4f, 7f, 20f, 7f); poly(false, 9f, 7f, 9f, 4f, 15f, 4f, 15f, 7f); poly(false, 6f, 7f, 7f, 20.5f, 17f, 20.5f, 18f, 7f); line(10f, 11f, 10f, 16.5f); line(14f, 11f, 14f, 16.5f) }
            I.RETRY -> {
                cv.drawArc(RectF(4f, 4f, 20f, 20f), -50f, 280f, false, p)
                val a = Math.toRadians(230.0)
                val ex = (12 + 8 * cos(a)).toFloat(); val ey = (12 + 8 * sin(a)).toFloat()
                val dx = (-sin(a)).toFloat(); val dy = cos(a).toFloat(); val nx = cos(a).toFloat(); val ny = sin(a).toFloat()
                p.style = Paint.Style.FILL
                path.reset(); path.moveTo(ex + dx * 3.6f, ey + dy * 3.6f)
                path.lineTo(ex + nx * 3.2f - dx * 0.8f, ey + ny * 3.2f - dy * 0.8f)
                path.lineTo(ex - nx * 3.2f - dx * 0.8f, ey - ny * 3.2f - dy * 0.8f)
                path.close(); cv.drawPath(path, p); p.style = Paint.Style.STROKE
            }
            I.CHECK -> poly(false, 5f, 12.5f, 10f, 17.5f, 19f, 7f)
            I.CROSS -> { line(6f, 6f, 18f, 18f); line(18f, 6f, 6f, 18f) }
            I.EXT -> { poly(false, 14f, 4f, 20f, 4f, 20f, 10f); line(20f, 4f, 11f, 13f); poly(false, 18f, 14.5f, 18f, 19f, 5f, 19f, 5f, 6f, 9.5f, 6f) }
            I.COPY -> { rr(9f, 9f, 20f, 20f, 2.5f); poly(false, 15f, 5f, 6.5f, 5f, 5f, 6.5f, 5f, 15f) }
            I.KEY -> { circ(8f, 15f, 4f); line(11f, 12f, 20f, 3f); line(17f, 6f, 19.5f, 8.5f); line(14f, 9f, 16f, 11f) }
            I.PALETTE -> { circ(12f, 12f, 9f); dot(8f, 10.5f, 1.3f); dot(12f, 7.5f, 1.3f); dot(16f, 10.5f, 1.3f); dot(8.5f, 15.5f, 1.3f) }
            I.VIBRATE -> { rr(8f, 3.5f, 16f, 20.5f, 2f); line(4.5f, 8f, 4.5f, 16f); line(19.5f, 8f, 19.5f, 16f); line(2f, 10.5f, 2f, 13.5f); line(22f, 10.5f, 22f, 13.5f) }
            I.SPARK -> poly(true, 12f, 3f, 14.3f, 9.7f, 21f, 12f, 14.3f, 14.3f, 12f, 21f, 9.7f, 14.3f, 3f, 12f, 9.7f, 9.7f)
            I.WAVE -> { path.reset(); path.moveTo(3f, 12f); path.quadTo(6f, 5f, 9f, 12f); path.quadTo(12f, 19f, 15f, 12f); path.quadTo(18f, 5f, 21f, 12f); cv.drawPath(path, p) }
            I.SEARCH -> { circ(10.5f, 10.5f, 6.5f); line(15.3f, 15.3f, 20.5f, 20.5f) }
            I.PLUS -> { line(12f, 5f, 12f, 19f); line(5f, 12f, 19f, 12f) }
            I.WARN -> { poly(true, 12f, 3.5f, 21.5f, 20f, 2.5f, 20f); line(12f, 9.5f, 12f, 14.5f); dot(12f, 17.3f, 1.1f) }
            I.INFO -> { circ(12f, 12f, 9f); line(12f, 11f, 12f, 16.5f); dot(12f, 7.8f, 1.1f) }
            I.BELL -> { cv.drawArc(RectF(6f, 5f, 18f, 17f), 180f, 180f, false, p); line(6f, 11f, 6f, 17f); line(18f, 11f, 18f, 17f); line(4f, 18f, 20f, 18f); cv.drawArc(RectF(10f, 19f, 14f, 23f), 0f, 180f, false, p) }
            I.CUBE -> { poly(true, 12f, 3f, 20f, 7.5f, 20f, 16.5f, 12f, 21f, 4f, 16.5f, 4f, 7.5f); poly(false, 4f, 7.5f, 12f, 12f, 20f, 7.5f); line(12f, 12f, 12f, 21f) }
            I.DISK -> { cv.drawOval(RectF(4f, 4f, 20f, 9f), p); line(4f, 6.5f, 4f, 17.5f); line(20f, 6.5f, 20f, 17.5f); cv.drawArc(RectF(4f, 15f, 20f, 20f), 0f, 180f, false, p) }
            I.FILE -> { poly(true, 6f, 3f, 14f, 3f, 19f, 8f, 19f, 21f, 6f, 21f); poly(false, 14f, 3f, 14f, 8f, 19f, 8f) }
            I.EYE -> { path.reset(); path.moveTo(2f, 12f); path.quadTo(12f, 3f, 22f, 12f); path.quadTo(12f, 21f, 2f, 12f); cv.drawPath(path, p); circ(12f, 12f, 3f) }
            I.BACK -> poly(false, 14.5f, 5f, 7.5f, 12f, 14.5f, 19f)
            I.GIT -> { circ(6f, 5.5f, 2.4f); circ(6f, 18.5f, 2.4f); circ(18f, 9f, 2.4f); line(6f, 7.9f, 6f, 16.1f); poly(false, 18f, 11.4f, 18f, 12.5f, 6f, 14.5f) }
            I.SAVE -> { rr(4f, 4f, 20f, 20f, 2.5f); poly(false, 8f, 4f, 8f, 9f, 16f, 9f, 16f, 4f); poly(false, 7.5f, 20f, 7.5f, 14f, 16.5f, 14f, 16.5f, 20f) }
            I.CLOUD -> { path.reset(); path.moveTo(7f, 18.5f); path.cubicTo(3f, 18.5f, 2.5f, 12.5f, 7f, 12f); path.cubicTo(7.5f, 7f, 15f, 6f, 16.5f, 11f); path.cubicTo(21.5f, 11f, 21.5f, 18.5f, 17f, 18.5f); path.close(); cv.drawPath(path, p) }
            else -> circ(12f, 12f, 9f)
        }
    }
}

open class IconView(c: Context, var kind: Int, private val sizeDp: Int = 22, var tint: Int = Color.WHITE) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; strokeWidth = 1.9f }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(dp(sizeDp), dp(sizeDp)) }
    override fun onDraw(cv: Canvas) {
        p.color = tint
        val s = min(width, height) / 24f
        cv.save(); cv.scale(s, s); Ic.draw(cv, kind, p); cv.restore()
    }
}

// ---------------------------------------------------------------- background
class AuroraView(c: Context) : View(c) {
    private val paints = Array(3) { Paint(Paint.ANTI_ALIAS_FLAG) }
    private val radii = FloatArray(3)
    private var phase = 0f
    private var anim: ValueAnimator? = null
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val p = Pal.p
        val cols = intArrayOf(p.a, p.b, p.c)
        val base = max(w, h) * 0.62f
        for (i in 0..2) {
            radii[i] = base * (if (i == 2) 0.8f else 1f)
            paints[i].shader = RadialGradient(0f, 0f, radii[i], withAlpha(cols[i], if (i == 2) 0x66 else 0x90), withAlpha(cols[i], 0), Shader.TileMode.CLAMP)
        }
    }
    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Pal.p.bg)
        val w = width.toFloat(); val h = height.toFloat(); val t = phase * 6.2831855f
        val xs = floatArrayOf(w * (0.15f + 0.12f * sin(t)), w * (0.9f + 0.1f * cos(t * 0.8f + 1f)), w * (0.55f + 0.18f * sin(t * 0.6f + 2f)))
        val ys = floatArrayOf(h * (0.1f + 0.08f * cos(t)), h * (0.9f + 0.07f * sin(t * 0.7f)), h * (0.5f + 0.12f * cos(t * 0.9f)))
        for (i in 0..2) { canvas.save(); canvas.translate(xs[i], ys[i]); canvas.drawCircle(0f, 0f, radii[i], paints[i]); canvas.restore() }
    }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (Cfg.reduceMotion) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 40000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedFraction; invalidate() }; start()
        }
    }
    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }
}

class GradText(c: Context) : TextView(c) {
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private var shader: LinearGradient? = null
    private val m = Matrix()
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val p = Pal.p
        shader = LinearGradient(0f, 0f, max(w, 1) * 2f, 0f, intArrayOf(p.c, Color.WHITE, p.b, p.a, p.c), null, Shader.TileMode.REPEAT)
    }
    override fun onDraw(canvas: Canvas) {
        val s = shader
        if (s != null) { m.setTranslate(-phase * max(width, 1) * 2f, 0f); s.setLocalMatrix(m); paint.shader = s }
        super.onDraw(canvas)
    }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (Cfg.reduceMotion) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 6000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedFraction; invalidate() }; start()
        }
    }
    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }
}

// ---------------------------------------------------------------- widgets
class GButton(c: Context, text: String, icon: Int?, private val primary: Boolean = true) : LinearLayout(c) {
    private var phase = 0f
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = tv(c, text, 15f, Color.WHITE, true)
    private val m = Matrix()
    private var shader: LinearGradient? = null
    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER; minimumHeight = dp(50)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        if (icon != null) addView(IconView(c, icon, 20), LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(9) })
        label.gravity = Gravity.CENTER
        addView(label, LayoutParams(WRAP, WRAP))
        setWillNotDraw(false)
        if (!primary) background = glass(18, 0x30, 0x10, 0x55)
    }
    fun text(t: String) { label.text = t }
    fun onTap(f: () -> Unit) { pressable { if (isEnabled) f() } }
    override fun setEnabled(enabled: Boolean) { super.setEnabled(enabled); alpha = if (enabled) 1f else 0.45f }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val p = Pal.p
        shader = LinearGradient(0f, 0f, max(w, 1) * 2f, 0f, intArrayOf(p.a, p.b, p.c, p.a), null, Shader.TileMode.REPEAT)
    }
    override fun onDraw(canvas: Canvas) {
        if (primary) {
            val s = shader
            if (s != null) { m.setTranslate(-phase * max(width, 1) * 2f, 0f); s.setLocalMatrix(m); paint.shader = s }
            canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), dpf(18), dpf(18), paint)
        }
        super.onDraw(canvas)
    }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!primary || Cfg.reduceMotion) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 7000; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedFraction; invalidate() }; start()
        }
    }
    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }
}

class Col(c: Context, private val maxDp: Int = 620) : LinearLayout(c) {
    init { orientation = VERTICAL }
    override fun onMeasure(w: Int, h: Int) {
        val size = MeasureSpec.getSize(w); val cap = dp(maxDp)
        super.onMeasure(if (size > cap) MeasureSpec.makeMeasureSpec(cap, MeasureSpec.EXACTLY) else w, h)
    }
}

class Ring(c: Context) : View(c) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dpf(10); color = withAlpha(Color.WHITE, 0x26) }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dpf(10); strokeCap = Paint.Cap.ROUND }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private var shown = 0f
    private var anim: ValueAnimator? = null
    private var bad = false
    fun set(p: Float, failed: Boolean = false) {
        bad = failed
        anim?.cancel()
        if (Cfg.reduceMotion) { shown = p; invalidate(); return }
        anim = ValueAnimator.ofFloat(shown, p).apply {
            duration = 700; interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }; start()
        }
    }
    override fun onMeasure(w: Int, h: Int) { val s = min(MeasureSpec.getSize(w), dp(190)); setMeasuredDimension(s, s) }
    override fun onDraw(cv: Canvas) {
        val s = min(width, height).toFloat(); val pad = dpf(10); val cx = width / 2f; val cy = height / 2f
        val r = RectF(cx - s / 2 + pad, cy - s / 2 + pad, cx + s / 2 - pad, cy + s / 2 - pad)
        cv.drawOval(r, track)
        val p = Pal.p
        arc.shader = SweepGradient(cx, cy, intArrayOf(if (bad) 0xFFFF5A5A.toInt() else p.c, if (bad) 0xFFFF9A5A.toInt() else p.b, if (bad) 0xFFFF5A5A.toInt() else p.c), null)
        cv.save(); cv.rotate(-90f, cx, cy); cv.drawArc(r, 0f, 360f * shown / 100f, false, arc); cv.restore()
        txt.textSize = s * 0.22f
        val fm = txt.fontMetrics
        cv.drawText("${shown.toInt()}%", cx, cy - (fm.ascent + fm.descent) / 2, txt)
    }
}

class StepDot(c: Context) : View(c) {
    private var state = 0
    private var pulse = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val k = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; strokeWidth = dpf(2.2f) }
    fun set(s: Int) {
        if (s == state && anim != null) return
        state = s; anim?.cancel(); anim = null
        if (s == 1 && !Cfg.reduceMotion) {
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1300; repeatCount = ValueAnimator.INFINITE
                addUpdateListener { pulse = it.animatedFraction; invalidate() }; start()
            }
        }
        invalidate()
    }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(dp(28), dp(28)) }
    override fun onDetachedFromWindow() { anim?.cancel(); anim = null; super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val r = dpf(11)
        val pal = Pal.p
        when (state) {
            2 -> { p.color = pal.c; cv.drawCircle(cx, cy, r, p); k.color = pal.bg
                val path = Path(); path.moveTo(cx - dpf(4.5f), cy); path.lineTo(cx - dpf(1.3f), cy + dpf(3.2f)); path.lineTo(cx + dpf(4.5f), cy - dpf(3.4f)); cv.drawPath(path, k) }
            1 -> { p.color = withAlpha(pal.b, ((1 - pulse) * 150).toInt()); cv.drawCircle(cx, cy, r + dpf(3) * pulse * 1.6f, p)
                p.color = pal.b; cv.drawCircle(cx, cy, r, p) }
            else -> { p.color = withAlpha(Color.WHITE, 0x28); cv.drawCircle(cx, cy, r, p) }
        }
    }
}

class Toggle(c: Context) : View(c) {
    var on = false
    var onChange: ((Boolean) -> Unit)? = null
    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    init { setOnClickListener { set(!on, true); Hap.tap(this); onChange?.invoke(on) } }
    fun set(v: Boolean, animate: Boolean) {
        on = v
        val to = if (v) 1f else 0f
        if (!animate || Cfg.reduceMotion) { t = to; invalidate(); return }
        ValueAnimator.ofFloat(t, to).apply {
            duration = 260; interpolator = OvershootInterpolator(1.4f)
            addUpdateListener { t = it.animatedValue as Float; invalidate() }; start()
        }
    }
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(dp(52), dp(30)) }
    override fun onDraw(cv: Canvas) {
        val tt = t.coerceIn(0f, 1f)
        p.color = ArgbEvaluator().evaluate(tt, withAlpha(Color.WHITE, 0x30), Pal.p.c) as Int
        cv.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), height / 2f, height / 2f, p)
        p.color = Color.WHITE
        val rad = height / 2f - dpf(3)
        cv.drawCircle(height / 2f + (width - height) * t, height / 2f, rad, p)
    }
}

class Chip(c: Context, text: String) : TextView(c) {
    var on = false
    init { this.text = text; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(16), dp(9), dp(16), dp(9)); paint(false) }
    private fun paint(v: Boolean) {
        background = if (v) solid(withAlpha(Pal.p.b, 0xD0), 20).also { it.setStroke(dp(1), withAlpha(Color.WHITE, 0x77)) } else glass(20, 0x28, 0x0C, 0x40)
    }
    fun select(v: Boolean) { on = v; paint(v); animate().scaleX(if (v) 1.06f else 1f).scaleY(if (v) 1.06f else 1f).setDuration(200).start() }
}

class Spinner(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = dpf(3.5f); strokeCap = Paint.Cap.ROUND; color = Pal.p.c }
    private var a = 0f
    private var anim: ValueAnimator? = null
    override fun onMeasure(w: Int, h: Int) { setMeasuredDimension(dp(34), dp(34)) }
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { a = it.animatedValue as Float; invalidate() }; start()
        }
    }
    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(cv: Canvas) {
        val pad = dpf(4)
        cv.save(); cv.rotate(a, width / 2f, height / 2f)
        cv.drawArc(RectF(pad, pad, width - pad, height - pad), 0f, 250f, false, p); cv.restore()
    }
}

class NavBar(c: Context, private val items: List<Pair<Int, String>>, private val onSel: (Int) -> Unit) : FrameLayout(c) {
    private val ind = View(c)
    private val row = LinearLayout(c)
    private val cells = ArrayList<LinearLayout>()
    private val icons = ArrayList<IconView>()
    private val labels = ArrayList<TextView>()
    private var vertical = false
    var sel = 0
    init {
        background = glass(26, 0x30, 0x10, 0x55)
        ind.background = glass(20, 0x66, 0x2A, 0x80)
        addView(ind, LayoutParams(1, 1))
        addView(row, LayoutParams(MATCH, MATCH))
        row.setPadding(dp(6), dp(6), dp(6), dp(6))
        items.forEachIndexed { i, it ->
            val cell = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)) }
            val iv = IconView(c, it.first, 24)
            val lb = tv(c, it.second, 11f, Color.WHITE, false, 0.7f)
            lb.gravity = Gravity.CENTER
            cell.addView(iv, LinearLayout.LayoutParams(dp(24), dp(24)))
            cell.addView(lb, lp(WRAP, WRAP, 0, 3, 0, 0))
            cell.pressable { select(i, true); onSel(i) }
            row.addView(cell, LinearLayout.LayoutParams(0, MATCH, 1f))
            cells.add(cell); icons.add(iv); labels.add(lb)
        }
        paintSel(false)
    }
    fun setVertical(v: Boolean) {
        vertical = v
        row.orientation = if (v) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
        cells.forEach { it.layoutParams = if (v) LinearLayout.LayoutParams(MATCH, 0, 1f) else LinearLayout.LayoutParams(0, MATCH, 1f) }
        requestLayout()
    }
    private fun paintSel(animate: Boolean) {
        for (i in cells.indices) {
            val on = i == sel
            val a = labels[i]; a.setTextColor(withAlpha(Color.WHITE, if (on) 255 else 170))
            if (animate) icons[i].animate().scaleX(if (on) 1.18f else 1f).scaleY(if (on) 1.18f else 1f).setDuration(260).start()
            else { icons[i].scaleX = if (on) 1.18f else 1f; icons[i].scaleY = icons[i].scaleX }
        }
    }
    fun select(i: Int, animate: Boolean) { sel = i; paintSel(animate); place(animate) }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) { super.onLayout(changed, l, t, r, b); place(false) }
    private fun place(animate: Boolean) {
        val cell = cells.getOrNull(sel) ?: return
        if (cell.width == 0) return
        ind.layout(0, 0, cell.width, cell.height)
        val tx = (cell.left + row.paddingLeft - row.paddingLeft).toFloat() + row.left
        val ty = cell.top.toFloat() + row.top
        if (animate && !Cfg.reduceMotion) ind.animate().translationX(tx).translationY(ty).setDuration(400).setInterpolator(OvershootInterpolator(0.8f)).start()
        else { ind.animate().cancel(); ind.translationX = tx; ind.translationY = ty }
    }
}

class Pager(c: Context, private val pages: List<View>) : FrameLayout(c) {
    var cur = -1
    init { pages.forEach { addView(it, LayoutParams(MATCH, MATCH)); it.visibility = View.GONE } }
    fun show(i: Int) {
        if (i == cur) return
        val old = if (cur >= 0) pages[cur] else null
        val nw = pages[i]
        val dir = if (i > cur) 1 else -1
        cur = i
        if (old != null) {
            old.animate().cancel()
            old.animate().alpha(0f).translationX(-dir * dpf(28)).setDuration(200).withEndAction { if (pages[cur] !== old) old.visibility = View.GONE }.start()
        }
        nw.animate().cancel()
        nw.visibility = View.VISIBLE; nw.alpha = 0f; nw.translationX = dir * dpf(28)
        nw.animate().alpha(1f).translationX(0f).setDuration(340).setInterpolator(DecelerateInterpolator(1.6f)).start()
    }
}

object Toasts {
    var host: ToastHost? = null
    fun show(m: String) { Bg.ui { host?.show(m) } }
}

class ToastHost(c: Context) : FrameLayout(c) {
    private val t = tv(c, "", 14f, Color.WHITE, true)
    private val hide = Runnable { t.animate().alpha(0f).translationY(-dpf(20)).setDuration(260).withEndAction { t.visibility = View.GONE }.start() }
    init {
        t.gravity = Gravity.CENTER; t.setPadding(dp(20), dp(12), dp(20), dp(12)); t.visibility = View.GONE
        t.background = solid(withAlpha(Color.BLACK, 0xE6), 24).also { it.setStroke(dp(1), withAlpha(Color.WHITE, 0x55)) }
        addView(t, LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(70); leftMargin = dp(16); rightMargin = dp(16) })
        isClickable = false
    }
    override fun onTouchEvent(e: MotionEvent?): Boolean = false
    fun show(m: String) {
        t.text = m; t.animate().cancel(); t.visibility = View.VISIBLE; t.alpha = 0f; t.translationY = -dpf(24)
        t.animate().alpha(1f).translationY(0f).setDuration(340).setInterpolator(OvershootInterpolator(1.2f)).start()
        removeCallbacks(hide); postDelayed(hide, 2800)
    }
}

class ConfettiView(c: Context) : View(c) {
    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var r: Float, var vr: Float, val s: Float, val col: Int)
    private var ps: List<P> = emptyList()
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    fun burst() {
        if (width == 0) return
        val p = Pal.p
        val cols = intArrayOf(Color.WHITE, p.a, p.b, p.c)
        ps = List(110) { P(width / 2f, height * 0.6f, (Math.random().toFloat() - 0.5f) * dpf(16), -(Math.random().toFloat() * dpf(18) + dpf(5)),
            Math.random().toFloat() * 6f, (Math.random().toFloat() - 0.5f) * 0.4f, dpf(5) + Math.random().toFloat() * dpf(6), cols[(Math.random() * cols.size).toInt()]) }
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            addUpdateListener { ps.forEach { q -> q.vy += dpf(0.45f); q.x += q.vx; q.y += q.vy; q.r += q.vr }; invalidate() }
            start()
        }
    }
    override fun onTouchEvent(e: MotionEvent?): Boolean = false
    override fun onDraw(cv: Canvas) {
        ps.forEach { q ->
            paint.color = q.col
            cv.save(); cv.translate(q.x, q.y); cv.rotate(Math.toDegrees(q.r.toDouble()).toFloat())
            cv.drawRect(-q.s / 2, -q.s / 2, q.s / 2, q.s * 0.3f, paint); cv.restore()
        }
    }
}

// ---------------------------------------------------------------- sheets
class Sheet(private val act: Activity) {
    private val dlg = Dialog(act, android.R.style.Theme_Translucent_NoTitleBar)
    fun dismiss() { try { dlg.dismiss() } catch (e: Exception) { } }
    fun show(title: String?, build: (LinearLayout, Sheet) -> Unit) {
        val root = FrameLayout(act)
        root.setBackgroundColor(Color.argb(150, 0, 0, 0))
        root.setOnClickListener { dismiss() }
        val box = Col(act, 560)
        val bgc = ArgbEvaluator().evaluate(0.12f, Pal.p.bg, Color.WHITE) as Int
        val g = GradientDrawable(); g.setColor(withAlpha(bgc, 0xF4))
        val r = dpf(28); g.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f); g.setStroke(dp(1), withAlpha(Color.WHITE, 0x44))
        box.background = g; box.setPadding(dp(18), dp(10), dp(18), dp(22)); box.isClickable = true
        val bar = View(act); bar.background = solid(withAlpha(Color.WHITE, 0x55), 3)
        box.addView(bar, lp(dp(44), dp(5), 0, 0, 0, 12).also { it.gravity = Gravity.CENTER_HORIZONTAL })
        if (title != null) box.addView(tv(act, title, 17f, Color.WHITE, true), lp(MATCH, WRAP, 2, 2, 2, 12))
        build(box, this)
        root.addView(box, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        dlg.setContentView(root)
        dlg.window?.setLayout(MATCH, MATCH)
        dlg.show()
        box.translationY = dpf(420)
        box.animate().translationY(0f).setDuration(380).setInterpolator(DecelerateInterpolator(2f)).start()
    }
}

fun sheetRow(c: Context, icon: Int, text: String, danger: Boolean = false, onClick: () -> Unit): LinearLayout {
    val row = LinearLayout(c)
    row.orientation = LinearLayout.HORIZONTAL; row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(dp(14), dp(13), dp(14), dp(13)); row.background = glass(16, 0x22, 0x0A, 0x33)
    val col = if (danger) 0xFFFF6B6B.toInt() else Color.WHITE
    row.addView(IconView(c, icon, 22, col), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(14) })
    row.addView(tv(c, text, 15f, col, false))
    row.pressable(onClick)
    return row
}

fun confirm(act: Activity, title: String, msg: String, okText: String, onOk: () -> Unit) {
    Sheet(act).show(title) { box, sh ->
        box.addView(tv(act, msg, 14f, Color.WHITE, false, 0.8f), lp(MATCH, WRAP, 2, 0, 2, 16))
        val row = LinearLayout(act); row.orientation = LinearLayout.HORIZONTAL
        val no = GButton(act, "বাতিল", null, false); no.onTap { sh.dismiss() }
        val ok = GButton(act, okText, I.TRASH, true); ok.onTap { sh.dismiss(); onOk() }
        row.addView(no, lp(0, WRAP, 0, 0, 6, 0).also { it.weight = 1f })
        row.addView(ok, lp(0, WRAP, 6, 0, 0, 0).also { it.weight = 1f })
        box.addView(row, lp())
    }
}

class BobIcon(c: Context, kind: Int, sizeDp: Int = 44, tint: Int = Color.WHITE) : IconView(c, kind, sizeDp, tint) {
    private var anim: ValueAnimator? = null
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (Cfg.reduceMotion) return
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2600; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            addUpdateListener { translationY = -dpf(9) * (it.animatedValue as Float); rotation = -5f * (it.animatedValue as Float) }; start()
        }
    }
    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }
}

class Flow(c: Context, private val gap: Int = 6) : ViewGroup(c) {
    override fun onMeasure(w: Int, h: Int) {
        val maxW = MeasureSpec.getSize(w) - paddingLeft - paddingRight
        var x = 0; var y = 0; var lineH = 0; val g = dp(gap)
        for (i in 0 until childCount) {
            val v = getChildAt(i); if (v.visibility == GONE) continue
            v.measure(MeasureSpec.makeMeasureSpec(maxW, MeasureSpec.AT_MOST), MeasureSpec.UNSPECIFIED)
            if (x > 0 && x + v.measuredWidth > maxW) { x = 0; y += lineH + g; lineH = 0 }
            x += v.measuredWidth + g; lineH = max(lineH, v.measuredHeight)
        }
        setMeasuredDimension(MeasureSpec.getSize(w), y + lineH + paddingTop + paddingBottom)
    }
    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l - paddingLeft - paddingRight
        var x = 0; var y = 0; var lineH = 0; val g = dp(gap)
        for (i in 0 until childCount) {
            val v = getChildAt(i); if (v.visibility == GONE) continue
            if (x > 0 && x + v.measuredWidth > maxW) { x = 0; y += lineH + g; lineH = 0 }
            v.layout(paddingLeft + x, paddingTop + y, paddingLeft + x + v.measuredWidth, paddingTop + y + v.measuredHeight)
            x += v.measuredWidth + g; lineH = max(lineH, v.measuredHeight)
        }
    }
}
