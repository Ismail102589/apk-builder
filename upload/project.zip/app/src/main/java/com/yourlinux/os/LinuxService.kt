package com.yourlinux.os

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.system.Os
import java.io.BufferedReader
import java.io.File
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket

class LinuxService : Service() {
    companion object {
        const val ACTION_START = "com.yourlinux.os.START"
        const val ACTION_STOP = "com.yourlinux.os.STOP"
        const val ACTION_RESET = "com.yourlinux.os.RESET"
        const val EXTRA_GEOMETRY = "geometry"
        const val VNC_PORT = 5901
        const val PREP_VERSION = "6"
        @Volatile var sessionAlive = false
        private const val CH = "yourlinux"
        private const val NOTIF_ID = 1
    }

    private var worker: Thread? = null
    @Volatile private var sessionProc: Process? = null
    @Volatile private var stopping = false
    private var geometry = "1280x576"
    @Volatile private var linuxStage = false
    @Volatile private var suspectProot = false
    private var lastNotifMsg = ""
    private var lastNotifTime = 0L
    private var wake: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private val listener: () -> Unit = { updateNotification() }

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "YOUR Linux OS", NotificationManager.IMPORTANCE_LOW))
        SessionState.addListener(listener)
        val pf = getSharedPreferences("yl", MODE_PRIVATE)
        if (pf.getInt("perf_ver", 0) < 2) {
            pf.edit().putBoolean("fast", true).putBoolean("fast_fallback_done", false).putInt("perf_ver", 2).apply()
        }
    }

    override fun onDestroy() {
        SessionState.removeListener(listener)
        killSession()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification(SessionState.message.ifEmpty { "শুরু হচ্ছে…" }))
        intent?.getStringExtra(EXTRA_GEOMETRY)?.let { geometry = it }
        when (intent?.action) {
            ACTION_STOP -> {
                killSession()
                SessionState.update(Phase.IDLE, 0, "")
                stopForeground(true)
                stopSelf()
            }
            ACTION_RESET -> Thread {
              try {
                killSession()
                worker?.join(5000)
                val env = Env(this)
                env.deleteTree(env.rootfs)
                env.deleteTree(env.state)
                File(env.files, "rootfs.tar.gz").delete()
                File(env.files, "rootfs.tar.gz.part").delete()
                SessionState.clearLog()
                SessionState.items = emptyList()
                SessionState.update(Phase.IDLE, 0, "রিসেট হয়েছে")
                startPipeline()
              } catch (e: Throwable) {
                SessionState.update(Phase.ERROR, message = "রিসেট ব্যর্থ: ${e.message}")
              }
            }.start()
            else -> {
                if (worker?.isAlive != true && !(SessionState.phase == Phase.RUNNING && sessionProc?.isAlive == true)) {
                    SessionState.update(Phase.STARTING, 0, "শুরু হচ্ছে…")
                }
                startPipeline()
            }
        }
        return START_NOT_STICKY
    }

    private fun startPipeline() {
        if (worker?.isAlive == true) return
        stopping = false
        worker = Thread({ runPipeline() }, "yourlinux-pipeline").also { it.start() }
    }

    private fun runPipeline() {
        val env = Env(this)
        linuxStage = false
        suspectProot = false
        try {
            try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_DISPLAY) } catch (_: Exception) {}
            acquireWake()
            env.prepare()
            if (!env.prootBin.exists()) {
                throw IOException("proot ফাইল APK-তে নেই (libproot.so)। বিল্ডের 'Fetch proot' ধাপ দেখুন।")
            }
            val existing = sessionProc
            if (existing != null && existing.isAlive) {
                SessionState.update(Phase.STARTING, 100, "ডেস্কটপ চালু হচ্ছে…")
                awaitDesktop(env, existing)
                return
            }
            if (!env.rootfsReadyFlag.exists()) installRootfs(env)
            RootfsInstaller.installScripts(this, env)
            linuxStage = true
            if (!env.setupDone()) {
                ensurePackages(env)
                releaseWifi()
                runSetup(env)
            }
            releaseWifi()
            startSession(env)
        } catch (e: Throwable) {
            if (!stopping) {
                val prefs = getSharedPreferences("yl", MODE_PRIVATE)
                if (suspectProot && prefs.getBoolean("fast", true) && !prefs.getBoolean("fast_fallback_done", false)) {
                    prefs.edit().putBoolean("fast", false).putBoolean("fast_fallback_done", true).apply()
                    SessionState.log("দ্রুত মোডে সমস্যা (${e.message}); সাধারণ মোডে আবার চেষ্টা হচ্ছে…")
                    runPipeline()
                    return
                }
                SessionState.log("ত্রুটি: ${e.message ?: e}")
                SessionState.update(Phase.ERROR, message = e.message ?: e.toString())
                try { wake?.release() } catch (_: Exception) {}
                wake = null
                releaseWifi()
            }
        }
    }

    // ---------- ধাপ ১: বেস সিস্টেম (ডাউনলোড + এক্সট্র্যাক্ট) ----------

    private fun installRootfs(env: Env) {
        if (env.files.usableSpace < 3L * 1024 * 1024 * 1024) {
            throw IOException("ফোনে অন্তত ৩ GB ফাঁকা জায়গা দরকার")
        }
        SessionState.clearLog()
        SessionState.stat1 = ""
        SessionState.stat2 = ""
        SessionState.update(Phase.DOWNLOADING, 0, "Ubuntu বেস সিস্টেম ডাউনলোড হচ্ছে…")
        val archive = File(env.files, "rootfs.tar.gz")
        val item = DlItem("Ubuntu 22.04 বেস সিস্টেম", RootfsInstaller.ROOTFS_URL, archive, 0L)
        Downloader(listOf(item), 1, { isOnline() }, { stopping }, 0, 8).run()

        SessionState.stat1 = ""
        SessionState.stat2 = ""
        SessionState.update(Phase.EXTRACTING, 8, "ফাইল এক্সট্র্যাক্ট হচ্ছে…")
        env.deleteTree(env.rootfs)
        env.rootfs.mkdirs()
        RootfsInstaller.extract(archive, env.rootfs) { pct ->
            SessionState.update(Phase.EXTRACTING, 8 + pct * 4 / 100, "ফাইল এক্সট্র্যাক্ট হচ্ছে… $pct%")
        }
        archive.delete()
        RootfsInstaller.finalizeRootfs(this, env)
        env.rootfsReadyFlag.writeText("ok")
        item.state = DlItem.INSTALLED
    }

    // ---------- ধাপ ২: তালিকা তৈরি + সমান্তরাল ডাউনলোড ----------

    private fun ensurePackages(env: Env) {
        val prepFlag = File(env.rootfs, "root/.prep_done")
        val prepOk = { prepFlag.exists() && prepFlag.readText().trim() == PREP_VERSION }
        if (!prepOk()) {
            SessionState.stat1 = ""
            SessionState.stat2 = ""
            SessionState.items = emptyList()
            SessionState.update(Phase.PREPARING, 12, "সবচেয়ে দ্রুত সার্ভার খোঁজা হচ্ছে…")
            acquireWifi()
            val mirror = MirrorPicker.pick { SessionState.log(it) }
            SessionState.log("নির্বাচিত সার্ভার: $mirror")
            var ok = runPrep(env, mirror)
            if (!ok && mirror != MirrorPicker.DEFAULT && !stopping) {
                SessionState.log("অন্য সার্ভারে আবার চেষ্টা হচ্ছে…")
                ok = runPrep(env, MirrorPicker.DEFAULT)
            }
            if (!ok) throw IOException("প্যাকেজ তালিকা তৈরি হয়নি। ইন্টারনেট চেক করে 'আবার চেষ্টা' চাপুন।")
        }
        acquireWifi()
        val list = ArrayList<DlItem>()
        list.addAll(PackageList.parse(env))
        SessionState.update(Phase.DOWNLOADING, 14, "প্যাকেজ ডাউনলোড হচ্ছে…")
        Downloader(list, 10, { isOnline() }, { stopping }, 14, 60).run()
    }

    private fun writeSources(env: Env, mirror: String) {
        val f = File(env.rootfs, "etc/apt/sources.list")
        f.parentFile?.mkdirs()
        try { Os.remove(f.path) } catch (_: Exception) {}
        f.writeText(
            "deb $mirror jammy main universe\n" +
                "deb $mirror jammy-updates main universe\n" +
                "deb $mirror jammy-security main universe\n"
        )
    }

    private fun runPrep(env: Env, mirror: String): Boolean {
        writeSources(env, mirror)
        val flag = File(env.rootfs, "root/.prep_done")
        flag.delete()
        SessionState.update(Phase.PREPARING, 13, "প্যাকেজ তালিকা আপডেট হচ্ছে…")
        val p = env.prootProcess(listOf("/bin/bash", "/root/prep.sh")).start()
        sessionProc = p
        try {
            BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).forEachLine { line ->
                if (line.startsWith("##STEP ")) SessionState.update(message = line.substring(7))
                else SessionState.log(line)
            }
            if (p.waitFor() >= 126) suspectProot = true
        } finally {
            sessionProc = null
        }
        return flag.exists() && flag.readText().trim() == PREP_VERSION
    }

    // ---------- ধাপ ৩: ইনস্টল ----------

    private fun runSetup(env: Env) {
        SessionState.update(Phase.CONFIGURING, 60, "প্যাকেজ ইনস্টল হচ্ছে…")
        val items = SessionState.items
        val byName = HashMap<String, DlItem>()
        for (it in items) byName[it.name] = it
        var total = if (items.isNotEmpty()) items.size else 300
        var unpacked = 0
        var configured = 0
        var seqNo = 0L
        var running = false
        var current: DlItem? = null
        val stamps = ArrayDeque<Long>()

        fun setStep(t: String) {
            SessionState.step = t
            SessionState.stepStart = System.currentTimeMillis()
        }
        fun publish() {
            if (configured > total) total = configured + 50
            val now = System.currentTimeMillis()
            while (stamps.size > 12) stamps.removeFirst()
            val eta = if (stamps.size >= 6) {
                val per = (now - stamps.first()) / (stamps.size - 1).toDouble() / 1000.0
                ((total - configured) * per).toLong()
            } else -1L
            SessionState.stat1 = "ফাইল বসানো: " + Fmt.bn("$unpacked/$total") + "  •  কনফিগার: " + Fmt.bn("$configured/$total")
            SessionState.stat2 = if (eta >= 0L) "বাকি প্রায়: " + Fmt.eta(eta)
            else "এই ধাপ ফোনে ধীর — ২০-৬০ মিনিট লাগা স্বাভাবিক"
            SessionState.progress = 60 + 20 * minOf(unpacked, total) / total + 18 * minOf(configured, total) / total
            SessionState.touch()
        }
        fun finishRunning() {
            if (running) {
                configured++
                stamps.addLast(System.currentTimeMillis())
                running = false
            }
            val c = current
            if (c != null && c.state != DlItem.INSTALLED) {
                c.state = DlItem.INSTALLED
                c.seq = ++seqNo
            }
            current = null
        }

        val p = env.prootProcess(listOf("/bin/bash", "/root/setup.sh")).start()
        sessionProc = p
        try {
            BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).forEachLine { line ->
                if (line.startsWith("##STEP ")) {
                    SessionState.update(message = line.substring(7))
                    setStep(line.substring(7))
                } else {
                    if (line.startsWith("Unpacking ")) {
                        val name = line.removePrefix("Unpacking ").substringBefore(' ').substringBefore(':')
                        unpacked++
                        val item = byName[name]
                        if (item != null && item.state < DlItem.UNPACKED) {
                            item.state = DlItem.UNPACKED
                            item.seq = ++seqNo
                        }
                        setStep("ফাইল বসানো হচ্ছে: $name")
                        publish()
                    } else if (line.startsWith("Setting up ")) {
                        val name = line.removePrefix("Setting up ").substringBefore(' ').substringBefore(':')
                        finishRunning()
                        running = true
                        val item = byName[name]
                        if (item != null) {
                            item.state = DlItem.CONFIGURING
                            item.seq = ++seqNo
                            current = item
                        }
                        setStep("কনফিগার হচ্ছে: $name")
                        publish()
                    } else if (line.startsWith("Processing triggers for ")) {
                        finishRunning()
                        val name = line.removePrefix("Processing triggers for ").substringBefore(' ')
                        setStep("ট্রিগার চলছে: $name (ভারী হতে পারে)")
                        publish()
                    }
                    SessionState.log(line)
                }
            }
            val code = p.waitFor()
            if (code >= 126) suspectProot = true
            finishRunning()
            if (!env.setupDone()) {
                throw IOException("ইনস্টল সম্পূর্ণ হয়নি (কোড $code)। লগ দেখে 'আবার চেষ্টা' চাপুন।")
            }
            for (it in items) it.state = DlItem.INSTALLED
            SessionState.step = ""
        } finally {
            sessionProc = null
        }
    }

    private fun startSession(env: Env) {
        SessionState.stat1 = ""
        SessionState.stat2 = ""
        SessionState.update(Phase.STARTING, 100, "ডেস্কটপ চালু হচ্ছে…")
        SessionState.step = "ডেস্কটপ চালু হচ্ছে (প্রথমবার ১-৩ মিনিট লাগে)"
        SessionState.stepStart = System.currentTimeMillis()
        env.desktopReadyFlag.delete()
        val envs = arrayListOf(
            "VNC_GEOMETRY=$geometry",
            "YL_CORES=${Runtime.getRuntime().availableProcessors()}"
        )
        val prefs = getSharedPreferences("yl", MODE_PRIVATE)
        if (prefs.getBoolean("glass", false)) envs.add("YL_GLASS=1")
        envs.add("YL_STYLE=" + (prefs.getString("style", "cutefish") ?: "cutefish"))
        val p = env.prootProcess(listOf("/bin/bash", "/root/start-desktop.sh"), envs).start()
        sessionProc = p
        Thread({
            try {
                BufferedReader(InputStreamReader(p.inputStream, Charsets.UTF_8)).forEachLine { SessionState.log(it) }
            } catch (_: Exception) {}
            val code = try { p.waitFor() } catch (_: Exception) { -1 }
            if (sessionProc === p) sessionAlive = false
            if (!stopping && sessionProc === p && SessionState.phase == Phase.RUNNING) {
                SessionState.update(Phase.ERROR, message = "Linux সেশন বন্ধ হয়ে গেছে (কোড $code)")
                try { wake?.release() } catch (_: Exception) {}
                wake = null
            }
        }, "yourlinux-session").start()
        awaitDesktop(env, p)
    }

    private fun dumpSessionLogs(env: Env) {
        for (n in listOf("xvnc.log", "xfce.log")) {
            try {
                val lines = File(env.rootfs, "tmp/$n").readLines().takeLast(25)
                SessionState.log("--- $n ---")
                for (l in lines) SessionState.log(l)
            } catch (_: Exception) {}
        }
    }

    private fun awaitDesktop(env: Env, p: Process) {
        val deadline = System.currentTimeMillis() + 240_000
        while (System.currentTimeMillis() < deadline) {
            if (!p.isAlive) {
                val ec = try { p.exitValue() } catch (_: Exception) { 0 }
                if (ec >= 126) suspectProot = true
                dumpSessionLogs(env)
                throw IOException("ডেস্কটপ চালু হয়নি। লগ দেখুন।")
            }
            if (env.desktopReadyFlag.exists() && portOpen()) {
                sessionAlive = true
                SessionState.update(Phase.RUNNING, 100, "প্রস্তুত")
                return
            }
            Thread.sleep(700)
        }
        dumpSessionLogs(env)
        throw IOException("ডেস্কটপ চালু হতে অনেক সময় লাগছে (টাইমআউট)। 'আবার চেষ্টা' চাপুন।")
    }

    private fun portOpen(): Boolean = try {
        Socket().use { it.connect(InetSocketAddress("127.0.0.1", VNC_PORT), 300) }
        true
    } catch (_: Exception) { false }

    private fun isOnline(): Boolean = try {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) { true }

    private fun killSession() {
        stopping = true
        sessionAlive = false
        try { sessionProc?.destroyForcibly() } catch (_: Exception) {}
        sessionProc = null
        try { wake?.release() } catch (_: Exception) {}
        wake = null
        releaseWifi()
    }

    private fun acquireWake() {
        if (wake == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "yourlinux:session").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    /** ডাউনলোডের সময় WiFi সর্বোচ্চ পারফরম্যান্স মোডে রাখে */
    @Suppress("DEPRECATION")
    private fun acquireWifi() {
        if (wifiLock != null) return
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
            else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock = wm.createWifiLock(mode, "yourlinux:download").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {}
    }

    private fun releaseWifi() {
        try { wifiLock?.release() } catch (_: Exception) {}
        wifiLock = null
    }

    private fun updateNotification() {
        val now = System.currentTimeMillis()
        if (now - lastNotifTime < 2000L) return
        val base = SessionState.message.ifEmpty { "YOUR Linux OS" }
        val s1 = SessionState.stat1
        val msg = if (s1.isNotEmpty() && SessionState.phase != Phase.RUNNING) "$base • $s1" else base
        if (msg == lastNotifMsg) return
        lastNotifTime = now
        lastNotifMsg = msg
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(msg))
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, SplashActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getForegroundService(
            this, 1, Intent(this, LinuxService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setContentTitle("YOUR Linux OS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete), "বন্ধ করুন", stop
                ).build()
            )
            .build()
    }
}
