package com.yourlinux.os

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/** ডাউনলোডের সময় খেলার জন্য ডাইনোসর রানার গেম (ট্যাপ = লাফ) */
class DinoView(ctx: Context) : View(ctx) {
    companion object {
        private val BODY = arrayOf(
            "..........########..",
            ".........##########.",
            ".........###.######.",
            ".........##########.",
            ".........##########.",
            ".........#####......",
            ".........#########..",
            "#.......###########.",
            "#.......###########.",
            "##.....############.",
            "##....#############.",
            "###..##############.",
            "###.###############.",
            ".##############.....",
            "..#############.....",
            "...###########......",
            "....##########......"
        )
        private val LEGS_A = arrayOf(
            ".....####...##......",
            ".....##.....##......",
            ".....####..........."
        )
        private val LEGS_B = arrayOf(
            ".....##...####......",
            ".....##.....##......",
            "...........####....."
        )
    }

    private val d = ctx.resources.displayMetrics.density
    private val prefs = ctx.getSharedPreferences("yl", Context.MODE_PRIVATE)
    private val fg = Color.parseColor("#C9CCD1")
    private val paint = Paint().apply { color = fg; isAntiAlias = true }
    private val textPaint = Paint().apply {
        color = fg
        isAntiAlias = true
        typeface = Typeface.MONOSPACE
        textSize = 12f * d
    }
    private val sprite = Paint()
    private val dinoA: Bitmap = makeDino(LEGS_A)
    private val dinoB: Bitmap = makeDino(LEGS_B)

    private var started = false
    private var dead = false
    private var yOff = 0f
    private var vy = 0f
    private var score = 0f
    private var hi = prefs.getInt("dino_hi", 0)
    private var speed = 260f * d
    private val obs = ArrayList<FloatArray>()
    private var nextGap = 0f
    private var last = 0L
    private var legT = 0f
    private var legFrame = false
    private val rnd = java.util.Random()
    private var groundShift = 0f

    private val dinoW = 40f * d
    private val dinoH = 40f * d
    private val dinoX = 36f * d

    private fun makeDino(legs: Array<String>): Bitmap {
        val rows = BODY + legs
        val bmp = Bitmap.createBitmap(20, rows.size, Bitmap.Config.ARGB_8888)
        for (y in rows.indices) {
            for (x in 0 until 20) {
                if (rows[y][x] == '#') bmp.setPixel(x, y, fg)
            }
        }
        return bmp
    }

    private fun reset() {
        started = true
        dead = false
        yOff = 0f
        vy = 0f
        score = 0f
        speed = 260f * d
        obs.clear()
        nextGap = 300f * d
        last = 0L
        groundShift = 0f
    }

    private fun jump() {
        if (yOff <= 0f) vy = 640f * d
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            if (dead || !started) reset()
            jump()
            invalidate()
        }
        return true
    }

    private fun update(dt: Float) {
        if (!started || dead) return
        speed = min(520f * d, speed + 9f * d * dt)
        vy -= 2600f * d * dt
        yOff += vy * dt
        if (yOff <= 0f) {
            yOff = 0f
            vy = 0f
        }
        score += speed * dt / (9f * d)
        groundShift = (groundShift + speed * dt) % (60f * d)
        legT += dt
        if (legT > 0.09f) {
            legT = 0f
            legFrame = !legFrame
        }
        for (o in obs) o[0] -= speed * dt
        obs.removeAll { it[0] + it[1] < 0f }
        nextGap -= speed * dt
        if (nextGap <= 0f && (obs.isEmpty() || obs[obs.size - 1][0] < width - 200f * d)) {
            val h = (28 + rnd.nextInt(18)) * d
            val w = (14 + rnd.nextInt(10)) * d
            obs.add(floatArrayOf(width.toFloat(), w, h))
            nextGap = (220f + rnd.nextInt(260)) * d
        }
        val gy = height - 26f * d
        val dl = dinoX + 8f * d
        val dr = dinoX + dinoW - 8f * d
        val db = gy - yOff - 3f * d
        for (o in obs) {
            val ol = o[0]
            val orr = o[0] + o[1]
            val ot = gy - o[2]
            if (dr > ol && dl < orr && db > ot) {
                dead = true
                val s = score.toInt()
                if (s > hi) {
                    hi = s
                    prefs.edit().putInt("dino_hi", hi).apply()
                }
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                break
            }
        }
    }

    private fun drawCactus(c: Canvas, x: Float, gy: Float, w: Float, h: Float) {
        val tw = w * 0.4f
        val tx = x + (w - tw) / 2f
        c.drawRoundRect(RectF(tx, gy - h, tx + tw, gy), tw / 2f, tw / 2f, paint)
        val aw = tw * 0.75f
        val ly = gy - h * 0.55f
        c.drawRect(x, ly, tx + 1f, ly + aw, paint)
        c.drawRoundRect(RectF(x, ly - h * 0.28f, x + aw, ly + aw), aw / 2f, aw / 2f, paint)
        val ry = gy - h * 0.40f
        c.drawRect(tx + tw - 1f, ry, x + w, ry + aw, paint)
        c.drawRoundRect(RectF(x + w - aw, ry - h * 0.22f, x + w, ry + aw), aw / 2f, aw / 2f, paint)
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        var dt = if (last == 0L) 0f else (now - last) / 1_000_000_000f
        last = now
        dt = min(dt, 0.04f)
        update(dt)

        val gy = height - 26f * d
        paint.strokeWidth = 2f * d
        c.drawLine(8f * d, gy, width - 8f * d, gy, paint)
        var sx = 8f * d - groundShift
        while (sx < width) {
            if (sx > 8f * d) c.drawRect(sx, gy + 6f * d, sx + 8f * d, gy + 8f * d, paint)
            sx += 60f * d
        }
        for (o in obs) drawCactus(c, o[0], gy, o[1], o[2])

        val bmp = if (!started || dead || yOff > 0f || legFrame) dinoA else dinoB
        c.drawBitmap(bmp, null, RectF(dinoX, gy - yOff - dinoH, dinoX + dinoW, gy - yOff), sprite)

        val s = String.format(java.util.Locale.US, "HI %05d  %05d", hi, score.toInt())
        c.drawText(s, width - 8f * d - textPaint.measureText(s), 20f * d, textPaint)
        if (!started) {
            val m = "ট্যাপ করে খেলা শুরু করুন"
            c.drawText(m, (width - textPaint.measureText(m)) / 2f, height / 2f - 10f * d, textPaint)
        }
        if (dead) {
            val m = "GAME OVER — ট্যাপ করুন"
            c.drawText(m, (width - textPaint.measureText(m)) / 2f, height / 2f - 10f * d, textPaint)
        }
        if (started && !dead) postInvalidateOnAnimation()
    }
}
