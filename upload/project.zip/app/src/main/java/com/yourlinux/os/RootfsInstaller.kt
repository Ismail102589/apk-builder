package com.yourlinux.os

import android.content.Context
import android.system.Os
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

object RootfsInstaller {
    // Ubuntu 22.04 (Linux Mint 21-এর ভিত্তি একই)
    val ROOTFS_URL = "https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/ubuntu-base-22.04-base-arm64.tar.gz"
    private val URLS = listOf(
        "https://cdimage.ubuntu.com/ubuntu-base/releases/22.04/release/ubuntu-base-22.04-base-arm64.tar.gz"
    )

    fun download(env: Env, report: (Int, String) -> Unit): File {
        val dst = File(env.files, "rootfs.download")
        var lastErr = ""
        for (u in URLS) {
            try {
                SessionState.log("ডাউনলোড: $u")
                val conn = URL(u).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "YourLinuxOS/1.0")
                if (conn.responseCode != 200) {
                    lastErr = "HTTP ${conn.responseCode}"
                    SessionState.log("ব্যর্থ: $lastErr")
                    conn.disconnect()
                    continue
                }
                val total = conn.contentLengthLong
                conn.inputStream.use { ins ->
                    FileOutputStream(dst).use { out ->
                        val buf = ByteArray(65536)
                        var got = 0L
                        var last = 0L
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            got += n
                            val now = System.currentTimeMillis()
                            if (now - last > 300) {
                                last = now
                                val pct = if (total > 0) (got * 100 / total).toInt() else 0
                                report(pct, "Linux ডাউনলোড হচ্ছে… ${got / 1048576} MB")
                            }
                        }
                    }
                }
                if (dst.length() < 1_000_000) {
                    lastErr = "ফাইল ছোট/নষ্ট"
                    continue
                }
                return dst
            } catch (e: Exception) {
                lastErr = e.toString()
                SessionState.log("ব্যর্থ: $lastErr")
            }
        }
        throw IOException("ডাউনলোড ব্যর্থ ($lastErr)। ইন্টারনেট চেক করে আবার চেষ্টা করুন।")
    }

    fun extract(archive: File, dest: File, report: (Int) -> Unit) {
        dest.mkdirs()
        val fis = FileInputStream(archive)
        val total = archive.length().coerceAtLeast(1)
        val raw = BufferedInputStream(fis, 1 shl 16)
        raw.mark(8)
        val magic = ByteArray(6)
        val n = raw.read(magic)
        raw.reset()
        val stream: InputStream = when {
            n >= 2 && magic[0] == 0x1f.toByte() && magic[1] == 0x8b.toByte() -> GzipCompressorInputStream(raw)
            n >= 6 && magic[0] == 0xFD.toByte() && magic[1] == 0x37.toByte() -> XZCompressorInputStream(raw)
            else -> raw
        }
        var lastPct = -1
        TarArchiveInputStream(stream).use { tar ->
            while (true) {
                val e = tar.nextTarEntry ?: break
                val name = e.name.removePrefix("./").trimStart('/')
                if (name.isEmpty() || name == ".") continue
                if (name.split('/').any { it == ".." }) continue
                val out = File(dest, name)
                val mode = e.mode and 0x1FF
                try {
                    when {
                        e.isDirectory -> {
                            out.mkdirs()
                            Os.chmod(out.path, mode or 0x1C0)
                        }
                        e.isSymbolicLink -> {
                            out.parentFile?.mkdirs()
                            try { Os.remove(out.path) } catch (_: Exception) {}
                            Os.symlink(e.linkName, out.path)
                        }
                        e.isLink -> {
                            val target = File(dest, e.linkName.removePrefix("./").trimStart('/'))
                            out.parentFile?.mkdirs()
                            if (target.exists()) target.copyTo(out, overwrite = true)
                        }
                        e.isCharacterDevice || e.isBlockDevice || e.isFIFO -> { /* বাদ */ }
                        else -> {
                            out.parentFile?.mkdirs()
                            try { Os.remove(out.path) } catch (_: Exception) {}
                            FileOutputStream(out).use { o -> tar.copyTo(o, 65536) }
                            Os.chmod(out.path, mode or 0x180)
                        }
                    }
                } catch (ex: Exception) {
                    SessionState.log("এড়িয়ে গেছি: $name (${ex.message})")
                }
                val pct = (fis.channel.position() * 100 / total).toInt()
                if (pct != lastPct) { lastPct = pct; report(pct) }
            }
        }
    }

    private fun put(f: File, text: String) {
        try { Os.remove(f.path) } catch (_: Exception) {}
        f.parentFile?.mkdirs()
        f.writeText(text)
    }

    fun finalizeRootfs(ctx: Context, env: Env) {
        for (d in listOf("root", "tmp", "dev", "proc", "sys", "run", "etc")) File(env.rootfs, d).mkdirs()
        Os.chmod(File(env.rootfs, "tmp").path, 0x1FF)
        put(File(env.rootfs, "etc/resolv.conf"), "nameserver 8.8.8.8\nnameserver 1.1.1.1\n")
        put(File(env.rootfs, "etc/hosts"), "127.0.0.1 localhost\n::1 localhost ip6-localhost\n")
        put(File(env.rootfs, "etc/hostname"), "yourlinux\n")
    }

    /** setup.sh ও start-desktop.sh প্রতিবার নতুন করে কপি হয় */
    private fun copyAsset(ctx: Context, asset: String, dest: File, mode: Int) {
        dest.parentFile?.mkdirs()
        try { Os.remove(dest.path) } catch (_: Exception) {}
        ctx.assets.open(asset).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        Os.chmod(dest.path, mode)
    }

    fun installScripts(ctx: Context, env: Env) {
        for (n in listOf("setup.sh", "start-desktop.sh", "prep.sh", "pkgs.sh")) {
            copyAsset(ctx, n, File(env.rootfs, "root/$n"), 0x1ED)
        }
        copyAsset(ctx, "yl-glass.sh", File(env.rootfs, "usr/local/bin/yl-glass"), 0x1ED)
        copyAsset(ctx, "yl-style.sh", File(env.rootfs, "usr/local/bin/yl-style"), 0x1ED)
        copyAsset(ctx, "yl-wallpaper.sh", File(env.rootfs, "usr/local/bin/yl-wallpaper"), 0x1ED)
        copyAsset(ctx, "wallpaper.jpg", File(env.rootfs, "usr/share/backgrounds/yourlinux.jpg"), 0x1A4)
        copyAsset(ctx, "wallpaper_elem.jpg", File(env.rootfs, "usr/share/backgrounds/yourlinux-elementary.jpg"), 0x1A4)
    }
}
