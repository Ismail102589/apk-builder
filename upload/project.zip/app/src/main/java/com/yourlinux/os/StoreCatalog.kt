package com.yourlinux.os

import java.io.File

class StoreApp(
    val id: String,
    val name: String,
    val desc: String,
    val cat: String,
    val emoji: String,
    val pkgs: String,
    val size: String,
    val debUrl: String? = null
) {
    fun installed(filesDir: File): Boolean =
        File(filesDir, "rootfs/var/lib/dpkg/info/" + pkgs.split(' ')[0] + ".list").exists()
}

/** স্টোরের কাজের অবস্থা (সার্ভিস লেখে, অ্যাক্টিভিটি পড়ে) */
object StoreState {
    @Volatile var busy = false
    @Volatile var downloading = false
    @Volatile var label = ""
    @Volatile var op = ""
    @Volatile var status = ""
    @Volatile var progress = 0
    @Volatile var result = ""
}

object StoreCatalog {
    val cats = listOf("সব", "ইন্টারনেট", "অফিস", "গ্রাফিক্স", "মিডিয়া", "ডেভেলপমেন্ট", "গেম", "টুলস")

    val apps = listOf(
        StoreApp("firefox", "Firefox", "দ্রুত ও নিরাপদ ওয়েব ব্রাউজার", "ইন্টারনেট", "🦊", "firefox", "বেসে আছে"),
        StoreApp("epiphany", "GNOME Web", "হালকা ওয়েব ব্রাউজার", "ইন্টারনেট", "🌐", "epiphany-browser", "~80 MB"),
        StoreApp("thunderbird", "Thunderbird", "ইমেইল ক্লায়েন্ট", "ইন্টারনেট", "📧", "thunderbird", "~70 MB"),
        StoreApp("transmission", "Transmission", "টরেন্ট ডাউনলোডার", "ইন্টারনেট", "⬇️", "transmission-gtk", "~20 MB"),
        StoreApp("filezilla", "FileZilla", "FTP ফাইল ট্রান্সফার", "ইন্টারনেট", "📡", "filezilla", "~25 MB"),
        StoreApp("libreoffice", "LibreOffice", "Word, Excel, PowerPoint-এর মতো পূর্ণ অফিস", "অফিস", "📝",
            "libreoffice-writer libreoffice-calc libreoffice-impress libreoffice-gtk3", "~450 MB"),
        StoreApp("abiword", "AbiWord", "হালকা ওয়ার্ড প্রসেসর", "অফিস", "📄", "abiword", "~30 MB"),
        StoreApp("gnumeric", "Gnumeric", "হালকা স্প্রেডশিট", "অফিস", "📊", "gnumeric", "~30 MB"),
        StoreApp("evince", "Evince", "PDF ও ডকুমেন্ট ভিউয়ার", "অফিস", "📕", "evince", "~15 MB"),
        StoreApp("gimp", "GIMP", "ফটো এডিটর (Photoshop-এর বিকল্প)", "গ্রাফিক্স", "🎨", "gimp", "~250 MB"),
        StoreApp("inkscape", "Inkscape", "ভেক্টর ডিজাইন ও লোগো", "গ্রাফিক্স", "✏️", "inkscape", "~150 MB"),
        StoreApp("drawing", "Drawing", "সহজ ছবি আঁকার অ্যাপ", "গ্রাফিক্স", "🖌️", "drawing", "~15 MB"),
        StoreApp("vlc", "VLC", "সব ধরনের ভিডিও ও গান চালায়", "মিডিয়া", "🎬", "vlc", "~180 MB"),
        StoreApp("mpv", "mpv", "হালকা ও দ্রুত ভিডিও প্লেয়ার", "মিডিয়া", "▶️", "mpv", "~60 MB"),
        StoreApp("audacity", "Audacity", "সাউন্ড রেকর্ড ও এডিট", "মিডিয়া", "🎙️", "audacity", "~40 MB"),
        StoreApp("vscode", "VS Code", "জনপ্রিয় কোড এডিটর (Microsoft)", "ডেভেলপমেন্ট", "💻", "code", "~100 MB",
            "https://update.code.visualstudio.com/latest/linux-deb-arm64/stable"),
        StoreApp("geany", "Geany", "হালকা কোড এডিটর", "ডেভেলপমেন্ট", "🧩", "geany", "~15 MB"),
        StoreApp("python", "Python 3 + pip", "প্রোগ্রামিং ভাষা", "ডেভেলপমেন্ট", "🐍", "python3 python3-pip", "~60 MB"),
        StoreApp("nodejs", "Node.js + npm", "JavaScript রানটাইম", "ডেভেলপমেন্ট", "🟢", "nodejs npm", "~90 MB"),
        StoreApp("git", "Git", "সোর্স কোড কন্ট্রোল", "ডেভেলপমেন্ট", "🌿", "git", "~50 MB"),
        StoreApp("build", "gcc ও Build Tools", "C/C++ কম্পাইলার", "ডেভেলপমেন্ট", "🔧", "build-essential", "~200 MB"),
        StoreApp("sqlitebrowser", "DB Browser", "SQLite ডাটাবেস দেখার অ্যাপ", "ডেভেলপমেন্ট", "🗄️", "sqlitebrowser", "~40 MB"),
        StoreApp("aisleriot", "Solitaire", "তাসের খেলা", "গেম", "🃏", "aisleriot", "~40 MB"),
        StoreApp("mines", "Mines", "মাইন-সুইপার", "গেম", "💣", "gnome-mines", "~15 MB"),
        StoreApp("sudoku", "Sudoku", "সুডোকু ধাঁধা", "গেম", "🔢", "gnome-sudoku", "~25 MB"),
        StoreApp("supertux", "SuperTux", "মারিওর মতো প্ল্যাটফর্ম গেম", "গেম", "🐧", "supertux", "~150 MB"),
        StoreApp("chess", "Chess", "দাবা খেলা", "গেম", "♟️", "gnome-chess", "~15 MB"),
        StoreApp("keepassxc", "KeePassXC", "পাসওয়ার্ড ম্যানেজার", "টুলস", "🔐", "keepassxc", "~30 MB"),
        StoreApp("meld", "Meld", "ফাইল ও ফোল্ডার তুলনা", "টুলস", "🔀", "meld", "~20 MB"),
        StoreApp("bleachbit", "BleachBit", "সিস্টেম পরিষ্কার", "টুলস", "🧹", "bleachbit", "~15 MB"),
        StoreApp("neofetch", "Neofetch", "সিস্টেমের তথ্য দেখায়", "টুলস", "ℹ️", "neofetch", "~1 MB")
    )
}
