package com.yourlinux.os

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.max
import kotlin.math.min

private class RowHolder(val icon: TextView, val name: TextView, val info: TextView, val bar: ProgressBar)

class SplashActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private val t0 = SystemClock.uptimeMillis()
    private var launched = false
    private var showLog = false

    // শুরুর/ত্রুটির দৃশ্য
    private lateinit var startView: LinearLayout
    private lateinit var status: TextView
    private lateinit var hint: TextView
    private lateinit var bar: ProgressBar
    private lateinit var logScroll: ScrollView
    private lateinit var logView: TextView
    private lateinit var buttons: LinearLayout

    // ডাউনলোড/ইনস্টলের দৃশ্য
    private lateinit var setupView: LinearLayout
    private lateinit var sStatus: TextView
    private lateinit var sBar: ProgressBar
    private lateinit var sStat1: TextView
    private lateinit var sStat2: TextView
    private lateinit var sOffline: TextView
    private lateinit var sStep: TextView
    private lateinit var startStep: TextView
    private var ticking = false
    private lateinit var listView: ListView
    private lateinit var sLogScroll: ScrollView
    private lateinit var sLogView: TextView
    private lateinit var logToggle: TextView
    private val adapter = ItemAdapter()

    private val listener: () -> Unit = { ui.post { render() } }

    private fun updateStep() {
        val st = SessionState.step
        if (st.isEmpty()) {
            sStep.visibility = View.GONE
            startStep.visibility = View.GONE
            return
        }
        val sec = (System.currentTimeMillis() - SessionState.stepStart) / 1000L
        val text = "▶ " + st + "  •  " + Fmt.dur(sec)
        sStep.visibility = View.VISIBLE
        sStep.text = text
        startStep.visibility = View.VISIBLE
        startStep.text = text
    }

    private val ticker = object : Runnable {
        override fun run() {
            val ph = SessionState.phase
            if (ph == Phase.CONFIGURING || ph == Phase.PREPARING || ph == Phase.DOWNLOADING || ph == Phase.EXTRACTING || ph == Phase.STARTING) {
                updateStep()
                ui.postDelayed(this, 1000)
            } else {
                ticking = false
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#0B1B3A")
        window.navigationBarColor = Color.parseColor("#0E6B6B")
        buildUi()
        if (SessionState.phase == Phase.RUNNING && !LinuxService.sessionAlive) {
            SessionState.update(Phase.IDLE, 0, "")
        }
        SessionState.addListener(listener)
        render()
        askPermissions()
        showPreviousCrash()
        if (autoStartAllowed()) startLinux(LinuxService.ACTION_START)
    }

    private fun showPreviousCrash() {
        val crash = CrashInfo.pending(this) ?: return
        Glass.show(
            this,
            Glass.dialogBuilder(this)
                .setTitle("আগের বার অ্যাপ ক্র্যাশ করেছিল")
                .setMessage(crash.take(900))
                .setPositiveButton("কপি করুন") { _, _ ->
                    val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("crash", CrashInfo.report(this)))
                    CrashInfo.clear(this)
                    Toast.makeText(this, "কপি হয়েছে — চ্যাটে পেস্ট করে পাঠান", Toast.LENGTH_LONG).show()
                }
                .setNegativeButton("মুছুন") { _, _ -> CrashInfo.clear(this) }
        )
    }

    /** Linux শুরুতেই বারবার বন্ধ হলে অন্তহীন রিস্টার্ট লুপ আটকায় */
    private fun autoStartAllowed(): Boolean {
        if (SessionState.phase == Phase.RUNNING && LinuxService.sessionAlive) return true
        val p = getSharedPreferences("yl", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val times = (p.getString("starts", "") ?: "").split(",").mapNotNull { it.toLongOrNull() }.filter { now - it < 120000L }
        if (times.size >= 4) {
            SessionState.update(Phase.ERROR, message = "Linux বারবার বন্ধ হয়ে যাচ্ছে। 'লগ কপি' চেপে আমাকে পাঠান, অথবা 'আবার চেষ্টা' চাপুন।")
            return false
        }
        p.edit().putString("starts", (times + now).joinToString(",")).apply()
        return true
    }

    override fun onDestroy() {
        ui.removeCallbacks(ticker)
        SessionState.removeListener(listener)
        super.onDestroy()
    }

    private fun askPermissions() {
        val need = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        try {
            val prefs = getSharedPreferences("yl", MODE_PRIVATE)
            if (prefs.getBoolean("battery_asked", false)) return
            prefs.edit().putBoolean("battery_asked", true).apply()
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                        .setData(Uri.parse("package:$packageName"))
                )
            }
        } catch (_: Exception) {}
    }

    private fun geometry(): String {
        val dm = resources.displayMetrics
        val long = max(dm.widthPixels, dm.heightPixels).toFloat()
        val short = min(dm.widthPixels, dm.heightPixels).toFloat()
        val cap = getSharedPreferences("yl", MODE_PRIVATE).getInt("cap", 1280)
        val k = min(1f, cap.toFloat() / long)
        var w = ((long * k).toInt() / 8) * 8
        var h = ((short * k).toInt() / 2) * 2
        if (w < 960) w = 960
        if (h < 480) h = 480
        return "${w}x${h}"
    }

    private fun startLinux(action: String) {
        val i = Intent(this, LinuxService::class.java)
            .setAction(action)
            .putExtra(LinuxService.EXTRA_GEOMETRY, geometry())
        startForegroundService(i)
    }

    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(10), dp(16), dp(10))
        background = Glass.pressable(this@SplashActivity)
        setOnClickListener { onClick() }
    }

    private fun tint(bar: ProgressBar) {
        bar.progressTintList = ColorStateList.valueOf(Color.parseColor("#7CFFB2"))
        bar.progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 255, 255, 255))
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#0B1B3A"), Color.parseColor("#0F3D6E"), Color.parseColor("#0E6B6B"))
        )
        root.addView(buildStartView(), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(buildSetupView(), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
    }

    // ---------------- শুরুর দৃশ্য ----------------

    private fun buildStartView(): View {
        startView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            adjustViewBounds = true
            alpha = 0f
            scaleX = 0.92f
            scaleY = 0.92f
        }
        startView.addView(logo, LinearLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT))
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Glass.card(this@SplashActivity)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        status = TextView(this).apply {
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        }
        card.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        tint(bar)
        card.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)))
        startStep = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#7CFFB2"))
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            visibility = View.GONE
        }
        card.addView(startStep)
        hint = TextView(this).apply {
            text = "প্রথমবার সেটআপে সময় লাগবে। WiFi ও চার্জার ব্যবহার করুন।"
            textSize = 12f
            setTextColor(Color.argb(190, 255, 255, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        card.addView(hint)
        logView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 10f
            setTextColor(Color.parseColor("#CFE8FF"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        logScroll = ScrollView(this).apply {
            background = Glass.shape(
                this@SplashActivity, 12, Color.argb(120, 0, 0, 0), Color.argb(150, 0, 0, 0), Color.argb(45, 255, 255, 255)
            )
            addView(logView)
        }
        card.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)).apply { topMargin = dp(12) })
        startView.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(14)
        })

        buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val bp = { LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(4), dp(14), dp(4), 0) } }
        buttons.addView(pill("আবার চেষ্টা") {
            getSharedPreferences("yl", MODE_PRIVATE).edit().remove("starts").apply()
            startLinux(LinuxService.ACTION_START)
        }, bp())
        buttons.addView(pill("লগ কপি") { copyLog() }, bp())
        buttons.addView(pill("রিসেট") { confirmReset() }, bp())
        startView.addView(buttons)

        val footer = TextView(this).apply {
            text = "YOUR Linux OS  v2.0"
            textSize = 11f
            setTextColor(Color.argb(120, 255, 255, 255))
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        startView.addView(footer)
        return startView
    }

    private fun copyLog() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", CrashInfo.report(this)))
        Toast.makeText(this, "লগ কপি হয়েছে", Toast.LENGTH_SHORT).show()
    }

    private fun confirmReset() {
        Glass.show(
            this,
            Glass.dialogBuilder(this)
                .setMessage("সব মুছে নতুন করে ইনস্টল করবেন?")
                .setPositiveButton("হ্যাঁ") { _, _ -> startLinux(LinuxService.ACTION_RESET) }
                .setNegativeButton("না", null)
        )
    }

    // ---------------- ডাউনলোড/ইনস্টলের দৃশ্য ----------------

    private fun buildSetupView(): View {
        setupView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = View.GONE
        }
        val smallLogo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            adjustViewBounds = true
        }
        setupView.addView(smallLogo, LinearLayout.LayoutParams(dp(130), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        // পরিসংখ্যান কার্ড
        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Glass.card(this@SplashActivity)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        sStatus = TextView(this).apply {
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, dp(8))
        }
        stats.addView(sStatus)
        sBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        tint(sBar)
        stats.addView(sBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)))
        sStat1 = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, dp(8), 0, 0)
        }
        stats.addView(sStat1)
        sStat2 = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.argb(220, 207, 232, 255))
            setPadding(0, dp(2), 0, 0)
        }
        stats.addView(sStat2)
        sOffline = TextView(this).apply {
            text = "⚠ ইন্টারনেট নেই — সংযোগ ফিরলেই ডাউনলোড নিজে চলবে। ততক্ষণ গেম খেলুন 🦖"
            textSize = 12f
            setTextColor(Color.parseColor("#FFB4AB"))
            setPadding(0, dp(6), 0, 0)
            visibility = View.GONE
        }
        stats.addView(sOffline)
        sStep = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#7CFFB2"))
            setPadding(0, dp(8), 0, 0)
            visibility = View.GONE
        }
        stats.addView(sStep)
        setupView.addView(stats, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
        })

        // তালিকা কার্ড (প্রতিটি ফাইলের আলাদা লাইন)
        val listCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Glass.card(this@SplashActivity)
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(6), dp(4))
        }
        val title = TextView(this).apply {
            text = "ফাইলের তালিকা"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        logToggle = pill("লগ") {
            showLog = !showLog
            render()
        }
        logToggle.setPadding(dp(14), dp(4), dp(14), dp(4))
        head.addView(logToggle)
        listCard.addView(head)

        listView = ListView(this).apply {
            divider = null
            dividerHeight = 0
            isVerticalScrollBarEnabled = false
            selector = ColorDrawable(Color.TRANSPARENT)
            this.adapter = this@SplashActivity.adapter
        }
        sLogView = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 10f
            setTextColor(Color.parseColor("#CFE8FF"))
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        sLogScroll = ScrollView(this).apply {
            addView(sLogView)
            visibility = View.GONE
        }
        listCard.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        listCard.addView(sLogScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setupView.addView(listCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(8)
        })

        // ডাইনো গেম
        val gameCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Glass.shape(
                this@SplashActivity, 20, Color.argb(235, 32, 33, 36), Color.argb(235, 32, 33, 36), Color.argb(90, 255, 255, 255)
            )
            setPadding(dp(6), dp(4), dp(6), dp(6))
        }
        val cap = TextView(this).apply {
            text = "🦖 ডাউনলোডের সময় খেলুন — ট্যাপ করলে লাফ দেবে"
            textSize = 11f
            setTextColor(Color.argb(190, 255, 255, 255))
            gravity = Gravity.CENTER
        }
        gameCard.addView(cap)
        gameCard.addView(DinoView(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(130)))
        setupView.addView(gameCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        })
        return setupView
    }

    private inner class ItemAdapter : BaseAdapter() {
        private var data: List<DlItem> = emptyList()

        fun set(d: List<DlItem>) {
            data = d
            notifyDataSetChanged()
        }

        override fun getCount(): Int = data.size
        override fun getItem(position: Int): Any = data[position]
        override fun getItemId(position: Int): Long = position.toLong()

        private fun makeRow(): View {
            val row = LinearLayout(this@SplashActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), dp(5), dp(10), dp(5))
            }
            val top = LinearLayout(this@SplashActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val icon = TextView(this@SplashActivity).apply {
                textSize = 13f
                gravity = Gravity.CENTER
            }
            val name = TextView(this@SplashActivity).apply {
                textSize = 13f
                setTextColor(Color.WHITE)
                setSingleLine(true)
                ellipsize = TextUtils.TruncateAt.END
            }
            val info = TextView(this@SplashActivity).apply {
                textSize = 11f
                setTextColor(Color.argb(200, 207, 232, 255))
                gravity = Gravity.END
            }
            top.addView(icon, LinearLayout.LayoutParams(dp(26), ViewGroup.LayoutParams.WRAP_CONTENT))
            top.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            top.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(top)
            val pb = ProgressBar(this@SplashActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                visibility = View.GONE
            }
            tint(pb)
            row.addView(pb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)).apply { topMargin = dp(3) })
            row.tag = RowHolder(icon, name, info, pb)
            return row
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: makeRow()
            val h = v.tag as RowHolder
            val item = data[position]
            h.name.text = item.name
            h.bar.visibility = View.GONE
            when (item.state) {
                DlItem.WAITING -> {
                    h.icon.text = "⏳"
                    h.info.text = if (item.size > 0L) Fmt.bn(Fmt.size(item.size)) else ""
                }
                DlItem.DOWNLOADING -> {
                    val pct = if (item.size > 0L) (item.done * 100L / item.size).toInt() else 0
                    h.icon.text = "⬇️"
                    h.info.text = Fmt.bn("$pct%  ") + Fmt.bn(Fmt.size(item.done))
                    h.bar.visibility = View.VISIBLE
                    h.bar.progress = pct
                }
                DlItem.DOWNLOADED -> {
                    h.icon.text = "✓"
                    h.info.text = "ডাউনলোড হয়েছে • " + Fmt.bn(Fmt.size(item.dest.length().coerceAtLeast(item.done)))
                }
                DlItem.UNPACKED -> {
                    h.icon.text = "📦"
                    h.info.text = "ফাইল বসানো হয়েছে • কনফিগারের অপেক্ষায়"
                }
                DlItem.CONFIGURING -> {
                    h.icon.text = "🔧"
                    h.info.text = "কনফিগার হচ্ছে…"
                }
                DlItem.INSTALLED -> {
                    h.icon.text = "✅"
                    h.info.text = "ইনস্টল হয়েছে"
                }
                else -> {
                    h.icon.text = "⚠️"
                    h.info.text = "ব্যর্থ"
                }
            }
            return v
        }
    }

    // ---------------- রেন্ডার ----------------

    private fun render() {
        val ph = SessionState.phase
        val msg = SessionState.message
        val setupMode = ph == Phase.DOWNLOADING || ph == Phase.EXTRACTING ||
            ph == Phase.PREPARING || ph == Phase.CONFIGURING
        setupView.visibility = if (setupMode) View.VISIBLE else View.GONE
        startView.visibility = if (setupMode) View.GONE else View.VISIBLE

        if (setupMode) {
            sStatus.text = if (msg.isNotEmpty()) msg else "চলছে…"
            sBar.progress = SessionState.progress
            sStat1.text = SessionState.stat1
            sStat2.text = SessionState.stat2
            sStat1.visibility = if (SessionState.stat1.isEmpty()) View.GONE else View.VISIBLE
            sStat2.visibility = if (SessionState.stat2.isEmpty()) View.GONE else View.VISIBLE
            sOffline.visibility = if (!SessionState.online && ph == Phase.DOWNLOADING) View.VISIBLE else View.GONE
            updateStep()
            if (!ticking) {
                ticking = true
                ui.postDelayed(ticker, 1000)
            }
            logToggle.text = if (showLog) "তালিকা" else "লগ"
            if (showLog) {
                listView.visibility = View.GONE
                sLogScroll.visibility = View.VISIBLE
                sLogView.text = SessionState.logTail(80)
                sLogScroll.post { sLogScroll.fullScroll(View.FOCUS_DOWN) }
            } else {
                sLogScroll.visibility = View.GONE
                listView.visibility = View.VISIBLE
                val all = SessionState.items
                val active = all.filter { it.state == DlItem.CONFIGURING || it.state == DlItem.DOWNLOADING || it.state == DlItem.FAILED }
                val done = all.filter { it.state == DlItem.DOWNLOADED || it.state == DlItem.INSTALLED }.sortedByDescending { it.seq }
                val waiting = all.filter { it.state == DlItem.WAITING || it.state == DlItem.UNPACKED }
                adapter.set(active + done + waiting)
            }
        } else {
            status.text = if (msg.isNotEmpty()) msg else "শুরু হচ্ছে…"
            status.setTextColor(if (ph == Phase.ERROR) Color.parseColor("#FFB4AB") else Color.WHITE)
            bar.progress = SessionState.progress
            bar.visibility = if (ph == Phase.ERROR) View.INVISIBLE else View.VISIBLE
            logScroll.visibility = if (ph == Phase.ERROR) View.VISIBLE else View.GONE
            if (ph == Phase.ERROR) {
                logView.text = SessionState.logTail(60)
                logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
            }
            buttons.visibility = if (ph == Phase.ERROR) View.VISIBLE else View.GONE
            updateStep()
            if (!ticking && ph == Phase.STARTING) {
                ticking = true
                ui.postDelayed(ticker, 1000)
            }
            val first = !File(filesDir, "rootfs/root/.setup_done").exists()
            hint.visibility = if (first && ph != Phase.ERROR) View.VISIBLE else View.GONE
        }

        if (ph == Phase.RUNNING && !launched) {
            launched = true
            val wait = max(0L, 2000L - (SystemClock.uptimeMillis() - t0))
            ui.postDelayed({
                startActivity(Intent(this, DesktopActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
                finish()
            }, wait)
        }
    }
}
