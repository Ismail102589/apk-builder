package com.yourlinux.os

import android.os.Handler
import android.os.Looper

enum class Phase { IDLE, DOWNLOADING, EXTRACTING, PREPARING, CONFIGURING, STARTING, RUNNING, ERROR }

/** Service ও Activity-র মধ্যে অবস্থা শেয়ার করার জায়গা */
object SessionState {
    @Volatile var phase: Phase = Phase.IDLE
    @Volatile var progress: Int = 0
    @Volatile var message: String = ""
    @Volatile var items: List<DlItem> = emptyList()
    @Volatile var stat1: String = ""
    @Volatile var stat2: String = ""
    @Volatile var online: Boolean = true
    @Volatile var speedBps: Long = 0L
    @Volatile var doneBytes: Long = 0L
    @Volatile var totalBytes: Long = 0L
    @Volatile var doneFiles: Int = 0
    @Volatile var totalFiles: Int = 0

    private val buf = StringBuilder()
    private val listeners = ArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var scheduled = false

    fun addListener(l: () -> Unit) { synchronized(listeners) { listeners.add(l) } }
    fun removeListener(l: () -> Unit) { synchronized(listeners) { listeners.remove(l) } }

    fun update(phase: Phase? = null, progress: Int? = null, message: String? = null) {
        if (phase != null) this.phase = phase
        if (progress != null) this.progress = progress
        if (message != null) this.message = message
        fire()
    }

    fun log(line: String) {
        synchronized(buf) {
            buf.append(line).append('\n')
            if (buf.length > 30000) buf.delete(0, buf.length - 20000)
        }
        fire()
    }

    fun touch() { fire() }

    fun clearLog() { synchronized(buf) { buf.setLength(0) } }
    fun logText(): String = synchronized(buf) { buf.toString() }
    fun logTail(n: Int): String = logText().trimEnd().split('\n').takeLast(n).joinToString("\n")

    /** সর্বোচ্চ ~৬ বার/সেকেন্ডে জানানো হয়, লগের বন্যায় UI আটকে যায় না */
    private fun fire() {
        if (scheduled) return
        scheduled = true
        main.postDelayed({
            scheduled = false
            val copy = synchronized(listeners) { ArrayList(listeners) }
            for (l in copy) l()
        }, 150)
    }
}
