package com.yourlinux.os

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

class YlApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(filesDir, "crash.log").writeText("সময়: " + java.util.Date() + "\nথ্রেড: " + t.name + "\n\n" + sw.toString())
            } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }
}

/** ক্র্যাশ ও ডায়াগনস্টিক তথ্য */
object CrashInfo {
    fun pending(ctx: Context): String? {
        val f = File(ctx.filesDir, "crash.log")
        return if (f.exists()) try { f.readText() } catch (_: Exception) { null } else null
    }

    fun clear(ctx: Context) {
        try { File(ctx.filesDir, "crash.log").delete() } catch (_: Exception) {}
    }

    private fun reasonName(c: Int): String = when (c) {
        1 -> "নিজে বন্ধ"
        2 -> "সিগন্যালে মারা (SIGNALED)"
        3 -> "মেমোরি কম (LOW_MEMORY)"
        4 -> "ক্র্যাশ (CRASH)"
        5 -> "নেটিভ ক্র্যাশ"
        6 -> "ANR (সাড়া দেয়নি)"
        9 -> "অতিরিক্ত রিসোর্স"
        10 -> "ব্যবহারকারী বন্ধ করেছে"
        13 -> "অন্য কারণ"
        14 -> "ফ্রিজ করা হয়েছে"
        else -> "কোড $c"
    }

    fun exitReasons(ctx: Context): String {
        if (Build.VERSION.SDK_INT < 30) return "(Android 11-এর নিচে পাওয়া যায় না)"
        return try {
            val am = ctx.getSystemService(ActivityManager::class.java)
            val list = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 6)
            if (list.isEmpty()) "(কিছু নেই)" else list.joinToString("\n") {
                java.util.Date(it.timestamp).toString() + " • " + reasonName(it.reason) + " • status=" + it.status + " " + (it.description ?: "")
            }
        } catch (_: Throwable) { "(পড়া যায়নি)" }
    }

    fun report(ctx: Context): String {
        fun tail(path: String, n: Int): String = try {
            File(ctx.filesDir, path).readLines().takeLast(n).joinToString("\n")
        } catch (_: Exception) { "(নেই)" }
        val sb = StringBuilder()
        sb.append("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n")
        sb.append("App 2.1, phase=${SessionState.phase}, msg=${SessionState.message}\n")
        try {
            val am = ctx.getSystemService(ActivityManager::class.java)
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            sb.append("RAM: ফাঁকা ${mi.availMem / 1048576} MB / মোট ${mi.totalMem / 1048576} MB\n")
        } catch (_: Throwable) {}
        sb.append("VNC: ").append(VncClient.lastInfo).append("\n")
        sb.append("\n--- অ্যাপ বন্ধ হওয়ার কারণ ---\n").append(exitReasons(ctx))
        pending(ctx)?.let { sb.append("\n\n--- ক্র্যাশ ---\n").append(it.take(3000)) }
        sb.append("\n\n--- app log ---\n").append(SessionState.logTail(60))
        sb.append("\n\n--- xvnc.log ---\n").append(tail("rootfs/tmp/xvnc.log", 40))
        sb.append("\n\n--- xfce.log ---\n").append(tail("rootfs/tmp/xfce.log", 60))
        return sb.toString()
    }
}
