package com.yourlinux.os

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class DesktopActivity : Activity() {
    private lateinit var vnc: VncView
    private lateinit var info: TextView
    private lateinit var bar: HorizontalScrollView
    private lateinit var ctrlBtn: TextView
    private lateinit var altBtn: TextView
    private lateinit var shiftBtn: TextView
    private var client: VncClient? = null
    private var retries = 0
    private var closing = false
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (pm.isSustainedPerformanceModeSupported) window.setSustainedPerformanceMode(true)
        } catch (_: Exception) {}
        Boost.start(this)
        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        vnc = VncView(this)
        root.addView(vnc, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        info = TextView(this).apply {
            text = "ডেস্কটপে সংযোগ হচ্ছে…"
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(14), dp(24), dp(14))
            background = Glass.bar(this@DesktopActivity)
        }
        root.addView(info, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        // গ্লাস টুলবার (উপরে, কারণ টাস্কবার নিচে)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(chip("Esc") { vnc.tapKey(Keys.ESC) })
        row.addView(chip("Tab") { vnc.tapKey(Keys.TAB) })
        ctrlBtn = chip("Ctrl") { vnc.ctrl = !vnc.ctrl; refreshLatch() }
        altBtn = chip("Alt") { vnc.alt = !vnc.alt; refreshLatch() }
        shiftBtn = chip("Shift") { vnc.shift = !vnc.shift; refreshLatch() }
        row.addView(ctrlBtn); row.addView(altBtn); row.addView(shiftBtn)
        row.addView(chip("←") { vnc.tapKey(Keys.LEFT) })
        row.addView(chip("↑") { vnc.tapKey(Keys.UP) })
        row.addView(chip("↓") { vnc.tapKey(Keys.DOWN) })
        row.addView(chip("→") { vnc.tapKey(Keys.RIGHT) })
        row.addView(chip("Del") { vnc.tapKey(Keys.DELETE) })
        row.addView(chip("⋮ মেনু") { showMenu() })
        vnc.onLatchChanged = { runOnUiThread { refreshLatch() } }

        bar = HorizontalScrollView(this).apply {
            background = Glass.bar(this@DesktopActivity)
            isHorizontalScrollBarEnabled = false
            visibility = View.GONE
            addView(row)
        }
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44), Gravity.TOP).apply {
            setMargins(dp(8), dp(8), dp(112), 0)
        })

        val toggle = circleBtn("☰") {
            bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        root.addView(toggle, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(8), dp(8), 0)
        })
        val kb = circleBtn("⌨") { toggleKeyboard() }
        kb.textSize = 18f
        root.addView(kb, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(8), dp(60), 0)
        })

        setContentView(root)

        // কীবোর্ড খুললে ডেস্কটপ উপরে ছোট হয়ে আসবে
        root.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect()
            root.getWindowVisibleDisplayFrame(r)
            val full = root.rootView.height
            val kbh = full - r.bottom
            vnc.bottomInset = if (kbh > full * 0.15f) kbh else 0
        }
        hideSystemUi()
        connect()
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        minWidth = dp(44)
        setPadding(dp(12), 0, dp(12), 0)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44))
        background = Glass.pressOverlay(this@DesktopActivity)
        setOnClickListener { onClick() }
    }

    private fun circleBtn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 16f
        gravity = Gravity.CENTER
        background = Glass.circle(this@DesktopActivity)
        setOnClickListener { onClick() }
    }

    private fun toggleKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (vnc.bottomInset > 0) {
            imm.hideSoftInputFromWindow(vnc.windowToken, 0)
            return
        }
        vnc.requestFocus()
        imm.restartInput(vnc)
        ui.postDelayed({
            @Suppress("DEPRECATION")
            imm.showSoftInput(vnc, InputMethodManager.SHOW_FORCED)
        }, 120)
    }

    private fun mark(btn: TextView, on: Boolean) {
        btn.background = if (on) {
            Glass.shape(this, 22, Color.argb(220, 59, 130, 246), Color.argb(200, 37, 99, 235), Color.TRANSPARENT)
        } else {
            Glass.pressOverlay(this)
        }
    }

    private fun refreshLatch() {
        mark(ctrlBtn, vnc.ctrl)
        mark(altBtn, vnc.alt)
        mark(shiftBtn, vnc.shift)
    }

    private fun showMenu() {
        Glass.show(
            this,
            Glass.dialogBuilder(this).setItems(
                arrayOf(
                    "আবার সংযোগ",
                    "ব্যাকগ্রাউন্ডে পাঠান",
                    "কোয়ালিটি / গতি / স্টাইল",
                    "ডায়াগনস্টিক কপি (সমস্যা জানাতে)",
                    "Linux বন্ধ করুন"
                )
            ) { _, which ->
                when (which) {
                    0 -> { retries = 0; connect() }
                    1 -> moveTaskToBack(true)
                    2 -> showQuality()
                    3 -> copyDiagnostics()
                    4 -> stopLinux()
                }
            }
        )
    }

    private fun showQuality() {
        val prefs = getSharedPreferences("yl", MODE_PRIVATE)
        val fast = prefs.getBoolean("fast", true)
        val glass = prefs.getBoolean("glass", false)
        val style = prefs.getString("style", "elementary") ?: "elementary"
        Glass.show(
            this,
            Glass.dialogBuilder(this)
                .setTitle("কোয়ালিটি / গতি / স্টাইল")
                .setItems(
                    arrayOf(
                        "কম কোয়ালিটি (১০২৪) — ধীর ফোনের জন্য",
                        "মাঝারি (১২৮০) — সাধারণ",
                        "উচ্চ (১৬০০) — ভালো ফোনের জন্য",
                        if (fast) "দ্রুত মোড বন্ধ করুন" else "দ্রুত মোড চালু করুন (পরীক্ষামূলক)",
                        if (glass) "ডেস্কটপ স্বচ্ছতা/ছায়া বন্ধ করুন" else "ডেস্কটপ স্বচ্ছতা/ছায়া চালু করুন (একটু ধীর)",
                        if (style == "elementary") "স্টাইল বদলান: Linux Mint" else "স্টাইল বদলান: elementary OS"
                    )
                ) { _, which ->
                    val e = prefs.edit()
                    when (which) {
                        0 -> e.putInt("cap", 1024)
                        1 -> e.putInt("cap", 1280)
                        2 -> e.putInt("cap", 1600)
                        3 -> e.putBoolean("fast", !fast)
                        4 -> e.putBoolean("glass", !glass)
                        5 -> e.putString("style", if (style == "elementary") "mint" else "elementary")
                    }
                    e.apply()
                    Toast.makeText(this, "Linux আবার চালু হচ্ছে…", Toast.LENGTH_SHORT).show()
                    restartLinux()
                }
        )
    }

    private fun restartLinux() {
        closing = true
        val app = applicationContext
        startForegroundService(Intent(this, LinuxService::class.java).setAction(LinuxService.ACTION_STOP))
        ui.postDelayed({
            app.startActivity(
                Intent(app, SplashActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            )
        }, 1500)
        finish()
    }

    private fun copyDiagnostics() {
        fun tail(path: String, n: Int): String = try {
            File(filesDir, path).readLines().takeLast(n).joinToString("\n")
        } catch (e: Exception) { "(নেই)" }
        val sb = StringBuilder()
        sb.append("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n")
        sb.append("App 1.7, phase=${SessionState.phase}, msg=${SessionState.message}\n")
        sb.append("\n--- app log ---\n").append(SessionState.logTail(60))
        sb.append("\n\n--- xvnc.log ---\n").append(tail("rootfs/tmp/xvnc.log", 40))
        sb.append("\n\n--- xfce.log ---\n").append(tail("rootfs/tmp/xfce.log", 60))
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("diag", sb.toString()))
        Toast.makeText(this, "কপি হয়েছে — চ্যাটে পেস্ট করে পাঠান", Toast.LENGTH_LONG).show()
    }

    private fun stopLinux() {
        closing = true
        startForegroundService(Intent(this, LinuxService::class.java).setAction(LinuxService.ACTION_STOP))
        finishAffinity()
    }

    private fun connect() {
        client?.close()
        info.visibility = View.VISIBLE
        info.text = "ডেস্কটপে সংযোগ হচ্ছে…"
        val c = VncClient("127.0.0.1", LinuxService.VNC_PORT, object : VncClient.Listener {
            override fun onConnected(width: Int, height: Int) {
                retries = 0
                runOnUiThread { info.visibility = View.GONE; vnc.invalidate() }
            }
            override fun onFrame() { vnc.postInvalidateOnAnimation() }
            override fun onDisconnected(reason: String) {
                runOnUiThread { handleDisconnect(reason) }
            }
        })
        client = c
        vnc.client = c
        c.start()
    }

    private fun handleDisconnect(reason: String) {
        if (closing || isFinishing) return
        val alive = SessionState.phase == Phase.RUNNING
        if (alive && retries < 5) {
            retries++
            info.visibility = View.VISIBLE
            info.text = "সংযোগ ছিঁড়ে গেছে, আবার চেষ্টা হচ্ছে ($retries)…"
            ui.postDelayed({ if (!closing && !isFinishing) connect() }, 1500)
        } else {
            Toast.makeText(this, "ডেস্কটপ বন্ধ: $reason", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SplashActivity::class.java))
            finish()
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        if (ev.actionMasked == android.view.MotionEvent.ACTION_DOWN) Boost.pulse()
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() {
        super.onStart()
        client?.setPaused(false)
    }

    override fun onStop() {
        client?.setPaused(true)
        super.onStop()
    }

    override fun onDestroy() {
        closing = true
        client?.close()
        Boost.stop()
        super.onDestroy()
    }
}
