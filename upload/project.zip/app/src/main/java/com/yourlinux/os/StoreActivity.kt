package com.yourlinux.os

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

private class AppRow(val emoji: TextView, val name: TextView, val desc: TextView, val size: TextView, val btn: TextView)

/** Linux অ্যাপ স্টোর: এক ট্যাপে ইনস্টল/মোছা */
class StoreActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var cat = "সব"
    private var query = ""
    private val adapter = AppAdapter()
    private lateinit var listView: ListView
    private lateinit var notice: TextView
    private lateinit var statusCard: LinearLayout
    private lateinit var stTitle: TextView
    private lateinit var stStatus: TextView
    private lateinit var stStat: TextView
    private lateinit var stBar: ProgressBar
    private lateinit var chipRow: LinearLayout
    private val listener: () -> Unit = { ui.post { refresh() } }

    private fun linuxReady(): Boolean = File(filesDir, "rootfs/root/.setup_done").exists()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        window.statusBarColor = Color.parseColor("#0B1B3A")
        window.navigationBarColor = Color.parseColor("#0E6B6B")
        setContentView(buildUi())
        SessionState.addListener(listener)
        refresh()
    }

    override fun onDestroy() {
        SessionState.removeListener(listener)
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun pill(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = Glass.pressable(this@StoreActivity)
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#0B1B3A"), Color.parseColor("#0F3D6E"), Color.parseColor("#0E6B6B"))
            )
            setPadding(dp(14), dp(12), dp(14), dp(10))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(pill("←") { finish() })
        top.addView(TextView(this).apply {
            text = "  🛍  অ্যাপ স্টোর"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(top)

        val search = EditText(this).apply {
            hint = "🔍  অ্যাপ খুঁজুন…"
            setHintTextColor(Color.argb(150, 255, 255, 255))
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT
            background = Glass.card(this@StoreActivity)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; refresh() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (c in StoreCatalog.cats) {
            chipRow.addView(pill(c) { cat = c; refresh() }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 0, dp(6), 0) })
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(10)
        })

        notice = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#FFD28A"))
            setPadding(dp(4), dp(8), dp(4), 0)
            visibility = View.GONE
        }
        root.addView(notice)

        listView = ListView(this).apply {
            divider = null
            dividerHeight = 0
            isVerticalScrollBarEnabled = false
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            this.adapter = this@StoreActivity.adapter
        }
        root.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) })

        statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Glass.card(this@StoreActivity)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            visibility = View.GONE
        }
        stTitle = TextView(this).apply { textSize = 14f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        stStatus = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#7CFFB2")); setSingleLine(true); ellipsize = TextUtils.TruncateAt.END }
        stBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#7CFFB2"))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(80, 255, 255, 255))
        }
        stStat = TextView(this).apply { textSize = 12f; setTextColor(Color.argb(220, 207, 232, 255)) }
        statusCard.addView(stTitle)
        statusCard.addView(stStatus)
        statusCard.addView(stBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)).apply { topMargin = dp(6) })
        statusCard.addView(stStat)
        root.addView(statusCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(8)
        })

        root.addView(pill("＋ নিজের প্যাকেজ ইনস্টল (apt নাম দিয়ে)") { customInstall() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        return root
    }

    private fun filtered(): List<StoreApp> = StoreCatalog.apps.filter {
        (cat == "সব" || it.cat == cat) &&
            (query.isBlank() || it.name.contains(query, true) || it.desc.contains(query, true) || it.pkgs.contains(query, true))
    }

    private fun refresh() {
        // ফলাফল জানানো
        val r = StoreState.result
        if (r.isNotEmpty()) {
            StoreState.result = ""
            val msg = if (r == "ok") "✅ " + StoreState.label + " — সম্পন্ন" else "⚠ ব্যর্থ: " + r.removePrefix("error:")
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
        val ready = linuxReady()
        notice.visibility = if (ready) View.GONE else View.VISIBLE
        notice.text = "Linux ইনস্টল শেষ হলে স্টোর চালু হবে।"
        for (i in 0 until chipRow.childCount) {
            val c = chipRow.getChildAt(i) as TextView
            c.alpha = if (c.text.toString() == cat) 1f else 0.65f
        }
        adapter.set(filtered())

        if (StoreState.busy) {
            statusCard.visibility = View.VISIBLE
            stTitle.text = (if (StoreState.op == "remove") "🗑 মোছা হচ্ছে: " else "⬇ ইনস্টল হচ্ছে: ") + StoreState.label
            stStatus.text = StoreState.status
            val p = if (StoreState.downloading) SessionState.progress else StoreState.progress
            stBar.progress = p.coerceIn(0, 100)
            stStat.text = if (StoreState.downloading) SessionState.stat1 + "\n" + SessionState.stat2 else "ফোন ধীর হলে সময় লাগতে পারে — অ্যাপ বন্ধ করলেও চলবে"
        } else {
            statusCard.visibility = View.GONE
        }
    }

    private fun startOp(op: String, label: String, pkgs: String, deb: String?) {
        if (!linuxReady()) {
            Toast.makeText(this, "আগে Linux ইনস্টল শেষ হতে দিন", Toast.LENGTH_SHORT).show()
            return
        }
        if (StoreState.busy) {
            Toast.makeText(this, "আরেকটি কাজ চলছে, শেষ হলে চেষ্টা করুন", Toast.LENGTH_SHORT).show()
            return
        }
        startForegroundService(
            Intent(this, LinuxService::class.java)
                .setAction(LinuxService.ACTION_STORE)
                .putExtra("op", op).putExtra("label", label).putExtra("pkgs", pkgs).putExtra("deb", deb ?: "")
        )
        Toast.makeText(this, "শুরু হয়েছে — ব্যাকগ্রাউন্ডে চলবে", Toast.LENGTH_SHORT).show()
    }

    private fun customInstall() {
        val input = EditText(this).apply {
            hint = "যেমন: htop gedit"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.argb(140, 255, 255, 255))
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        Glass.show(
            this,
            Glass.dialogBuilder(this)
                .setTitle("প্যাকেজের নাম লিখুন")
                .setView(input)
                .setPositiveButton("ইনস্টল") { _, _ ->
                    val tokens = input.text.toString().split(Regex("[\\s,]+"))
                        .filter { Regex("[a-z0-9][a-z0-9+.:-]*").matches(it) }
                    if (tokens.isEmpty()) Toast.makeText(this, "নাম ঠিক নেই (ছোট হাতের অক্ষর, সংখ্যা, - + .)", Toast.LENGTH_LONG).show()
                    else startOp("install", tokens.joinToString(" "), tokens.joinToString(" "), null)
                }
                .setNegativeButton("বাতিল", null)
        )
    }

    private fun onAction(app: StoreApp, installed: Boolean) {
        if (installed) {
            Glass.show(
                this,
                Glass.dialogBuilder(this)
                    .setTitle(app.name + " মুছবেন?")
                    .setPositiveButton("মুছুন") { _, _ -> startOp("remove", app.name, app.pkgs, null) }
                    .setNegativeButton("না", null)
            )
        } else {
            Glass.show(
                this,
                Glass.dialogBuilder(this)
                    .setTitle(app.name + " ইনস্টল করবেন?")
                    .setMessage("আনুমানিক ডাউনলোড: " + app.size + "\nWiFi ব্যবহার করুন। ইনস্টল হলে Applications মেনুতে পাবেন।")
                    .setPositiveButton("ইনস্টল") { _, _ -> startOp("install", app.name, app.pkgs, app.debUrl) }
                    .setNegativeButton("না", null)
            )
        }
    }

    private inner class AppAdapter : BaseAdapter() {
        private var data: List<StoreApp> = emptyList()
        fun set(d: List<StoreApp>) { data = d; notifyDataSetChanged() }
        override fun getCount(): Int = data.size
        override fun getItem(position: Int): Any = data[position]
        override fun getItemId(position: Int): Long = position.toLong()

        private fun makeRow(): View {
            val row = LinearLayout(this@StoreActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = Glass.card(this@StoreActivity)
                setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            val emoji = TextView(this@StoreActivity).apply { textSize = 30f; gravity = Gravity.CENTER }
            val col = LinearLayout(this@StoreActivity).apply { orientation = LinearLayout.VERTICAL }
            val name = TextView(this@StoreActivity).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
            val desc = TextView(this@StoreActivity).apply { textSize = 12f; setTextColor(Color.argb(210, 207, 232, 255)) }
            val size = TextView(this@StoreActivity).apply { textSize = 11f; setTextColor(Color.argb(160, 255, 255, 255)) }
            col.addView(name); col.addView(desc); col.addView(size)
            val btn = TextView(this@StoreActivity).apply {
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(dp(16), dp(8), dp(16), dp(8))
            }
            row.addView(emoji, LinearLayout.LayoutParams(dp(46), ViewGroup.LayoutParams.WRAP_CONTENT))
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(btn)
            val wrap = LinearLayout(this@StoreActivity).apply { setPadding(0, dp(4), 0, dp(4)) }
            wrap.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            wrap.tag = AppRow(emoji, name, desc, size, btn)
            return wrap
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: makeRow()
            val h = v.tag as AppRow
            val app = data[position]
            val installed = app.installed(filesDir)
            h.emoji.text = app.emoji
            h.name.text = app.name
            h.desc.text = app.desc
            h.size.text = app.cat + " • " + app.size
            val busyNow = StoreState.busy
            h.btn.text = if (installed) "মুছুন" else "ইনস্টল"
            h.btn.alpha = if (busyNow) 0.5f else 1f
            h.btn.background = Glass.shape(
                this@StoreActivity, 18,
                if (installed) Color.argb(200, 200, 70, 70) else Color.argb(220, 30, 160, 110),
                if (installed) Color.argb(200, 160, 50, 50) else Color.argb(220, 20, 120, 90),
                Color.argb(120, 255, 255, 255)
            )
            h.btn.setOnClickListener { onAction(app, installed) }
            return v
        }
    }
}
