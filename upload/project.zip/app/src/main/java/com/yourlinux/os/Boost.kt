package com.yourlinux.os

import android.content.Context
import android.os.Build
import android.os.PerformanceHintManager
import android.os.SystemClock

/**
 * Windows-এর "টার্বো বুস্ট"-এর কাছাকাছি: ব্যবহারকারী কিছু করলেই সিস্টেমকে জানায়
 * "এখন বেশি CPU দরকার" (Android 12+ ADPF)। রুট ছাড়া CPU-র ক্লক সরাসরি বদলানো যায় না,
 * এটাই অ্যাপের জন্য অনুমোদিত সবচেয়ে কাছের উপায়।
 */
object Boost {
    private var session: Any? = null
    private var last = 0L

    fun start(ctx: Context) {
        if (Build.VERSION.SDK_INT < 31) return
        try {
            val mgr = ctx.getSystemService(Context.PERFORMANCE_HINT_SERVICE) as? PerformanceHintManager ?: return
            session = mgr.createHintSession(intArrayOf(android.os.Process.myTid()), 12_000_000L)
        } catch (_: Throwable) {
            session = null
        }
    }

    fun pulse() {
        if (Build.VERSION.SDK_INT < 31) return
        val s = session as? PerformanceHintManager.Session ?: return
        val now = SystemClock.uptimeMillis()
        if (now - last < 80L) return
        last = now
        try { s.reportActualWorkDuration(30_000_000L) } catch (_: Throwable) {}
    }

    fun stop() {
        if (Build.VERSION.SDK_INT < 31) return
        try { (session as? PerformanceHintManager.Session)?.close() } catch (_: Throwable) {}
        session = null
    }
}
