package com.yourlinux.os

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

/** একটি ডাউনলোডের আইটেম (প্যাকেজ বা ফাইল) */
class DlItem(val name: String, val url: String, val dest: File, var size: Long) {
    @Volatile var done: Long = 0L
    @Volatile var state: Int = WAITING
    @Volatile var seq: Long = 0L

    companion object {
        const val WAITING = 0
        const val DOWNLOADING = 1
        const val DOWNLOADED = 2
        const val UNPACKED = 3
        const val INSTALLED = 4
        const val FAILED = 5
    }
}

object Fmt {
    fun bn(s: String): String {
        val sb = StringBuilder()
        for (c in s) sb.append(if (c in '0'..'9') ('০' + (c - '0')) else c)
        return sb.toString()
    }

    fun size(b: Long): String = when {
        b >= (1L shl 30) -> String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0)
        b >= (1L shl 20) -> String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)
        b >= 1024L -> String.format(java.util.Locale.US, "%.0f KB", b / 1024.0)
        else -> "$b B"
    }

    fun speed(bps: Long): String = size(bps) + "/s"

    fun eta(sec: Long): String {
        if (sec < 0) return "হিসাব হচ্ছে…"
        if (sec < 60) return bn(sec.toString()) + " সেকেন্ড"
        if (sec < 3600) return bn((sec / 60).toString()) + " মিনিট " + bn((sec % 60).toString()) + " সেকেন্ড"
        return bn((sec / 3600).toString()) + " ঘণ্টা " + bn(((sec % 3600) / 60).toString()) + " মিনিট"
    }
}

/**
 * একসাথে অনেকগুলো কানেকশনে ডাউনলোড (সর্বোচ্চ গতি), বন্ধ হলে যেখান থেকে থেমেছে সেখান থেকে শুরু (Range),
 * ইন্টারনেট না থাকলে অপেক্ষা করে আবার চলে।
 */
class Downloader(
    private val items: List<DlItem>,
    private val workers: Int,
    private val isOnline: () -> Boolean,
    private val shouldStop: () -> Boolean,
    private val progFrom: Int,
    private val progTo: Int
) {
    @Volatile private var cancelled = false
    @Volatile private var failure: Throwable? = null
    private val seq = AtomicLong(0)

    fun run() {
        SessionState.items = items
        val queue = ConcurrentLinkedQueue<DlItem>()
        for (item in items.sortedByDescending { it.size }) {
            val d = item.dest
            if (d.exists() && (item.size <= 0L || d.length() == item.size)) {
                item.done = d.length()
                item.state = DlItem.DOWNLOADED
                item.seq = seq.incrementAndGet()
            } else {
                val part = File(d.path + ".part")
                item.done = if (part.exists()) part.length() else 0L
                item.state = DlItem.WAITING
                queue.add(item)
            }
        }
        if (queue.isEmpty()) {
            publish(0L, 0L)
            return
        }
        val threads = ArrayList<Thread>()
        val n = minOf(workers, queue.size)
        for (i in 0 until n) {
            val t = Thread({ worker(queue) }, "dl-$i")
            threads.add(t)
            t.start()
        }
        monitor(threads)
        failure?.let { throw it }
        if (cancelled) throw InterruptedException("বন্ধ করা হয়েছে")
    }

    private fun total(): Long {
        var t = 0L
        for (it in items) t += if (it.size > 0L) it.size else it.done
        return t
    }

    private fun monitor(threads: List<Thread>) {
        val samples = ArrayDeque<Pair<Long, Long>>()
        while (threads.any { it.isAlive }) {
            if (shouldStop()) cancelled = true
            val now = System.currentTimeMillis()
            var done = 0L
            for (it in items) done += it.done
            samples.addLast(Pair(now, done))
            while (samples.size > 2 && now - samples.first().first > 5000L) samples.removeFirst()
            val first = samples.first()
            val dt = maxOf(now - first.first, 1L)
            val bps = maxOf(0L, (done - first.second) * 1000L / dt)
            publish(done, bps)
            try { Thread.sleep(400) } catch (_: InterruptedException) {}
        }
        var done = 0L
        for (it in items) done += it.done
        publish(done, 0L)
    }

    private fun publish(done: Long, bps: Long) {
        val total = total()
        var files = 0
        for (it in items) if (it.state >= DlItem.DOWNLOADED && it.state != DlItem.FAILED) files++
        SessionState.doneBytes = done
        SessionState.totalBytes = total
        SessionState.speedBps = bps
        SessionState.doneFiles = files
        SessionState.totalFiles = items.size
        val eta = if (bps > 1024L && total > done) (total - done) / bps else -1L
        SessionState.stat1 = Fmt.bn(Fmt.size(done)) + " / " + Fmt.bn(Fmt.size(total)) + "  •  " + Fmt.bn(Fmt.speed(bps))
        SessionState.stat2 = "বাকি: " + Fmt.eta(eta) + "  •  ফাইল " + Fmt.bn(files.toString()) + "/" + Fmt.bn(items.size.toString())
        if (total > 0L) SessionState.progress = progFrom + (done * (progTo - progFrom) / total).toInt()
        SessionState.online = isOnline()
        SessionState.touch()
    }

    private fun worker(queue: ConcurrentLinkedQueue<DlItem>) {
        while (!cancelled && failure == null) {
            val item = queue.poll() ?: return
            try {
                fetch(item)
            } catch (e: InterruptedException) {
                return
            } catch (e: Throwable) {
                item.state = DlItem.FAILED
                failure = IOException(item.name + ": " + (e.message ?: e.toString()))
                return
            }
        }
    }

    private fun fetch(item: DlItem) {
        val part = File(item.dest.path + ".part")
        item.dest.parentFile?.mkdirs()
        item.state = DlItem.DOWNLOADING
        var attempts = 0
        while (true) {
            if (cancelled) throw InterruptedException()
            if (!isOnline()) {
                Thread.sleep(1500)
                continue
            }
            try {
                var offset = if (part.exists()) part.length() else 0L
                if (item.size > 0L && offset > item.size) {
                    part.delete()
                    offset = 0L
                }
                item.done = offset
                if (item.size > 0L && offset == item.size) {
                    finish(item, part)
                    return
                }
                val conn = URL(item.url).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 20000
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "YourLinuxOS/1.0")
                conn.setRequestProperty("Accept-Encoding", "identity")
                if (offset > 0L) conn.setRequestProperty("Range", "bytes=$offset-")
                val code = conn.responseCode
                if (code == 416) {
                    part.delete()
                    conn.disconnect()
                    throw IOException("HTTP 416")
                }
                if (code != 200 && code != 206) {
                    conn.disconnect()
                    throw IOException("HTTP $code")
                }
                val append = code == 206 && offset > 0L
                if (!append) {
                    offset = 0L
                    item.done = 0L
                }
                val len = conn.contentLengthLong
                if (item.size <= 0L && len > 0L) item.size = offset + len
                conn.inputStream.use { ins ->
                    FileOutputStream(part, append).use { out ->
                        val buf = ByteArray(128 * 1024)
                        while (true) {
                            if (cancelled) throw InterruptedException()
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            item.done = item.done + n
                        }
                    }
                }
                conn.disconnect()
                finish(item, part)
                return
            } catch (e: InterruptedException) {
                throw e
            } catch (e: IOException) {
                attempts++
                if (attempts > 8) throw e
                Thread.sleep(minOf(500L * attempts, 4000L))
            }
        }
    }

    private fun finish(item: DlItem, part: File) {
        if (item.size > 0L && part.length() != item.size) {
            part.delete()
            throw IOException("ফাইলের সাইজ মেলেনি")
        }
        if (!part.renameTo(item.dest)) throw IOException("ফাইল সরানো যায়নি")
        item.done = item.dest.length()
        item.state = DlItem.DOWNLOADED
        item.seq = seq.incrementAndGet()
    }
}

/** সবচেয়ে দ্রুত Ubuntu মিরর খোঁজে */
object MirrorPicker {
    const val DEFAULT = "http://ports.ubuntu.com/ubuntu-ports"
    private val CANDIDATES = listOf(
        DEFAULT,
        "http://mirrors.ustc.edu.cn/ubuntu-ports",
        "http://mirrors.tuna.tsinghua.edu.cn/ubuntu-ports",
        "http://mirror.nju.edu.cn/ubuntu-ports",
        "http://mirrors.aliyun.com/ubuntu-ports",
        "http://mirrors.cloud.tencent.com/ubuntu-ports",
        "http://repo.huaweicloud.com/ubuntu-ports",
        "http://mirror.kakao.com/ubuntu-ports"
    )

    fun pick(log: (String) -> Unit): String {
        val results = java.util.concurrent.ConcurrentHashMap<String, Long>()
        val threads = ArrayList<Thread>()
        for (base in CANDIDATES) {
            val t = Thread {
                try {
                    val t0 = System.nanoTime()
                    val c = URL("$base/dists/jammy/InRelease").openConnection() as HttpURLConnection
                    c.connectTimeout = 6000
                    c.readTimeout = 8000
                    if (c.responseCode == 200) {
                        var total = 0L
                        c.inputStream.use { ins ->
                            val b = ByteArray(32768)
                            while (true) {
                                val n = ins.read(b)
                                if (n < 0) break
                                total += n
                            }
                        }
                        if (total > 10000L) results[base] = (System.nanoTime() - t0) / 1_000_000L
                    }
                    c.disconnect()
                } catch (_: Exception) {}
            }
            threads.add(t)
            t.start()
        }
        for (t in threads) try { t.join(10000) } catch (_: Exception) {}
        var best = DEFAULT
        var bestMs = Long.MAX_VALUE
        for ((k, v) in results) {
            log("সার্ভার $k: $v ms")
            if (v < bestMs) { bestMs = v; best = k }
        }
        return best
    }
}

/** Linux Mint থিম/আইকন প্যাকেজের তালিকা */
object MintRepo {
    fun resolve(env: Env, log: (String) -> Unit): List<DlItem> {
        val out = ArrayList<DlItem>()
        try {
            val base = "http://packages.linuxmint.com"
            val c = URL("$base/dists/virginia/main/binary-amd64/Packages.gz").openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 20000
            val text = java.util.zip.GZIPInputStream(c.inputStream).bufferedReader().use { it.readText() }
            val wanted = setOf("mint-x-icons", "mint-y-icons", "mint-themes")
            for (para in text.split("\n\n")) {
                var pkg = ""
                var fn = ""
                var size = 0L
                for (line in para.lines()) {
                    if (line.startsWith("Package: ")) pkg = line.substring(9).trim()
                    else if (line.startsWith("Filename: ")) fn = line.substring(10).trim()
                    else if (line.startsWith("Size: ")) size = line.substring(6).trim().toLongOrNull() ?: 0L
                }
                if (pkg in wanted && fn.isNotEmpty() && out.none { it.name == pkg }) {
                    out.add(DlItem(pkg, "$base/$fn", File(env.rootfs, "root/mint/" + fn.substringAfterLast('/')), size))
                }
            }
        } catch (e: Exception) {
            log("Mint তালিকা পাওয়া যায়নি: ${e.message}")
        }
        return out
    }
}

object PackageList {
    /** prep.sh যে uris.txt বানায় তা থেকে ডাউনলোডের তালিকা */
    fun parse(env: Env): List<DlItem> {
        val f = File(env.rootfs, "root/uris.txt")
        val list = ArrayList<DlItem>()
        if (!f.exists()) return list
        for (line in f.readLines()) {
            val p = line.trim().split(" ")
            if (p.size < 3) continue
            val fn = p[1]
            val size = p[2].toLongOrNull() ?: 0L
            list.add(DlItem(fn.substringBefore('_'), p[0], File(env.rootfs, "var/cache/apt/archives/$fn"), size))
        }
        return list
    }
}
