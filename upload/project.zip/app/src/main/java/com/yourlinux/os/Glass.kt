package com.yourlinux.os

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build

/** গ্লাস (কাচের মতো স্বচ্ছ) UI-র সাহায্যকারী */
object Glass {
    fun shape(ctx: Context, radiusDp: Int, top: Int, bottom: Int, stroke: Int): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom))
        g.cornerRadius = ctx.dp(radiusDp).toFloat()
        g.setStroke(ctx.dp(1), stroke)
        return g
    }

    fun card(ctx: Context) = shape(
        ctx, 24, Color.argb(74, 255, 255, 255), Color.argb(26, 255, 255, 255), Color.argb(100, 255, 255, 255)
    )

    fun bar(ctx: Context) = shape(
        ctx, 22, Color.argb(200, 28, 40, 62), Color.argb(175, 12, 20, 38), Color.argb(80, 255, 255, 255)
    )

    fun circle(ctx: Context): GradientDrawable {
        val g = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(200, 28, 40, 62), Color.argb(175, 12, 20, 38))
        )
        g.shape = GradientDrawable.OVAL
        g.setStroke(ctx.dp(1), Color.argb(90, 255, 255, 255))
        return g
    }

    fun pressable(ctx: Context): StateListDrawable {
        val sl = StateListDrawable()
        sl.addState(
            intArrayOf(android.R.attr.state_pressed),
            shape(ctx, 20, Color.argb(140, 255, 255, 255), Color.argb(100, 255, 255, 255), Color.argb(150, 255, 255, 255))
        )
        sl.addState(
            intArrayOf(),
            shape(ctx, 20, Color.argb(70, 255, 255, 255), Color.argb(30, 255, 255, 255), Color.argb(95, 255, 255, 255))
        )
        return sl
    }

    /** টুলবারের বাটনের জন্য: চাপলে হালকা আলো */
    fun pressOverlay(ctx: Context): StateListDrawable {
        val sl = StateListDrawable()
        sl.addState(
            intArrayOf(android.R.attr.state_pressed),
            shape(ctx, 22, Color.argb(100, 255, 255, 255), Color.argb(100, 255, 255, 255), Color.TRANSPARENT)
        )
        sl.addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
        return sl
    }

    fun dialogBuilder(ctx: Context): AlertDialog.Builder =
        AlertDialog.Builder(ctx, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    fun show(ctx: Context, b: AlertDialog.Builder): AlertDialog {
        val d = b.create()
        d.window?.setBackgroundDrawable(
            shape(ctx, 22, Color.argb(220, 28, 40, 62), Color.argb(205, 12, 20, 38), Color.argb(90, 255, 255, 255))
        )
        if (Build.VERSION.SDK_INT >= 31) {
            try { d.window?.setBackgroundBlurRadius(90) } catch (_: Exception) {}
        }
        d.show()
        return d
    }
}
