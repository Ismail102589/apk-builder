#!/bin/bash
# YOUR Linux OS — ডেস্কটপ স্টাইল: cutefish / elementary / mint। বদলালেই একবার প্রয়োগ হয়
STYLE="${YL_STYLE:-cutefish}"
WS=""; [ -d /usr/share/themes/WhiteSur-Light ] && WS="-ws"
TAG="$STYLE-2$WS"
[ "$(cat /root/.yl_style_applied 2>/dev/null)" = "$TAG" ] && exit 0

X=/root/.config/xfce4/xfconf/xfce-perchannel-xml
P=/root/.config/xfce4/panel
rm -rf $P/launcher-*
mkdir -p $X $P /root/.config/autostart

have_theme() { [ -d "/usr/share/themes/$1" ]; }
have_icon() { [ -d "/usr/share/icons/$1" ]; }
mk_launcher() { # id file name exec icon
  mkdir -p $P/launcher-$1
  printf '[Desktop Entry]\nVersion=1.0\nType=Application\nName=%s\nExec=%s\nIcon=%s\n' "$3" "$4" "$5" > $P/launcher-$1/$2.desktop
}
launcher_xml() { # id file
  echo "    <property name=\"plugin-$1\" type=\"string\" value=\"launcher\"><property name=\"items\" type=\"array\"><value type=\"string\" value=\"$2.desktop\"/></property></property>"
}
SEP='<property name="expand" type="bool" value="true"/><property name="style" type="uint" value="0"/>'

CURSOR=Adwaita; have_icon DMZ-White && CURSOR=DMZ-White
FONT="Noto Sans 10"; fc-list 2>/dev/null | grep -qi "Inter" && FONT="Inter 10"
BTN="|HMC"

case "$STYLE" in
  mint)
    THEME=Adwaita; for t in Mint-Y-Aqua Mint-Y Arc; do have_theme $t && { THEME=$t; break; }; done
    ICON=Adwaita;  for i in Mint-Y-Aqua Mint-Y elementary-xfce; do have_icon $i && { ICON=$i; break; }; done
    FONT="Noto Sans 10" ;;
  elementary)
    THEME=Adwaita; for t in io.elementary.stylesheet.blueberry Arc Greybird; do have_theme $t && { THEME=$t; break; }; done
    ICON=Adwaita;  for i in elementary-xfce elementary-xfce-light; do have_icon $i && { ICON=$i; break; }; done
    BTN="C|HM" ;;
  *)
    THEME=Adwaita; for t in WhiteSur-Light Arc Greybird; do have_theme $t && { THEME=$t; break; }; done
    ICON=Adwaita;  for i in WhiteSur elementary-xfce elementary-xfce-light; do have_icon $i && { ICON=$i; break; }; done ;;
esac
TFONT="${FONT/ 10/ Bold 10}"
XFWM=Default
for t in "$THEME" Arc Greybird; do [ -d "/usr/share/themes/$t/xfwm4" ] && { XFWM=$t; break; }; done
echo "style=$STYLE theme=$THEME xfwm=$XFWM icon=$ICON font=$FONT"

cat > $X/xsettings.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="$THEME"/>
    <property name="IconThemeName" type="string" value="$ICON"/>
  </property>
  <property name="Gtk" type="empty">
    <property name="FontName" type="string" value="$FONT"/>
    <property name="CursorThemeName" type="string" value="$CURSOR"/>
    <property name="CursorThemeSize" type="int" value="32"/>
  </property>
  <property name="Xft" type="empty">
    <property name="DPI" type="int" value="120"/>
    <property name="Antialias" type="int" value="1"/>
    <property name="HintStyle" type="string" value="hintslight"/>
    <property name="RGBA" type="string" value="none"/>
  </property>
</channel>
XML

cat > $X/xfwm4.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="$XFWM"/>
    <property name="button_layout" type="string" value="$BTN"/>
    <property name="use_compositing" type="bool" value="false"/>
    <property name="title_alignment" type="string" value="center"/>
    <property name="title_font" type="string" value="$TFONT"/>
  </property>
</channel>
XML

if [ "$STYLE" = "mint" ]; then
  mk_launcher 6 fx Firefox "firefox %u" firefox
  mk_launcher 7 files Files thunar system-file-manager
  mk_launcher 8 term Terminal xfce4-terminal utilities-terminal
  cat > $X/xfce4-panel.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <property name="panel-1" type="empty">
      <property name="position" type="string" value="p=10;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="46"/>
      <property name="icon-size" type="uint" value="28"/>
      <property name="plugin-ids" type="array">
        <value type="int" value="1"/><value type="int" value="6"/><value type="int" value="7"/><value type="int" value="8"/>
        <value type="int" value="2"/><value type="int" value="3"/><value type="int" value="4"/><value type="int" value="5"/>
      </property>
    </property>
  </property>
  <property name="plugins" type="empty">
    <property name="plugin-1" type="string" value="whiskermenu"/>
$(launcher_xml 6 fx)
$(launcher_xml 7 files)
$(launcher_xml 8 term)
    <property name="plugin-2" type="string" value="tasklist"/>
    <property name="plugin-3" type="string" value="separator">$SEP</property>
    <property name="plugin-4" type="string" value="systray"/>
    <property name="plugin-5" type="string" value="clock"/>
  </property>
</channel>
XML
  printf 'button-icon=start-here\nshow-button-title=false\nshow-button-icon=true\n' > $P/whiskermenu-1.rc
else
  mk_launcher 6 files Files thunar system-file-manager
  mk_launcher 7 fx Firefox "firefox %u" firefox
  mk_launcher 8 term Terminal xfce4-terminal utilities-terminal
  mk_launcher 9 edit "Text Editor" mousepad accessories-text-editor
  mk_launcher 10 calc Calculator galculator accessories-calculator
  mk_launcher 11 soft Software synaptic system-software-install
  mk_launcher 12 set Settings xfce4-settings-manager preferences-system
  if [ "$STYLE" = "elementary" ]; then
    TOP_H=32; TOP_I=18; DOCK_H=64; DOCK_I=46; TOP_A=0.93; DOCK_A=0.82
    TOP_PLUGINS='<value type="int" value="1"/><value type="int" value="2"/><value type="int" value="3"/><value type="int" value="4"/><value type="int" value="5"/><value type="int" value="14"/>'
    printf 'button-title=Applications\nshow-button-title=true\nshow-button-icon=false\n' > $P/whiskermenu-1.rc
    TOP_PLUGIN_XML='    <property name="plugin-2" type="string" value="separator">'"$SEP"'</property>
    <property name="plugin-3" type="string" value="clock"/>
    <property name="plugin-4" type="string" value="separator">'"$SEP"'</property>
    <property name="plugin-5" type="string" value="windowmenu"/>
    <property name="plugin-14" type="string" value="systray"/>'
  else
    # Cutefish: পাতলা স্টেটাস বার (বামে লঞ্চার, ডানে ট্রে ও ঘড়ি) + বড় আইকনের ডক
    TOP_H=30; TOP_I=18; DOCK_H=78; DOCK_I=54; TOP_A=0.82; DOCK_A=0.58
    TOP_PLUGINS='<value type="int" value="1"/><value type="int" value="5"/><value type="int" value="2"/><value type="int" value="14"/><value type="int" value="3"/>'
    printf 'button-icon=view-app-grid-symbolic\nshow-button-title=false\nshow-button-icon=true\n' > $P/whiskermenu-1.rc
    TOP_PLUGIN_XML='    <property name="plugin-5" type="string" value="windowmenu"/>
    <property name="plugin-2" type="string" value="separator">'"$SEP"'</property>
    <property name="plugin-14" type="string" value="systray"/>
    <property name="plugin-3" type="string" value="clock"/>'
  fi
  cat > $X/xfce4-panel.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <value type="int" value="2"/>
    <property name="panel-1" type="empty">
      <property name="position" type="string" value="p=6;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="$TOP_H"/>
      <property name="icon-size" type="uint" value="$TOP_I"/>
      <property name="background-style" type="uint" value="1"/>
      <property name="background-rgba" type="array">
        <value type="double" value="0.97"/><value type="double" value="0.97"/><value type="double" value="0.98"/><value type="double" value="$TOP_A"/>
      </property>
      <property name="plugin-ids" type="array">$TOP_PLUGINS</property>
    </property>
    <property name="panel-2" type="empty">
      <property name="position" type="string" value="p=10;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="$DOCK_H"/>
      <property name="icon-size" type="uint" value="$DOCK_I"/>
      <property name="background-style" type="uint" value="1"/>
      <property name="background-rgba" type="array">
        <value type="double" value="0.97"/><value type="double" value="0.97"/><value type="double" value="0.98"/><value type="double" value="$DOCK_A"/>
      </property>
      <property name="plugin-ids" type="array">
        <value type="int" value="15"/><value type="int" value="6"/><value type="int" value="7"/><value type="int" value="8"/><value type="int" value="9"/><value type="int" value="10"/><value type="int" value="11"/><value type="int" value="12"/><value type="int" value="16"/>
      </property>
    </property>
  </property>
  <property name="plugins" type="empty">
    <property name="plugin-1" type="string" value="whiskermenu"/>
$TOP_PLUGIN_XML
    <property name="plugin-15" type="string" value="separator">$SEP</property>
$(launcher_xml 6 files)
$(launcher_xml 7 fx)
$(launcher_xml 8 term)
$(launcher_xml 9 edit)
$(launcher_xml 10 calc)
$(launcher_xml 11 soft)
$(launcher_xml 12 set)
    <property name="plugin-16" type="string" value="separator">$SEP</property>
  </property>
</channel>
XML
fi

echo "$TAG" > /root/.yl_style_applied
