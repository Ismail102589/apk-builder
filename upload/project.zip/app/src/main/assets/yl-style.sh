#!/bin/bash
# YOUR Linux OS — ডেস্কটপ স্টাইল (elementary OS বা Linux Mint), পরিবর্তন হলে একবারই প্রয়োগ হয়
STYLE="${YL_STYLE:-elementary}"
TAG="$STYLE-1"
[ "$(cat /root/.yl_style_applied 2>/dev/null)" = "$TAG" ] && exit 0

X=/root/.config/xfce4/xfconf/xfce-perchannel-xml
P=/root/.config/xfce4/panel
rm -rf $P/launcher-*
mkdir -p $X $P /root/.config/autostart

have_theme() { [ -d "/usr/share/themes/$1" ]; }
have_icon() { [ -d "/usr/share/icons/$1" ]; }
mk_launcher() { # id file name exec icon
  mkdir -p $P/launcher-$1
  printf '[Desktop Entry]\nVersion=1.0\nType=Application\nName=%s\nExec=%s\nIcon=%s\n' "$3" "$4" "$5" > $P/launcher-$1/$2.desktop
}
launcher_xml() { # id file
  echo "    <property name=\"plugin-$1\" type=\"string\" value=\"launcher\"><property name=\"items\" type=\"array\"><value type=\"string\" value=\"$2.desktop\"/></property></property>"
}

CURSOR=Adwaita; have_icon DMZ-White && CURSOR=DMZ-White

if [ "$STYLE" = "mint" ]; then
  THEME=Adwaita; for t in Mint-Y-Aqua Mint-Y Arc; do have_theme $t && { THEME=$t; break; }; done
  ICON=Adwaita;  for i in Mint-Y-Aqua Mint-Y Papirus; do have_icon $i && { ICON=$i; break; }; done
  FONT="Noto Sans 10"; BTN="|HMC"; TFONT="Noto Sans Bold 10"
else
  THEME=Adwaita
  have_theme io.elementary.stylesheet.blueberry && THEME=io.elementary.stylesheet.blueberry
  if [ "$THEME" = Adwaita ]; then for t in Arc Greybird; do have_theme $t && { THEME=$t; break; }; done; fi
  ICON=Adwaita;  for i in elementary-xfce elementary-xfce-light Papirus; do have_icon $i && { ICON=$i; break; }; done
  FONT="Noto Sans 10"; fc-list 2>/dev/null | grep -qi "Inter" && FONT="Inter 10"
  BTN="C|HM"; TFONT="$FONT"; TFONT="${TFONT/ 10/ Bold 10}"
fi
XFWM=Default
for t in Arc Greybird "$THEME"; do [ -d "/usr/share/themes/$t/xfwm4" ] && { XFWM=$t; break; }; done
[ "$STYLE" = "mint" ] && [ -d "/usr/share/themes/$THEME/xfwm4" ] && XFWM=$THEME
echo "style=$STYLE theme=$THEME xfwm=$XFWM icon=$ICON font=$FONT"

cat > $X/xsettings.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="$THEME"/>
    <property name="IconThemeName" type="string" value="$ICON"/>
  </property>
  <property name="Gtk" type="empty">
    <property name="FontName" type="string" value="$FONT"/>
    <property name="CursorThemeName" type="string" value="$CURSOR"/>
    <property name="CursorThemeSize" type="int" value="32"/>
  </property>
  <property name="Xft" type="empty">
    <property name="DPI" type="int" value="120"/>
    <property name="Antialias" type="int" value="1"/>
    <property name="HintStyle" type="string" value="hintslight"/>
    <property name="RGBA" type="string" value="none"/>
  </property>
</channel>
XML

cat > $X/xfwm4.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="$XFWM"/>
    <property name="button_layout" type="string" value="$BTN"/>
    <property name="use_compositing" type="bool" value="false"/>
    <property name="title_alignment" type="string" value="center"/>
    <property name="title_font" type="string" value="$TFONT"/>
  </property>
</channel>
XML

if [ "$STYLE" = "mint" ]; then
  # ---- Linux Mint: নিচে একটাই টাস্কবার ----
  mk_launcher 6 fx Firefox "firefox %u" firefox
  mk_launcher 7 files Files thunar system-file-manager
  mk_launcher 8 term Terminal xfce4-terminal utilities-terminal
  cat > $X/xfce4-panel.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <property name="panel-1" type="empty">
      <property name="position" type="string" value="p=10;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="46"/>
      <property name="icon-size" type="uint" value="28"/>
      <property name="plugin-ids" type="array">
        <value type="int" value="1"/><value type="int" value="6"/><value type="int" value="7"/><value type="int" value="8"/>
        <value type="int" value="2"/><value type="int" value="3"/><value type="int" value="4"/><value type="int" value="5"/>
      </property>
    </property>
  </property>
  <property name="plugins" type="empty">
    <property name="plugin-1" type="string" value="whiskermenu"/>
$(launcher_xml 6 fx)
$(launcher_xml 7 files)
$(launcher_xml 8 term)
    <property name="plugin-2" type="string" value="tasklist"/>
    <property name="plugin-3" type="string" value="separator"><property name="expand" type="bool" value="true"/><property name="style" type="uint" value="0"/></property>
    <property name="plugin-4" type="string" value="systray"/>
    <property name="plugin-5" type="string" value="clock"/>
  </property>
</channel>
XML
  printf 'button-icon=start-here\nshow-button-title=false\nshow-button-icon=true\n' > $P/whiskermenu-1.rc
else
  # ---- elementary: ওপরে বার + নিচে ডক ----
  mk_launcher 6 files Files thunar system-file-manager
  mk_launcher 7 fx Firefox "firefox %u" firefox
  mk_launcher 8 term Terminal xfce4-terminal utilities-terminal
  mk_launcher 9 edit "Text Editor" mousepad accessories-text-editor
  mk_launcher 10 soft Software synaptic system-software-install
  mk_launcher 11 set Settings xfce4-settings-manager preferences-system
  cat > $X/xfce4-panel.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <value type="int" value="2"/>
    <property name="panel-1" type="empty">
      <property name="position" type="string" value="p=6;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="32"/>
      <property name="icon-size" type="uint" value="18"/>
      <property name="background-style" type="uint" value="1"/>
      <property name="background-rgba" type="array">
        <value type="double" value="0.96"/><value type="double" value="0.96"/><value type="double" value="0.97"/><value type="double" value="0.93"/>
      </property>
      <property name="plugin-ids" type="array">
        <value type="int" value="1"/><value type="int" value="2"/><value type="int" value="3"/><value type="int" value="4"/><value type="int" value="5"/><value type="int" value="14"/>
      </property>
    </property>
    <property name="panel-2" type="empty">
      <property name="position" type="string" value="p=10;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="64"/>
      <property name="icon-size" type="uint" value="46"/>
      <property name="background-style" type="uint" value="1"/>
      <property name="background-rgba" type="array">
        <value type="double" value="0.96"/><value type="double" value="0.96"/><value type="double" value="0.97"/><value type="double" value="0.82"/>
      </property>
      <property name="plugin-ids" type="array">
        <value type="int" value="15"/><value type="int" value="6"/><value type="int" value="7"/><value type="int" value="8"/><value type="int" value="9"/><value type="int" value="10"/><value type="int" value="11"/><value type="int" value="16"/>
      </property>
    </property>
  </property>
  <property name="plugins" type="empty">
    <property name="plugin-1" type="string" value="whiskermenu"/>
    <property name="plugin-2" type="string" value="separator"><property name="expand" type="bool" value="true"/><property name="style" type="uint" value="0"/></property>
    <property name="plugin-3" type="string" value="clock"/>
    <property name="plugin-4" type="string" value="separator"><property name="expand" type="bool" value="true"/><property name="style" type="uint" value="0"/></property>
    <property name="plugin-5" type="string" value="windowmenu"/>
    <property name="plugin-14" type="string" value="systray"/>
    <property name="plugin-15" type="string" value="separator"><property name="expand" type="bool" value="true"/><property name="style" type="uint" value="0"/></property>
$(launcher_xml 6 files)
$(launcher_xml 7 fx)
$(launcher_xml 8 term)
$(launcher_xml 9 edit)
$(launcher_xml 10 soft)
$(launcher_xml 11 set)
    <property name="plugin-16" type="string" value="separator"><property name="expand" type="bool" value="true"/><property name="style" type="uint" value="0"/></property>
  </property>
</channel>
XML
  printf 'button-title=Applications\nshow-button-title=true\nshow-button-icon=false\n' > $P/whiskermenu-1.rc
fi

echo "$TAG" > /root/.yl_style_applied
