const $=s=>document.querySelector(s),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const A=window.Android||{openUrl(){},download(){},install(){},haptic(){},hasApk(){return false},deleteApk(){},workflow(){return''},copy(){},fetchLog(){},share(){},apkSize(){return 0},storage(){return 0}};
let cfg=Object.assign({owner:'Ismail102589',repo:'apk-builder',theme:'aurora',haptic:true,token:'',autoInst:true,conf:true,rm:false},JSON.parse(localStorage.cfg||'{}'));
let builds=JSON.parse(localStorage.bl||'[]');
const S={f:null,view:null,tab:0,flt:'all'},dls={},logw={},WFV='v3';let lock=Promise.resolve();
const NAMES=['আপলোড','সারিতে','বিল্ড','ডাউনলোড','রেডি'];
const save=()=>{localStorage.cfg=JSON.stringify(cfg);localStorage.bl=JSON.stringify(builds.slice(0,40))};
const hap=()=>{if(cfg.haptic)A.haptic()};
const repo=()=>`/repos/${cfg.owner}/${cfg.repo}`;
const find=id=>builds.find(x=>x.id===id);
const esc=s=>String(s).replace(/[<>&"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c]));
const fmt=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
const size=b=>b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),2800)}
window.toast=toast;
function tab(n){S.tab=n;document.querySelectorAll('.page').forEach((p,i)=>p.classList.toggle('on',i==n));
 document.querySelectorAll('nav button').forEach((b,i)=>b.classList.toggle('on',i==n));
 $('#ind').style.transform=`translateX(${n*100}%)`;if(n==1)renderHist();if(n==2)storUI();hap()}
function theme(t){document.documentElement.dataset.t=t;cfg.theme=t;save();
 document.querySelectorAll('.th').forEach(e=>e.classList.toggle('on',e.dataset.k==t))}
function b64(f){return new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(r.result.split(',')[1]);r.onerror=()=>no(Error('ফাইল পড়া যায়নি'));r.readAsDataURL(f)})}
function gh(p,o={}){if(!o.method||o.method==='GET')p+=(p.includes('?')?'&':'?')+'_='+Date.now();return fetch('https://api.github.com'+p,{cache:'no-store',...o,headers:{Authorization:'Bearer '+cfg.token,Accept:'application/vnd.github+json',...(o.body?{'Content-Type':'application/json'}:{})}})}
async function runs(){const r=await gh(`${repo()}/actions/runs?per_page=30`);
 if(!r.ok)throw Error('রান তালিকা পাওয়া যায়নি ('+r.status+')');return(await r.json()).workflow_runs||[]}
function confetti(){const c=$('#cv'),x=c.getContext('2d');c.width=innerWidth;c.height=innerHeight;
 const st=getComputedStyle(document.documentElement),col=['#fff',...['--a','--b','--c'].map(v=>st.getPropertyValue(v).trim())];
 const ps=Array.from({length:110},()=>({x:innerWidth/2,y:innerHeight*.55,vx:(Math.random()-.5)*16,vy:-Math.random()*17-4,s:5+Math.random()*7,c:col[Math.random()*col.length|0],r:Math.random()*6}));
 let f=0;(function d(){x.clearRect(0,0,c.width,c.height);
  ps.forEach(p=>{p.vy+=.45;p.x+=p.vx;p.y+=p.vy;p.r+=.2;x.save();x.translate(p.x,p.y);x.rotate(p.r);x.fillStyle=p.c;x.fillRect(-p.s/2,-p.s/2,p.s,p.s*.6);x.restore()});
  if(++f<110)requestAnimationFrame(d);else x.clearRect(0,0,c.width,c.height)})()}
// ---- UI painting
function progUI(b){$('#sl').textContent=b.l;$('#pc').textContent=Math.round(b.p)+'%';$('#rp').style.strokeDashoffset=327*(1-b.p/100);
 document.querySelectorAll('.st').forEach((e,k)=>{e.classList.toggle('done',k<b.i||b.p>=100);e.classList.toggle('act',k==b.i&&b.s==='run')})}
function resUI(b){const ok=b.s==='ok';$('#rI').textContent=ok?'🎉':'😕';$('#rT').textContent=ok?b.name+' থেকে APK তৈরি':b.err;
 $('#rIn').hidden=!(ok&&A.hasApk(b.id));$('#rLg').hidden=!b.url;const L=$('#rL');L.textContent=b.log||'';L.hidden=!b.log;$('#rCp').hidden=!b.log;$('#rSh').hidden=!(ok&&A.hasApk(b.id));$('#rRt').hidden=!(b.s==='fail'&&b.run);
 const r=$('#res');r.style.animation='none';r.offsetWidth;r.style.animation=''}
function paint(){const b=find(S.view);
 $('#pick').hidden=!!b;$('#prog').hidden=!b;$('#nw').hidden=!b;
 if(b){progUI(b);$('#res').hidden=b.s==='run';if(b.s!=='run')resUI(b)}else $('#res').hidden=true}
function bd(){const n=builds.filter(x=>x.s==='run').length;$('#bd').textContent=n||''}
function upd(b,i,l,p){b.i=i;b.l=l;b.p=p;save();if(S.view===b.id)progUI(b)}
function fin(b,ok,msg){b.s=ok?'ok':'fail';b.err=msg;b.l=ok?'রেডি! 🎉':'❌ '+String(msg||'ফেল').split('\n')[0];if(ok){b.i=4;b.p=100}b.dur=Math.round((Date.now()-b.t)/1000);save();bd();hap();
 if(S.view===b.id&&S.tab==0){paint();if(ok){if(cfg.conf)confetti();if(cfg.autoInst)A.install(b.id)}}
 else{toast((ok?'✅ APK তৈরি: ':'❌ ফেল: ')+b.name);if(S.tab==1)renderHist()}}
// ---- build pipeline (many can run together)
async function ensureWf(force){
 if(!force&&cfg.wfv===WFV)return;
 const want=A.workflow();if(!want)return;
 const g=await gh(`${repo()}/contents/.github/workflows/build.yml?ref=main`);
 let sha,cur='';
 if(g.ok){const x=await g.json();sha=x.sha;try{cur=atob((x.content||'').replace(/\n/g,''))}catch(e){}}
 if(cur!==want){
  const p=await gh(`${repo()}/contents/.github/workflows/build.yml`,{method:'PUT',body:JSON.stringify({message:'update build workflow',content:btoa(want),branch:'main',...(sha?{sha}:{})})});
  if(!p.ok)throw Error((await p.json()).message||'workflow আপডেট হয়নি');
 }
 cfg.wfv=WFV;save();
}
function put(name,data){
 const job=lock.then(async()=>{
  try{await ensureWf()}catch(e){}
  let last='';
  for(let k=0;k<4;k++){
   let sha;const g=await gh(`${repo()}/contents/upload/project.zip?ref=main`);
   if(g.ok)sha=(await g.json()).sha;
   const p=await gh(`${repo()}/contents/upload/project.zip`,{method:'PUT',body:JSON.stringify({message:'build '+name,content:data,branch:'main',...(sha?{sha}:{})})});
   if(p.ok)return(await p.json()).commit.sha;
   last=(await p.json()).message||('HTTP '+p.status);
   if(p.status!==409&&p.status!==422)throw Error('আপলোড ফেল: '+last);
   await sleep(2000);
  }
  throw Error('আপলোড ফেল: '+last)});
 lock=job.catch(()=>{});return job}
async function work(b,f){
 upd(b,0,'ZIP পড়া হচ্ছে…',4);
 const data=await b64(f);
 upd(b,0,'আপলোড হচ্ছে…',8);
 const prev=Math.max(0,...(await runs()).map(r=>r.id));
 const csha=await put(f.name,data);
 upd(b,1,'বিল্ডের সারিতে…',22);
 let run=null;
 for(let i=0;i<60&&!run;i++){
  await sleep(3000);
  const rs=await runs();
  run=rs.find(r=>r.head_sha===csha&&r.event==='push')||null;
  if(!run&&i>=7&&!b.disp){b.disp=1;await gh(`${repo()}/actions/workflows/build.yml/dispatches`,{method:'POST',body:JSON.stringify({ref:'main'})})}
  if(!run&&b.disp)run=rs.filter(r=>r.id>prev&&r.event==='workflow_dispatch'&&!builds.some(x=>x.run===r.id)).sort((x,y)=>x.id-y.id)[0]||null;
 }
 if(!run)throw Error('বিল্ড শুরু হয়নি। রিপোর Actions ট্যাব দেখুন');
 b.run=run.id;b.url=run.html_url;b.t2=Date.now();save();
 await track(b);
}
async function track(b){
 b.t2=b.t2||Date.now();let run,fails=0;
 for(;;){
  try{run=await(await gh(`${repo()}/actions/runs/${b.run}`)).json();fails=0}
  catch(e){if(++fails>10)throw Error('ইন্টারনেট সমস্যা');await sleep(4000);continue}
  const el=(Date.now()-b.t2)/1000;
  if(run.status==='completed'&&!(b.att&&run.run_attempt<=b.att))break;
  upd(b,2,'বিল্ড চলছে… '+fmt(el),28+57*(1-Math.exp(-el/90)));
  if(el>2700)throw Error('বিল্ড অনেক সময় নিচ্ছে, লগ দেখুন');
  await sleep(4000);
 }
 b.att=run.run_attempt;
 if(run.conclusion!=='success'){upd(b,2,'কারণ খোঁজা হচ্ছে…',b.p);await why(b);fin(b,false,b.err||'বিল্ড ফেল হয়েছে');return}
 const a=await(await gh(`${repo()}/actions/runs/${b.run}/artifacts`)).json();
 if(!a.artifacts||!a.artifacts.length)throw Error('বিল্ড হয়েছে কিন্তু APK পাওয়া যায়নি');
 upd(b,3,'APK নামছে…',85);
 await new Promise((res,rej)=>{dls[b.id]={res,rej};A.download(cfg.token,cfg.owner,cfg.repo,String(a.artifacts[0].id),b.id)});
 fin(b,true,'');
}
async function why(b){
 b.err='বিল্ড ফেল হয়েছে';
 try{
  const jb=(await(await gh(`${repo()}/actions/runs/${b.run}/jobs`)).json()).jobs[0];
  const st=(jb.steps||[]).find(s=>s.conclusion==='failure');
  if(st)b.err='বিল্ড ফেল, ধাপ: '+st.name;
  await new Promise(res=>{logw[b.id]=res;A.fetchLog(cfg.token,cfg.owner,cfg.repo,String(jb.id),b.id);setTimeout(res,25000)});
 }catch(e){}
}
window.onLog=(id,t)=>{const b=find(id);if(b){b.log=t;save()}logw[id]&&logw[id]()};
function start(){
 if(!S.f)return;
 if(!cfg.token){toast('আগে সেটিংসে টোকেন বসান');tab(2);return}
 const f=S.f,b={id:String(Date.now()),name:f.name,t:Date.now(),s:'run',i:0,p:0,l:'শুরু হচ্ছে…',url:'',run:0};
 builds.unshift(b);S.view=b.id;S.f=null;resetPicker();save();bd();paint();hap();
 work(b,f).catch(e=>fin(b,false,e.message||String(e)));
}
window.onDl=(id,p)=>{const b=find(id);if(b)upd(b,3,'APK নামছে… '+p+'%',85+p*.13)};
window.onDone=id=>dls[id]&&dls[id].res();
window.onErr=(id,m)=>dls[id]&&dls[id].rej(Error(m));
window.onShared=async name=>{
 try{const bl=await(await fetch('https://shared.local/zip?'+Date.now())).blob();
  S.f=new File([bl],name,{type:'application/zip'});S.view=null;paint();tab(0);
  $('#fn').textContent=name;$('#fs').textContent=size(S.f.size);$('#go').disabled=false;chk(S.f);
  toast('📥 ZIP পাওয়া গেছে, এবার APK বানান চাপুন')}
 catch(e){toast('শেয়ার করা ফাইল পড়া যায়নি')}};
function resetPicker(){$('#file').value='';$('#fn').textContent='ZIP ফাইল বাছুন';$('#fs').textContent='এখানে চাপুন';$('#go').disabled=true;$('#zc').hidden=true}
async function scanZip(f){
 try{
  const n=Math.min(f.size,70000),v=new DataView(await f.slice(f.size-n).arrayBuffer());
  let e=-1;for(let i=n-22;i>=0;i--){if(v.getUint32(i,true)===0x06054b50){e=i;break}}
  if(e<0)return null;
  const cnt=v.getUint16(e+10,true),csz=v.getUint32(e+12,true),off=v.getUint32(e+16,true);
  if(off===0xffffffff)return null;
  const cd=new DataView(await f.slice(off,off+csz).arrayBuffer()),td=new TextDecoder(),names=[];let p=0;
  for(let k=0;k<cnt&&p+46<=cd.byteLength;k++){
   if(cd.getUint32(p,true)!==0x02014b50)break;
   const nl=cd.getUint16(p+28,true),el=cd.getUint16(p+30,true),cl=cd.getUint16(p+32,true);
   names.push(td.decode(new Uint8Array(cd.buffer,p+46,nl)));p+=46+nl+el+cl}
  const has=r=>names.some(x=>r.test(x));
  return{n:cnt,gradle:has(/(^|\/)settings\.gradle(\.kts)?$/),wrap:has(/(^|\/)gradlew$/),man:has(/AndroidManifest\.xml$/)}
 }catch(e){return null}}
async function chk(f){const z=$('#zc');z.hidden=true;const r=await scanZip(f);if(S.f!==f||!r)return;
 const c=(ok,t)=>`<span class="${ok?'ok':'bad'}">${ok?'✅':'⚠️'} ${t}</span>`;
 z.innerHTML=`<span>📁 ${r.n}টি ফাইল</span>`+c(r.gradle,'settings.gradle')+c(r.man,'AndroidManifest')+`<span>${r.wrap?'✅':'➖'} gradlew</span>`+(r.gradle?'':'<span class="bad">Gradle প্রজেক্ট নয়, বিল্ড ফেল হতে পারে</span>');
 z.hidden=false}
async function rerun(b){
 if(!b||!b.run){toast('এটা আবার চালানো যাবে না');return}
 const r=await gh(`${repo()}/actions/runs/${b.run}/rerun`,{method:'POST'});
 if(!r.ok){toast('❌ '+((await r.json()).message||r.status));return}
 b.s='run';b.err='';b.log='';b.t=Date.now();b.t2=Date.now();upd(b,2,'আবার চালু হচ্ছে…',30);bd();paint();
 track(b).catch(e=>fin(b,false,e.message||String(e)))}
function storUI(){const n=A.storage();$('#sgv').textContent=n?size(n):'0 KB'}
function statsUI(){
 const ok=builds.filter(x=>x.s==='ok').length,fl=builds.filter(x=>x.s==='fail').length,d=builds.filter(x=>x.dur).map(x=>x.dur);
 $('#stats').innerHTML=[[builds.length,'মোট'],[ok,'সফল'],[fl,'ফেল'],[d.length?fmt(d.reduce((a,c)=>a+c,0)/d.length):'–','গড় সময়']].map(([v,l])=>`<div><b>${v}</b><small>${l}</small></div>`).join('')}
const apkName=b=>b.name.replace(/\.zip$/i,'')+'.apk';
function renderHist(){
 statsUI();
 $('#fl').innerHTML=[['all','সব'],['ok','✅ সফল'],['fail','❌ ফেল'],['run','⏳ চলছে']].map(([k,l])=>`<button class="chip ${S.flt==k?'on':''}" data-f="${k}">${l}</button>`).join('');
 $('#fl').querySelectorAll('.chip').forEach(e=>e.onclick=()=>{S.flt=e.dataset.f;hap();renderHist()});
 const h=$('#hist'),list=builds.filter(x=>S.flt=='all'||x.s==S.flt);
 if(!list.length){h.innerHTML='<div class="empty">📭<br>এখানে কিছু নেই</div>';return}
 h.innerHTML=list.map((x,i)=>{const has=x.s==='ok'&&A.hasApk(x.id);
  const st=x.s==='run'?x.l:x.s==='ok'?(has?'APK সেভ আছে · '+size(A.apkSize(x.id)):'APK মুছে ফেলা'):'ফেল';
  const act=has?`<button class="mini" data-i="${x.id}">📲</button><button class="mini" data-s="${x.id}">📤</button><button class="mini" data-d="${x.id}">🗑</button>`:x.s!=='run'?`<button class="mini" data-r="${x.id}">✖</button>`:'';
  return`<div class="glass hi" data-id="${x.id}" style="animation-delay:${i*60}ms"><span class="e">${x.s=='ok'?'✅':x.s=='fail'?'❌':'⏳'}</span><div><b>${esc(x.name)}</b><small>${esc(st)}${x.dur?' · ⏱ '+fmt(x.dur):''} · ${new Date(x.t).toLocaleString('bn-BD')}</small></div>${act}</div>`}).join('');
 h.querySelectorAll('.hi').forEach(e=>e.onclick=()=>{S.view=e.dataset.id;tab(0);paint()});
 const on=(q,fn)=>h.querySelectorAll(q).forEach(e=>e.onclick=ev=>{ev.stopPropagation();hap();fn(e)});
 on('[data-i]',e=>A.install(e.dataset.i));
 on('[data-s]',e=>{const b=find(e.dataset.s);if(b)A.share(b.id,apkName(b))});
 on('[data-d]',e=>{A.deleteApk(e.dataset.d);toast('APK মুছে ফেলা হয়েছে');renderHist()});
 on('[data-r]',e=>{builds=builds.filter(x=>x.id!==e.dataset.r);if(S.view===e.dataset.r){S.view=null;paint()}save();renderHist()})}
// ---- wiring
$('#steps').innerHTML=NAMES.map((n,i)=>`<div class="st"><i>${i+1}</i><span>${n}</span></div>`).join('');
$('#file').onchange=e=>{const f=e.target.files[0];if(!f)return;S.f=f;$('#fn').textContent=f.name;$('#fs').textContent=size(f.size);$('#go').disabled=false;chk(f);hap()};
$('#go').onclick=start;
$('#nw').onclick=()=>{S.view=null;paint();hap()};
$('#rIn').onclick=()=>A.install(S.view);
$('#rLg').onclick=()=>{const b=find(S.view);if(b&&b.url)A.openUrl(b.url)};
document.querySelectorAll('nav button').forEach((b,i)=>b.onclick=()=>tab(i));
$('#tk').value=cfg.token;$('#ow').value=cfg.owner;$('#rp2').value=cfg.repo;$('#hp').checked=cfg.haptic;
$('#tk').oninput=e=>{cfg.token=e.target.value.trim();save()};
$('#ow').oninput=e=>{cfg.owner=e.target.value.trim();save()};
$('#rp2').oninput=e=>{cfg.repo=e.target.value.trim();save()};
$('#hp').onchange=e=>{cfg.haptic=e.target.checked;save()};
$('#pa').onclick=async()=>{try{const t=await navigator.clipboard.readText();$('#tk').value=cfg.token=t.trim();save();toast('টোকেন বসানো হয়েছে')}catch(e){toast('পেস্ট হয়নি, ঘরে চেপে ধরে পেস্ট করুন')}};
$('#ts').onclick=async()=>{hap();if(!cfg.token){toast('আগে টোকেন দিন');return}
 try{const r=await gh(repo());const j=await r.json();
  toast(r.ok?(j.permissions&&j.permissions.push?'✅ সংযোগ ঠিক আছে':'⚠️ রিপো পাওয়া গেছে, কিন্তু লেখার অনুমতি নেই'):'❌ '+(j.message||r.status))}
 catch(e){toast('❌ ইন্টারনেট বা সংযোগ সমস্যা')}};
$('#cl').onclick=()=>{builds.forEach(b=>A.deleteApk(b.id));builds=builds.filter(b=>b.s==='run');S.view=null;save();paint();renderHist();toast('মুছে ফেলা হয়েছে');hap()};
$('#th').innerHTML=[['aurora','#7c5cff,#ff4fa3'],['forest','#18c76b,#e6c84a'],['rose','#ff4d6d,#c77dff'],['sunset','#ff7a3d,#ff3d81'],['ocean','#1fb5ff,#2de2a6'],['candy','#ff6ad5,#6be3ff']]
 .map(([k,c])=>`<div class="th" data-k="${k}" style="background:linear-gradient(135deg,${c})"></div>`).join('');
document.querySelectorAll('.th').forEach(e=>e.onclick=()=>{theme(e.dataset.k);hap()});
document.addEventListener('pointerdown',e=>{const b=e.target.closest('.btn');if(!b||b.disabled)return;
 const r=b.getBoundingClientRect(),s=document.createElement('span'),d=Math.max(r.width,r.height)/3;
 s.className='rip';s.style.cssText=`width:${d}px;height:${d}px;left:${e.clientX-r.left-d/2}px;top:${e.clientY-r.top-d/2}px`;
 b.appendChild(s);setTimeout(()=>s.remove(),650)});
$('#rSh').onclick=()=>{const b=find(S.view);if(b)A.share(b.id,apkName(b))};
$('#rRt').onclick=()=>rerun(find(S.view));
$('#ac').onclick=()=>A.openUrl(`https://github.com/${cfg.owner}/${cfg.repo}/actions`);
$('#ai').checked=cfg.autoInst;$('#cf').checked=cfg.conf;$('#rm').checked=cfg.rm;
$('#ai').onchange=e=>{cfg.autoInst=e.target.checked;save()};
$('#cf').onchange=e=>{cfg.conf=e.target.checked;save()};
$('#rm').onchange=e=>{cfg.rm=e.target.checked;save();document.documentElement.toggleAttribute('data-rm',cfg.rm)};
$('#rCp').onclick=()=>{const b=find(S.view);if(b&&b.log){A.copy(b.log);toast('📋 লগ কপি হয়েছে')}};
$('#wf').onclick=async()=>{hap();if(!cfg.token){toast('আগে টোকেন দিন');return}
 try{await ensureWf(true);toast('✅ workflow আপডেট হয়েছে')}catch(e){toast('❌ '+e.message)}};
theme(cfg.theme);document.documentElement.toggleAttribute('data-rm',!!cfg.rm);paint();bd();
if(!cfg.token)setTimeout(()=>{tab(2);toast('আগে GitHub টোকেন বসান, একবারই লাগবে')},500);
builds.filter(b=>b.s==='run').forEach(b=>{if(b.run&&cfg.token)track(b).catch(e=>fin(b,false,e.message||String(e)));else fin(b,false,'অ্যাপ বন্ধ হয়ে যাওয়ায় থেমে গেছে')});
