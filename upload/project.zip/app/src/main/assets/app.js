const $=s=>document.querySelector(s),sleep=ms=>new Promise(r=>setTimeout(r,ms));
const A=window.Android||{openUrl(){},download(){},install(){},haptic(){}};
let cfg=Object.assign({owner:'Ismail102589',repo:'apk-builder',theme:'aurora',haptic:true,token:''},JSON.parse(localStorage.cfg||'{}'));
let hist=JSON.parse(localStorage.hist||'[]');
const S={f:null,busy:false,dl:null,url:''};
const NAMES=['আপলোড','সারিতে','বিল্ড','ডাউনলোড','রেডি'];
const save=()=>{localStorage.cfg=JSON.stringify(cfg);localStorage.hist=JSON.stringify(hist.slice(0,30))};
const hap=()=>{if(cfg.haptic)A.haptic()};
const repo=()=>`/repos/${cfg.owner}/${cfg.repo}`;
const fmt=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
const size=b=>b>1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),2800)}
function tab(n){document.querySelectorAll('.page').forEach((p,i)=>p.classList.toggle('on',i==n));
 document.querySelectorAll('nav button').forEach((b,i)=>b.classList.toggle('on',i==n));
 $('#ind').style.transform=`translateX(${n*100}%)`;if(n==1)renderHist();hap()}
function theme(t){document.documentElement.dataset.t=t;cfg.theme=t;save();
 document.querySelectorAll('.th').forEach(e=>e.classList.toggle('on',e.dataset.k==t))}
function step(i,label,p){$('#sl').textContent=label;$('#pc').textContent=Math.round(p)+'%';
 $('#rp').style.strokeDashoffset=327*(1-p/100);
 document.querySelectorAll('.st').forEach((e,k)=>{e.classList.toggle('done',k<i||p>=100);e.classList.toggle('act',k==i&&p<100)})}
function b64(f){return new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(r.result.split(',')[1]);r.onerror=()=>no(Error('ফাইল পড়া যায়নি'));r.readAsDataURL(f)})}
function gh(p,o={}){return fetch('https://api.github.com'+p,{...o,headers:{Authorization:'Bearer '+cfg.token,Accept:'application/vnd.github+json',...(o.body?{'Content-Type':'application/json'}:{})}})}
async function runs(){const r=await gh(`${repo()}/actions/runs?per_page=10`);
 if(!r.ok)throw Error('রান তালিকা পাওয়া যায়নি ('+r.status+')');return(await r.json()).workflow_runs||[]}
function confetti(){const c=$('#cv'),x=c.getContext('2d');c.width=innerWidth;c.height=innerHeight;
 const st=getComputedStyle(document.documentElement),col=['#fff',...['--a','--b','--c'].map(v=>st.getPropertyValue(v).trim())];
 const ps=Array.from({length:110},()=>({x:innerWidth/2,y:innerHeight*.55,vx:(Math.random()-.5)*16,vy:-Math.random()*17-4,s:5+Math.random()*7,c:col[Math.random()*col.length|0],r:Math.random()*6}));
 let f=0;(function d(){x.clearRect(0,0,c.width,c.height);
  ps.forEach(p=>{p.vy+=.45;p.x+=p.vx;p.y+=p.vy;p.r+=.2;x.save();x.translate(p.x,p.y);x.rotate(p.r);x.fillStyle=p.c;x.fillRect(-p.s/2,-p.s/2,p.s,p.s*.6);x.restore()});
  if(++f<110)requestAnimationFrame(d);else x.clearRect(0,0,c.width,c.height)})()}
function result(ok,msg,url){S.url=url||'';$('#rI').textContent=ok?'🎉':'😕';$('#rT').textContent=msg;
 $('#rIn').hidden=!ok;$('#rLg').hidden=!url;const r=$('#res');r.hidden=false;r.style.animation='none';r.offsetWidth;r.style.animation=''}
async function build(){
 if(S.busy||!S.f)return;
 if(!cfg.token){toast('আগে সেটিংসে টোকেন বসান');tab(2);return}
 S.busy=true;hap();$('#res').hidden=true;$('#prog').hidden=false;$('#go').disabled=true;
 const item={name:S.f.name,t:Date.now(),s:'run',url:''};hist.unshift(item);save();
 try{
  step(0,'ZIP আপলোড হচ্ছে…',6);
  const prev=Math.max(0,...(await runs()).map(r=>r.id));
  const data=await b64(S.f);
  let sha;const g=await gh(`${repo()}/contents/upload/project.zip?ref=main`);
  if(g.ok)sha=(await g.json()).sha;
  const p=await gh(`${repo()}/contents/upload/project.zip`,{method:'PUT',body:JSON.stringify({message:'build '+S.f.name,content:data,branch:'main',...(sha?{sha}:{})})});
  if(!p.ok)throw Error((await p.json()).message||'আপলোড ফেল');
  step(1,'বিল্ডের সারিতে…',22);
  let run=null;
  for(let i=0;i<60&&!run;i++){
   await sleep(3000);
   run=(await runs()).filter(r=>r.id>prev).sort((a,b)=>a.id-b.id)[0]||null;
   if(!run&&i==7)await gh(`${repo()}/actions/workflows/build.yml/dispatches`,{method:'POST',body:JSON.stringify({ref:'main'})});
  }
  if(!run)throw Error('বিল্ড শুরু হয়নি। রিপোর Actions ট্যাব দেখুন');
  item.url=run.html_url;const t1=Date.now();
  for(;;){
   const r=await(await gh(`${repo()}/actions/runs/${run.id}`)).json(),el=(Date.now()-t1)/1000;
   if(r.status==='completed'){run=r;break}
   step(2,'বিল্ড চলছে… '+fmt(el),28+57*(1-Math.exp(-el/90)));
   if(el>2400)throw Error('বিল্ড অনেক সময় নিচ্ছে, লগ দেখুন');
   await sleep(4000);
  }
  if(run.conclusion!=='success'){item.s='fail';save();result(false,'বিল্ড ফেল হয়েছে। লগে কারণ দেখুন।',run.html_url);return}
  const a=await(await gh(`${repo()}/actions/runs/${run.id}/artifacts`)).json();
  if(!a.artifacts||!a.artifacts.length)throw Error('বিল্ড হয়েছে কিন্তু APK পাওয়া যায়নি');
  step(3,'APK নামছে…',85);
  await new Promise((res,rej)=>{S.dl={res,rej};A.download(cfg.token,cfg.owner,cfg.repo,String(a.artifacts[0].id))});
  item.s='ok';save();step(4,'রেডি! 🎉',100);confetti();hap();
  result(true,item.name+' থেকে APK তৈরি',run.html_url);A.install();
 }catch(e){item.s='fail';save();result(false,e.message||String(e),item.url)}
 finally{S.busy=false;$('#go').disabled=!S.f}
}
window.onDl=p=>step(3,'APK নামছে… '+p+'%',85+p*.13);
window.onDone=()=>S.dl&&S.dl.res();
window.onErr=m=>S.dl&&S.dl.rej(Error(m));
window.toast=toast;
function renderHist(){const h=$('#hist');
 if(!hist.length){h.innerHTML='<div class="empty">📭<br>এখনো কোনো বিল্ড নেই</div>';return}
 h.innerHTML=hist.map((x,i)=>`<div class="glass hi" style="animation-delay:${i*70}ms"><span class="e">${x.s=='ok'?'✅':x.s=='fail'?'❌':'⏳'}</span><div><b>${x.name.replace(/</g,'&lt;')}</b><small>${new Date(x.t).toLocaleString('bn-BD')}</small></div>${x.url?`<button class="mini" data-u="${x.url}">লগ</button>`:''}</div>`).join('');
 h.querySelectorAll('[data-u]').forEach(b=>b.onclick=()=>{hap();A.openUrl(b.dataset.u)})}
// wiring
$('#steps').innerHTML=NAMES.map((n,i)=>`<div class="st"><i>${i+1}</i><span>${n}</span></div>`).join('');
$('#file').onchange=e=>{const f=e.target.files[0];if(!f)return;S.f=f;$('#fn').textContent=f.name;$('#fs').textContent=size(f.size);$('#go').disabled=S.busy;hap()};
$('#go').onclick=build;
$('#rIn').onclick=()=>A.install();
$('#rLg').onclick=()=>A.openUrl(S.url);
document.querySelectorAll('nav button').forEach((b,i)=>b.onclick=()=>tab(i));
$('#tk').value=cfg.token;$('#ow').value=cfg.owner;$('#rp2').value=cfg.repo;$('#hp').checked=cfg.haptic;
$('#tk').oninput=e=>{cfg.token=e.target.value.trim();save()};
$('#ow').oninput=e=>{cfg.owner=e.target.value.trim();save()};
$('#rp2').oninput=e=>{cfg.repo=e.target.value.trim();save()};
$('#hp').onchange=e=>{cfg.haptic=e.target.checked;save()};
$('#pa').onclick=async()=>{try{const t=await navigator.clipboard.readText();$('#tk').value=cfg.token=t.trim();save();toast('টোকেন বসানো হয়েছে')}catch(e){toast('পেস্ট হয়নি, ঘরে চেপে ধরে পেস্ট করুন')}};
$('#ts').onclick=async()=>{hap();if(!cfg.token){toast('আগে টোকেন দিন');return}
 try{const r=await gh(repo());const j=await r.json();
  toast(r.ok?(j.permissions&&j.permissions.push?'✅ সংযোগ ঠিক আছে':'⚠️ রিপো পাওয়া গেছে, কিন্তু লেখার অনুমতি নেই'):'❌ '+(j.message||r.status))}
 catch(e){toast('❌ ইন্টারনেট বা সংযোগ সমস্যা')}};
$('#cl').onclick=()=>{hist=[];save();toast('ইতিহাস মুছেছে');hap()};
$('#th').innerHTML=[['aurora','#7c5cff,#ff4fa3'],['sunset','#ff7a3d,#ff3d81'],['ocean','#1fb5ff,#2de2a6'],['candy','#ff6ad5,#6be3ff']]
 .map(([k,c])=>`<div class="th" data-k="${k}" style="background:linear-gradient(135deg,${c})"></div>`).join('');
document.querySelectorAll('.th').forEach(e=>e.onclick=()=>{theme(e.dataset.k);hap()});
document.addEventListener('pointerdown',e=>{const b=e.target.closest('.btn');if(!b||b.disabled)return;
 const r=b.getBoundingClientRect(),s=document.createElement('span'),d=Math.max(r.width,r.height)/3;
 s.className='rip';s.style.cssText=`width:${d}px;height:${d}px;left:${e.clientX-r.left-d/2}px;top:${e.clientY-r.top-d/2}px`;
 b.appendChild(s);setTimeout(()=>s.remove(),650)});
theme(cfg.theme);step(0,'প্রস্তুত',0);
