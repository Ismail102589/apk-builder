#!/bin/bash
# YL_GLASS=1 হলে স্বচ্ছ প্যানেল ও জানালা চালু; নইলে সাধারণ (দ্রুত) মোড
sleep 5
Q=xfconf-query
if [ "$YL_GLASS" = "1" ]; then
  $Q -c xfwm4 -p /general/use_compositing -n -t bool -s true
  $Q -c xfwm4 -p /general/show_frame_shadow -n -t bool -s true
  $Q -c xfwm4 -p /general/show_popup_shadow -n -t bool -s true
  $Q -c xfwm4 -p /general/frame_opacity -n -t int -s 92
  $Q -c xfce4-panel -p /panels/panel-1/background-style -n -t uint -s 1
  $Q -c xfce4-panel -p /panels/panel-1/background-rgba -n -a -t double -s 1.0 -t double -s 1.0 -t double -s 1.0 -t double -s 0.62
else
  $Q -c xfwm4 -p /general/use_compositing -n -t bool -s false
  $Q -c xfce4-panel -p /panels/panel-1/background-style -n -t uint -s 0
fi
