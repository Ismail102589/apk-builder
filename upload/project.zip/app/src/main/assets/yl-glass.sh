#!/bin/bash
# YL_GLASS=1 হলে স্বচ্ছতা, ছায়া ও নরম প্যানেল চালু; নইলে সাধারণ (দ্রুত) মোড
sleep 5
Q=xfconf-query
if [ "$YL_GLASS" = "1" ]; then
  $Q -c xfwm4 -p /general/use_compositing -n -t bool -s true
  $Q -c xfwm4 -p /general/show_frame_shadow -n -t bool -s true
  $Q -c xfwm4 -p /general/show_popup_shadow -n -t bool -s true
  for n in 1 2; do
    $Q -c xfce4-panel -p /panels/panel-$n/background-style -n -t uint -s 1
    $Q -c xfce4-panel -p /panels/panel-$n/background-rgba -n -a -t double -s 0.97 -t double -s 0.97 -t double -s 0.98 -t double -s 0.60
  done
else
  $Q -c xfwm4 -p /general/use_compositing -n -t bool -s false
fi
