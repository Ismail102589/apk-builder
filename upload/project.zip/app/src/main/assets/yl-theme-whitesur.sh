#!/bin/bash
# ঐচ্ছিক: macOS/Cutefish-এর মতো GTK থিম (WhiteSur) বসায়। ২০-৪০ মিনিট লাগতে পারে।
export DEBIAN_FRONTEND=noninteractive
echo "WhiteSur থিম বসানো হচ্ছে…"
apt-get update
apt-get install -y --no-install-recommends sassc libglib2.0-dev-bin libxml2-utils curl ca-certificates || exit 1
cd /tmp && rm -rf ws && mkdir ws && cd ws
curl -fsSL https://github.com/vinceliuice/WhiteSur-gtk-theme/archive/refs/heads/master.tar.gz | tar -xz --strip-components=1 || exit 1
timeout 1500 ./install.sh -c Light -t default
cd /tmp && rm -rf ws
echo
echo "শেষ! ⋮ মেনু থেকে Linux বন্ধ করে আবার চালু করুন।"
read -p "Enter চাপুন।" x
