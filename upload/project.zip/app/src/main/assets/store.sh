#!/bin/bash
# অ্যাপ স্টোরের কাজ: update | uris | install | debinstall | remove
export DEBIAN_FRONTEND=noninteractive LANG=C.UTF-8 HOME=/root
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > /etc/resolv.conf
mkdir -p /var/cache/apt/archives/partial /root/store
cmd="$1"; shift

stub_on()  { dpkg-divert --local --rename --add /usr/bin/py3compile >/dev/null 2>&1; printf '#!/bin/sh\nexit 0\n' > /usr/bin/py3compile; chmod +x /usr/bin/py3compile; }
stub_off() { rm -f /usr/bin/py3compile; dpkg-divert --local --rename --remove /usr/bin/py3compile >/dev/null 2>&1; }

case "$cmd" in
  update)
    echo "##STEP প্যাকেজ তালিকা আপডেট হচ্ছে…"
    apt-get update || { sleep 3; apt-get update; } ;;
  uris)
    apt-get install --print-uris -y -qq --no-install-recommends $1 \
      | grep "^'" | sed -E "s/^'([^']+)' +([^ ]+) +([0-9]+).*/URI \1 \2 \3/" ;;
  install)
    echo "##STEP ইনস্টল হচ্ছে…"
    dpkg --configure -a 2>/dev/null
    stub_on
    apt-get install -y --no-install-recommends $1; rc=$?
    stub_off
    update-desktop-database 2>/dev/null
    exit $rc ;;
  debinstall)
    echo "##STEP ইনস্টল হচ্ছে…"
    echo "code code/add-microsoft-repo boolean false" | debconf-set-selections 2>/dev/null
    stub_on
    apt-get install -y --no-install-recommends "$1"; rc=$?
    stub_off
    rm -f /etc/apt/sources.list.d/vscode.list /etc/apt/sources.list.d/vscode.sources /etc/apt/trusted.gpg.d/microsoft.gpg
    if [ -x /usr/share/code/code ]; then
      cat > /usr/share/applications/code-root.desktop <<'DE'
[Desktop Entry]
Type=Application
Name=Visual Studio Code
Exec=/usr/share/code/code --no-sandbox --user-data-dir=/root/.config/Code-root %F
Icon=vscode
Categories=Development;IDE;
DE
    fi
    update-desktop-database 2>/dev/null
    rm -f /root/store/app.deb
    exit $rc ;;
  remove)
    echo "##STEP মোছা হচ্ছে…"
    apt-get remove -y --purge $1; rc=$?
    apt-get autoremove -y 2>/dev/null
    update-desktop-database 2>/dev/null
    exit $rc ;;
  *) echo "অজানা কাজ: $cmd"; exit 2 ;;
esac
