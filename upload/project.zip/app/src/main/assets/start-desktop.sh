#!/bin/bash
export HOME=/root USER=root LOGNAME=root LANG=C.UTF-8 SHELL=/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export XDG_RUNTIME_DIR=/tmp/runtime-root XDG_CURRENT_DESKTOP=XFCE
export MOZ_FAKE_NO_SANDBOX=1 MOZ_DISABLE_CONTENT_SANDBOX=1 MOZ_DISABLE_GMP_SANDBOX=1
export LIBGL_ALWAYS_SOFTWARE=1 NO_AT_BRIDGE=1 QT_X11_NO_MITSHM=1 _X11_NO_MITSHM=1
export XCURSOR_SIZE=32 MALLOC_ARENA_MAX=2
export GALLIUM_DRIVER=llvmpipe LP_NUM_THREADS="${YL_CORES:-4}"
export GIO_USE_VFS=local GSETTINGS_BACKEND=memory GTK_A11Y=none QT_ACCESSIBILITY=0 GTK_USE_PORTAL=0
GEOM="${VNC_GEOMETRY:-1280x576}"

# আগের সেশনের বাকি প্রসেস সরাও
pkill -x Xtigervnc 2>/dev/null
for i in 1 2 3 4 5 6 7 8 9 10; do pgrep -x Xtigervnc >/dev/null || break; sleep 0.3; done
rm -rf /tmp/.X1-lock /tmp/.X11-unix/X1 /tmp/.desktop_ready "$XDG_RUNTIME_DIR"
mkdir -p "$XDG_RUNTIME_DIR" /tmp/.X11-unix
chmod 700 "$XDG_RUNTIME_DIR"; chmod 1777 /tmp/.X11-unix

# ---- VNC সার্ভার: যে অপশন আগে ঠিকমতো চলেছে সেগুলোই ----
Xtigervnc :1 -geometry "$GEOM" -depth 24 -rfbport 5901 -localhost \
  -SecurityTypes None -AlwaysShared -ac -nolisten tcp -desktop "YOUR Linux OS" \
  >/tmp/xvnc.log 2>&1 &
XVNC=$!
sleep 2
if ! kill -0 $XVNC 2>/dev/null; then
  echo "!! Xtigervnc শুরুতেই বন্ধ হয়েছে, সহজ অপশনে আবার চেষ্টা" | tee -a /tmp/xvnc.log
  rm -rf /tmp/.X1-lock /tmp/.X11-unix/X1
  Xtigervnc :1 -geometry "$GEOM" -depth 24 -rfbport 5901 -localhost -SecurityTypes None -ac \
    >>/tmp/xvnc.log 2>&1 &
  XVNC=$!
fi

for i in $(seq 1 60); do [ -S /tmp/.X11-unix/X1 ] && break; sleep 0.5; done
export DISPLAY=:1
xset s off -dpms 2>/dev/null

# সংযোগ পরীক্ষা (লগে লেখা থাকবে, সমস্যা ধরতে সাহায্য করে)
(
  sleep 1
  if exec 3<>/dev/tcp/127.0.0.1/5901 2>/dev/null; then
    B=$(head -c 12 <&3 2>/dev/null | tr -d '\n')
    printf 'RFB 003.008\n' >&3
    N=$(dd bs=1 count=1 <&3 2>/dev/null | od -An -tu1 | tr -d ' ')
    echo "probe: banner='$B' security-types=$N" >> /tmp/xvnc.log
    exec 3>&-
  else
    echo "probe: 5901 পোর্টে সংযোগ হয়নি" >> /tmp/xvnc.log
  fi
) &

# ভারী অপ্রয়োজনীয় অটোস্টার্ট বন্ধ
mkdir -p /root/.config/autostart
for n in at-spi-dbus-bus xdg-user-dirs xdg-user-dirs-update polkit-gnome-authentication-agent-1 print-applet nm-applet blueman xiccd tracker-extract tracker-miner-fs update-notifier gnome-keyring-pkcs11 gnome-keyring-secrets gnome-keyring-ssh pulseaudio geoclue-demo-agent; do
  [ -f /etc/xdg/autostart/$n.desktop ] && printf '[Desktop Entry]\nType=Application\nHidden=true\n' > /root/.config/autostart/$n.desktop
done

/usr/local/bin/yl-style 2>/dev/null
printf '[Desktop Entry]\nType=Application\nName=Install macOS/Cutefish Theme\nComment=WhiteSur\nExec=xfce4-terminal -e yl-theme-whitesur\nIcon=preferences-desktop-theme\nCategories=System;Settings;\n' > /usr/share/applications/yourlinux-theme.desktop 2>/dev/null
printf '[Desktop Entry]\nType=Application\nName=YL Glass\nExec=/usr/local/bin/yl-glass\nHidden=false\n' > /root/.config/autostart/yl-glass.desktop
printf '[Desktop Entry]\nType=Application\nName=YL Wallpaper\nExec=/usr/local/bin/yl-wallpaper\nHidden=false\n' > /root/.config/autostart/yl-wallpaper.desktop

start_xfce() {
  dbus-launch --exit-with-session startxfce4 >/tmp/xfce.log 2>&1 &
  XFCE=$!
}
start_xfce

# প্রথম ১৫ সেকেন্ডে XFCE বন্ধ হয়ে গেলে ডিফল্ট কনফিগে আবার চেষ্টা
for i in $(seq 1 15); do
  sleep 1
  kill -0 $XFCE 2>/dev/null || break
  pgrep -x xfce4-panel >/dev/null && break
done
if ! kill -0 $XFCE 2>/dev/null; then
  echo "!! XFCE শুরুতেই বন্ধ হয়েছে, ডিফল্ট কনফিগে আবার চেষ্টা" | tee -a /tmp/xvnc.log
  tail -8 /tmp/xfce.log
  rm -rf /root/.config/xfce4 /root/.cache/sessions /root/.yl_style_applied
  start_xfce
fi

for i in $(seq 1 150); do
  kill -0 $XFCE 2>/dev/null || break
  pgrep -x xfce4-panel >/dev/null && break
  sleep 1
done
sleep 2
touch /tmp/.desktop_ready

# প্রথম অ্যাপ দ্রুত খুলতে বড় লাইব্রেরি আগেই মেমোরিতে তুলে রাখো (পেছনে, কম অগ্রাধিকারে)
(
  nice -n 19 sh -c 'for f in /usr/lib/firefox/libxul.so /usr/lib/aarch64-linux-gnu/libLLVM*.so* /usr/lib/aarch64-linux-gnu/libgtk-3.so.0; do [ -f "$f" ] && cat "$f" > /dev/null; done' 2>/dev/null
) &

wait $XFCE
kill $XVNC 2>/dev/null
exit 0
