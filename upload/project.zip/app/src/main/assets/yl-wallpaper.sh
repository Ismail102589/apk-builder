#!/bin/bash
case "${YL_STYLE:-cutefish}" in
  mint)       W=/usr/share/backgrounds/yourlinux.jpg ;;
  elementary) W=/usr/share/backgrounds/yourlinux-elementary.jpg ;;
  *)          W=/usr/share/backgrounds/yourlinux-cutefish.jpg ;;
esac
for i in $(seq 1 30); do
  props=$(xfconf-query -c xfce4-desktop -l 2>/dev/null | grep 'last-image$')
  [ -n "$props" ] && break
  sleep 1
done
for p in $props; do
  xfconf-query -c xfce4-desktop -p "$p" -s "$W"
  xfconf-query -c xfce4-desktop -p "${p%last-image}image-style" -n -t int -s 5
done
