#!/bin/bash
# YOUR Linux OS - সেটআপ v3 (Linux Mint স্টাইল)
export DEBIAN_FRONTEND=noninteractive LANG=C.UTF-8 HOME=/root
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
p() { echo "##STEP $2"; }

. /root/pkgs.sh
mkdir -p /tmp /root; chmod 1777 /tmp
printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > /etc/resolv.conf

p 0 "প্যাকেজ ইনস্টল হচ্ছে (ফোনের গতির ওপর নির্ভর করে)…"
dpkg --configure -a 2>/dev/null
VALID=$(cat /root/pkgs.valid 2>/dev/null)
[ -n "$VALID" ] || VALID="$PKG_MUST $PKG_TRY"
apt-get install -y --no-install-recommends $VALID || {
  dpkg --configure -a
  apt-get -f install -y
  apt-get install -y --no-install-recommends $VALID
} || { echo "!! ইনস্টল ব্যর্থ"; exit 1; }

p 0 "Linux Mint থিম ও আইকন বসানো হচ্ছে…"
if ls /root/mint/*.deb >/dev/null 2>&1; then
  dpkg -i --force-depends --force-overwrite /root/mint/*.deb || echo "!! Mint থিম ব্যর্থ, Arc থিম ব্যবহার হবে"
fi
rm -rf /root/mint

p 0 "elementary থিম বানানো হচ্ছে…"
if ! ls -d /usr/share/themes/io.elementary.stylesheet.* >/dev/null 2>&1; then
  (
    cd /tmp && rm -rf stylesheet
    timeout 300 git clone --depth 1 https://github.com/elementary/stylesheet.git </dev/null &&
    cd stylesheet &&
    timeout 600 meson setup build --prefix=/usr </dev/null &&
    timeout 900 ninja -C build install </dev/null
  ) || echo "!! elementary থিম বানানো যায়নি (Arc থিম ব্যবহার হবে)"
  rm -rf /tmp/stylesheet
fi

# Firefox হালকা সেটিংস (কম RAM, সফটওয়্যার রেন্ডারিং)
mkdir -p /etc/firefox
cat > /etc/firefox/syspref.js <<'FFP'
pref("dom.ipc.processCount", 2);
pref("browser.tabs.unloadOnLowMemory", true);
pref("gfx.webrender.software", true);
pref("browser.cache.disk.enable", false);
pref("browser.cache.memory.capacity", 65536);
FFP
for d in /usr/lib/firefox/browser/defaults/preferences /usr/lib/firefox/defaults/pref; do
  [ -d "$d" ] && cp /etc/firefox/syspref.js "$d/yl.js"
done

p 0 "ডেস্কটপ সাজানো হচ্ছে…"
THEME=Adwaita
for t in Mint-Y-Aqua Mint-Y Arc; do [ -d /usr/share/themes/$t ] && { THEME=$t; break; }; done
XFWM=Default; [ -d /usr/share/themes/$THEME/xfwm4 ] && XFWM=$THEME
ICON=Adwaita
for i in Mint-Y-Aqua Mint-Y Papirus; do [ -d /usr/share/icons/$i ] && { ICON=$i; break; }; done
CURSOR=Adwaita; [ -d /usr/share/icons/DMZ-White ] && CURSOR=DMZ-White
echo "theme=$THEME xfwm=$XFWM icon=$ICON cursor=$CURSOR"

X=/root/.config/xfce4/xfconf/xfce-perchannel-xml
mkdir -p $X /root/.config/xfce4/panel/launcher-6 /root/.config/xfce4/panel/launcher-7 /root/.config/xfce4/panel/launcher-8 /root/.config/autostart /usr/share/backgrounds

cat > $X/xsettings.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net" type="empty">
    <property name="ThemeName" type="string" value="$THEME"/>
    <property name="IconThemeName" type="string" value="$ICON"/>
  </property>
  <property name="Gtk" type="empty">
    <property name="FontName" type="string" value="Noto Sans 10"/>
    <property name="CursorThemeName" type="string" value="$CURSOR"/>
    <property name="CursorThemeSize" type="int" value="32"/>
  </property>
  <property name="Xft" type="empty">
    <property name="DPI" type="int" value="120"/>
    <property name="Antialias" type="int" value="1"/>
    <property name="HintStyle" type="string" value="hintslight"/>
    <property name="RGBA" type="string" value="none"/>
  </property>
</channel>
XML

cat > $X/xfwm4.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="general" type="empty">
    <property name="theme" type="string" value="$XFWM"/>
    <property name="button_layout" type="string" value="|HMC"/>
    <property name="use_compositing" type="bool" value="false"/>
    <property name="title_alignment" type="string" value="center"/>
    <property name="title_font" type="string" value="Noto Sans Bold 10"/>
  </property>
</channel>
XML

cat > $X/xfce4-panel.xml <<XML
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-panel" version="1.0">
  <property name="configver" type="int" value="2"/>
  <property name="panels" type="array">
    <value type="int" value="1"/>
    <property name="panel-1" type="empty">
      <property name="position" type="string" value="p=10;x=0;y=0"/>
      <property name="length" type="uint" value="100"/>
      <property name="position-locked" type="bool" value="true"/>
      <property name="size" type="uint" value="46"/>
      <property name="icon-size" type="uint" value="28"/>
      <property name="plugin-ids" type="array">
        <value type="int" value="1"/>
        <value type="int" value="6"/>
        <value type="int" value="7"/>
        <value type="int" value="8"/>
        <value type="int" value="2"/>
        <value type="int" value="3"/>
        <value type="int" value="4"/>
        <value type="int" value="5"/>
      </property>
    </property>
  </property>
  <property name="plugins" type="empty">
    <property name="plugin-1" type="string" value="whiskermenu"/>
    <property name="plugin-6" type="string" value="launcher">
      <property name="items" type="array"><value type="string" value="fx.desktop"/></property>
    </property>
    <property name="plugin-7" type="string" value="launcher">
      <property name="items" type="array"><value type="string" value="files.desktop"/></property>
    </property>
    <property name="plugin-8" type="string" value="launcher">
      <property name="items" type="array"><value type="string" value="term.desktop"/></property>
    </property>
    <property name="plugin-2" type="string" value="tasklist"/>
    <property name="plugin-3" type="string" value="separator">
      <property name="expand" type="bool" value="true"/>
      <property name="style" type="uint" value="0"/>
    </property>
    <property name="plugin-4" type="string" value="systray"/>
    <property name="plugin-5" type="string" value="clock"/>
  </property>
</channel>
XML

printf '[Desktop Entry]\nVersion=1.0\nType=Application\nName=Firefox\nExec=firefox %%u\nIcon=firefox\n' > /root/.config/xfce4/panel/launcher-6/fx.desktop
printf '[Desktop Entry]\nVersion=1.0\nType=Application\nName=Files\nExec=thunar\nIcon=system-file-manager\n' > /root/.config/xfce4/panel/launcher-7/files.desktop
printf '[Desktop Entry]\nVersion=1.0\nType=Application\nName=Terminal\nExec=xfce4-terminal\nIcon=utilities-terminal\n' > /root/.config/xfce4/panel/launcher-8/term.desktop
printf 'button-icon=start-here\nshow-button-title=false\nshow-button-icon=true\n' > /root/.config/xfce4/panel/whiskermenu-1.rc

# আরও অ্যাপ ইনস্টলের টুল
cat > /usr/local/bin/install-more-apps <<'MA'
#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
echo "LibreOffice, VLC, GIMP ইনস্টল হচ্ছে (সময় লাগবে)…"
apt-get update
apt-get install -y --no-install-recommends libreoffice-writer libreoffice-calc libreoffice-impress libreoffice-gtk3 vlc gimp
echo; read -p "শেষ। Enter চাপুন।" x
MA
chmod +x /usr/local/bin/install-more-apps
cat > /usr/share/applications/yourlinux-more-apps.desktop <<'DE'
[Desktop Entry]
Type=Application
Name=Install More Apps
Comment=LibreOffice, VLC, GIMP
Exec=xfce4-terminal -e install-more-apps
Icon=system-software-install
Categories=System;Settings;
DE

cat > /etc/profile.d/yourlinux.sh <<'PROF'
export MOZ_FAKE_NO_SANDBOX=1 MOZ_DISABLE_CONTENT_SANDBOX=1 MOZ_DISABLE_GMP_SANDBOX=1
export LIBGL_ALWAYS_SOFTWARE=1 NO_AT_BRIDGE=1 QT_X11_NO_MITSHM=1 _X11_NO_MITSHM=1
PROF

update-desktop-database 2>/dev/null
gtk-update-icon-cache -f /usr/share/icons/$ICON 2>/dev/null
echo 4 > /root/.setup_done
apt-get clean
rm -f /root/uris.raw /root/uris.err
p 0 "সেটআপ সম্পন্ন!"
