#!/bin/bash
# ধাপ ১: প্যাকেজ তালিকা আপডেট ও ডাউনলোডের URL তালিকা তৈরি (ডাউনলোড করে অ্যাপ নিজে, দ্রুত ও সমান্তরালে)
export DEBIAN_FRONTEND=noninteractive LANG=C.UTF-8 HOME=/root
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
step() { echo "##STEP $1"; }
. /root/pkgs.sh

step "সিস্টেম প্রস্তুত হচ্ছে…"
mkdir -p /etc/apt/apt.conf.d /etc/apt/preferences.d /etc/apt/sources.list.d /etc/dpkg/dpkg.cfg.d /tmp /root /var/cache/apt/archives/partial
chmod 1777 /tmp
printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > /etc/resolv.conf
cat > /etc/apt/apt.conf.d/01yourlinux <<'APT'
APT::Sandbox::User "root";
Acquire::Retries "5";
Acquire::Languages "none";
Acquire::PDiffs "false";
APT::Install-Recommends "false";
APT
echo 'force-unsafe-io' > /etc/dpkg/dpkg.cfg.d/02yourlinux
# ডক/ম্যান/অন্য ভাষার ফাইল বাদ: ইনস্টল অনেক দ্রুত ও জায়গা কম লাগে
cat > /etc/dpkg/dpkg.cfg.d/01-nodoc <<'DP'
path-exclude=/usr/share/doc/*
path-exclude=/usr/share/man/*
path-exclude=/usr/share/info/*
path-exclude=/usr/share/lintian/*
path-exclude=/usr/share/locale/*
path-include=/usr/share/locale/en*
path-include=/usr/share/locale/bn*
path-include=/usr/share/doc/*/copyright
DP
printf '#!/bin/sh\nexit 101\n' > /usr/sbin/policy-rc.d; chmod +x /usr/sbin/policy-rc.d

# Firefox (সত্যিকারের deb) এর জন্য Mozilla PPA
echo 'deb [trusted=yes] http://ppa.launchpadcontent.net/mozillateam/ppa/ubuntu jammy main' > /etc/apt/sources.list.d/mozilla.list
printf 'Package: *\nPin: release o=LP-PPA-mozillateam\nPin-Priority: 1001\n' > /etc/apt/preferences.d/mozilla-firefox

step "প্যাকেজ তালিকা আপডেট হচ্ছে…"
apt-get update || { sleep 3; apt-get update; } || exit 1

step "ডাউনলোডের তালিকা তৈরি হচ্ছে…"
VALID=""
for p in $PKG_MUST $PKG_TRY; do
  if apt-cache show "$p" >/dev/null 2>&1; then VALID="$VALID $p"; else echo "!! বাদ: $p"; fi
done
if apt-get install --print-uris -y -qq --no-install-recommends $VALID > /root/uris.raw 2>/root/uris.err; then
  :
else
  echo "!! সব প্যাকেজ একসাথে মেলেনি, শুধু জরুরিগুলো নিচ্ছি"
  cat /root/uris.err | tail -5
  VALID=""
  for p in $PKG_MUST; do apt-cache show "$p" >/dev/null 2>&1 && VALID="$VALID $p"; done
  apt-get install --print-uris -y -qq --no-install-recommends $VALID > /root/uris.raw 2>/root/uris.err || exit 1
fi
grep "^'" /root/uris.raw | sed -E "s/^'([^']+)' +([^ ]+) +([0-9]+).*/\1 \2 \3/" > /root/uris.txt
echo "$VALID" > /root/pkgs.valid
echo "files: $(wc -l < /root/uris.txt)"
echo 6 > /root/.prep_done
step "তালিকা প্রস্তুত"
