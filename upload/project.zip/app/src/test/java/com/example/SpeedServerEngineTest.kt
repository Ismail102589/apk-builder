package com.example

import android.content.Context
import android.net.Uri
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.SpeedDatabase
import com.example.data.repository.SpeedRepository
import com.example.data.repository.ToggleServerResult
import com.example.server.PeerVisitorClient
import com.example.server.SpeedHttpServer
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SpeedServerEngineTest {

    private lateinit var context: Context
    private lateinit var db: SpeedDatabase
    private lateinit var repo: SpeedRepository
    private lateinit var server: SpeedHttpServer

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, SpeedDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repo = SpeedRepository(context, db.speedDao())
        server = SpeedHttpServer(repo)
    }

    @After
    fun teardown() {
        server.stop()
        db.close()
    }

    @Test
    fun `duplicate folder names auto-increment cleanly`() = runBlocking {
        val f1 = repo.createFolder("Projects", null)
        val f2 = repo.createFolder("Projects", null)
        val f3 = repo.createFolder("Projects", null)

        assertEquals("Projects", f1.name)
        assertEquals("Projects (1)", f2.name)
        assertEquals("Projects (2)", f3.name)
    }

    @Test
    fun `live ancestor prevents child server toggle and serves child files`() = runBlocking {
        val parent = repo.createFolder("WebApps", null)
        val child = repo.createFolder("Demo", parent.id)

        val resParent = repo.toggleServerForFolders(setOf(parent.id))
        assertTrue(resParent is ToggleServerResult.Updated)
        assertTrue(repo.isEffectivelyLive(child.id, repo.getAllFoldersSync()))

        val resChild = repo.toggleServerForFolders(setOf(child.id))
        assertTrue(resChild is ToggleServerResult.BlockedByLiveAncestor)
        assertEquals("WebApps", (resChild as ToggleServerResult.BlockedByLiveAncestor).ancestorName)
    }

    @Test
    fun `embedded http server serves live folder and streams html file`() = runBlocking {
        val folder = repo.createFolder("LiveSite", null)
        repo.updateTags(setOf(folder.id), "#webapp #demo, showcase")
        repo.setFolderLive(folder.id, true)

        val tempHtml = File(context.cacheDir, "index.html")
        val htmlContent = "<!doctype html><html><body><h1>Speed Server Live!</h1></body></html>"
        tempHtml.writeText(htmlContent)

        val imported = repo.importFilesFromUris(folder.id, listOf(Uri.fromFile(tempHtml)))
        assertEquals(1, imported.size)
        assertTrue(imported[0].isHtml)

        server.ensureStarted()
        assertTrue(server.isRunning.value)

        val baseUrl = "http://127.0.0.1:${server.port.value}"
        val visitor = PeerVisitorClient(context)
        val snapshot = visitor.fetchFolder(baseUrl, folder.id)

        assertTrue(snapshot.online)
        assertNotNull(snapshot.folder)
        assertEquals("LiveSite", snapshot.folder?.name)
        assertEquals(listOf("webapp", "demo", "showcase"), snapshot.folder?.tagList())
        assertEquals(1, snapshot.files.size)

        val streamedFile = visitor.streamFileToCache(baseUrl, folder.id, snapshot.files[0]) {}
        assertNotNull(streamedFile)
        assertEquals(htmlContent, streamedFile?.readText())
        assertTrue(server.bytesUploaded.value >= htmlContent.length.toLong())

        // Recursive deletion removes physical file and folder
        repo.deleteFoldersRecursively(setOf(folder.id))
        assertFalse(File(imported[0].localPath).exists())
        assertTrue(repo.getAllFoldersSync().isEmpty())
    }
}
