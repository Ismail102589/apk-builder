plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.yourlinux.os"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.yourlinux.os"
        minSdk = 26
        // targetSdk 28: Android 10+ এ অ্যাপের ডেটা ফোল্ডার থেকে Linux বাইনারি চালাতে (Termux-এর মতো)
        targetSdk = 28
        versionCode = 12
        versionName = "2.1"
        ndk { abiFilters += "arm64-v8a" }
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs {
            useLegacyPackaging = true
            keepDebugSymbols += "**/*.so"
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

// বিল্ডের সময় proot বাইনারি নিজে নামায়, তাই যেকোনো বিল্ডার অ্যাপ দিয়েই APK হবে
val fetchProot = tasks.register<Exec>("fetchProot") {
    workingDir = rootProject.projectDir
    commandLine("bash", "scripts/fetch-proot.sh")
    onlyIf { !file("src/main/jniLibs/arm64-v8a/libproot.so").exists() }
}
val fetchTheme = tasks.register<Exec>("fetchTheme") {
    workingDir = rootProject.projectDir
    commandLine("bash", "scripts/fetch-theme.sh")
    isIgnoreExitValue = true
    onlyIf { !file("src/main/assets/whitesur.tar.gz").exists() }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchProot, fetchTheme) }

dependencies {
    implementation("org.apache.commons:commons-compress:1.21")
    implementation("org.tukaani:xz:1.9")
}
