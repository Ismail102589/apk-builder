package com.storeapk.core

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import coil.compose.AsyncImage
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

/** Firestore "apps" document (same schema as the web version). */
data class AppItem(
    val id: String = "", val name: String = "", val dev: String = "", val kind: String = "apk",
    val cat: String = "app", val tags: String = "", val ver: String = "", val size: String = "",
    val url: String = "", val desc: String = "", val icon: String = "",
    val shots: List<String> = emptyList(), val paths: List<String> = emptyList(),
    val owner: String = "", val ts: Long = 0
)

@Composable
fun rememberApps(): Pair<List<AppItem>, String?> {
    var list by remember { mutableStateOf(emptyList<AppItem>()) }
    var err by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) {
        val reg = FirebaseFirestore.getInstance().collection("apps").orderBy("ts", Query.Direction.DESCENDING)
            .addSnapshotListener { s, e ->
                if (e != null) err = e.message
                else list = s!!.documents.mapNotNull { d -> d.toObject(AppItem::class.java)?.copy(id = d.id) }
            }
        onDispose { reg.remove() }
    }
    return list to err
}

val Muted = Color(0xFFA9AFBD)

@Composable
fun StoreTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        background = Color(0xFF111214), surface = Color(0xFF111214), primary = Color(0xFFA8C7FA),
        onPrimary = Color(0xFF062E6F), surfaceVariant = Color(0xFF2A2D34), secondaryContainer = Color(0xFF0F3A5F)
    ), content = content
)

@Composable
fun Header(onLogout: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color.White, Color(0xFF9A9A9A))), RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp))
            .statusBarsPadding().padding(16.dp, 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(64.dp).clip(RoundedCornerShape(16.dp)))
        Text("Store APK", Modifier.weight(1f).padding(start = 12.dp), color = Color(0xFF10182B), fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (onLogout != null) TextButton(onLogout) { Text("লগআউট", color = Color(0xFF10182B)) }
    }
}

@Composable
fun AppIcon(a: AppItem, size: Dp = 68.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(18.dp))
            .background(Brush.linearGradient(listOf(Color(0xFFC99A2E), Color(0xFF2F5BD8)))),
        Alignment.Center
    ) {
        if (a.icon.startsWith("https")) AsyncImage(a.icon, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(a.name.take(1).uppercase(), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun AppRow(a: AppItem, installed: Boolean = false, onClick: () -> Unit, trailing: (@Composable () -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        AppIcon(a)
        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            Text(a.name, fontSize = 19.sp, maxLines = 1)
            Text(a.tags.ifBlank { a.dev }.split(",").joinToString(" • ") { it.trim() }, color = Muted, fontSize = 15.sp, maxLines = 1)
            val chip = if (installed) "✓ Installed" else a.size
            if (chip.isNotBlank()) Text(
                chip, Modifier.padding(top = 7.dp).background(Color(0xFF2A2D34), RoundedCornerShape(10.dp)).padding(12.dp, 5.dp),
                color = Muted, fontSize = 14.sp
            )
        }
        trailing?.invoke()
    }
}
