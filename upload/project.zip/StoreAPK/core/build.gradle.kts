plugins { id("com.android.library"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose") }
android {
    namespace = "com.storeapk.core"
    defaultConfig { minSdk = 24 }
    compileSdk = 34
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    api(platform("androidx.compose:compose-bom:2024.09.00"))
    api("androidx.compose.material3:material3")
    api("androidx.compose.ui:ui")
    api("androidx.activity:activity-compose:1.9.2")
    api("io.coil-kt:coil-compose:2.7.0")
    api(platform("com.google.firebase:firebase-bom:33.3.0"))
    api("com.google.firebase:firebase-firestore")
    api("com.google.firebase:firebase-auth")
    api("com.google.firebase:firebase-storage")
    api("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
}
