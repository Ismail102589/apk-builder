package com.storeapk.dev

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import com.storeapk.core.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StoreTheme { Surface(Modifier.fillMaxSize()) { DevApp() } } }
    }
}

@Composable
fun DevApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { user = it.currentUser }
        auth.addAuthStateListener(l); onDispose { auth.removeAuthStateListener(l) }
    }
    Column(Modifier.fillMaxSize()) {
        Header(if (user != null) ({ auth.signOut() }) else null)
        val u = user
        if (u == null) Login(auth) else Panel(u)
    }
}

@Composable
fun Login(auth: FirebaseAuth) {
    var em by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Developer লগইন", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(em, { em = it }, Modifier.fillMaxWidth(), label = { Text("ইমেইল") }, singleLine = true)
        OutlinedTextField(pw, { pw = it }, Modifier.fillMaxWidth(), label = { Text("পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        if (msg.isNotBlank()) Text(msg, color = Color(0xFFFF8A80))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button({ auth.signInWithEmailAndPassword(em.trim(), pw).addOnFailureListener { msg = it.message ?: "ব্যর্থ" } }) { Text("লগইন") }
            OutlinedButton({ auth.createUserWithEmailAndPassword(em.trim(), pw).addOnFailureListener { msg = it.message ?: "ব্যর্থ" } }) { Text("নতুন অ্যাকাউন্ট") }
        }
    }
}

@Composable
fun Panel(user: FirebaseUser) {
    val (apps, _) = rememberApps()
    val mine = apps.filter { it.owner == user.uid }
    var form by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf<AppItem?>(null) }
    if (form) { PublishForm(user) { form = false }; return }
    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        item {
            Button({ form = true }, Modifier.fillMaxWidth()) { Text("+ নতুন অ্যাপ প্রকাশ করুন") }
            Text("আমার অ্যাপ", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp))
            if (mine.isEmpty()) Text("এখনো কোনো অ্যাপ প্রকাশ করেননি।", color = Muted, modifier = Modifier.padding(top = 8.dp))
        }
        items(mine, key = { it.id }) { a -> AppRow(a, false, {}) { TextButton({ del = a }) { Text("মুছুন") } } }
    }
    del?.let { a ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("${a.name} মুছবেন?") },
            confirmButton = {
                TextButton({
                    a.paths.forEach { FirebaseStorage.getInstance().reference.child(it).delete() }
                    FirebaseFirestore.getInstance().collection("apps").document(a.id).delete(); del = null
                }) { Text("মুছুন") }
            }, dismissButton = { TextButton({ del = null }) { Text("বাতিল") } })
    }
}

fun meta(ctx: Context, u: Uri): Pair<String, Long> {
    ctx.contentResolver.query(u, null, null, null, null)?.use {
        if (it.moveToFirst()) {
            val n = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); val s = it.getColumnIndex(OpenableColumns.SIZE)
            return Pair(if (n >= 0) it.getString(n) else "", if (s >= 0) it.getLong(s) else 0L)
        }
    }
    return Pair("", 0L)
}

suspend fun upload(ctx: Context, uri: Uri, path: String, type: String? = null, onP: (Float) -> Unit): String {
    val r = FirebaseStorage.getInstance().reference.child(path)
    val md = StorageMetadata.Builder().setContentType(type ?: ctx.contentResolver.getType(uri) ?: "image/jpeg").build()
    r.putFile(uri, md).addOnProgressListener { onP(it.bytesTransferred.toFloat() / it.totalByteCount.coerceAtLeast(1)) }.await()
    return r.downloadUrl.await().toString()
}

@Composable
fun TF(l: String, v: String, min: Int = 1, on: (String) -> Unit) =
    OutlinedTextField(v, on, Modifier.fillMaxWidth(), label = { Text(l) }, minLines = min)

@Composable
fun PublishForm(user: FirebaseUser, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var dev by remember { mutableStateOf(user.displayName ?: "") }
    var kind by remember { mutableStateOf("apk") }
    var cat by remember { mutableStateOf("game") }
    var tags by remember { mutableStateOf("") }
    var ver by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    var apk by remember { mutableStateOf<Uri?>(null) }
    var ico by remember { mutableStateOf<Uri?>(null) }
    var shots by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var prog by remember { mutableFloatStateOf(0f) }
    var msg by remember { mutableStateOf("") }
    val apkP = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { apk = it }
    val icoP = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { ico = it }
    val shP = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { shots = it.take(6) }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), Arrangement.spacedBy(10.dp)) {
        Text("নতুন অ্যাপ প্রকাশ", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        TF("অ্যাপের নাম", name) { name = it }
        TF("ডেভেলপারের নাম", dev) { dev = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("apk" to "Android APK", "web" to "Web app").forEach { (k, l) -> FilterChip(kind == k, { kind = k }, { Text(l) }) }
        }
        if (kind == "apk") Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("game" to "Game", "app" to "App").forEach { (k, l) -> FilterChip(cat == k, { cat = k }, { Text(l) }) }
        }
        TF("ট্যাগ (কমা দিয়ে, যেমন: Action, Tactical shooter)", tags) { tags = it }
        TF("ভার্সন (যেমন: 1.0.0)", ver) { ver = it }
        TF("বর্ণনা", desc, 3) { desc = it }
        if (kind == "apk") {
            OutlinedButton({ apkP.launch(arrayOf("*/*")) }) { Text("APK ফাইল বাছাই করুন") }
            apk?.let { Text(meta(ctx, it).first, color = Muted) }
        }
        TF(if (kind == "apk") "অথবা APK ডাউনলোড লিংক (https://)" else "Web app লিংক (https://)", link) { link = it }
        OutlinedButton({ icoP.launch("image/*") }) { Text(if (ico == null) "আইকন ছবি বাছাই করুন" else "আইকন বাছাই হয়েছে ✓") }
        OutlinedButton({ shP.launch("image/*") }) { Text(if (shots.isEmpty()) "স্ক্রিনশট বাছাই করুন (সর্বোচ্চ ৬টি)" else "${shots.size}টি স্ক্রিনশট বাছাই হয়েছে ✓") }
        if (msg.isNotBlank()) Text(msg, color = if (msg.startsWith("ব্যর্থ") || msg.contains("দিন") || msg.contains("বাছাই")) Color(0xFFFF8A80) else Muted)
        if (busy) LinearProgressIndicator(progress = { prog }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onDone, enabled = !busy) { Text("বাতিল") }
            Button(enabled = !busy, onClick = {
                scope.launch {
                    val web = kind == "web"; val a = apk
                    if (name.isBlank()) { msg = "অ্যাপের নাম দিন"; return@launch }
                    if (!web && a != null && !meta(ctx, a).first.endsWith(".apk", true)) { msg = "শুধু .apk ফাইল বাছাই করুন"; return@launch }
                    if ((web || a == null) && !link.trim().startsWith("https://")) { msg = "APK ফাইল বাছাই করুন অথবা https:// লিংক দিন"; return@launch }
                    busy = true
                    try {
                        val doc = FirebaseFirestore.getInstance().collection("apps").document()
                        val base = "apps/${user.uid}/${doc.id}/"
                        val paths = mutableListOf<String>(); val su = mutableListOf<String>()
                        var url = link.trim(); var size = ""; var icon = ""
                        if (!web && a != null) {
                            msg = "APK আপলোড হচ্ছে..."; size = String.format("%.1f MB", meta(ctx, a).second / 1048576.0)
                            paths += base + "app.apk"; url = upload(ctx, a, base + "app.apk", "application/vnd.android.package-archive") { prog = it }
                        }
                        ico?.let { msg = "আইকন আপলোড হচ্ছে..."; paths += base + "icon"; icon = upload(ctx, it, base + "icon") { p -> prog = p } }
                        shots.forEachIndexed { i, u -> msg = "স্ক্রিনশট ${i + 1} আপলোড হচ্ছে..."; paths += base + "shot$i"; su += upload(ctx, u, base + "shot$i") { p -> prog = p } }
                        doc.set(mapOf(
                            "name" to name.trim(), "dev" to dev.trim(), "kind" to kind, "cat" to if (web) "web" else cat,
                            "tags" to tags.trim(), "ver" to ver.trim(), "size" to size, "url" to url, "desc" to desc.trim(),
                            "icon" to icon, "shots" to su, "paths" to paths, "owner" to user.uid, "ts" to System.currentTimeMillis()
                        )).await()
                        onDone()
                    } catch (e: Exception) { msg = "ব্যর্থ: ${e.message}"; busy = false }
                }
            }) { Text("প্রকাশ করুন") }
        }
    }
}
