package com.storeapk.user

import android.app.DownloadManager
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import com.storeapk.core.*
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StoreTheme { Surface(Modifier.fillMaxSize()) { UserApp() } } }
    }
}

object Installer {
    fun install(ctx: Context, a: AppItem) {
        val app = ctx.applicationContext
        if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(app, "ইনস্টলের অনুমতি দিন, তারপর আবার Install চাপুন", Toast.LENGTH_LONG).show()
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${app.packageName}")))
            return
        }
        val f = File(app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "${a.id}.apk").also { it.delete() }
        val dm = app.getSystemService(DownloadManager::class.java)
        val id = dm.enqueue(
            DownloadManager.Request(Uri.parse(a.url)).setTitle(a.name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(Uri.fromFile(f))
        )
        Toast.makeText(app, "ডাউনলোড শুরু হয়েছে", Toast.LENGTH_SHORT).show()
        ContextCompat.registerReceiver(app, object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != id) return
                app.unregisterReceiver(this)
                if (!f.exists() || f.length() == 0L) { Toast.makeText(app, "ডাউনলোড ব্যর্থ", Toast.LENGTH_LONG).show(); return }
                val uri = FileProvider.getUriForFile(app, "${app.packageName}.files", f)
                app.startActivity(
                    Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED)
    }
}

@Composable
fun UserApp() {
    val ctx = LocalContext.current
    val (apps, err) = rememberApps()
    var tab by remember { mutableStateOf(0) }
    var q by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf<AppItem?>(null) }
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    var inst by remember { mutableStateOf(prefs.getStringSet("inst", emptySet())!!.toSet()) }
    BackHandler(sel != null) { sel = null }

    Column(Modifier.fillMaxSize()) {
        Header()
        Box(Modifier.weight(1f)) {
            val a = sel
            if (a != null) {
                Detail(a, a.id in inst) {
                    if (a.kind == "web") ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(a.url)))
                    else {
                        Installer.install(ctx, a)
                        inst = inst + a.id
                        prefs.edit().putStringSet("inst", inst).apply()
                    }
                }
            } else {
                val shown = apps.filter {
                    val ok = when (tab) {
                        0 -> it.kind != "web" && it.cat == "game"
                        1 -> it.kind != "web" && it.cat == "app"
                        3 -> it.kind == "web"
                        else -> true
                    }
                    ok && "${it.name} ${it.dev} ${it.tags}".contains(q, true)
                }
                LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    if (tab == 2) item {
                        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(bottom = 12.dp), placeholder = { Text("Search apps & games") }, singleLine = true)
                    }
                    if (err != null) item { Text("ডেটা লোড হয়নি: $err") }
                    if (shown.isEmpty() && err == null) item { Text("এখানে এখনো কিছু নেই।", color = Muted) }
                    items(shown, key = { it.id }) { AppRow(it, it.id in inst, { sel = it }) }
                }
            }
        }
        if (sel == null) NavigationBar(containerColor = androidx.compose.ui.graphics.Color(0xFF1D1F24)) {
            listOf(Icons.Filled.SportsEsports to "Games", Icons.Filled.Apps to "Apps", Icons.Filled.Search to "Search", Icons.Filled.Language to "Web app")
                .forEachIndexed { i, (ic, l) -> NavigationBarItem(tab == i, { tab = i; q = "" }, { Icon(ic, l) }, label = { Text(l) }) }
        }
    }
}

@Composable
fun Detail(a: AppItem, installed: Boolean, onAction: () -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(a, 88.dp)
            Column(Modifier.padding(start = 16.dp)) {
                Text(a.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(a.dev, color = Muted)
            }
        }
        Spacer(Modifier.height(16.dp))
        if (a.url.startsWith("https")) Button(onAction) { Text(if (a.kind == "web") "Open" else if (installed) "Install again" else "Install") }
        if (a.shots.isNotEmpty()) LazyRow(Modifier.padding(vertical = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(a.shots) { AsyncImage(it, null, Modifier.height(300.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.FillHeight) }
        }
        Text("সম্পর্কে", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(a.desc.ifBlank { "বর্ণনা নেই" }, Modifier.padding(vertical = 8.dp))
        Text("তথ্য", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        listOf(
            "ডেভেলপার" to a.dev, "ধরন" to if (a.kind == "web") "Web app" else "Android APK",
            "ক্যাটাগরি" to if (a.kind == "web") "Web app" else if (a.cat == "game") "Game" else "App",
            "ট্যাগ" to a.tags, "সাইজ" to a.size, "ভার্সন" to a.ver
        ).filter { it.second.isNotBlank() }.forEach {
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), Arrangement.SpaceBetween) { Text(it.first, color = Muted); Text(it.second) }
        }
    }
}
