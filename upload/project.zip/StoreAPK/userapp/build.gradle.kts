plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.compose"); id("com.google.gms.google-services") }
android {
    namespace = "com.storeapk.user"
    defaultConfig { applicationId = "com.storeapk.user"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileSdk = 34
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies { implementation(project(":core")) }
