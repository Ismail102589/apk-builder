# Store APK (Android)

দুটি অ্যাপ, একই Firebase প্রজেক্ট (app-store-5af7f):
- `userapp` (com.storeapk.user): ব্রাউজ, অ্যাপের বিস্তারিত দেখা, Install / Open
- `devapp`  (com.storeapk.dev): লগইন, APK + আইকন + স্ক্রিনশট আপলোড করে প্রকাশ, নিজের অ্যাপ মোছা

## চালানোর ধাপ
1. Firebase Console > Project settings > Add app > Android দিয়ে দুটি অ্যাপ রেজিস্টার করুন:
   `com.storeapk.user` এবং `com.storeapk.dev`
2. প্রতিটির `google-services.json` ডাউনলোড করে রাখুন:
   `userapp/google-services.json` এবং `devapp/google-services.json`
3. Firebase Console: Authentication > Email/Password চালু, Firestore ও Storage তৈরি, Rules বসান।
4. Android Studio (Koala বা নতুন) তে এই ফোল্ডার খুলুন, Gradle sync করুন।
5. Build > Build APK(s) দিয়ে দুটি module এর APK বানান।
