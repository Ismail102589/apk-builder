export type FsId = "FAT16" | "FAT32" | "exFAT" | "NTFS" | "EXT2" | "EXT3" | "EXT4";
export type TableKind = "MBR" | "GPT";
export type ClusterChoice =
  | "default"
  | "512"
  | "1024"
  | "2048"
  | "4096"
  | "8192"
  | "16384"
  | "32768"
  | "65536";
export type ScanMode = "quick" | "smart" | "deep" | "raw";
export type RecoverLevel = "quick" | "smart" | "deep" | "raw";
export type FileKind = "image" | "video" | "audio" | "doc" | "archive" | "iso" | "other";

export interface VFile {
  id: string;
  name: string;
  bytes: number;
  kind: FileKind;
  deleted: boolean;
  recover: RecoverLevel;
  fragments: number;
  preview: string;
}

export interface Partition {
  id: string;
  label: string;
  fs: FsId;
  bytes: number;
  cluster: number;
  files: VFile[];
}

export interface Drive {
  id: string;
  model: string;
  vendor: string;
  product: string;
  vid: string;
  pid: string;
  serial: string;
  advertised: number;
  real: number;
  blockSize: number;
  speed: string;
  kind: "Flash" | "SSD" | "HDD" | "SD";
  readMBs: number;
  writeMBs: number;
  badBlockRatio: number;
  verifiedReal: boolean;
  table: TableKind | null;
  partitions: Partition[];
  lost: Partition[];
  scrap: VFile[];
  carved: VFile[];
}

export interface Backup {
  id: string;
  at: number;
  serial: string;
  model: string;
  real: number;
  table: TableKind | null;
  partitions: Partition[];
  lost: Partition[];
}

export interface BenchResult {
  id: string;
  at: number;
  model: string;
  serial: string;
  seqRead: number;
  seqWrite: number | null;
  randRead: number;
  randWrite: number | null;
}

export interface WipeCert {
  id: string;
  at: number;
  model: string;
  serial: string;
  method: string;
  passes: number;
  verify: string;
  verified: boolean;
  bytes: number;
}

export interface LogLine {
  id: string;
  at: number;
  text: string;
}

export interface Check {
  tone: "ok" | "warn" | "bad";
  label: string;
}

export const MBR_LIMIT = 2_199_023_255_552;
export const FAT_FILE_LIMIT = 4_294_967_296;
export const MIB = 1_048_576;

export const FILESYSTEMS: { id: FsId; hint: string }[] = [
  { id: "FAT16", hint: "Legacy devices · 4 GB volume limit" },
  { id: "FAT32", hint: "Consoles, TVs, cars · 4 GB file limit" },
  { id: "exFAT", hint: "Large files · Windows, macOS, many TVs" },
  { id: "NTFS", hint: "Windows · large files and permissions" },
  { id: "EXT2", hint: "Linux, no journal" },
  { id: "EXT3", hint: "Linux with a journal" },
  { id: "EXT4", hint: "Modern Linux default" },
];

export const WIPE_METHODS = [
  { id: "nist", name: "NIST 800-88 Clear", passes: 1, detail: "One pass of zeros." },
  { id: "dod", name: "DoD 5220.22-M", passes: 3, detail: "Classic three-pass overwrite." },
  { id: "schneier", name: "Schneier", passes: 7, detail: "Seven-pass pattern." },
  { id: "gutmann", name: "Gutmann", passes: 35, detail: "Thirty-five passes. Slowest." },
] as const;

export type WipeId = (typeof WIPE_METHODS)[number]["id"];
export type VerifyMode = "off" | "sample" | "full";

const LABEL_LIMIT: Record<FsId, number> = {
  FAT16: 11,
  FAT32: 11,
  exFAT: 15,
  NTFS: 32,
  EXT2: 16,
  EXT3: 16,
  EXT4: 16,
};

const RECOVER_RANK: Record<RecoverLevel, number> = { quick: 0, smart: 1, deep: 2, raw: 3 };

export function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}

export function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function formatBytes(n: number): string {
  const sign = n < 0 ? "-" : "";
  let v = Math.abs(n);
  const units = ["B", "KB", "MB", "GB", "TB"];
  let u = 0;
  while (v >= 1000 && u < units.length - 1) {
    v /= 1000;
    u += 1;
  }
  const digits = u === 0 || v >= 100 ? 0 : v >= 10 ? 1 : 2;
  const text = v.toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d)0$/, "$1");
  return `${sign}${text} ${units[u]}`;
}

export function formatCluster(n: number): string {
  if (n % 1024 === 0 && n >= 1024) return `${n / 1024} KB`;
  return `${n} bytes`;
}

export function formatWhen(at: number): string {
  return new Date(at).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

export function tokenWord(n: number): string {
  return `${n} token${n === 1 ? "" : "s"}`;
}

export function labelLimit(fs: FsId): number {
  return LABEL_LIMIT[fs];
}

export function labelIssue(raw: string, fs: FsId): string | null {
  if (!raw) return null;
  if (raw.length > LABEL_LIMIT[fs]) {
    return `${fs} labels stop at ${LABEL_LIMIT[fs]} characters.`;
  }
  if ((fs === "FAT16" || fs === "FAT32") && !/^[A-Za-z0-9 _-]+$/.test(raw)) {
    return "FAT labels can only use letters, numbers, space, _ and -.";
  }
  if (/[\\/:*?"<>|]/.test(raw)) return 'Label cannot include \\ / : * ? " < > |.';
  return null;
}

export function sanitizeLabel(raw: string, fs: FsId): string {
  const trimmed = raw.trim().slice(0, LABEL_LIMIT[fs]);
  if (fs === "FAT16" || fs === "FAT32") return trimmed.toUpperCase();
  return trimmed;
}

export function fsIssue(fs: FsId, bytes: number): string | null {
  if (fs === "FAT16" && bytes > 4_000_000_000) return "FAT16 only supports volumes up to 4 GB.";
  if (fs === "FAT32" && bytes > MBR_LIMIT) return "FAT32 stops at 2 TB here. Use exFAT or NTFS.";
  if (fs === "FAT32" && bytes < 32_000_000) return "FAT32 needs at least 32 MB.";
  return null;
}

export function tableIssue(table: TableKind, bytes: number): string | null {
  if (table === "MBR" && bytes > MBR_LIMIT) return "MBR cannot address more than 2 TB. Choose GPT.";
  return null;
}

export function formatCost(fs: FsId): number {
  return fs === "FAT16" || fs === "FAT32" ? 1 : 2;
}

export function clusterChoices(fs: FsId): ClusterChoice[] {
  if (fs === "EXT2" || fs === "EXT3" || fs === "EXT4") return ["default", "1024", "2048", "4096"];
  if (fs === "exFAT") return ["default", "4096", "8192", "16384", "32768", "65536"];
  return ["default", "512", "1024", "2048", "4096", "8192", "16384", "32768", "65536"];
}

export function clusterLabel(c: ClusterChoice): string {
  if (c === "default") return "Default Value";
  return formatCluster(Number(c));
}

export function resolveCluster(fs: FsId, choice: ClusterChoice, bytes: number): number {
  if (choice !== "default") return Number(choice);
  if (fs === "FAT16") {
    if (bytes > 2_000_000_000) return 65536;
    if (bytes > 1_000_000_000) return 32768;
    return 16384;
  }
  if (fs === "FAT32") {
    if (bytes > 32_000_000_000) return 32768;
    if (bytes > 16_000_000_000) return 16384;
    if (bytes > 8_000_000_000) return 8192;
    return 4096;
  }
  if (fs === "exFAT") return bytes > 32_000_000_000 ? 131072 : 32768;
  if (fs === "EXT2" || fs === "EXT3" || fs === "EXT4") return 4096;
  return 4096;
}

export function alignDown(n: number): number {
  return Math.max(MIB, Math.floor(n / MIB) * MIB);
}

export function usedBytes(p: Partition): number {
  let n = 0;
  for (const file of p.files) if (!file.deleted) n += file.bytes;
  return n;
}

export function allocatedBytes(drive: Drive): number {
  return drive.partitions.reduce((s, p) => s + p.bytes, 0);
}

export function unallocated(drive: Drive): number {
  return Math.max(0, drive.real - allocatedBytes(drive));
}

export function liveFileCount(drive: Drive): number {
  return drive.partitions.reduce((s, p) => s + p.files.filter((f) => !f.deleted).length, 0);
}

export function volumeFree(drive: Drive): number {
  return drive.partitions.reduce((s, p) => s + Math.max(0, p.bytes - usedBytes(p)), 0);
}

export function isCounterfeit(drive: Drive): boolean {
  return drive.advertised > drive.real * 1.15;
}

export function maxPartitions(table: TableKind): number {
  return table === "MBR" ? 4 : 8;
}

export function displayLabel(label: string): string {
  return label.trim() ? label : "NO NAME";
}

export function driveSubtitle(drive: Drive): string {
  if (!drive.table || drive.partitions.length === 0) {
    const base = `${formatBytes(drive.advertised)} · Not formatted`;
    if (drive.verifiedReal && isCounterfeit(drive)) {
      return `${formatBytes(drive.advertised)} advertised · real ${formatBytes(drive.real)} · Not formatted`;
    }
    return base;
  }
  const vol = drive.partitions.reduce((s, p) => s + p.bytes, 0);
  const fs =
    drive.partitions.length === 1 ? drive.partitions[0].fs : `${drive.partitions.length} volumes`;
  return `${formatBytes(vol)} · ${fs} · ${formatBytes(volumeFree(drive))} free`;
}

function file(
  id: string,
  name: string,
  bytes: number,
  kind: FileKind,
  extra: Partial<VFile> = {},
): VFile {
  return {
    id,
    name,
    bytes,
    kind,
    deleted: false,
    recover: "quick",
    fragments: 1,
    preview: "",
    ...extra,
  };
}

function part(
  id: string,
  label: string,
  fs: FsId,
  bytes: number,
  cluster: number,
  files: VFile[],
): Partition {
  return { id, label, fs, bytes: alignDown(bytes), cluster, files };
}

export function seedDrives(): Drive[] {
  return [
    {
      id: "drv-sandisk",
      model: "SanDisk Ultra",
      vendor: "SanDisk",
      product: "Ultra USB 3.0",
      vid: "0781",
      pid: "5581",
      serial: "SD-4C530001",
      advertised: 32_000_000_000,
      real: 32_000_000_000,
      blockSize: 512,
      speed: "USB 3.0",
      kind: "Flash",
      readMBs: 130,
      writeMBs: 42,
      badBlockRatio: 0,
      verifiedReal: false,
      table: "MBR",
      partitions: [
        part("p-sandisk", "SANDISK", "FAT32", 32_000_000_000, 16384, [
          file("f-img-2401", "IMG_2401.jpg", 3_200_000, "image"),
          file("f-img-2402", "IMG_2402.jpg", 2_800_000, "image"),
          file("f-vid-100", "VID_100.mp4", 740_000_000, "video", { fragments: 4 }),
          file("f-resume", "Resume.pdf", 220_000, "doc", {
            preview: "J. Rahman — embedded engineer. Ships, Dhaka. Available from December.",
          }),
          file("f-img-2390", "IMG_2390.jpg", 3_000_000, "image", { deleted: true, recover: "quick" }),
          file("f-notes", "notes.txt", 4_200, "doc", {
            deleted: true,
            recover: "smart",
            preview: "Router: living-room · guest password rotates on Fridays.",
          }),
          file("f-oldzip", "old-trip.zip", 88_000_000, "archive", { deleted: true, recover: "deep" }),
        ]),
      ],
      lost: [],
      scrap: [],
      carved: [],
    },
    {
      id: "drv-kingston",
      model: "Kingston DT",
      vendor: "Kingston",
      product: "DataTraveler",
      vid: "0951",
      pid: "1666",
      serial: "KN-80A2",
      advertised: 64_000_000_000,
      real: 64_000_000_000,
      blockSize: 512,
      speed: "USB 3.2",
      kind: "Flash",
      readMBs: 180,
      writeMBs: 70,
      badBlockRatio: 0.012,
      verifiedReal: false,
      table: "MBR",
      partitions: [
        part("p-king", "KINGSTON", "exFAT", 64_000_000_000, 32768, [
          file("f-movie", "lecture.mkv", 3_400_000_000, "video", { fragments: 28 }),
          file("f-photos", "photos.zip", 800_000_000, "archive", { fragments: 12 }),
          file("f-song", "demo.mp3", 8_000_000, "audio", { fragments: 3 }),
        ]),
      ],
      lost: [],
      scrap: [],
      carved: [],
    },
    {
      id: "drv-fake",
      model: "Generic 128G",
      vendor: "Generic",
      product: "USB DISK",
      vid: "FFFF",
      pid: "0001",
      serial: "FAKE-128-08",
      advertised: 128_000_000_000,
      real: 8_000_000_000,
      blockSize: 512,
      speed: "USB 2.0",
      kind: "Flash",
      readMBs: 18,
      writeMBs: 8,
      badBlockRatio: 0.08,
      verifiedReal: false,
      table: "MBR",
      partitions: [
        part("p-fake", "USB", "FAT32", 8_000_000_000, 4096, [
          file("f-readme", "README.txt", 1_200, "doc", {
            preview: "Thanks for your purchase. Capacity is tested at the factory.",
          }),
        ]),
      ],
      lost: [],
      scrap: [],
      carved: [
        file("f-carve", "DSC_0044.jpg", 2_400_000, "image", { deleted: true, recover: "raw" }),
      ],
    },
    {
      id: "drv-t7",
      model: "Samsung T7",
      vendor: "Samsung",
      product: "PSSD T7",
      vid: "04E8",
      pid: "61F5",
      serial: "T7-S6RX",
      advertised: 1_000_000_000_000,
      real: 1_000_000_000_000,
      blockSize: 4096,
      speed: "USB 3.2",
      kind: "SSD",
      readMBs: 920,
      writeMBs: 860,
      badBlockRatio: 0,
      verifiedReal: false,
      table: "GPT",
      partitions: [
        part("p-t7", "T7", "NTFS", 1_000_000_000_000, 4096, [
          file("f-projects", "Projects.zip", 12_000_000_000, "archive"),
          file("f-iso", "installer.iso", 5_400_000_000, "iso", { fragments: 2 }),
        ]),
      ],
      lost: [],
      scrap: [],
      carved: [],
    },
    {
      id: "drv-seagate",
      model: "Seagate Expansion",
      vendor: "Seagate",
      product: "Expansion HDD",
      vid: "0BC2",
      pid: "231A",
      serial: "SG-NA8B",
      advertised: 4_000_000_000_000,
      real: 4_000_000_000_000,
      blockSize: 4096,
      speed: "USB 3.0",
      kind: "HDD",
      readMBs: 150,
      writeMBs: 140,
      badBlockRatio: 0,
      verifiedReal: false,
      table: "GPT",
      partitions: [
        part("p-sea", "ARCHIVE", "NTFS", 4_000_000_000_000, 4096, [
          file("f-vhdx", "Archive-2024.vhdx", 1_200_000_000_000, "archive", { fragments: 6 }),
          file("f-rawvid", "wedding.mov", 18_000_000_000, "video", { deleted: true, recover: "raw" }),
        ]),
      ],
      lost: [],
      scrap: [],
      carved: [],
    },
    {
      id: "drv-sony",
      model: "Sony MicroVault",
      vendor: "Sony",
      product: "USB FLASH",
      vid: "054C",
      pid: "05BA",
      serial: "SY-MV16",
      advertised: 16_000_000_000,
      real: 16_000_000_000,
      blockSize: 512,
      speed: "USB 2.0",
      kind: "Flash",
      readMBs: 22,
      writeMBs: 9,
      badBlockRatio: 0,
      verifiedReal: false,
      table: null,
      partitions: [],
      lost: [
        part("p-sony-lost", "DCIM", "FAT32", 16_000_000_000, 8192, [
          file("f-sony-1", "DSC_0102.jpg", 4_100_000, "image", { recover: "deep" }),
          file("f-sony-2", "DSC_0103.jpg", 3_800_000, "image", { recover: "deep" }),
          file("f-sony-3", "clip.mp4", 220_000_000, "video", { recover: "deep" }),
        ]),
      ],
      scrap: [],
      carved: [],
    },
    {
      id: "drv-ps2",
      model: "PS2 OPL Stick",
      vendor: "SanDisk",
      product: "Cruzer Blade",
      vid: "0781",
      pid: "5567",
      serial: "PS2-OPL-01",
      advertised: 32_000_000_000,
      real: 32_000_000_000,
      blockSize: 512,
      speed: "USB 2.0",
      kind: "Flash",
      readMBs: 28,
      writeMBs: 10,
      badBlockRatio: 0,
      verifiedReal: false,
      table: "MBR",
      partitions: [
        part("p-ps2", "OPL", "FAT32", 32_000_000_000, 32768, [
          file("f-gow", "God of War.iso", 4_500_000_000, "iso", { fragments: 6 }),
          file("f-ico", "ICO.iso", 1_200_000_000, "iso"),
        ]),
      ],
      lost: [],
      scrap: [],
      carved: [],
    },
  ];
}

export function applyFormat(
  drive: Drive,
  opts: { fs: FsId; cluster: ClusterChoice; table: TableKind; label: string },
): { drive: Drive; summary: string } {
  const bytes = alignDown(drive.real);
  const cluster = resolveCluster(opts.fs, opts.cluster, bytes);
  const label = sanitizeLabel(opts.label, opts.fs);
  const next: Drive = {
    ...drive,
    table: opts.table,
    lost: [],
    scrap: [],
    carved: [],
    partitions: [
      {
        id: uid("part"),
        label,
        fs: opts.fs,
        bytes,
        cluster,
        files: [],
      },
    ],
  };
  const lines = [
    `${drive.model} is now ${opts.fs} · ${opts.table} · ${formatCluster(cluster)} clusters.`,
    `Volume label: ${displayLabel(label)}. Writable size ${formatBytes(bytes)}.`,
  ];
  if (isCounterfeit(drive)) {
    lines.push(
      `The case says ${formatBytes(drive.advertised)}. The writable size is ${formatBytes(drive.real)} — treat it as counterfeit until a bad-block test says otherwise.`,
    );
  }
  if (opts.fs === "FAT16" || opts.fs === "FAT32") {
    lines.push("Files larger than 4 GB will not fit on this file system.");
  }
  return { drive: next, summary: lines.join(" ") };
}

export function badMap(drive: Drive, cells = 64): boolean[] {
  return Array.from({ length: cells }, (_, i) => {
    const h = hash(`${drive.serial}:${i}`) % 10000;
    return h < drive.badBlockRatio * 10000;
  });
}

export function healthChecks(drive: Drive): Check[] {
  const checks: Check[] = [];
  checks.push(
    drive.table
      ? { tone: "ok", label: `${drive.table} partition table is present` }
      : { tone: "bad", label: "No partition table — the stick looks unallocated or corrupt" },
  );
  const sum = allocatedBytes(drive);
  checks.push(
    sum <= drive.real
      ? { tone: "ok", label: "Partitions fit in the writable capacity" }
      : { tone: "bad", label: "Partitions claim more space than the drive can hold" },
  );
  const aligned = drive.partitions.every((p) => p.bytes % MIB === 0);
  checks.push(
    aligned
      ? { tone: "ok", label: "Every partition is 1 MB aligned" }
      : { tone: "warn", label: "A partition is not 1 MB aligned" },
  );
  if (drive.table) {
    const limit = maxPartitions(drive.table);
    checks.push(
      drive.partitions.length <= limit
        ? { tone: "ok", label: `${drive.partitions.length} of ${limit} partition slots used` }
        : { tone: "bad", label: `${drive.table} cannot hold ${drive.partitions.length} partitions` },
    );
  }
  if (drive.table === "MBR") {
    checks.push(
      drive.real > MBR_LIMIT
        ? { tone: "bad", label: "MBR cannot address a disk larger than 2 TB" }
        : { tone: "ok", label: "Disk size is inside the MBR limit" },
    );
  }
  if (!drive.verifiedReal) {
    checks.push({ tone: "warn", label: "Capacity is unverified — run Bad Blocks" });
  } else if (isCounterfeit(drive)) {
    checks.push({
      tone: "bad",
      label: `Counterfeit capacity: label ${formatBytes(drive.advertised)}, real ${formatBytes(drive.real)}`,
    });
  } else {
    checks.push({ tone: "ok", label: "Advertised capacity matches the writable size" });
  }
  const bad = badMap(drive).filter(Boolean).length;
  if (drive.verifiedReal && bad > 0) {
    checks.push({ tone: "warn", label: `${bad} bad blocks in the last surface sample` });
  }
  return checks;
}

export function fragStats(drive: Drive): { supported: boolean; files: number; extra: number } {
  let supported = false;
  let files = 0;
  let extra = 0;
  for (const p of drive.partitions) {
    if (p.fs !== "FAT32" && p.fs !== "exFAT") continue;
    supported = true;
    for (const f of p.files) {
      if (f.deleted) continue;
      files += 1;
      extra += Math.max(0, f.fragments - 1);
    }
  }
  return { supported, files, extra };
}

export function applyDefrag(drive: Drive): { drive: Drive; fixed: number } {
  let fixed = 0;
  const partitions = drive.partitions.map((p) => {
    if (p.fs !== "FAT32" && p.fs !== "exFAT") return p;
    return {
      ...p,
      files: p.files.map((f) => {
        if (!f.deleted && f.fragments > 1) {
          fixed += 1;
          return { ...f, fragments: 1 };
        }
        return f;
      }),
    };
  });
  return { drive: { ...drive, partitions }, fixed };
}

export function wipeFails(drive: Drive, verify: VerifyMode): boolean {
  if (verify === "off") return false;
  if (verify === "sample") return drive.badBlockRatio >= 0.05;
  return drive.badBlockRatio > 0;
}

export function applyWipe(
  drive: Drive,
  opts: { method: string; passes: number; verify: VerifyMode },
): { drive: Drive; cert: Omit<WipeCert, "id" | "at"> } {
  const verified = !wipeFails(drive, opts.verify);
  const cert = {
    model: drive.model,
    serial: drive.serial,
    method: opts.method,
    passes: opts.passes,
    verify: opts.verify,
    verified,
    bytes: drive.real,
  };
  return {
    drive: {
      ...drive,
      table: null,
      partitions: [],
      lost: [],
      scrap: [],
      carved: [],
    },
    cert,
  };
}

export function jitter(serial: string, salt: string, base: number): number {
  const h = hash(`${serial}:${salt}`) % 1000;
  const factor = 0.92 + (h / 1000) * 0.16;
  return Math.round(base * factor * 10) / 10;
}

export function planBench(drive: Drive, write: boolean) {
  return {
    model: drive.model,
    serial: drive.serial,
    seqRead: jitter(drive.serial, "sr", drive.readMBs),
    seqWrite: write ? jitter(drive.serial, "sw", drive.writeMBs) : null,
    randRead: Math.round(jitter(drive.serial, "rr", drive.readMBs * 28)),
    randWrite: write ? Math.round(jitter(drive.serial, "rw", drive.writeMBs * 22)) : null,
  };
}

export function collectRecoverable(drive: Drive, mode: ScanMode): VFile[] {
  const max = RECOVER_RANK[mode];
  const allow = (level: RecoverLevel) => RECOVER_RANK[level] <= max;
  const out: VFile[] = [];
  const seen = new Set<string>();
  const add = (f: VFile) => {
    if (seen.has(f.id)) return;
    seen.add(f.id);
    out.push(f);
  };
  for (const p of drive.partitions) {
    for (const f of p.files) if (f.deleted && allow(f.recover)) add(f);
  }
  if (mode === "deep" || mode === "raw") {
    for (const p of drive.lost) {
      for (const f of p.files) if (allow(f.recover === "raw" ? "raw" : "deep")) add(f);
    }
    for (const f of drive.scrap) if (allow(f.recover)) add(f);
  }
  if (mode === "raw") {
    for (const p of drive.lost) for (const f of p.files) add(f);
    for (const f of drive.scrap) add(f);
    for (const f of drive.carved) add(f);
  }
  return out;
}

function stripFile(drive: Drive, fileId: string): { drive: Drive; file: VFile | null } {
  let found: VFile | null = null;
  const pull = (files: VFile[]) => {
    const next: VFile[] = [];
    for (const f of files) {
      if (f.id === fileId && !found) found = f;
      else next.push(f);
    }
    return next;
  };
  const partitions = drive.partitions.map((p) => ({ ...p, files: pull(p.files) }));
  const lost = drive.lost.map((p) => ({ ...p, files: pull(p.files) }));
  const scrap = pull(drive.scrap);
  const carved = pull(drive.carved);
  return { drive: { ...drive, partitions, lost, scrap, carved }, file: found };
}

function uniqueName(part: Partition, name: string): string {
  const names = new Set(part.files.filter((f) => !f.deleted).map((f) => f.name.toLowerCase()));
  if (!names.has(name.toLowerCase())) return name;
  const dot = name.lastIndexOf(".");
  const stem = dot > 0 ? name.slice(0, dot) : name;
  const ext = dot > 0 ? name.slice(dot) : "";
  let i = 2;
  let candidate = `${stem} (${i})${ext}`;
  while (names.has(candidate.toLowerCase())) {
    i += 1;
    candidate = `${stem} (${i})${ext}`;
  }
  return candidate;
}

export function restoreFile(drive: Drive, fileId: string): { drive: Drive; ok: boolean; message: string } {
  const taken = stripFile(drive, fileId);
  if (!taken.file) return { drive, ok: false, message: "That file is no longer recoverable." };
  const file: VFile = { ...taken.file, deleted: false };
  const part = taken.drive.partitions.find((p) => p.bytes - usedBytes(p) >= file.bytes);
  if (!part) {
    return {
      drive: { ...taken.drive, scrap: [...taken.drive.scrap, { ...taken.file, deleted: true }] },
      ok: false,
      message: `${file.name} needs ${formatBytes(file.bytes)} free on one volume.`,
    };
  }
  const named = { ...file, name: uniqueName(part, file.name) };
  const partitions = taken.drive.partitions.map((p) =>
    p.id === part.id ? { ...p, files: [...p.files, named] } : p,
  );
  return {
    drive: { ...taken.drive, partitions },
    ok: true,
    message: `Restored ${named.name} to ${displayLabel(part.label)}.`,
  };
}

export function deleteFile(drive: Drive, fileId: string): Drive {
  const mark = (files: VFile[]) =>
    files.map((f) => (f.id === fileId ? { ...f, deleted: true, recover: "quick" as const } : f));
  return {
    ...drive,
    partitions: drive.partitions.map((p) => ({ ...p, files: mark(p.files) })),
  };
}

export function renameFile(
  drive: Drive,
  fileId: string,
  rawName: string,
): { drive: Drive; ok: boolean; message: string } {
  const name = rawName.trim();
  if (!name || /[\\/]/.test(name)) {
    return { drive, ok: false, message: "Use a file name without slashes." };
  }
  let clash = false;
  const partitions = drive.partitions.map((p) => {
    if (!p.files.some((f) => f.id === fileId)) return p;
    const taken = p.files.some((f) => f.id !== fileId && !f.deleted && f.name.toLowerCase() === name.toLowerCase());
    if (taken) {
      clash = true;
      return p;
    }
    return { ...p, files: p.files.map((f) => (f.id === fileId ? { ...f, name } : f)) };
  });
  if (clash) return { drive, ok: false, message: "Another file already uses that name." };
  return { drive: { ...drive, partitions }, ok: true, message: `Renamed to ${name}.` };
}

export function restorePartition(
  drive: Drive,
  partId: string,
): { drive: Drive; ok: boolean; message: string } {
  const part = drive.lost.find((p) => p.id === partId);
  if (!part) return { drive, ok: false, message: "That partition is no longer in the lost list." };
  const table = drive.table ?? "MBR";
  if (drive.partitions.length >= maxPartitions(table)) {
    return { drive, ok: false, message: `${table} is already full. Delete or convert the table first.` };
  }
  if (part.bytes > unallocated(drive)) {
    return { drive, ok: false, message: "Not enough unallocated space to put this partition back." };
  }
  return {
    drive: {
      ...drive,
      table,
      partitions: [...drive.partitions, structuredClone(part)],
      lost: drive.lost.filter((p) => p.id !== partId),
    },
    ok: true,
    message: `Restored ${displayLabel(part.label)} (${part.fs}, ${formatBytes(part.bytes)}).`,
  };
}

export interface WizardDraft {
  table: TableKind;
  parts: Partition[];
  lost: Partition[];
  scrap: VFile[];
}

export function wizardIssue(drive: Drive, draft: WizardDraft): string | null {
  if (draft.table === "MBR" && drive.real > MBR_LIMIT) return tableIssue("MBR", drive.real);
  if (draft.parts.length > maxPartitions(draft.table)) {
    return `${draft.table} allows ${maxPartitions(draft.table)} partitions.`;
  }
  const sum = draft.parts.reduce((s, p) => s + p.bytes, 0);
  if (sum > drive.real) return "The layout is larger than the writable capacity.";
  for (const p of draft.parts) {
    const label = labelIssue(p.label, p.fs);
    if (label) return label;
    const fs = fsIssue(p.fs, p.bytes);
    if (fs) return fs;
    if (p.bytes < MIB) return "Each partition needs at least 1 MB.";
  }
  return null;
}

export function applyWizard(drive: Drive, draft: WizardDraft): { drive: Drive; ok: boolean; message: string } {
  const issue = wizardIssue(drive, draft);
  if (issue) return { drive, ok: false, message: issue };
  return {
    drive: {
      ...drive,
      table: draft.table,
      partitions: structuredClone(draft.parts),
      lost: structuredClone(draft.lost),
      scrap: structuredClone(draft.scrap),
    },
    ok: true,
    message: `Wrote a ${draft.table} table with ${draft.parts.length} partition${draft.parts.length === 1 ? "" : "s"}.`,
  };
}

export function makeBackup(drive: Drive): Backup {
  return {
    id: uid("bak"),
    at: Date.now(),
    serial: drive.serial,
    model: drive.model,
    real: drive.real,
    table: drive.table,
    partitions: structuredClone(drive.partitions),
    lost: structuredClone(drive.lost),
  };
}

export function restoreBackup(
  drive: Drive,
  bak: Backup,
): { drive: Drive; ok: boolean; message: string } {
  const sum = bak.partitions.reduce((s, p) => s + p.bytes, 0);
  if (sum > drive.real) {
    return { drive, ok: false, message: "This image does not fit on the connected drive." };
  }
  return {
    drive: {
      ...drive,
      table: bak.table,
      partitions: structuredClone(bak.partitions),
      lost: structuredClone(bak.lost),
      scrap: [],
      carved: [],
    },
    ok: true,
    message: `Restored the image of ${bak.model} from ${formatWhen(bak.at)}.`,
  };
}

export function gameFiles(drive: Drive): { part: Partition; file: VFile }[] {
  const out: { part: Partition; file: VFile }[] = [];
  for (const p of drive.partitions) {
    for (const f of p.files) {
      if (f.deleted) continue;
      if (f.kind === "iso" || /\.(iso|bin|vcd|zso|cso|chd)$/i.test(f.name) || f.name.toLowerCase().startsWith("ul.")) {
        out.push({ part: p, file: f });
      }
    }
  }
  return out;
}

export function splitForOpl(drive: Drive, fileId: string): { drive: Drive; ok: boolean; message: string } {
  let source: { partId: string; file: VFile } | null = null;
  for (const p of drive.partitions) {
    const f = p.files.find((file) => file.id === fileId && !file.deleted);
    if (f) source = { partId: p.id, file: f };
  }
  if (!source) return { drive, ok: false, message: "Game image was not found." };
  if (source.file.bytes <= FAT_FILE_LIMIT) {
    return { drive, ok: false, message: "This image is already under the 4 GB FAT32 limit." };
  }
  const slug = (source.file.name.replace(/\.[^.]+$/, "").replace(/[^A-Za-z0-9]/g, "").slice(0, 8) || "GAME").toUpperCase();
  const chunk = 1_073_741_824;
  const parts: VFile[] = [];
  let left = source.file.bytes;
  let index = 0;
  while (left > 0) {
    const bytes = Math.min(chunk, left);
    const suffix = index.toString().padStart(2, "0");
    parts.push(
      file(uid("ul"), `ul.${slug}.${suffix}`, bytes, "iso", {
        fragments: 1,
        preview: `USBExtreme slice ${suffix} of ${source.file.name}.`,
      }),
    );
    left -= bytes;
    index += 1;
  }
  const cfgName = "ul.cfg";
  const cfgBody = parts
    .map((p, i) => `${p.name}|${source?.file.name}|${p.bytes}|part ${i + 1}`)
    .join("\n");
  const cfg = file(uid("cfg"), cfgName, cfgBody.length, "doc", { preview: cfgBody });
  const partitions = drive.partitions.map((p) => {
    if (p.id !== source?.partId) return p;
    const without = p.files.filter((f) => f.id !== fileId && f.name.toLowerCase() !== "ul.cfg");
    return { ...p, files: [...without, ...parts, cfg] };
  });
  return {
    drive: { ...drive, partitions },
    ok: true,
    message: `Split into ${parts.length} USBExtreme parts and wrote ul.cfg.`,
  };
}

const CONVERT_EXT = ["iso", "bin", "vcd", "zso", "cso", "chd"] as const;
export type ConvertExt = (typeof CONVERT_EXT)[number];
export const CONVERT_TARGETS: ConvertExt[] = [...CONVERT_EXT];

export function convertFile(
  drive: Drive,
  fileId: string,
  target: ConvertExt,
): { drive: Drive; ok: boolean; message: string } {
  let changed = false;
  let message = "File was not found.";
  const partitions = drive.partitions.map((p) => ({
    ...p,
    files: p.files.map((f) => {
      if (f.id !== fileId || f.deleted) return f;
      const dot = f.name.lastIndexOf(".");
      const stem = dot > 0 ? f.name.slice(0, dot) : f.name;
      const nextName = `${stem}.${target}`;
      if (f.name.toLowerCase() === nextName.toLowerCase()) {
        message = `${f.name} is already that format.`;
        return f;
      }
      changed = true;
      message = `Converted ${f.name} to ${nextName}.`;
      return { ...f, name: nextName, kind: "iso" as const, fragments: 1 };
    }),
  }));
  return { drive: changed ? { ...drive, partitions } : drive, ok: changed, message };
}

export function findFile(drive: Drive, fileId: string): VFile | null {
  for (const p of [...drive.partitions, ...drive.lost]) {
    const f = p.files.find((file) => file.id === fileId);
    if (f) return f;
  }
  return drive.scrap.find((f) => f.id === fileId) ?? drive.carved.find((f) => f.id === fileId) ?? null;
}

export function wipeStages(passes: number, verify: VerifyMode): { until: number; label: string }[] {
  const verifyShare = verify === "off" ? 0 : 0.18;
  const span = 1 - verifyShare;
  const stages = Array.from({ length: passes }, (_, i) => ({
    until: (span * (i + 1)) / passes,
    label: `Pass ${i + 1} of ${passes}`,
  }));
  if (verify !== "off") {
    stages.push({
      until: 1,
      label: verify === "full" ? "Verifying every block" : "Verifying a sample",
    });
  }
  return stages;
}

export function scanDuration(mode: ScanMode): number {
  if (mode === "quick") return 1400;
  if (mode === "smart") return 2200;
  if (mode === "deep") return 3800;
  return 5200;
}
