import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  applyDefrag,
  applyFormat,
  applyWipe,
  applyWizard,
  badMap,
  clusterChoices,
  collectRecoverable,
  convertFile,
  deleteFile,
  formatBytes,
  makeBackup,
  planBench,
  renameFile,
  restoreBackup,
  restoreFile,
  restorePartition,
  seedDrives,
  splitForOpl,
  uid,
  type Backup,
  type BenchResult,
  type ClusterChoice,
  type ConvertExt,
  type Drive,
  type FsId,
  type LogLine,
  type ScanMode,
  type TableKind,
  type VerifyMode,
  type WipeCert,
  type WizardDraft,
} from "@/lib/usb/engine";

export type JobStage = { until: number; label: string };

export type Job = {
  id: string;
  title: string;
  stage: string;
  progress: number;
  duration: number;
  cancellable: boolean;
  settled: boolean;
  stages: JobStage[];
};

export type Notice = { title: string; body: string; browse?: boolean };

export type Payload =
  | { kind: "format"; driveId: string; fs: FsId; cluster: ClusterChoice; table: TableKind; label: string; cost: number }
  | { kind: "wipe"; driveId: string; method: string; passes: number; verify: VerifyMode }
  | { kind: "defrag"; driveId: string }
  | { kind: "badblocks"; driveId: string }
  | {
      kind: "bench";
      driveId: string;
      planned: Omit<BenchResult, "id" | "at">;
    }
  | { kind: "scan"; driveId: string; mode: ScanMode }
  | { kind: "restore-files"; driveId: string; ids: string[] }
  | { kind: "restore-part"; driveId: string; partId: string }
  | { kind: "wizard"; driveId: string; draft: WizardDraft; cost: number }
  | { kind: "backup"; driveId: string }
  | { kind: "restore-backup"; driveId: string; backupId: string }
  | { kind: "split"; driveId: string; fileId: string }
  | { kind: "convert"; driveId: string; fileId: string; target: ConvertExt };

export interface LastScan {
  driveId: string;
  mode: ScanMode;
  ids: string[];
}

type Persisted = {
  drives: Drive[];
  connectedId: string | null;
  tokens: number;
  pro: boolean;
  pinned: string[];
  fs: FsId;
  cluster: ClusterChoice;
  table: TableKind;
  label: string;
  backups: Backup[];
  benches: BenchResult[];
  certs: WipeCert[];
  logs: LogLine[];
  lastScan: LastScan | null;
};

type UsbState = Persisted & {
  job: Job | null;
  payload: Payload | null;
  notice: Notice | null;
  toast: string | null;
  setFs: (fs: FsId) => void;
  setCluster: (cluster: ClusterChoice) => void;
  setTable: (table: TableKind) => void;
  setLabel: (label: string) => void;
  connect: (id: string) => void;
  eject: () => void;
  togglePin: (id: string) => void;
  addTokens: (n: number) => void;
  unlockPro: () => void;
  dismissNotice: () => void;
  clearToast: () => void;
  deleteBackup: (id: string) => void;
  removeFile: (driveId: string, fileId: string) => void;
  renameLiveFile: (driveId: string, fileId: string, name: string) => string | null;
  resetBench: () => void;
  startJob: (job: Omit<Job, "id" | "progress" | "settled" | "stage"> & { payload: Payload }) => boolean;
  setProgress: (progress: number) => void;
  cancelJob: () => void;
  finishJob: () => void;
};

function logLine(text: string): LogLine {
  return { id: uid("log"), at: Date.now(), text };
}

function withDrive(drives: Drive[], id: string, fn: (d: Drive) => Drive): Drive[] | null {
  if (!drives.some((d) => d.id === id)) return null;
  return drives.map((d) => (d.id === id ? fn(d) : d));
}

const initial: Persisted = {
  drives: seedDrives(),
  connectedId: null,
  tokens: 0,
  pro: false,
  pinned: [],
  fs: "FAT32",
  cluster: "default",
  table: "MBR",
  label: "",
  backups: [],
  benches: [],
  certs: [],
  logs: [],
  lastScan: null,
};

export const useUsb = create<UsbState>()(
  persist(
    (set, get) => ({
      ...initial,
      job: null,
      payload: null,
      notice: null,
      toast: null,
      setFs: (fs) =>
        set((s) => ({
          fs,
          cluster: clusterChoices(fs).includes(s.cluster) ? s.cluster : "default",
        })),
      setCluster: (cluster) => set({ cluster }),
      setTable: (table) => set({ table }),
      setLabel: (label) => set({ label }),
      connect: (id) => {
        if (get().job) return;
        set({ connectedId: id, lastScan: null });
      },
      eject: () => {
        if (get().job) return;
        set({ connectedId: null });
      },
      togglePin: (id) =>
        set((s) => {
          const has = s.pinned.includes(id);
          return {
            pinned: has ? s.pinned.filter((p) => p !== id) : [...s.pinned, id],
            toast: has ? "Removed from favorites" : "Pinned to the top of tools",
          };
        }),
      addTokens: (n) =>
        set((s) => ({
          tokens: s.tokens + n,
          toast: `Added ${n} token${n === 1 ? "" : "s"}`,
          logs: [logLine(`Token balance increased by ${n}.`), ...s.logs].slice(0, 40),
        })),
      unlockPro: () =>
        set((s) => ({
          pro: true,
          toast: "Pro unlocked on this bench",
          logs: [logLine("Pro enabled. Format and partition actions no longer spend tokens."), ...s.logs].slice(0, 40),
        })),
      dismissNotice: () => set({ notice: null }),
      clearToast: () => set({ toast: null }),
      deleteBackup: (id) => set((s) => ({ backups: s.backups.filter((b) => b.id !== id) })),
      removeFile: (driveId, fileId) =>
        set((s) => {
          const drives = withDrive(s.drives, driveId, (d) => deleteFile(d, fileId));
          if (!drives) return {};
          return {
            drives,
            logs: [logLine("Moved a file to the deleted list."), ...s.logs].slice(0, 40),
            toast: "File deleted. Recover can bring it back.",
          };
        }),
      renameLiveFile: (driveId, fileId, name) => {
        const drive = get().drives.find((d) => d.id === driveId);
        if (!drive) return "Drive missing.";
        const result = renameFile(drive, fileId, name);
        if (!result.ok) return result.message;
        set((s) => ({
          drives: s.drives.map((d) => (d.id === driveId ? result.drive : d)),
          toast: result.message,
        }));
        return null;
      },
      resetBench: () =>
        set((s) => ({
          drives: seedDrives(),
          connectedId: null,
          backups: [],
          benches: [],
          certs: [],
          logs: [logLine("Bench drives reset."), ...s.logs].slice(0, 40),
          lastScan: null,
          toast: "Bench drives restored",
          fs: s.fs,
        })),
      startJob: (spec) => {
        if (get().job) return false;
        set({
          notice: null,
          payload: spec.payload,
          job: {
            id: uid("job"),
            title: spec.title,
            stage: spec.stages[0]?.label ?? "Working",
            progress: 0,
            duration: spec.duration,
            cancellable: spec.cancellable,
            settled: false,
            stages: spec.stages,
          },
        });
        return true;
      },
      setProgress: (progress) =>
        set((s) => {
          if (!s.job || s.job.settled) return {};
          const stage = s.job.stages.find((item) => progress <= item.until)?.label ?? s.job.stage;
          return { job: { ...s.job, progress, stage } };
        }),
      cancelJob: () => {
        const { job } = get();
        if (!job?.cancellable || job.settled) return;
        set({
          job: null,
          payload: null,
          notice: { title: "Stopped", body: "Nothing was written." },
        });
      },
      finishJob: () => {
        const snap = get();
        if (!snap.job || snap.job.settled || !snap.payload) return;
        const payload = snap.payload;
        let tokens = snap.tokens;
        let drives = snap.drives;
        let backups = snap.backups;
        let benches = snap.benches;
        let certs = snap.certs;
        let logs = snap.logs;
        let lastScan = snap.lastScan;
        let notice: Notice = { title: "Done", body: "" };

        const spend = (cost: number) => {
          if (snap.pro || cost <= 0) return true;
          if (tokens < cost) return false;
          tokens -= cost;
          return true;
        };
        const note = (text: string) => {
          logs = [logLine(text), ...logs].slice(0, 40);
        };
        const update = (id: string, fn: (d: Drive) => Drive) => {
          const next = withDrive(drives, id, fn);
          if (!next) return false;
          drives = next;
          return true;
        };

        switch (payload.kind) {
          case "format": {
            const drive = drives.find((d) => d.id === payload.driveId);
            if (!drive) {
              notice = { title: "Drive missing", body: "The drive left the bench before the write finished." };
              break;
            }
            if (!spend(payload.cost)) {
              notice = {
                title: "Not enough tokens",
                body: "Earn a token, then format again. The drive was not changed.",
              };
              break;
            }
            const applied = applyFormat(drive, payload);
            drives = drives.map((d) => (d.id === drive.id ? applied.drive : d));
            notice = { title: "Format complete", body: applied.summary, browse: true };
            note(`Formatted ${drive.model} as ${payload.fs}.`);
            lastScan = null;
            break;
          }
          case "wipe": {
            let certBody = "";
            const ok = update(payload.driveId, (d) => {
              const applied = applyWipe(d, payload);
              const cert: WipeCert = { ...applied.cert, id: uid("cert"), at: Date.now() };
              certs = [cert, ...certs].slice(0, 12);
              certBody = applied.cert.verified
                ? "Verification passed. The stick is unallocated and must be formatted before use."
                : "Wipe finished, but verification found blocks that did not read back. The stick is still erased.";
              note(`Wiped ${d.model} with ${payload.method}.`);
              return applied.drive;
            });
            notice = ok
              ? { title: "Wipe finished", body: certBody }
              : { title: "Drive missing", body: "Nothing to wipe." };
            lastScan = null;
            break;
          }
          case "defrag": {
            const ok = update(payload.driveId, (d) => {
              const applied = applyDefrag(d);
              notice = {
                title: applied.fixed ? "Defrag complete" : "Already contiguous",
                body: applied.fixed
                  ? `Rewrote ${applied.fixed} fragmented file${applied.fixed === 1 ? "" : "s"} into single extents.`
                  : "No fragmented FAT32 or exFAT files were on the drive.",
              };
              note(notice.body);
              return applied.drive;
            });
            if (!ok) notice = { title: "Drive missing", body: "Defrag did not run." };
            break;
          }
          case "badblocks": {
            const ok = update(payload.driveId, (d) => {
              const bad = badMap(d).filter(Boolean).length;
              const fake = d.advertised > d.real * 1.15;
              notice = {
                title: fake ? "Counterfeit capacity" : bad ? "Bad blocks found" : "Surface looks clean",
                body: fake
                  ? `Label says ${formatBytes(d.advertised)}. The test could only hold ${formatBytes(d.real)}. ${bad} bad cells in the sample. Format uses the real size.`
                  : bad
                    ? `${bad} cells failed the write/read sample. A full wipe verification will fail until the stick is replaced.`
                    : "The sample passed and the label matches the writable size.",
              };
              note(`Bad-block test on ${d.model}: ${notice.title}.`);
              return { ...d, verifiedReal: true };
            });
            if (!ok) notice = { title: "Drive missing", body: "Test did not finish." };
            break;
          }
          case "bench": {
            const row: BenchResult = { ...payload.planned, id: uid("bench"), at: Date.now() };
            benches = [row, ...benches].slice(0, 12);
            notice = {
              title: "Benchmark saved",
              body: `${row.model}: ${row.seqRead} MB/s read${row.seqWrite != null ? `, ${row.seqWrite} MB/s write` : ""}.`,
            };
            note(notice.body);
            break;
          }
          case "scan": {
            const drive = drives.find((d) => d.id === payload.driveId);
            const ids = drive ? collectRecoverable(drive, payload.mode).map((f) => f.id) : [];
            lastScan = { driveId: payload.driveId, mode: payload.mode, ids };
            notice = {
              title: "Scan finished",
              body: ids.length
                ? `Found ${ids.length} recoverable file${ids.length === 1 ? "" : "s"} with a ${payload.mode} scan.`
                : `No files turned up in a ${payload.mode} scan.`,
            };
            note(notice.body);
            break;
          }
          case "restore-files": {
            const messages: string[] = [];
            let restored = 0;
            update(payload.driveId, (d) => {
              let cursor = d;
              for (const id of payload.ids) {
                const applied = restoreFile(cursor, id);
                cursor = applied.drive;
                if (applied.ok) restored += 1;
                else messages.push(applied.message);
              }
              return cursor;
            });
            notice = {
              title: restored ? "Files restored" : "Nothing restored",
              body: restored
                ? `Put ${restored} file${restored === 1 ? "" : "s"} back on the volume.${messages[0] ? ` ${messages[0]}` : ""}`
                : messages[0] ?? "Those files are gone.",
              browse: restored > 0,
            };
            note(notice.body);
            break;
          }
          case "restore-part": {
            const ok = update(payload.driveId, (d) => {
              const applied = restorePartition(d, payload.partId);
              notice = { title: applied.ok ? "Partition restored" : "Could not restore", body: applied.message };
              return applied.drive;
            });
            if (!ok) notice = { title: "Drive missing", body: "Partition was not restored." };
            else note(notice.body);
            break;
          }
          case "wizard": {
            const drive = drives.find((d) => d.id === payload.driveId);
            if (!drive) {
              notice = { title: "Drive missing", body: "Nothing was written." };
              break;
            }
            if (!spend(payload.cost)) {
              notice = { title: "Not enough tokens", body: "Partition changes were not written." };
              break;
            }
            const applied = applyWizard(drive, payload.draft);
            if (!applied.ok) {
              if (!snap.pro) tokens += payload.cost;
              notice = { title: "Layout rejected", body: applied.message };
              break;
            }
            drives = drives.map((d) => (d.id === drive.id ? applied.drive : d));
            notice = { title: "Partitions updated", body: applied.message };
            note(applied.message);
            break;
          }
          case "backup": {
            const drive = drives.find((d) => d.id === payload.driveId);
            if (!drive) {
              notice = { title: "Drive missing", body: "Nothing to image." };
              break;
            }
            const bak = makeBackup(drive);
            backups = [bak, ...backups].slice(0, 8);
            notice = {
              title: "Image saved",
              body: `Stored ${drive.model} on this device. It stays in the browser, not on a second stick.`,
            };
            note(`Backed up ${drive.model}.`);
            break;
          }
          case "restore-backup": {
            const bak = backups.find((b) => b.id === payload.backupId);
            if (!bak) {
              notice = { title: "Image missing", body: "That backup is no longer on this device." };
              break;
            }
            const ok = update(payload.driveId, (d) => {
              const applied = restoreBackup(d, bak);
              notice = { title: applied.ok ? "Restore complete" : "Restore blocked", body: applied.message };
              return applied.ok ? applied.drive : d;
            });
            if (!ok) notice = { title: "Drive missing", body: "Restore did not run." };
            else note(notice.body);
            lastScan = null;
            break;
          }
          case "split": {
            const ok = update(payload.driveId, (d) => {
              const applied = splitForOpl(d, payload.fileId);
              notice = { title: applied.ok ? "Split for OPL" : "Not split", body: applied.message };
              return applied.ok ? applied.drive : d;
            });
            if (!ok) notice = { title: "Drive missing", body: "Split did not run." };
            else note(notice.body);
            break;
          }
          case "convert": {
            const ok = update(payload.driveId, (d) => {
              const applied = convertFile(d, payload.fileId, payload.target);
              notice = { title: applied.ok ? "Converted" : "Not converted", body: applied.message };
              return applied.ok ? applied.drive : d;
            });
            if (!ok) notice = { title: "Drive missing", body: "Convert did not run." };
            else note(notice.body);
            break;
          }
          default:
            break;
        }

        set({
          job: null,
          payload: null,
          tokens,
          drives,
          backups,
          benches,
          certs,
          logs,
          lastScan,
          notice,
        });
      },
    }),
    {
      name: "usb-tools-bench-v1",
      skipHydration: true,
      version: 1,
      partialize: (s) => ({
        drives: s.drives,
        connectedId: s.connectedId,
        tokens: s.tokens,
        pro: s.pro,
        pinned: s.pinned,
        fs: s.fs,
        cluster: s.cluster,
        table: s.table,
        label: s.label,
        backups: s.backups,
        benches: s.benches,
        certs: s.certs,
        logs: s.logs,
        lastScan: s.lastScan,
      }),
    },
  ),
);

export function useConnected(): Drive | null {
  return useUsb((s) => s.drives.find((d) => d.id === s.connectedId) ?? null);
}
