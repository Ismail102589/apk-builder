export type ToolId =
  | "format"
  | "partition"
  | "defrag"
  | "wipe"
  | "backup"
  | "recover"
  | "lost"
  | "badblocks"
  | "bench"
  | "info"
  | "ps2"
  | "convert";

export const TOOLS: {
  id: ToolId;
  name: string;
  group: "Disk" | "Recovery" | "Diagnostics" | "Games";
  blurb: string;
  cost: string;
}[] = [
  { id: "format", name: "Format", group: "Disk", blurb: "File system, cluster size, label", cost: "1–2 tokens" },
  { id: "partition", name: "Partition Wizard", group: "Disk", blurb: "Create, delete, rename, queue, undo", cost: "Up to 3 tokens" },
  { id: "defrag", name: "Defragmenter", group: "Disk", blurb: "FAT32 and exFAT extents", cost: "Free" },
  { id: "wipe", name: "Wipe", group: "Disk", blurb: "NIST, DoD, Schneier, Gutmann", cost: "Free" },
  { id: "backup", name: "Backup & Restore", group: "Disk", blurb: "Image the bench drive", cost: "Free" },
  { id: "recover", name: "Recover Files", group: "Recovery", blurb: "Quick, smart, deep, and raw", cost: "Free" },
  { id: "lost", name: "Lost Partitions", group: "Recovery", blurb: "Put a dropped volume back", cost: "Free" },
  { id: "badblocks", name: "Bad Blocks", group: "Diagnostics", blurb: "Surface test and fake capacity", cost: "Free" },
  { id: "bench", name: "Benchmark", group: "Diagnostics", blurb: "Sequential and random speed", cost: "Free" },
  { id: "info", name: "Device Info", group: "Diagnostics", blurb: "IDs, table, and health", cost: "Free" },
  { id: "ps2", name: "PS2 USB Utils", group: "Games", blurb: "OPL split, rename, PS2 format", cost: "Format is 1 token" },
  { id: "convert", name: "Game Converter", group: "Games", blurb: "ISO, BIN, VCD, ZSO, CSO, CHD", cost: "Free" },
];

export const TOOL_GROUPS = ["Disk", "Recovery", "Diagnostics", "Games"] as const;
