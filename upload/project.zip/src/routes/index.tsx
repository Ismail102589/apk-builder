import { createFileRoute } from "@tanstack/react-router";
import { UsbToolsApp } from "@/components/usb/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <UsbToolsApp />;
}
