import { useEffect, useMemo, useState } from "react";
import {
  Archive,
  ChevronLeft,
  Columns2,
  Eraser,
  FileSearch,
  Gamepad2,
  Gauge,
  Grid3x3,
  HardDrive,
  Info,
  Layers,
  Repeat,
  RotateCcw,
  Search,
  Star,
} from "lucide-react";
import {
  CONVERT_TARGETS,
  FAT_FILE_LIMIT,
  FILESYSTEMS,
  MIB,
  WIPE_METHODS,
  alignDown,
  badMap,
  displayLabel,
  findFile,
  formatBytes,
  formatCluster,
  formatWhen,
  fragStats,
  fsIssue,
  gameFiles,
  healthChecks,
  labelIssue,
  liveFileCount,
  maxPartitions,
  planBench,
  resolveCluster,
  sanitizeLabel,
  scanDuration,
  tokenWord,
  unallocated,
  usedBytes,
  volumeFree,
  wipeStages,
  type ConvertExt,
  type FsId,
  type Partition,
  type ScanMode,
  type TableKind,
  type VerifyMode,
  type WizardDraft,
  type WipeId,
} from "@/lib/usb/engine";
import { useConnected, useUsb } from "@/lib/usb/store";
import { TOOLS, TOOL_GROUPS, type ToolId } from "@/lib/usb/tools";
import { useUi } from "@/components/usb/ui-context";
import { Card, PrimaryButton, QuietButton, cx } from "@/components/usb/widgets";

const ICONS: Record<ToolId, typeof HardDrive> = {
  format: HardDrive,
  partition: Columns2,
  defrag: Layers,
  wipe: Eraser,
  backup: Archive,
  recover: FileSearch,
  lost: RotateCcw,
  badblocks: Grid3x3,
  bench: Gauge,
  info: Info,
  ps2: Gamepad2,
  convert: Repeat,
};

export function ToolsMenu() {
  const ui = useUi();
  const pinned = useUsb((s) => s.pinned);
  const togglePin = useUsb((s) => s.togglePin);
  const [query, setQuery] = useState("");
  const needle = query.trim().toLowerCase();
  const items = TOOLS.filter((tool) => {
    if (!needle) return true;
    return `${tool.name} ${tool.blurb} ${tool.group}`.toLowerCase().includes(needle);
  }).sort((a, b) => Number(pinned.includes(b.id)) - Number(pinned.includes(a.id)));

  return (
    <div>
      <h2 className="text-2xl font-medium">Tools</h2>
      <label className="mt-4 flex items-center gap-2 rounded-2xl bg-surface px-4">
        <Search className="size-4 text-muted" aria-hidden="true" />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search tools"
          aria-label="Search tools"
          className="h-12 w-full bg-transparent text-base outline-none placeholder:text-muted"
        />
      </label>
      {items.length === 0 ? <p className="mt-6 text-sm text-muted">No tool matches that search.</p> : null}
      {TOOL_GROUPS.map((group) => {
        const groupItems = items.filter((tool) => tool.group === group);
        if (!groupItems.length) return null;
        return (
          <section key={group} className="mt-6">
            <h3 className="text-xs tracking-widest text-muted uppercase">{group}</h3>
            <ul className="mt-2 overflow-hidden rounded-3xl bg-surface">
              {groupItems.map((tool) => {
                const Icon = ICONS[tool.id];
                const isPinned = pinned.includes(tool.id);
                return (
                  <li key={tool.id} className="flex items-stretch border-b border-fg/10 last:border-b-0">
                    <button
                      type="button"
                      className="flex min-w-0 flex-1 items-center gap-3 px-4 py-3 text-left"
                      onClick={() => ui.go(tool.id)}
                    >
                      <Icon className="size-5 shrink-0" aria-hidden="true" />
                      <span className="min-w-0">
                        <span className="block text-base">{tool.name}</span>
                        <span className="block truncate text-sm text-muted">
                          {tool.blurb} · {tool.cost}
                        </span>
                      </span>
                    </button>
                    <button
                      type="button"
                      className="grid w-12 place-items-center"
                      aria-label={isPinned ? `Unpin ${tool.name}` : `Pin ${tool.name}`}
                      onClick={() => togglePin(tool.id)}
                    >
                      <Star className={cx("size-4", isPinned && "fill-current")} />
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
        );
      })}
    </div>
  );
}

export function ToolBody({ screen }: { screen: ToolId }) {
  if (screen === "partition") return <PartitionTool />;
  if (screen === "defrag") return <DefragTool />;
  if (screen === "wipe") return <WipeTool />;
  if (screen === "backup") return <BackupTool />;
  if (screen === "recover") return <RecoverTool />;
  if (screen === "lost") return <LostTool />;
  if (screen === "badblocks") return <BadBlocksTool />;
  if (screen === "bench") return <BenchTool />;
  if (screen === "info") return <InfoTool />;
  if (screen === "ps2") return <Ps2Tool />;
  return <ConvertTool />;
}

function ToolHeading({ title }: { title: string }) {
  const ui = useUi();
  return (
    <div className="mb-4 flex items-center gap-1">
      <button type="button" className="grid size-11 place-items-center" aria-label="Back" onClick={() => ui.go("format")}>
        <ChevronLeft className="size-6" />
      </button>
      <h2 className="text-2xl font-medium">{title}</h2>
    </div>
  );
}

function NeedDrive() {
  const ui = useUi();
  return (
    <Card>
      <p className="text-lg">No device connected.</p>
      <p className="mt-2 text-sm leading-relaxed text-muted">Connect a bench drive. This browser cannot rewrite a physical USB stick.</p>
      <PrimaryButton className="mt-5" onClick={() => ui.setDeviceOpen(true)}>
        Connect a drive
      </PrimaryButton>
    </Card>
  );
}

function PartitionTool() {
  const drive = useConnected();
  const pro = useUsb((s) => s.pro);
  const tokens = useUsb((s) => s.tokens);
  const busy = useUsb((s) => !!s.job);
  const startJob = useUsb((s) => s.startJob);
  const [draft, setDraft] = useState<WizardDraft | null>(null);
  const [undo, setUndo] = useState<WizardDraft[]>([]);
  const [editor, setEditor] = useState<null | "create" | "rename" | "format">(null);
  const [targetId, setTargetId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [fs, setFs] = useState<FsId>("FAT32");
  const [size, setSize] = useState(MIB);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!drive) {
      setDraft(null);
      setUndo([]);
      return;
    }
    setDraft({
      table: drive.table ?? "MBR",
      parts: structuredClone(drive.partitions),
      lost: structuredClone(drive.lost),
      scrap: structuredClone(drive.scrap),
    });
    setUndo([]);
    setEditor(null);
  }, [drive]);

  if (!drive || !draft) {
    return (
      <div>
        <ToolHeading title="Partition Wizard" />
        <NeedDrive />
      </div>
    );
  }

  const free = Math.max(0, drive.real - draft.parts.reduce((sum, part) => sum + part.bytes, 0));
  const dirty = undo.length > 0;
  const cost = Math.min(3, Math.max(1, undo.length));
  const push = (next: WizardDraft) => {
    setUndo((stack) => [...stack, draft].slice(-20));
    setDraft(next);
    setEditor(null);
    setError(null);
  };

  const create = () => {
    if (draft.parts.length >= maxPartitions(draft.table)) {
      setError(`${draft.table} already has ${maxPartitions(draft.table)} partitions.`);
      return;
    }
    const bytes = alignDown(Math.min(size, free));
    const issue = fsIssue(fs, bytes) || labelIssue(name, fs);
    if (issue) {
      setError(issue);
      return;
    }
    if (bytes > free) {
      setError("That is larger than the unallocated space.");
      return;
    }
    const part: Partition = {
      id: `new-${Date.now().toString(36)}`,
      label: sanitizeLabel(name, fs),
      fs,
      bytes,
      cluster: resolveCluster(fs, "default", bytes),
      files: [],
    };
    push({ ...draft, parts: [...draft.parts, part] });
  };

  return (
    <div>
      <ToolHeading title="Partition Wizard" />
      <Card>
        <p className="text-sm text-muted">
          Writable {formatBytes(drive.real)} · unallocated {formatBytes(free)} · {draft.table}
        </p>
        <DiskBar parts={draft.parts} total={drive.real} />
        <ul className="mt-4 flex flex-col gap-3">
          {draft.parts.map((part) => (
            <li key={part.id} className="rounded-2xl bg-bg px-3 py-3">
              <p className="text-base">
                {displayLabel(part.label)} · {part.fs}
              </p>
              <p className="text-sm text-muted">
                {formatBytes(part.bytes)} · {formatCluster(part.cluster)} · {part.files.filter((f) => !f.deleted).length} files
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <QuietButton
                  onClick={() => {
                    setTargetId(part.id);
                    setName(part.label);
                    setEditor("rename");
                  }}
                >
                  Rename
                </QuietButton>
                <QuietButton
                  onClick={() => {
                    setTargetId(part.id);
                    setFs(part.fs);
                    setName(part.label);
                    setEditor("format");
                  }}
                >
                  Format
                </QuietButton>
                <QuietButton
                  onClick={() => {
                    const files = part.files.map((f) => ({ ...f, deleted: true, recover: "smart" as const }));
                    push({
                      ...draft,
                      scrap: [...draft.scrap, ...files],
                      parts: draft.parts.map((item) => (item.id === part.id ? { ...item, files: [] } : item)),
                    });
                  }}
                >
                  Wipe
                </QuietButton>
                <QuietButton
                  onClick={() =>
                    push({
                      ...draft,
                      parts: draft.parts.filter((item) => item.id !== part.id),
                      lost: [...draft.lost, part],
                    })
                  }
                >
                  Delete
                </QuietButton>
              </div>
            </li>
          ))}
          {draft.parts.length === 0 ? <li className="text-sm text-muted">No partitions in the table.</li> : null}
        </ul>
        {draft.lost.length ? (
          <div className="mt-4">
            <p className="text-sm text-muted">Lost, not in the table yet</p>
            <ul className="mt-2 flex flex-col gap-2">
              {draft.lost.map((part) => (
                <li key={part.id} className="flex items-center justify-between gap-2 text-sm">
                  <span>
                    {displayLabel(part.label)} · {formatBytes(part.bytes)}
                  </span>
                  <QuietButton
                    onClick={() => {
                      if (draft.parts.length >= maxPartitions(draft.table)) {
                        setError(`${draft.table} is full.`);
                        return;
                      }
                      if (part.bytes > free) {
                        setError("Not enough unallocated space.");
                        return;
                      }
                      push({
                        ...draft,
                        lost: draft.lost.filter((item) => item.id !== part.id),
                        parts: [...draft.parts, part],
                      });
                    }}
                  >
                    Put back
                  </QuietButton>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
        {error ? <p className="mt-3 text-sm text-danger">{error}</p> : null}
        <div className="mt-4 flex flex-wrap gap-2">
          <QuietButton
            disabled={free < MIB || busy}
            onClick={() => {
              setEditor("create");
              setName("");
              setFs("FAT32");
              setSize(alignDown(free));
              setError(null);
            }}
          >
            New partition
          </QuietButton>
          <QuietButton
            disabled={busy}
            onClick={() => {
              const next: TableKind = draft.table === "MBR" ? "GPT" : "MBR";
              if (next === "MBR" && drive.real > 2_199_023_255_552) {
                setError("This disk is larger than 2 TB, so it has to stay GPT.");
                return;
              }
              if (next === "MBR" && draft.parts.length > 4) {
                setError("Delete partitions until 4 or fewer before converting to MBR.");
                return;
              }
              push({ ...draft, table: next });
            }}
          >
            Convert to {draft.table === "MBR" ? "GPT" : "MBR"}
          </QuietButton>
          <QuietButton
            disabled={!dirty || busy}
            onClick={() => {
              const prev = undo[undo.length - 1];
              if (!prev) return;
              setUndo(undo.slice(0, -1));
              setDraft(prev);
            }}
          >
            Undo
          </QuietButton>
        </div>
        <p className="mt-4 text-sm text-muted">
          {dirty
            ? `${undo.length} queued change${undo.length === 1 ? "" : "s"} · ${pro ? "Pro, no token" : tokenWord(cost)} on apply`
            : "Queue is empty. Apply stays off until you change the layout."}
        </p>
        <PrimaryButton
          className="mt-3"
          disabled={!dirty || busy || (!pro && tokens < cost)}
          onClick={() => {
            const started = startJob({
              title: "Writing partitions",
              duration: 2800,
              cancellable: false,
              stages: [
                { until: 0.35, label: "Checking the queue" },
                { until: 0.75, label: "Writing the table" },
                { until: 1, label: "Reloading volumes" },
              ],
              payload: { kind: "wizard", driveId: drive.id, draft, cost: pro ? 0 : cost },
            });
            if (!started) setError("An operation is already running.");
          }}
        >
          {!pro && tokens < cost ? "Need tokens" : "Apply"}
        </PrimaryButton>
      </Card>

      {editor === "create" ? (
        <Card className="mt-4">
          <h3 className="text-lg">New partition</h3>
          <label className="mt-3 block text-sm text-muted">
            Label
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              className="mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg outline-none"
              aria-label="New partition label"
            />
          </label>
          <label className="mt-3 block text-sm text-muted">
            File system
            <select
              value={fs}
              onChange={(event) => setFs(event.target.value as FsId)}
              className="mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg"
              aria-label="New partition file system"
            >
              {FILESYSTEMS.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.id}
                </option>
              ))}
            </select>
          </label>
          <label className="mt-3 block text-sm text-muted">
            Size · {formatBytes(size)}
            <input
              type="range"
              min={MIB}
              max={Math.max(MIB, free)}
              step={free > 100_000_000_000 ? 1_000_000_000 : MIB}
              value={Math.min(size, Math.max(MIB, free))}
              onChange={(event) => setSize(Number(event.target.value))}
              className="mt-2 w-full"
              aria-label="New partition size"
            />
          </label>
          <div className="mt-4 flex gap-2">
            <QuietButton className="flex-1" onClick={() => setEditor(null)}>Cancel</QuietButton>
            <PrimaryButton className="w-auto flex-1" onClick={create}>Queue create</PrimaryButton>
          </div>
        </Card>
      ) : null}

      {editor === "rename" || editor === "format" ? (
        <Card className="mt-4">
          <h3 className="text-lg">{editor === "rename" ? "Rename" : "Format partition"}</h3>
          <label className="mt-3 block text-sm text-muted">
            Label
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              className="mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg outline-none"
              aria-label="Partition label"
            />
          </label>
          {editor === "format" ? (
            <label className="mt-3 block text-sm text-muted">
              File system
              <select
                value={fs}
                onChange={(event) => setFs(event.target.value as FsId)}
                className="mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg"
                aria-label="Partition file system"
              >
                {FILESYSTEMS.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.id}
                  </option>
                ))}
              </select>
            </label>
          ) : null}
          <div className="mt-4 flex gap-2">
            <QuietButton className="flex-1" onClick={() => setEditor(null)}>Cancel</QuietButton>
            <PrimaryButton className="w-auto flex-1"
              onClick={() => {
                const part = draft.parts.find((item) => item.id === targetId);
                if (!part) return;
                const useFs = editor === "format" ? fs : part.fs;
                const issue = labelIssue(name, useFs) || (editor === "format" ? fsIssue(useFs, part.bytes) : null);
                if (issue) {
                  setError(issue);
                  return;
                }
                if (editor === "rename") {
                  push({
                    ...draft,
                    parts: draft.parts.map((item) =>
                      item.id === part.id ? { ...item, label: sanitizeLabel(name, part.fs) } : item,
                    ),
                  });
                  return;
                }
                push({
                  ...draft,
                  scrap: [...draft.scrap, ...part.files.map((f) => ({ ...f, deleted: true, recover: "smart" as const }))],
                  parts: draft.parts.map((item) =>
                    item.id === part.id
                      ? {
                          ...item,
                          fs: useFs,
                          label: sanitizeLabel(name, useFs),
                          cluster: resolveCluster(useFs, "default", item.bytes),
                          files: [],
                        }
                      : item,
                  ),
                });
              }}
            >
              Queue
            </PrimaryButton>
          </div>
        </Card>
      ) : null}
    </div>
  );
}

function DiskBar({ parts, total }: { parts: Partition[]; total: number }) {
  return (
    <div className="mt-3 flex h-8 overflow-hidden rounded-lg bg-bg" aria-hidden="true">
      {parts.map((part, index) => (
        <div
          key={part.id}
          className="h-full bg-fg"
          style={{ width: `${(part.bytes / total) * 100}%`, opacity: 1 - index * 0.15 }}
        />
      ))}
    </div>
  );
}

function DefragTool() {
  const drive = useConnected();
  const busy = useUsb((s) => !!s.job);
  const startJob = useUsb((s) => s.startJob);
  const [error, setError] = useState<string | null>(null);
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Defragmenter" />
        <NeedDrive />
      </div>
    );
  }
  const stats = fragStats(drive);
  const files = drive.partitions.flatMap((part) =>
    part.fs === "FAT32" || part.fs === "exFAT"
      ? part.files.filter((file) => !file.deleted).map((file) => ({ ...file, fs: part.fs }))
      : [],
  );
  return (
    <div>
      <ToolHeading title="Defragmenter" />
      <Card>
        {!stats.supported ? (
          <p className="text-sm leading-relaxed text-muted">Only FAT32 and exFAT can be defragmented here. Format the stick first if OPL or a console requires it.</p>
        ) : (
          <>
            <p className="text-lg">{stats.extra ? `${stats.extra} extra fragments` : "Already contiguous"}</p>
            <p className="mt-1 text-sm text-muted">{stats.files} files on FAT32 or exFAT.</p>
            <ul className="mt-4 flex flex-col gap-2">
              {files.map((file) => (
                <li key={file.id} className="flex justify-between gap-3 text-sm">
                  <span className="truncate">{file.name}</span>
                  <span className="shrink-0 text-muted">{file.fragments} extent{file.fragments === 1 ? "" : "s"}</span>
                </li>
              ))}
            </ul>
          </>
        )}
        {error ? <p className="mt-3 text-sm text-danger">{error}</p> : null}
        <PrimaryButton
          className="mt-5"
          disabled={!stats.supported || stats.extra === 0 || busy}
          onClick={() => {
            const started = startJob({
              title: "Defragmenting",
              duration: 2600,
              cancellable: true,
              stages: [
                { until: 0.4, label: "Reading extents" },
                { until: 0.85, label: "Packing files" },
                { until: 1, label: "Updating the table" },
              ],
              payload: { kind: "defrag", driveId: drive.id },
            });
            if (!started) setError("An operation is already running.");
          }}
        >
          Start
        </PrimaryButton>
      </Card>
    </div>
  );
}

function WipeTool() {
  const drive = useConnected();
  const certs = useUsb((s) => s.certs);
  const busy = useUsb((s) => !!s.job);
  const startJob = useUsb((s) => s.startJob);
  const [method, setMethod] = useState<WipeId>("nist");
  const [verify, setVerify] = useState<VerifyMode>("sample");
  const [armed, setArmed] = useState(false);
  const chosen = WIPE_METHODS.find((item) => item.id === method) ?? WIPE_METHODS[0];
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Wipe" />
        <NeedDrive />
      </div>
    );
  }
  const mine = certs.filter((cert) => cert.serial === drive.serial);
  return (
    <div>
      <ToolHeading title="Wipe" />
      <Card>
        <p className="text-sm leading-relaxed text-muted">
          Secure erase clears partitions and recoverable files on {drive.model}. You will need to format it afterwards.
        </p>
        <ul className="mt-4 flex flex-col gap-2">
          {WIPE_METHODS.map((item) => (
            <li key={item.id}>
              <button
                type="button"
                onClick={() => setMethod(item.id)}
                className={cx("w-full rounded-2xl px-3 py-3 text-left", method === item.id ? "bg-fg text-bg" : "bg-bg")}
              >
                <span className="block text-base">{item.name}</span>
                <span className={cx("block text-sm", method === item.id ? "text-bg/70" : "text-muted")}>
                  {item.passes} pass{item.passes === 1 ? "" : "es"} · {item.detail}
                </span>
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex gap-2">
          {(["off", "sample", "full"] as const).map((mode) => (
            <button
              key={mode}
              type="button"
              onClick={() => setVerify(mode)}
              className={cx("h-10 flex-1 rounded-xl text-sm", verify === mode ? "bg-fg text-bg" : "bg-bg")}
            >
              {mode === "off" ? "No verify" : mode === "sample" ? "Sample" : "Full"}
            </button>
          ))}
        </div>
        <PrimaryButton className="mt-5" disabled={busy} onClick={() => setArmed(true)}>
          Wipe drive
        </PrimaryButton>
      </Card>
      {mine.length ? (
        <Card className="mt-4">
          <h3 className="text-lg">Certificates</h3>
          <ul className="mt-3 flex flex-col gap-3">
            {mine.map((cert) => (
              <li key={cert.id} className="rounded-2xl bg-bg px-3 py-3 text-sm">
                <p>
                  {cert.method} · {cert.passes} passes · {cert.verified ? "Verification passed" : "Verification failed"}
                </p>
                <p className="mt-1 text-muted">
                  {drive.model} · {cert.serial} · {formatBytes(cert.bytes)} · {formatWhen(cert.at)}
                </p>
                <Seal seed={`${cert.serial}${cert.at}`} />
              </li>
            ))}
          </ul>
        </Card>
      ) : null}
      {armed ? (
        <Card className="mt-4">
          <p>Erase {drive.model} with {chosen.name}? {liveFileCount(drive)} live files will be destroyed, not just deleted.</p>
          <div className="mt-4 flex gap-2">
            <QuietButton className="flex-1" onClick={() => setArmed(false)}>Cancel</QuietButton>
            <PrimaryButton
              className="w-auto flex-1"
              onClick={() => {
                setArmed(false);
                startJob({
                  title: "Wiping",
                  duration: Math.min(9000, 650 * chosen.passes + (verify === "full" ? 2200 : verify === "sample" ? 900 : 0)),
                  cancellable: false,
                  stages: wipeStages(chosen.passes, verify),
                  payload: { kind: "wipe", driveId: drive.id, method: chosen.name, passes: chosen.passes, verify },
                });
              }}
            >
              Erase
            </PrimaryButton>
          </div>
        </Card>
      ) : null}
    </div>
  );
}

function Seal({ seed }: { seed: string }) {
  const cells = useMemo(() => {
    let h = 0;
    return Array.from({ length: 36 }, (_, i) => {
      h = (h * 33 + seed.charCodeAt(i % seed.length) + i) >>> 0;
      return h % 3 === 0;
    });
  }, [seed]);
  return (
    <div className="mt-3 grid w-24 grid-cols-6 gap-0.5" aria-hidden="true">
      {cells.map((on, index) => (
        <span key={index} className={cx("aspect-square", on ? "bg-fg" : "bg-surface")} />
      ))}
    </div>
  );
}

function BackupTool() {
  const drive = useConnected();
  const backups = useUsb((s) => s.backups);
  const busy = useUsb((s) => !!s.job);
  const startJob = useUsb((s) => s.startJob);
  const deleteBackup = useUsb((s) => s.deleteBackup);
  const [pick, setPick] = useState<string | null>(null);
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Backup & Restore" />
        <NeedDrive />
      </div>
    );
  }
  return (
    <div>
      <ToolHeading title="Backup & Restore" />
      <Card>
        <p className="text-sm leading-relaxed text-muted">
          Images stay in this browser. Restoring replaces the connected drive's table and files.
        </p>
        <PrimaryButton
          className="mt-4"
          disabled={busy}
          onClick={() =>
            startJob({
              title: "Imaging drive",
              duration: 2000,
              cancellable: true,
              stages: [
                { until: 0.6, label: "Reading partitions" },
                { until: 1, label: "Saving the image" },
              ],
              payload: { kind: "backup", driveId: drive.id },
            })
          }
        >
          Save image
        </PrimaryButton>
      </Card>
      <ul className="mt-4 flex flex-col gap-3">
        {backups.map((bak) => (
          <li key={bak.id}>
            <Card className="py-4">
              <p>{bak.model}</p>
              <p className="text-sm text-muted">
                {formatWhen(bak.at)} · {formatBytes(bak.real)} · {bak.table ?? "No table"} · {bak.partitions.length} volumes
              </p>
              <div className="mt-3 flex gap-2">
                <QuietButton onClick={() => setPick(bak.id)} disabled={busy}>
                  Restore
                </QuietButton>
                <QuietButton onClick={() => deleteBackup(bak.id)}>Delete image</QuietButton>
              </div>
            </Card>
          </li>
        ))}
        {backups.length === 0 ? <li className="text-sm text-muted">No images saved yet.</li> : null}
      </ul>
      {pick ? (
        <Card className="mt-4">
          <p>Replace the contents of {drive.model} with this image?</p>
          <div className="mt-4 flex gap-2">
            <QuietButton className="flex-1" onClick={() => setPick(null)}>Cancel</QuietButton>
            <PrimaryButton
              className="w-auto flex-1"
              onClick={() => {
                const id = pick;
                setPick(null);
                startJob({
                  title: "Restoring image",
                  duration: 2400,
                  cancellable: false,
                  stages: [
                    { until: 0.5, label: "Checking the image" },
                    { until: 1, label: "Writing partitions" },
                  ],
                  payload: { kind: "restore-backup", driveId: drive.id, backupId: id },
                });
              }}
            >
              Restore
            </PrimaryButton>
          </div>
        </Card>
      ) : null}
    </div>
  );
}

const SCAN_MODES: { id: ScanMode; label: string; hint: string }[] = [
  { id: "quick", label: "Quick", hint: "Just deleted" },
  { id: "smart", label: "Smart", hint: "Named leftovers" },
  { id: "deep", label: "Deep", hint: "Lost volumes" },
  { id: "raw", label: "Raw", hint: "Carved signatures" },
];

function RecoverTool() {
  const drive = useConnected();
  const lastScan = useUsb((s) => s.lastScan);
  const busy = useUsb((s) => !!s.job);
  const startJob = useUsb((s) => s.startJob);
  const [mode, setMode] = useState<ScanMode>("smart");
  const [picked, setPicked] = useState<string[]>([]);
  const [preview, setPreview] = useState<string | null>(null);
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Recover Files" />
        <NeedDrive />
      </div>
    );
  }
  const hits = lastScan?.driveId === drive.id ? lastScan.ids : [];
  const files = hits.map((id) => findFile(drive, id)).filter((file) => file != null);
  return (
    <div>
      <ToolHeading title="Recover Files" />
      <Card>
        <div className="grid grid-cols-4 gap-2">
          {SCAN_MODES.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setMode(item.id)}
              className={cx("rounded-xl px-1 py-2 text-center text-sm", mode === item.id ? "bg-fg text-bg" : "bg-bg")}
            >
              {item.label}
            </button>
          ))}
        </div>
        <p className="mt-3 text-sm text-muted">{SCAN_MODES.find((item) => item.id === mode)?.hint}. Preview before you write anything back.</p>
        <PrimaryButton
          className="mt-4"
          disabled={busy}
          onClick={() => {
            setPicked([]);
            startJob({
              title: "Scanning",
              duration: scanDuration(mode),
              cancellable: true,
              stages: [
                { until: 0.3, label: "Reading the table" },
                { until: 0.75, label: `Running a ${mode} scan` },
                { until: 1, label: "Listing matches" },
              ],
              payload: { kind: "scan", driveId: drive.id, mode },
            });
          }}
        >
          Start scan
        </PrimaryButton>
      </Card>
      <ul className="mt-4 flex flex-col gap-2">
        {files.map((file) => (
          <li key={file.id} className="flex items-center gap-3 rounded-2xl bg-surface px-3 py-3">
            <input
              type="checkbox"
              checked={picked.includes(file.id)}
              onChange={() =>
                setPicked((current) =>
                  current.includes(file.id) ? current.filter((id) => id !== file.id) : [...current, file.id],
                )
              }
              aria-label={`Select ${file.name}`}
            />
            <button type="button" className="min-w-0 flex-1 text-left" onClick={() => setPreview(file.id)}>
              <span className="block truncate">{file.name}</span>
              <span className="block text-sm text-muted">
                {formatBytes(file.bytes)} · {file.kind}
              </span>
            </button>
          </li>
        ))}
      </ul>
      {lastScan?.driveId === drive.id && files.length === 0 ? (
        <p className="mt-4 text-sm text-muted">The last {lastScan.mode} scan found nothing on this drive.</p>
      ) : null}
      {picked.length ? (
        <PrimaryButton
          className="mt-4"
          disabled={busy}
          onClick={() =>
            startJob({
              title: "Restoring files",
              duration: 1600,
              cancellable: false,
              stages: [
                { until: 0.5, label: "Checking free space" },
                { until: 1, label: "Copying files back" },
              ],
              payload: { kind: "restore-files", driveId: drive.id, ids: picked },
            })
          }
        >
          Restore {picked.length}
        </PrimaryButton>
      ) : null}
      {preview ? <Preview fileId={preview} onClose={() => setPreview(null)} /> : null}
    </div>
  );
}

function Preview({ fileId, onClose }: { fileId: string; onClose: () => void }) {
  const drive = useConnected();
  const file = drive ? findFile(drive, fileId) : null;
  if (!file) return null;
  return (
    <Card className="mt-4">
      <p className="text-lg">{file.name}</p>
      <p className="text-sm text-muted">
        {formatBytes(file.bytes)} · {file.fragments} extent{file.fragments === 1 ? "" : "s"} · found as {file.recover}
      </p>
      <p className="mt-3 text-sm leading-relaxed">
        {file.preview || "No text preview. The signature matched this file type, but the bytes are not a document."}
      </p>
      <QuietButton className="mt-4" onClick={onClose}>
        Close preview
      </QuietButton>
    </Card>
  );
}

function LostTool() {
  const drive = useConnected();
  const busy = useUsb((s) => !!s.job);
  const startJob = useUsb((s) => s.startJob);
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Lost Partitions" />
        <NeedDrive />
      </div>
    );
  }
  return (
    <div>
      <ToolHeading title="Lost Partitions" />
      <Card>
        {drive.lost.length === 0 ? (
          <p className="text-sm text-muted">No lost partitions on {drive.model}. Deleting one in the wizard, without applying a full format, leaves it here.</p>
        ) : (
          <ul className="flex flex-col gap-3">
            {drive.lost.map((part) => (
              <li key={part.id} className="rounded-2xl bg-bg px-3 py-3">
                <p>
                  {displayLabel(part.label)} · {part.fs}
                </p>
                <p className="text-sm text-muted">
                  {formatBytes(part.bytes)} · {part.files.length} files
                </p>
                <QuietButton
                  className="mt-3"
                  disabled={busy}
                  onClick={() =>
                    startJob({
                      title: "Restoring partition",
                      duration: 1800,
                      cancellable: false,
                      stages: [
                        { until: 0.5, label: "Checking free space" },
                        { until: 1, label: "Updating the table" },
                      ],
                      payload: { kind: "restore-part", driveId: drive.id, partId: part.id },
                    })
                  }
                >
                  Restore
                </QuietButton>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-4 text-sm text-muted">Unallocated space: {formatBytes(unallocated(drive))}.</p>
      </Card>
    </div>
  );
}

function BadBlocksTool() {
  const drive = useConnected();
  const job = useUsb((s) => s.job);
  const payload = useUsb((s) => s.payload);
  const busy = !!job;
  const startJob = useUsb((s) => s.startJob);
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Bad Blocks" />
        <NeedDrive />
      </div>
    );
  }
  const scanning = payload?.kind === "badblocks" && payload.driveId === drive.id && job ? job.progress : drive.verifiedReal ? 1 : 0;
  const cells = badMap(drive);
  const shown = Math.floor(scanning * cells.length);
  return (
    <div>
      <ToolHeading title="Bad Blocks" />
      <Card>
        <p className="text-sm leading-relaxed text-muted">
          One sample pass over the surface. A counterfeit stick fails when the writable size is far below the label.
        </p>
        <div className="mt-4 grid grid-cols-8 gap-1">
          {cells.map((bad, index) => {
            const seen = index < shown;
            return (
              <div
                key={index}
                className={cx("aspect-square rounded-sm", !seen && "bg-bg", seen && !bad && "bg-fg", seen && bad && "bg-danger")}
                title={seen ? (bad ? "Bad" : "Readable") : "Unread"}
              />
            );
          })}
        </div>
        <p className="mt-3 text-sm text-muted">Light cells read back. Marked cells failed. Dark cells are still unread.</p>
        <PrimaryButton
          className="mt-4"
          disabled={busy}
          onClick={() =>
            startJob({
              title: "Testing blocks",
              duration: 4200,
              cancellable: true,
              stages: [
                { until: 0.45, label: "Writing the pattern" },
                { until: 0.9, label: "Reading it back" },
                { until: 1, label: "Comparing capacity" },
              ],
              payload: { kind: "badblocks", driveId: drive.id },
            })
          }
        >
          {drive.verifiedReal ? "Test again" : "Start test"}
        </PrimaryButton>
      </Card>
    </div>
  );
}

function BenchTool() {
  const drive = useConnected();
  const benches = useUsb((s) => s.benches);
  const job = useUsb((s) => s.job);
  const payload = useUsb((s) => s.payload);
  const busy = !!job;
  const startJob = useUsb((s) => s.startJob);
  const [write, setWrite] = useState(false);
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Benchmark" />
        <NeedDrive />
      </div>
    );
  }
  const live = payload?.kind === "bench" && payload.driveId === drive.id && job ? payload.planned : null;
  const progress = live && job ? job.progress : 0;
  const history = benches.filter((row) => row.serial === drive.serial);
  return (
    <div>
      <ToolHeading title="Benchmark" />
      <Card>
        <div className="flex gap-2">
          <button type="button" className={cx("h-10 flex-1 rounded-xl text-sm", !write ? "bg-fg text-bg" : "bg-bg")} onClick={() => setWrite(false)}>
            Read only
          </button>
          <button type="button" className={cx("h-10 flex-1 rounded-xl text-sm", write ? "bg-fg text-bg" : "bg-bg")} onClick={() => setWrite(true)}>
            Read and write
          </button>
        </div>
        {live ? (
          <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <Meter label="Seq read" value={`${(live.seqRead * progress).toFixed(0)} MB/s`} />
            <Meter label="Seq write" value={live.seqWrite != null ? `${(live.seqWrite * progress).toFixed(0)} MB/s` : "—"} />
            <Meter label="Random read" value={`${Math.round(live.randRead * progress)} IOPS`} />
            <Meter label="Random write" value={live.randWrite != null ? `${Math.round(live.randWrite * progress)} IOPS` : "—"} />
          </div>
        ) : (
          <p className="mt-4 text-sm text-muted">
            {drive.kind} on {drive.speed}. Write tests are simulated and do not erase files.
          </p>
        )}
        <PrimaryButton
          className="mt-4"
          disabled={busy}
          onClick={() =>
            startJob({
              title: "Benchmark",
              duration: 3600,
              cancellable: true,
              stages: [
                { until: 0.5, label: "Sequential run" },
                { until: 1, label: write ? "Random run" : "Random read" },
              ],
              payload: { kind: "bench", driveId: drive.id, planned: planBench(drive, write) },
            })
          }
        >
          Start
        </PrimaryButton>
      </Card>
      {history.length ? (
        <ul className="mt-4 flex flex-col gap-2">
          {history.map((row) => (
            <li key={row.id} className="rounded-2xl bg-surface px-4 py-3 text-sm">
              <p>{formatWhen(row.at)}</p>
              <p className="text-muted">
                {row.seqRead} MB/s read{row.seqWrite != null ? ` · ${row.seqWrite} MB/s write` : ""} · {row.randRead} IOPS
              </p>
            </li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

function Meter({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-bg px-3 py-3">
      <p className="text-muted">{label}</p>
      <p className="mt-1 text-lg tabular-nums text-fg">{value}</p>
    </div>
  );
}

function InfoTool() {
  const drive = useConnected();
  const logs = useUsb((s) => s.logs);
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Device Info" />
        <NeedDrive />
      </div>
    );
  }
  const rows: [string, string][] = [
    ["Model", drive.model],
    ["Vendor", drive.vendor],
    ["Product", drive.product],
    ["Kind", `${drive.kind} · ${drive.speed}`],
    ["VID:PID", `${drive.vid}:${drive.pid}`],
    ["Serial", drive.serial],
    ["Block size", `${drive.blockSize} bytes`],
    ["Advertised", formatBytes(drive.advertised)],
    ["Writable", drive.verifiedReal ? formatBytes(drive.real) : "Run Bad Blocks to verify"],
    ["Table", drive.table ?? "None"],
    ["Live files", String(liveFileCount(drive))],
    ["Free in volumes", formatBytes(volumeFree(drive))],
  ];
  const checks = healthChecks(drive);
  return (
    <div>
      <ToolHeading title="Device Info" />
      <Card className="py-4">
        <dl className="flex flex-col">
          {rows.map(([label, value]) => (
            <div key={label} className="flex items-baseline justify-between gap-4 border-b border-fg/10 py-2 text-sm last:border-b-0">
              <dt className="text-muted">{label}</dt>
              <dd className="text-right break-all">{value}</dd>
            </div>
          ))}
        </dl>
      </Card>
      <Card className="mt-4">
        <h3 className="text-lg">Table check</h3>
        <ul className="mt-3 flex flex-col gap-2">
          {checks.map((check) => (
            <li key={check.label} className={cx("text-sm", check.tone === "bad" && "text-danger", check.tone === "warn" && "text-muted")}>
              {check.tone === "ok" ? "Pass" : check.tone === "warn" ? "Check" : "Fail"} · {check.label}
            </li>
          ))}
        </ul>
      </Card>
      {drive.partitions.map((part) => (
        <Card key={part.id} className="mt-4 py-4">
          <p>
            {displayLabel(part.label)} · {part.fs}
          </p>
          <p className="text-sm text-muted">
            {formatBytes(part.bytes)} · cluster {formatCluster(part.cluster)} · used {formatBytes(usedBytes(part))}
          </p>
        </Card>
      ))}
      {logs.length ? (
        <Card className="mt-4">
          <h3 className="text-lg">Activity</h3>
          <ul className="mt-3 flex flex-col gap-2">
            {logs.slice(0, 8).map((line) => (
              <li key={line.id} className="text-sm">
                <span className="text-muted">{formatWhen(line.at)} · </span>
                {line.text}
              </li>
            ))}
          </ul>
        </Card>
      ) : null}
    </div>
  );
}

function Ps2Tool() {
  const ui = useUi();
  const drive = useConnected();
  const pro = useUsb((s) => s.pro);
  const tokens = useUsb((s) => s.tokens);
  const busy = useUsb((s) => !!s.job);
  const startJob = useUsb((s) => s.startJob);
  const renameLiveFile = useUsb((s) => s.renameLiveFile);
  const [renameId, setRenameId] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [confirm, setConfirm] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  if (!drive) {
    return (
      <div>
        <ToolHeading title="PS2 USB Utils" />
        <NeedDrive />
      </div>
    );
  }
  const games = gameFiles(drive);
  const cfg = drive.partitions.flatMap((part) => part.files).find((file) => file.name.toLowerCase() === "ul.cfg" && !file.deleted);
  return (
    <div>
      <ToolHeading title="PS2 USB Utils" />
      <Card>
        <p className="text-sm leading-relaxed text-muted">
          OPL wants FAT32, MBR, and files at or under 4 GB. Bigger ISOs have to be split into USBExtreme parts.
        </p>
        <PrimaryButton className="mt-4" disabled={busy} onClick={() => setConfirm(true)}>
          Format for PS2
        </PrimaryButton>
        <QuietButton className="mt-3 w-full" onClick={() => ui.go("defrag")}>
          Open defragmenter
        </QuietButton>
      </Card>
      <ul className="mt-4 flex flex-col gap-3">
        {games.map(({ file, part }) => (
          <li key={file.id} className="rounded-3xl bg-surface px-4 py-4">
            <p className="break-all">{file.name}</p>
            <p className="text-sm text-muted">
              {formatBytes(file.bytes)} · {part.fs}
              {file.bytes > FAT_FILE_LIMIT && part.fs === "FAT32" ? " · over the 4 GB FAT limit" : ""}
              {file.fragments > 1 ? ` · ${file.fragments} fragments` : ""}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <QuietButton
                onClick={() => {
                  setRenameId(file.id);
                  setName(file.name);
                }}
              >
                Rename
              </QuietButton>
              <QuietButton
                disabled={busy || file.bytes <= FAT_FILE_LIMIT}
                onClick={() =>
                  startJob({
                    title: "Splitting image",
                    duration: 2400,
                    cancellable: false,
                    stages: [
                      { until: 0.7, label: "Cutting USBExtreme parts" },
                      { until: 1, label: "Writing ul.cfg" },
                    ],
                    payload: { kind: "split", driveId: drive.id, fileId: file.id },
                  })
                }
              >
                Split for OPL
              </QuietButton>
            </div>
          </li>
        ))}
        {games.length === 0 ? <li className="text-sm text-muted">No game images on this drive.</li> : null}
      </ul>
      {cfg?.preview ? (
        <Card className="mt-4">
          <h3 className="text-lg">ul.cfg</h3>
          <pre className="mt-3 overflow-x-auto text-xs leading-relaxed whitespace-pre-wrap">{cfg.preview}</pre>
        </Card>
      ) : null}
      {message ? <p className="mt-3 text-sm text-danger">{message}</p> : null}
      {renameId ? (
        <Card className="mt-4">
          <label className="block text-sm text-muted">
            File name
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              className="mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg outline-none"
              aria-label="Game file name"
            />
          </label>
          <div className="mt-3 flex gap-2">
            <QuietButton className="flex-1" onClick={() => setRenameId(null)}>Cancel</QuietButton>
            <PrimaryButton
              className="w-auto flex-1"
              onClick={() => {
                const err = renameLiveFile(drive.id, renameId, name);
                setMessage(err);
                if (!err) setRenameId(null);
              }}
            >
              Save
            </PrimaryButton>
          </div>
        </Card>
      ) : null}
      {confirm ? (
        <Card className="mt-4">
          <p>
            Format {drive.model} as FAT32 / MBR / 32 KB, label OPL? Every file on it goes away.
            {pro ? " Pro does not spend a token." : ` This spends 1 token. You have ${tokens}.`}
          </p>
          <div className="mt-4 flex gap-2">
            <QuietButton className="flex-1" onClick={() => setConfirm(false)}>Cancel</QuietButton>
            {!pro && tokens < 1 ? (
              <PrimaryButton
                className="w-auto flex-1"
                onClick={() => {
                  setConfirm(false);
                  ui.setTokenOpen(true);
                }}
              >
                Get a token
              </PrimaryButton>
            ) : (
              <PrimaryButton
                className="w-auto flex-1"
                onClick={() => {
                  setConfirm(false);
                  startJob({
                    title: "PS2 format",
                    duration: 3400,
                    cancellable: false,
                    stages: [
                      { until: 0.4, label: "Writing an MBR" },
                      { until: 1, label: "Formatting FAT32 for OPL" },
                    ],
                    payload: {
                      kind: "format",
                      driveId: drive.id,
                      fs: "FAT32",
                      cluster: "32768",
                      table: "MBR",
                      label: "OPL",
                      cost: pro ? 0 : 1,
                    },
                  });
                }}
              >
                Format
              </PrimaryButton>
            )}
          </div>
        </Card>
      ) : null}
    </div>
  );
}

function ConvertTool() {
  const drive = useConnected();
  const busy = useUsb((s) => !!s.job);
  const startJob = useUsb((s) => s.startJob);
  const [fileId, setFileId] = useState<string>("");
  const [target, setTarget] = useState<ConvertExt>("chd");
  if (!drive) {
    return (
      <div>
        <ToolHeading title="Game Converter" />
        <NeedDrive />
      </div>
    );
  }
  const files = drive.partitions.flatMap((part) => part.files.filter((file) => !file.deleted));
  const selected = fileId || files[0]?.id || "";
  return (
    <div>
      <ToolHeading title="Game Converter" />
      <Card>
        {files.length === 0 ? (
          <p className="text-sm text-muted">This volume has no files to convert.</p>
        ) : (
          <>
            <label className="block text-sm text-muted">
              Source
              <select
                value={selected}
                onChange={(event) => setFileId(event.target.value)}
                className="mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg"
                aria-label="File to convert"
              >
                {files.map((file) => (
                  <option key={file.id} value={file.id}>
                    {file.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="mt-3 block text-sm text-muted">
              Target
              <select
                value={target}
                onChange={(event) => setTarget(event.target.value as ConvertExt)}
                className="mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg"
                aria-label="Target format"
              >
                {CONVERT_TARGETS.map((ext) => (
                  <option key={ext} value={ext}>
                    {ext.toUpperCase()}
                  </option>
                ))}
              </select>
            </label>
            <PrimaryButton
              className="mt-4"
              disabled={busy || !selected}
              onClick={() =>
                startJob({
                  title: "Converting",
                  duration: 2200,
                  cancellable: true,
                  stages: [
                    { until: 0.6, label: `Building ${target.toUpperCase()}` },
                    { until: 1, label: "Replacing the file" },
                  ],
                  payload: { kind: "convert", driveId: drive.id, fileId: selected, target },
                })
              }
            >
              Convert
            </PrimaryButton>
          </>
        )}
      </Card>
    </div>
  );
}
