import type { ButtonHTMLAttributes, ReactNode } from "react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cx(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

export function LogoMark({ className }: { className?: string }) {
  const teeth = [0, 45, 90, 135, 180, 225, 270, 315];
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <g fill="currentColor">
        {teeth.map((deg) => (
          <rect key={deg} x="28" y="2" width="8" height="14" rx="2" transform={`rotate(${deg} 32 32)`} />
        ))}
        <circle cx="32" cy="32" r="16" />
      </g>
      <circle cx="32" cy="32" r="11" fill="var(--color-bg)" />
      <g fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
        <path d="M32 25.5v13" />
        <path d="M32 27.5 26.5 33" />
        <path d="M32 27.5 37.5 33" />
      </g>
      <circle cx="26.2" cy="34.2" r="1.7" fill="currentColor" />
      <rect x="36.2" y="31.6" width="3.3" height="3.3" rx="0.4" fill="currentColor" />
      <circle cx="32" cy="40.2" r="1.8" fill="currentColor" />
    </svg>
  );
}

export function UsbPlug({
  className,
  badge,
}: {
  className?: string;
  badge?: "off" | "on";
}) {
  return (
    <svg viewBox="0 0 86 64" className={className} aria-hidden="true">
      <g
        transform="rotate(-36 30 34)"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <rect x="16" y="6" width="22" height="13" rx="2" />
        <path d="M22 19v8M32 19v8" />
        <path d="M14 27h26v11H14z" />
      </g>
      {badge === "off" ? (
        <g>
          <circle cx="64" cy="46" r="11" fill="var(--color-surface)" stroke="currentColor" strokeWidth="2.4" />
          <path d="M58 46h12" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
        </g>
      ) : null}
    </svg>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <section className={cx("rounded-3xl bg-surface px-5 py-6", className)}>{children}</section>;
}

export function Sheet({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-30 flex flex-col justify-end bg-bg/70" role="presentation" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="max-h-[86%] overflow-y-auto rounded-t-3xl bg-surface px-5 pt-3 pb-8"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mx-auto mb-4 h-1 w-10 rounded-full bg-muted" />
        <div className="mb-4 flex items-center justify-between gap-3">
          <h2 className="text-xl font-medium">{title}</h2>
          <button type="button" className="grid size-11 place-items-center text-muted" onClick={onClose} aria-label="Close">
            <CloseIcon />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Dialog({
  title,
  children,
  onClose,
}: {
  title: string;
  children: ReactNode;
  onClose?: () => void;
}) {
  return (
    <div
      className="absolute inset-0 z-40 grid place-items-center bg-bg/75 px-5"
      role="presentation"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="w-full max-w-sm rounded-3xl bg-surface p-5"
        onClick={(event) => event.stopPropagation()}
      >
        <h2 className="text-xl font-medium">{title}</h2>
        <div className="mt-3 text-base leading-relaxed text-fg">{children}</div>
      </div>
    </div>
  );
}

export function PrimaryButton({
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...props}
      className={cx(
        "h-12 w-full rounded-xl text-base font-medium tracking-wide disabled:cursor-default",
        props.disabled ? "bg-sunken text-muted" : "bg-fg text-bg",
        className,
      )}
    />
  );
}

export function QuietButton({
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      type="button"
      {...props}
      className={cx(
        "h-11 rounded-xl bg-sunken px-4 text-sm text-fg disabled:text-muted",
        className,
      )}
    />
  );
}

export function ProgressBar({ value }: { value: number }) {
  const width = `${Math.max(0, Math.min(100, Math.round(value * 100)))}%`;
  return (
    <div className="h-2 overflow-hidden rounded-full bg-bg" aria-hidden="true">
      <div className="h-full bg-fg" style={{ width }} />
    </div>
  );
}

function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path d="M6 6l12 12M18 6 6 18" strokeLinecap="round" />
    </svg>
  );
}
