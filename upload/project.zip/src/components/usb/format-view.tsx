import { useState } from "react";
import { ChevronDown } from "lucide-react";
import {
  FILESYSTEMS,
  clusterChoices,
  clusterLabel,
  displayLabel,
  driveSubtitle,
  formatCluster,
  formatCost,
  fsIssue,
  labelIssue,
  liveFileCount,
  resolveCluster,
  tableIssue,
  tokenWord,
  type TableKind,
} from "@/lib/usb/engine";
import { useConnected, useUsb } from "@/lib/usb/store";
import { useUi } from "@/components/usb/ui-context";
import { Card, Dialog, PrimaryButton, Sheet, UsbPlug, cx } from "@/components/usb/widgets";

const FORMAT_STAGES = [
  { until: 0.16, label: "Unmounting the volume" },
  { until: 0.45, label: "Writing the partition table" },
  { until: 0.86, label: "Formatting clusters" },
  { until: 1, label: "Verifying the new volume" },
];

export function FormatView() {
  const ui = useUi();
  const drive = useConnected();
  const fs = useUsb((s) => s.fs);
  const cluster = useUsb((s) => s.cluster);
  const table = useUsb((s) => s.table);
  const label = useUsb((s) => s.label);
  const pro = useUsb((s) => s.pro);
  const tokens = useUsb((s) => s.tokens);
  const busy = useUsb((s) => !!s.job);
  const setFs = useUsb((s) => s.setFs);
  const setCluster = useUsb((s) => s.setCluster);
  const setTable = useUsb((s) => s.setTable);
  const setLabel = useUsb((s) => s.setLabel);
  const startJob = useUsb((s) => s.startJob);
  const [picker, setPicker] = useState<null | "fs" | "cluster" | "table">(null);
  const [about, setAbout] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [block, setBlock] = useState<string | null>(null);

  const issue = drive
    ? fsIssue(fs, drive.real) || tableIssue(table, drive.real) || labelIssue(label, fs)
    : null;
  const cost = formatCost(fs);
  const resolved = drive ? resolveCluster(fs, cluster, alignGuess(drive.real)) : null;

  const onFormat = () => {
    if (!drive || busy) return;
    if (issue) {
      setBlock(issue);
      return;
    }
    setConfirm(true);
  };

  const runFormat = () => {
    if (!drive) return;
    setConfirm(false);
    if (!pro && tokens < cost) {
      ui.setTokenOpen(true);
      return;
    }
    const started = startJob({
      title: "Format",
      duration: 3400,
      cancellable: false,
      stages: FORMAT_STAGES,
      payload: { kind: "format", driveId: drive.id, fs, cluster, table, label, cost: pro ? 0 : cost },
    });
    if (!started) setBlock("An operation is already running.");
  };

  return (
    <div className="flex flex-col gap-4">
      <button
        type="button"
        onClick={() => ui.setDeviceOpen(true)}
        className="flex items-center gap-3 rounded-3xl bg-surface px-5 py-6 text-left"
        aria-label={drive ? `Connected drive ${drive.model}` : "No device connected. Connect a drive"}
      >
        <span className="min-w-0 flex-1">
          <span className="block text-xl">{drive ? drive.model : "No Device Connected."}</span>
          <span className="mt-1 block text-sm text-muted">
            {drive ? driveSubtitle(drive) : "Tap to connect a bench drive"}
          </span>
        </span>
        <UsbPlug className="size-14 shrink-0 text-fg" badge={drive ? "on" : "off"} />
      </button>

      <Card className="pb-5">
        <div className="relative">
          <h2 className="text-center text-3xl font-medium">Format</h2>
          <button
            type="button"
            className="absolute top-0 right-0 grid size-11 place-items-center"
            aria-label="About format options"
            onClick={() => setAbout(true)}
          >
            <span className="grid size-7 place-items-center rounded-full bg-fg text-sm font-semibold text-bg">i</span>
          </button>
        </div>

        <div className="mt-6 flex flex-col">
          <OptionRow label="File System:" value={fs} onClick={() => setPicker("fs")} />
          <OptionRow label="Cluster Size:" value={clusterLabel(cluster)} onClick={() => setPicker("cluster")} />
          <OptionRow label="Partition Table:" value={table} onClick={() => setPicker("table")} />
        </div>

        {issue ? <p className="mt-4 text-sm leading-relaxed text-danger">{issue}</p> : null}

        <label className="mt-10 block">
          <input
            value={label}
            onChange={(event) => setLabel(event.target.value)}
            placeholder="Volume Label"
            maxLength={32}
            aria-label="Volume label"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            className="w-full bg-transparent text-center text-2xl text-fg outline-none placeholder:text-fg"
          />
          <span className="mt-3 block h-px bg-fg" />
        </label>

        <button
          type="button"
          onClick={onFormat}
          disabled={!drive || busy}
          className={cx(
            "mt-8 h-14 w-full rounded-xl text-base font-medium tracking-widest",
            drive && !busy ? "bg-fg text-bg" : "bg-sunken text-muted",
          )}
        >
          FORMAT
        </button>
        {drive ? (
          <p className="mt-3 text-center text-sm text-muted">
            {pro ? "Pro · no token needed" : `Uses ${tokenWord(cost)}`}
            {resolved ? ` · ${cluster === "default" ? "Default" : "Cluster"} ${formatCluster(resolved)}` : ""}
          </p>
        ) : null}
      </Card>

      {picker === "fs" ? (
        <Sheet title="File System" onClose={() => setPicker(null)}>
          <ul>
            {FILESYSTEMS.map((item) => (
              <li key={item.id}>
                <PickRow
                  label={item.id}
                  hint={item.hint}
                  selected={item.id === fs}
                  onClick={() => {
                    setFs(item.id);
                    setPicker(null);
                  }}
                />
              </li>
            ))}
          </ul>
        </Sheet>
      ) : null}

      {picker === "cluster" ? (
        <Sheet title="Cluster Size" onClose={() => setPicker(null)}>
          <ul>
            {clusterChoices(fs).map((item) => (
              <li key={item}>
                <PickRow
                  label={clusterLabel(item)}
                  hint={item === "default" ? "Picked from the volume size when you format" : undefined}
                  selected={item === cluster}
                  onClick={() => {
                    setCluster(item);
                    setPicker(null);
                  }}
                />
              </li>
            ))}
          </ul>
        </Sheet>
      ) : null}

      {picker === "table" ? (
        <Sheet title="Partition Table" onClose={() => setPicker(null)}>
          <ul>
            {([
              ["MBR", "Legacy BIOS · 4 primary partitions · up to 2 TB"],
              ["GPT", "UEFI · large disks · more partitions"],
            ] as const).map(([id, hint]) => (
              <li key={id}>
                <PickRow
                  label={id}
                  hint={hint}
                  selected={table === id}
                  onClick={() => {
                    setTable(id as TableKind);
                    setPicker(null);
                  }}
                />
              </li>
            ))}
          </ul>
        </Sheet>
      ) : null}

      {about ? (
        <Sheet title="Format" onClose={() => setAbout(false)}>
          <div className="flex flex-col gap-4 text-sm leading-relaxed text-muted">
            <p className="text-fg">These options match a USB maintenance bench. The write happens on the connected bench drive, then the volume is empty.</p>
            <p><span className="text-fg">FAT32</span> is the safe pick for consoles, TVs, and car stereos. A single file cannot exceed 4 GB.</p>
            <p><span className="text-fg">exFAT and NTFS</span> hold large files. EXT2, EXT3, and EXT4 are for Linux. FAT16 is only for tiny legacy devices.</p>
            <p><span className="text-fg">Cluster size</span> is the allocation unit. Default follows the volume size. Larger clusters waste space on tiny files and can be required by older players.</p>
            <p><span className="text-fg">MBR</span> is what older consoles expect. <span className="text-fg">GPT</span> is required past 2 TB.</p>
            <p>FAT labels allow 11 characters: letters, numbers, space, underscore, hyphen. They are stored in uppercase.</p>
          </div>
        </Sheet>
      ) : null}

      {confirm && drive ? (
        <Dialog title={`Format ${drive.model}?`} onClose={() => setConfirm(false)}>
          <p>
            This erases {liveFileCount(drive)} file{liveFileCount(drive) === 1 ? "" : "s"}, deleted files, and lost partitions.
            The new volume will be {fs}, {table}, {resolved ? formatCluster(resolved) : "default"} clusters, label {displayLabel(label.trim() && (fs === "FAT16" || fs === "FAT32") ? label.toUpperCase() : label)}.
          </p>
          <p className="mt-3 text-sm text-muted">
            {pro ? "Pro is on, so this does not spend a token." : `This spends ${tokenWord(cost)}. You have ${tokens}.`}
          </p>
          <div className="mt-5 flex gap-2">
            <button type="button" className="h-12 flex-1 rounded-xl bg-sunken" onClick={() => setConfirm(false)}>
              Cancel
            </button>
            {!pro && tokens < cost ? (
              <button
                type="button"
                className="h-12 flex-1 rounded-xl bg-fg font-medium text-bg"
                onClick={() => {
                  setConfirm(false);
                  ui.setTokenOpen(true);
                }}
              >
                Get tokens
              </button>
            ) : (
              <button type="button" className="h-12 flex-1 rounded-xl bg-danger font-medium text-bg" onClick={runFormat}>
                Format
              </button>
            )}
          </div>
        </Dialog>
      ) : null}

      {block ? (
        <Dialog title="Can't format yet" onClose={() => setBlock(null)}>
          <p>{block}</p>
          <PrimaryButton className="mt-5" onClick={() => setBlock(null)}>
            OK
          </PrimaryButton>
        </Dialog>
      ) : null}
    </div>
  );
}

function alignGuess(bytes: number): number {
  const mib = 1_048_576;
  return Math.max(mib, Math.floor(bytes / mib) * mib);
}

function OptionRow({ label, value, onClick }: { label: string; value: string; onClick: () => void }) {
  return (
    <div className="grid grid-cols-2 items-center gap-3 py-4">
      <span className="text-lg">{label}</span>
      <button type="button" onClick={onClick} className="flex items-center gap-2 text-left text-lg font-medium">
        <span>{value}</span>
        <ChevronDown className="size-4 shrink-0" aria-hidden="true" />
      </button>
    </div>
  );
}

function PickRow({
  label,
  hint,
  selected,
  onClick,
}: {
  label: string;
  hint?: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className="flex w-full items-start justify-between gap-3 border-b border-fg/10 py-3 text-left">
      <span>
        <span className="block text-lg">{label}</span>
        {hint ? <span className="mt-1 block text-sm text-muted">{hint}</span> : null}
      </span>
      <span className={cx("mt-1 size-3 shrink-0 rounded-full", selected ? "bg-fg" : "bg-sunken")} aria-hidden="true" />
    </button>
  );
}
