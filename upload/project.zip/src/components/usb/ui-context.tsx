import { createContext, useContext } from "react";
import type { ToolId } from "@/lib/usb/tools";

export type UiApi = {
  screen: ToolId;
  go: (id: ToolId) => void;
  setToolsOpen: (open: boolean) => void;
  setDeviceOpen: (open: boolean) => void;
  setTokenOpen: (open: boolean) => void;
  setHelpOpen: (open: boolean) => void;
  setBrowseOpen: (open: boolean) => void;
};

export const UiContext = createContext<UiApi | null>(null);

export function useUi(): UiApi {
  const value = useContext(UiContext);
  if (!value) throw new Error("USB Tools UI is not mounted");
  return value;
}
