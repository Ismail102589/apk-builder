import { useEffect, useState } from "react";
import { CircleHelp, Plus, Star, Zap } from "lucide-react";
import { displayLabel, driveSubtitle, formatBytes, usedBytes, type VFile } from "@/lib/usb/engine";
import { useConnected, useUsb } from "@/lib/usb/store";
import type { ToolId } from "@/lib/usb/tools";
import { UiContext, useUi } from "@/components/usb/ui-context";
import { FormatView } from "@/components/usb/format-view";
import { ToolBody, ToolsMenu } from "@/components/usb/tool-views";
import { Card, Dialog, LogoMark, PrimaryButton, ProgressBar, QuietButton, Sheet, cx } from "@/components/usb/widgets";

export function UsbToolsApp() {
  const [screen, setScreen] = useState<ToolId>("format");
  const [toolsOpen, setToolsOpen] = useState(false);
  const [deviceOpen, setDeviceOpen] = useState(false);
  const [tokenOpen, setTokenOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [browseOpen, setBrowseOpen] = useState(false);
  const job = useUsb((s) => s.job);
  const notice = useUsb((s) => s.notice);
  const toast = useUsb((s) => s.toast);
  const dismissNotice = useUsb((s) => s.dismissNotice);
  const clearToast = useUsb((s) => s.clearToast);
  const setProgress = useUsb((s) => s.setProgress);
  const finishJob = useUsb((s) => s.finishJob);
  const cancelJob = useUsb((s) => s.cancelJob);

  useEffect(() => {
    void useUsb.persist.rehydrate();
  }, []);

  const jobId = job?.id ?? null;

  useEffect(() => {
    if (!jobId) return;
    const current = useUsb.getState().job;
    if (!current || current.id !== jobId) return;
    const started = performance.now();
    const startP = current.progress;
    const duration = Math.max(1, current.duration * (1 - startP));
    const timer = window.setInterval(() => {
      const live = useUsb.getState().job;
      if (!live || live.id !== jobId) {
        window.clearInterval(timer);
        return;
      }
      const elapsed = performance.now() - started;
      const progress = Math.min(1, startP + elapsed / duration);
      if (progress >= 1) {
        window.clearInterval(timer);
        setProgress(1);
        finishJob();
      } else {
        setProgress(progress);
      }
    }, 80);
    return () => window.clearInterval(timer);
  }, [jobId, finishJob, setProgress]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => clearToast(), 1600);
    return () => window.clearTimeout(timer);
  }, [toast, clearToast]);

  const go = (id: ToolId) => {
    setScreen(id);
    setToolsOpen(false);
  };

  return (
    <UiContext.Provider
      value={{ screen, go, setToolsOpen, setDeviceOpen, setTokenOpen, setHelpOpen, setBrowseOpen }}
    >
      <div className="relative mx-auto flex h-dvh w-full max-w-md flex-col overflow-hidden bg-bg text-fg">
        <Header
          screen={screen}
          toolsOpen={toolsOpen}
          onTools={() => setToolsOpen((open) => !open)}
        />
        <main className="min-h-0 flex-1 overflow-y-auto px-4 pt-1 pb-10">
          {toolsOpen ? <ToolsMenu /> : screen === "format" ? <FormatView /> : <ToolBody screen={screen} />}
        </main>
        {toast ? (
          <div className="pointer-events-none absolute bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-fg px-4 py-2 text-sm text-bg">
            {toast}
          </div>
        ) : null}
        {deviceOpen ? (
          <DeviceSheet
            onClose={() => setDeviceOpen(false)}
            onBrowse={() => {
              setDeviceOpen(false);
              setBrowseOpen(true);
            }}
          />
        ) : null}
        {tokenOpen ? <TokenSheet onClose={() => setTokenOpen(false)} /> : null}
        {helpOpen ? <HelpSheet onClose={() => setHelpOpen(false)} /> : null}
        {browseOpen ? <BrowseSheet onClose={() => setBrowseOpen(false)} /> : null}
        {job ? (
          <Dialog title={job.title}>
            <p className="text-sm text-muted">{job.stage}</p>
            <div className="mt-4">
              <ProgressBar value={job.progress} />
            </div>
            <p className="mt-2 text-right text-sm text-muted tabular-nums">{Math.round(job.progress * 100)}%</p>
            {job.cancellable ? (
              <QuietButton className="mt-4 w-full" onClick={() => cancelJob()}>
                Stop
              </QuietButton>
            ) : (
              <p className="mt-4 text-sm text-muted">Keep this page open until the write finishes.</p>
            )}
          </Dialog>
        ) : null}
        {notice && !job ? (
          <Dialog title={notice.title} onClose={dismissNotice}>
            <p>{notice.body}</p>
            <div className="mt-5 flex gap-2">
              {notice.browse ? (
                <button
                  type="button"
                  className="h-12 flex-1 rounded-xl bg-sunken"
                  onClick={() => {
                    dismissNotice();
                    setBrowseOpen(true);
                  }}
                >
                  Browse files
                </button>
              ) : null}
              <button type="button" className="h-12 flex-1 rounded-xl bg-fg font-medium text-bg" onClick={dismissNotice}>
                OK
              </button>
            </div>
          </Dialog>
        ) : null}
      </div>
    </UiContext.Provider>
  );
}

function Header({ screen, onTools, toolsOpen }: { screen: ToolId; toolsOpen: boolean; onTools: () => void }) {
  const ui = useUi();
  const pinned = useUsb((s) => s.pinned);
  const togglePin = useUsb((s) => s.togglePin);
  const tokens = useUsb((s) => s.tokens);
  const pro = useUsb((s) => s.pro);
  const starred = !toolsOpen && pinned.includes(screen);
  return (
    <header className="flex items-center gap-1 px-3 pt-5 pb-3">
      <button type="button" className="grid size-11 shrink-0 place-items-center" aria-label="All tools" onClick={onTools}>
        <LogoMark className="size-9" />
      </button>
      <h1 className="truncate text-xl font-semibold tracking-wide">USB TOOLS</h1>
      <div className="ml-auto flex items-center">
        <button
          type="button"
          className="grid size-11 place-items-center"
          aria-label={starred ? "Unpin this tool" : "Pin this tool"}
          aria-pressed={starred}
          onClick={() => togglePin(screen)}
        >
          <Star className={cx("size-6", starred && "fill-current")} />
        </button>
        <button type="button" className="grid size-11 place-items-center" aria-label="Help" onClick={() => ui.setHelpOpen(true)}>
          <CircleHelp className="size-6" strokeWidth={1.75} />
        </button>
        <button
          type="button"
          className="flex h-11 items-center gap-1 pr-1 pl-1"
          aria-label={pro ? "Pro unlocked. Token shop" : `${tokens} tokens. Get more`}
          onClick={() => ui.setTokenOpen(true)}
        >
          <span className="grid size-7 place-items-center rounded-full border border-fg">
            <Zap className="size-3.5" aria-hidden="true" />
          </span>
          <span className="text-lg tabular-nums">{pro ? "∞" : tokens}</span>
          <Plus className="size-4" aria-hidden="true" />
        </button>
      </div>
    </header>
  );
}

function DeviceSheet({ onClose, onBrowse }: { onClose: () => void; onBrowse: () => void }) {
  const drives = useUsb((s) => s.drives);
  const connectedId = useUsb((s) => s.connectedId);
  const connect = useUsb((s) => s.connect);
  const eject = useUsb((s) => s.eject);
  const busy = useUsb((s) => !!s.job);
  const drive = drives.find((item) => item.id === connectedId) ?? null;
  return (
    <Sheet title="USB devices" onClose={onClose}>
      {busy ? <p className="mb-3 text-sm text-muted">Wait for the current operation before swapping drives.</p> : null}
      {drive ? (
        <div className="mb-4 rounded-2xl bg-bg px-4 py-3">
          <p>{drive.model} is connected</p>
          <p className="text-sm text-muted">{driveSubtitle(drive)}</p>
          <div className="mt-3 flex gap-2">
            <QuietButton
              onClick={() => {
                eject();
              }}
              disabled={busy}
            >
              Eject
            </QuietButton>
            <QuietButton onClick={onBrowse} disabled={drive.partitions.length === 0}>
              Browse files
            </QuietButton>
          </div>
        </div>
      ) : null}
      <ul className="flex flex-col">
        {drives.map((item) => {
          const on = item.id === connectedId;
          return (
            <li key={item.id} className="border-b border-fg/10 last:border-b-0">
              <button
                type="button"
                disabled={busy}
                className="flex w-full flex-col py-3 text-left disabled:text-muted"
                onClick={() => {
                  connect(item.id);
                  onClose();
                }}
              >
                <span className="text-base">
                  {item.model}
                  {on ? " · Connected" : ""}
                </span>
                <span className="text-sm text-muted">
                  {item.kind} · {item.speed} · {driveSubtitle(item)}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
      <p className="mt-4 text-sm leading-relaxed text-muted">
        Virtual OTG bench. A browser cannot format a physical USB stick, so every action here runs on these drives and stays on this device.
      </p>
    </Sheet>
  );
}

function TokenSheet({ onClose }: { onClose: () => void }) {
  const tokens = useUsb((s) => s.tokens);
  const pro = useUsb((s) => s.pro);
  const addTokens = useUsb((s) => s.addTokens);
  const unlockPro = useUsb((s) => s.unlockPro);
  const [until, setUntil] = useState<number | null>(null);
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!until) return;
    const timer = window.setInterval(() => {
      const time = Date.now();
      setNow(time);
      if (time >= until) {
        addTokens(1);
        setUntil(null);
      }
    }, 200);
    return () => window.clearInterval(timer);
  }, [until, addTokens]);

  const left = until ? Math.max(0, Math.ceil((until - now) / 1000)) : 0;
  return (
    <Sheet title="Tokens" onClose={() => (until ? undefined : onClose())}>
      <p className="text-lg tabular-nums">{pro ? "Pro · tokens are not required" : `${tokens} token${tokens === 1 ? "" : "s"}`}</p>
      <p className="mt-2 text-sm leading-relaxed text-muted">
        Format spends 1 token for FAT16 or FAT32, and 2 for the other file systems. The partition wizard spends up to 3. Everything else is free.
      </p>
      <div className="mt-4 rounded-2xl bg-bg px-4 py-4">
        <p className="text-sm text-muted">{until ? "Demo clip. No network ad is loaded." : "Watch a short demo clip for 1 token."}</p>
        {until ? (
          <div className="mt-3">
            <ProgressBar value={1 - left / 4} />
            <p className="mt-2 text-sm tabular-nums">{left}s</p>
          </div>
        ) : null}
        <PrimaryButton className="mt-3" disabled={!!until} onClick={() => setUntil(Date.now() + 4000)}>
          {until ? "Playing" : "Watch clip · +1"}
        </PrimaryButton>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2">
        {[10, 30, 80].map((pack) => (
          <button
            key={pack}
            type="button"
            className="h-16 rounded-2xl bg-bg text-sm"
            onClick={() => addTokens(pack)}
          >
            Add {pack}
            <span className="mt-1 block text-xs text-muted">Demo, free</span>
          </button>
        ))}
      </div>
      <PrimaryButton className="mt-4" disabled={pro} onClick={() => unlockPro()}>
        {pro ? "Pro is on" : "Unlock Pro"}
      </PrimaryButton>
      <p className="mt-3 text-sm text-muted">Pro and packs are a local demo. Nothing is charged.</p>
    </Sheet>
  );
}

function HelpSheet({ onClose }: { onClose: () => void }) {
  const resetBench = useUsb((s) => s.resetBench);
  return (
    <Sheet title="Help" onClose={onClose}>
      <div className="flex flex-col gap-4 text-sm leading-relaxed text-muted">
        <p className="text-fg">Tap the status card to plug in a bench drive. The gear opens every tool. The star pins the current tool to the top of that list.</p>
        <p>FAT32 is the compatible choice for consoles and TVs, with a 4 GB file limit. Use exFAT or NTFS for larger files. MBR is legacy; GPT is required past 2 TB.</p>
        <p>The lightning counter is your token balance. Earn one with the demo clip, or add a demo pack. Pro removes token costs.</p>
        <p>Bad Blocks reveals counterfeit capacity. Wipe offers NIST, DoD, Schneier, and Gutmann passes plus a certificate. Recover scans deleted files; Lost Partitions puts a dropped volume back.</p>
        <p>PS2 USB Utils splits images over 4 GB into USBExtreme parts and can format a stick as FAT32 / MBR for OPL.</p>
      </div>
      <QuietButton
        className="mt-5 w-full"
        onClick={() => {
          resetBench();
          onClose();
        }}
      >
        Reset bench drives
      </QuietButton>
    </Sheet>
  );
}

function BrowseSheet({ onClose }: { onClose: () => void }) {
  const drive = useConnected();
  const removeFile = useUsb((s) => s.removeFile);
  const renameLiveFile = useUsb((s) => s.renameLiveFile);
  const [rename, setRename] = useState<VFile | null>(null);
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [open, setOpen] = useState<VFile | null>(null);
  if (!drive) return null;
  return (
    <Sheet title="Files" onClose={onClose}>
      {drive.partitions.length === 0 ? <p className="text-sm text-muted">This stick has no volumes. Format it first.</p> : null}
      {drive.partitions.map((part) => {
        const live = part.files.filter((file) => !file.deleted);
        const gone = part.files.filter((file) => file.deleted).length;
        return (
          <section key={part.id} className="mb-4">
            <h3 className="text-sm text-muted">
              {displayLabel(part.label)} · {part.fs} · {formatBytes(Math.max(0, part.bytes - usedBytes(part)))} free
            </h3>
            {live.length === 0 ? <p className="mt-2 text-sm">Empty volume.</p> : null}
            <ul className="mt-2">
              {live.map((file) => (
                <li key={file.id} className="border-b border-fg/10 py-3">
                  <button type="button" className="w-full text-left" onClick={() => setOpen(file)}>
                    <span className="block break-all">{file.name}</span>
                    <span className="text-sm text-muted">
                      {formatBytes(file.bytes)}
                      {file.fragments > 1 ? ` · ${file.fragments} fragments` : ""}
                    </span>
                  </button>
                  <div className="mt-2 flex gap-2">
                    <QuietButton
                      onClick={() => {
                        setRename(file);
                        setName(file.name);
                        setError(null);
                      }}
                    >
                      Rename
                    </QuietButton>
                    <QuietButton onClick={() => removeFile(drive.id, file.id)}>Delete</QuietButton>
                  </div>
                </li>
              ))}
            </ul>
            {gone ? <p className="mt-2 text-sm text-muted">{gone} deleted · use Recover Files.</p> : null}
          </section>
        );
      })}
      {open ? (
        <Card className="mt-2">
          <p className="break-all">{open.name}</p>
          <p className="mt-2 text-sm leading-relaxed">{open.preview || "No text preview for this file."}</p>
          <QuietButton className="mt-3" onClick={() => setOpen(null)}>
            Close
          </QuietButton>
        </Card>
      ) : null}
      {rename ? (
        <Card className="mt-3">
          <label className="block text-sm text-muted">
            File name
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              className="mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg outline-none"
              aria-label="Rename file"
            />
          </label>
          {error ? <p className="mt-2 text-sm text-danger">{error}</p> : null}
          <div className="mt-3 flex gap-2">
            <QuietButton className="flex-1" onClick={() => setRename(null)}>Cancel</QuietButton>
            <PrimaryButton
              className="w-auto flex-1"
              onClick={() => {
                const err = renameLiveFile(drive.id, rename.id, name);
                if (err) setError(err);
                else setRename(null);
              }}
            >
              Save
            </PrimaryButton>
          </div>
        </Card>
      ) : null}
    </Sheet>
  );
}
