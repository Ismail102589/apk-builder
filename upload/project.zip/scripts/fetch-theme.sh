#!/bin/bash
# বিল্ডের সময় macOS-এর মতো WhiteSur থিম+আইকন বানিয়ে APK-তে ঢোকায়। ব্যর্থ হলে চুপচাপ বাদ।
OUT=app/src/main/assets/whitesur.tar.gz
[ -f "$OUT" ] && exit 0
WORK=$(mktemp -d)
mkdir -p "$WORK/out/themes" "$WORK/out/icons"
if ! command -v sassc >/dev/null 2>&1; then
  (sudo -n apt-get update -qq && sudo -n apt-get install -y -qq sassc libglib2.0-dev-bin libxml2-utils) >/dev/null 2>&1 \
    || { echo "sassc নেই, থিম বাদ"; exit 0; }
fi
(
  set -e
  cd "$WORK"
  curl -fsSL https://github.com/vinceliuice/WhiteSur-gtk-theme/archive/refs/heads/master.tar.gz | tar xz
  cd WhiteSur-gtk-theme-master
  ./install.sh -d "$WORK/out/themes" -c Light -t default || ./install.sh -d "$WORK/out/themes"
  cd "$WORK"
  curl -fsSL https://github.com/vinceliuice/WhiteSur-icon-theme/archive/refs/heads/master.tar.gz | tar xz
  cd WhiteSur-icon-theme-master
  ./install.sh -d "$WORK/out/icons" || true
) || { echo "থিম বানানো যায়নি, বাদ"; exit 0; }
if [ -d "$WORK/out/themes/WhiteSur-Light" ]; then
  tar czf "$OUT" -C "$WORK/out" . && echo "থিম তৈরি: $(du -h $OUT | cut -f1)"
else
  echo "WhiteSur-Light পাওয়া যায়নি, বাদ"
fi
exit 0
