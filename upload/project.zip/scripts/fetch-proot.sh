#!/bin/bash
# Termux-এর রিপো থেকে proot, loader ও libtalloc নামিয়ে jniLibs-এ বসায়
set -euo pipefail
OUT=app/src/main/jniLibs/arm64-v8a
WORK=$(mktemp -d)
mkdir -p "$OUT"

BASES=("https://packages.termux.dev/apt/termux-main" "https://packages-cf.termux.dev/apt/termux-main")
BASE=""
for b in "${BASES[@]}"; do
  if curl -fsSL --retry 3 "$b/dists/stable/main/binary-aarch64/Packages" -o "$WORK/Packages"; then BASE="$b"; break; fi
done
[ -n "$BASE" ] || { echo "ERROR: Termux repo পাওয়া যায়নি"; exit 1; }

get_filename() {
  awk -v pkg="$1" 'BEGIN{RS="";FS="\n"} {
    ok=0; fn="";
    for(i=1;i<=NF;i++){
      if($i=="Package: " pkg) ok=1;
      if($i ~ /^Filename: /) fn=substr($i,11);
    }
    if(ok){print fn; exit}
  }' "$WORK/Packages"
}

for pkg in proot libtalloc libandroid-shmem; do
  f=$(get_filename "$pkg")
  [ -n "$f" ] || { echo "ERROR: $pkg পাওয়া যায়নি"; exit 1; }
  echo "Downloading $pkg: $f"
  curl -fsSL --retry 3 "$BASE/$f" -o "$WORK/$pkg.deb"
  mkdir -p "$WORK/$pkg"
  (cd "$WORK/$pkg" && ar x ../$pkg.deb && tar xf data.tar.*)
done

PROOT=$(find "$WORK/proot" -type f -name proot | head -1)
LOADER=$(find "$WORK/proot" -type f -path '*proot*' -name loader | head -1)
TALLOC=$(find "$WORK/libtalloc" -type f -name 'libtalloc.so*' | head -1)
[ -n "$PROOT" ] && [ -n "$LOADER" ] && [ -n "$TALLOC" ] || { echo "ERROR: ফাইল খুঁজে পাওয়া যায়নি"; find "$WORK" -type f | head -50; exit 1; }

cp "$PROOT"  "$OUT/libproot.so"
cp "$LOADER" "$OUT/libproot-loader.so"
cp "$TALLOC" "$OUT/libtalloc.so"
SHMEM=$(find "$WORK/libandroid-shmem" -type f -name 'libandroid-shmem.so' | head -1)
[ -n "$SHMEM" ] || { echo "ERROR: libandroid-shmem.so পাওয়া যায়নি"; exit 1; }
cp "$SHMEM" "$OUT/libandroid-shmem.so"
echo "--- shmem NEEDED ---"; readelf -d "$OUT/libandroid-shmem.so" | grep NEEDED || true
chmod 755 "$OUT"/*.so

echo "--- proot NEEDED libs ---"
readelf -d "$OUT/libproot.so" | grep -E 'NEEDED|RUNPATH|RPATH' || true
ls -la "$OUT"
