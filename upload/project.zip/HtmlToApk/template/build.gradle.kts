plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.htmlapk.template"
    compileSdk = 34
    defaultConfig {
        // এই প্লেসহোল্ডার ApkBuilder.kt-এর PKG_PH-এর সাথে হুবহু মিলতে হবে (৩১ অক্ষর)
        applicationId = "com.htmlapp.gen0000000000000000"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
