# HTML to APK (অফলাইন)

## একবার বিল্ড করার নিয়ম (কম্পিউটারে)
1. Android Studio (Koala বা নতুন) দিয়ে এই ফোল্ডারটি Open করুন।
2. Gradle sync শেষ হলে Build > Build APK(s) এ `builder` মডিউল বেছে নিন
   (অথবা টার্মিনালে: `gradle :builder:assembleDebug`)।
   - `template` মডিউল নিজে নিজেই বিল্ড হয়ে `builder/src/main/assets/template.apk` হয়ে যায়।
3. `builder/build/outputs/apk/debug/builder-debug.apk` ফোনে ইনস্টল করুন।

এরপর অ্যাপটি সম্পূর্ণ অফলাইনে কাজ করবে।

## ব্যবহার
HTML (বা index.html সহ ZIP) বাছাই > নাম দিন > "APK বানান" > "ইনস্টল করুন"।

## সীমাবদ্ধতা
- অ্যাপ নামের সর্বোচ্চ ৬৪ অক্ষর। প্যাকেজ নাম নাম থেকে স্বয়ংক্রিয় তৈরি হয়।
- সব অ্যাপ একই বিল্ট-ইন কী দিয়ে সাইন হয় (প্রকাশের জন্য নিজের কী ব্যবহার করুন)।
- আইকন ডিফল্ট Android আইকন।
