package com.htmlapk.builder

import android.content.Context
import android.graphics.*
import java.io.ByteArrayOutputStream
import android.net.Uri
import com.android.apksig.ApkSigner
import java.io.File
import java.io.FilterOutputStream
import java.io.OutputStream
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ApkBuilder {
    // template/build.gradle.kts ও template AndroidManifest-এর সাথে মিলতে হবে
    private const val PKG_PH = "com.htmlapp.gen0000000000000000"
    private val NAME_PH = "APPNAME_" + "X".repeat(56)

    /** input = একটি .html অথবা index.html সহ .zip। ফলাফল: সাইন করা APK ফাইল। */
    fun build(ctx: Context, input: Uri, appName: String, out: File, iconUri: Uri? = null) {
        val icon = iconUri?.let { decodeIcon(ctx, it) }
        val userFiles = readUserFiles(ctx, input)
        val template = File(ctx.cacheDir, "template.apk")
        ctx.assets.open("template.apk").use { i -> template.outputStream().use { i.copyTo(it) } }

        val unsigned = File(ctx.cacheDir, "unsigned.apk")
        val name = appName.trim().ifEmpty { "My App" }
        val hash = MessageDigest.getInstance("SHA-256").digest(name.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(16)
        val pkg = "com.htmlapp.gen$hash"

        FileOutputCounting(unsigned.outputStream()).use { cnt ->
            ZipOutputStream(cnt).use { zos ->
                ZipFile(template).use { zf ->
                    for (e in zf.entries()) {
                        if (e.isDirectory || e.name.startsWith("META-INF/") || e.name.startsWith("assets/")) continue
                        var data = zf.getInputStream(e).readBytes()
                        if (e.name == "AndroidManifest.xml") {
                            check(patch(data, PKG_PH, pkg) && patch(data, NAME_PH, name)) { "Manifest প্যাচ করা যায়নি" }
                        }
                        if (icon != null && e.name.startsWith("res/mipmap") && e.name.endsWith("/ic_launcher.png"))
                            data = iconPng(icon, densityPx(e.name))
                        val stored = e.name == "resources.arsc" || e.name.endsWith(".so")
                        writeEntry(zos, cnt, e.name, data, stored)
                    }
                }
                for ((n, d) in userFiles) writeEntry(zos, cnt, n, d, false)
            }
        }
        sign(ctx, unsigned, out)
        unsigned.delete(); template.delete()
    }

    /** ছবি পড়ে মাঝখান থেকে বর্গাকার করে কেটে নেয়। */
    fun decodeIcon(ctx: Context, uri: Uri): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
        val o2 = BitmapFactory.Options().apply { inSampleSize = maxOf(1, minOf(o.outWidth, o.outHeight) / 512) }
        val bmp = ctx.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) }
            ?: error("ছবি পড়া যায়নি")
        val s = minOf(bmp.width, bmp.height)
        return Bitmap.createBitmap(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s)
    }

    private fun densityPx(n: String) = when {
        "xxxhdpi" in n -> 192; "xxhdpi" in n -> 144; "xhdpi" in n -> 96
        "hdpi" in n -> 72; "mdpi" in n -> 48; else -> 96
    }

    private fun iconPng(src: Bitmap, px: Int): ByteArray {
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val scaled = Bitmap.createScaledBitmap(src, px, px, true)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
        Canvas(out).drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), px * 0.22f, px * 0.22f, p)
        return ByteArrayOutputStream().also { out.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
    }

    private fun readUserFiles(ctx: Context, uri: Uri): Map<String, ByteArray> {
        val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val map = LinkedHashMap<String, ByteArray>()
        val isZip = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        if (!isZip) { map["assets/index.html"] = bytes; return map }
        val raw = LinkedHashMap<String, ByteArray>()
        ZipInputStream(bytes.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name.replace('\\', '/').trimStart('/')
                if (!e.isDirectory && !n.contains("..") && !n.startsWith("__MACOSX")) raw[n] = z.readBytes()
                e = z.nextEntry
            }
        }
        val idx = raw.keys.filter { it == "index.html" || it.endsWith("/index.html") }
            .minByOrNull { k -> k.count { it == '/' } } ?: error("ZIP-এর ভেতরে index.html নেই")
        val prefix = idx.removeSuffix("index.html")
        raw.forEach { (k, v) -> if (k.startsWith(prefix)) map["assets/" + k.removePrefix(prefix)] = v }
        return map
    }

    /** বাইনারি AndroidManifest-এর স্ট্রিং পুলে প্লেসহোল্ডার জায়গায় বদলে দেয় (UTF-16 ও UTF-8 দুটোই সাপোর্ট)। */
    private fun patch(d: ByteArray, ph: String, rep: String): Boolean {
        val ph16 = ph.toByteArray(Charsets.UTF_16LE)
        var i = indexOf(d, ph16)
        if (i >= 2) {
            val r = rep.take(ph.length)
            val b = r.toByteArray(Charsets.UTF_16LE)
            java.util.Arrays.fill(d, i, i + ph16.size, 0)
            System.arraycopy(b, 0, d, i, b.size)
            d[i - 2] = (r.length and 0xFF).toByte(); d[i - 1] = (r.length shr 8).toByte()
            return true
        }
        val ph8 = ph.toByteArray(Charsets.UTF_8)
        i = indexOf(d, ph8)
        if (i >= 2) {
            var r = rep
            while (r.toByteArray(Charsets.UTF_8).size > ph8.size || r.length > 127) r = r.dropLast(1)
            val b = r.toByteArray(Charsets.UTF_8)
            java.util.Arrays.fill(d, i, i + ph8.size, 0)
            System.arraycopy(b, 0, d, i, b.size)
            d[i - 2] = r.length.toByte(); d[i - 1] = b.size.toByte()
            return true
        }
        return false
    }

    private fun indexOf(d: ByteArray, p: ByteArray): Int {
        outer@ for (i in 0..d.size - p.size) {
            for (j in p.indices) if (d[i + j] != p[j]) continue@outer
            return i
        }
        return -1
    }

    private class FileOutputCounting(o: OutputStream) : FilterOutputStream(o) {
        var n = 0L
        override fun write(b: Int) { out.write(b); n++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); n += len }
    }

    /** stored এন্ট্রি ৪-বাইট অ্যালাইন করে (resources.arsc-এর জন্য বাধ্যতামূলক)। */
    private fun writeEntry(z: ZipOutputStream, c: FileOutputCounting, name: String, data: ByteArray, stored: Boolean) {
        val e = ZipEntry(name)
        if (stored) {
            e.method = ZipEntry.STORED
            e.size = data.size.toLong(); e.compressedSize = e.size
            e.crc = CRC32().also { it.update(data) }.value
            val base = c.n + 30 + name.toByteArray().size
            val pad = ((4 - base % 4) % 4).toInt()
            e.extra = ByteArray(4 + pad).also { it[0] = 0x35; it[1] = 0xD9.toByte(); it[2] = pad.toByte() }
        }
        z.putNextEntry(e); z.write(data); z.closeEntry()
    }

    private fun sign(ctx: Context, input: File, output: File) {
        val key = KeyFactory.getInstance("RSA").generatePrivate(
            PKCS8EncodedKeySpec(ctx.assets.open("key.pk8").use { it.readBytes() }))
        val cert = ctx.assets.open("cert.der").use {
            CertificateFactory.getInstance("X.509").generateCertificate(it) as X509Certificate
        }
        val cfg = ApkSigner.SignerConfig.Builder("htmlapk", key, listOf(cert)).build()
        output.delete()
        ApkSigner.Builder(listOf(cfg)).setInputApk(input).setOutputApk(output)
            .setMinSdkVersion(24).setV1SigningEnabled(true).setV2SigningEnabled(true)
            .setV3SigningEnabled(true).build().sign()
    }
}
