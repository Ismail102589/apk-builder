package com.htmlapk.builder

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {
    private var picked: Uri? = null
    private var built: File? = null
    private lateinit var nameEt: EditText
    private lateinit var fileTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var buildBtn: Button
    private lateinit var installBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(p, p * 2, p, p) }
        fun tv(t: String, size: Float = 16f) = TextView(this).apply { text = t; textSize = size; setPadding(0, p / 2, 0, p / 2) }

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.logo); adjustViewBounds = true
        })
        root.addView(tv("HTML থেকে APK", 26f))
        root.addView(tv("একটি .html ফাইল অথবা index.html সহ .zip ফোল্ডার বাছাই করুন। ইন্টারনেট লাগবে না।", 14f))
        nameEt = EditText(this).apply { hint = "অ্যাপের নাম"; setSingleLine() }
        root.addView(nameEt)
        root.addView(Button(this).apply { text = "HTML / ZIP বাছাই করুন"; setOnClickListener { pick() } })
        fileTv = tv("কোনো ফাইল বাছাই হয়নি", 14f); root.addView(fileTv)
        buildBtn = Button(this).apply { text = "APK বানান"; isEnabled = false; setOnClickListener { build() } }
        root.addView(buildBtn)
        statusTv = tv("", 14f); root.addView(statusTv)
        installBtn = Button(this).apply { text = "ইনস্টল করুন"; visibility = View.GONE; setOnClickListener { install() } }
        root.addView(installBtn)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/html", "application/zip", "application/x-zip-compressed"))
        }
        startActivityForResult(i, 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK && data?.data != null) {
            picked = data.data
            val n = contentResolver.query(picked!!, null, null, null, null)?.use {
                if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow("_display_name")) else null
            } ?: "ফাইল"
            fileTv.text = "বাছাই করা: $n"
            if (nameEt.text.isBlank()) nameEt.setText(n.substringBeforeLast('.'))
            buildBtn.isEnabled = true
        }
    }

    private fun build() {
        val uri = picked ?: return
        val name = nameEt.text.toString()
        buildBtn.isEnabled = false; installBtn.visibility = View.GONE
        statusTv.text = "বানানো হচ্ছে..."
        Thread {
            try {
                val out = File(cacheDir, "out.apk")
                ApkBuilder.build(this, uri, name, out)
                val safe = name.trim().replace(Regex("[^\\p{L}\\p{N}_-]"), "_").ifEmpty { "app" }
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, "$safe.apk")
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                }
                val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { o -> out.inputStream().use { it.copyTo(o) } }
                built = out
                runOnUiThread {
                    statusTv.text = "সম্পন্ন! Downloads ফোল্ডারে $safe.apk সেভ হয়েছে।"
                    installBtn.visibility = View.VISIBLE; buildBtn.isEnabled = true
                }
            } catch (e: Throwable) {
                runOnUiThread { statusTv.text = "ত্রুটি: ${e.message}"; buildBtn.isEnabled = true }
            }
        }.start()
    }

    private fun install() {
        val f = built ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "এই অ্যাপকে ইনস্টলের অনুমতি দিন, তারপর আবার চাপুন", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }
}
