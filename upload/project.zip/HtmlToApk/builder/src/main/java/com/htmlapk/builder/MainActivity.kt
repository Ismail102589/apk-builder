package com.htmlapk.builder

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {
    private var picked: Uri? = null
    private var iconUri: Uri? = null
    private var built: File? = null
    private lateinit var nameEt: EditText
    private lateinit var fileTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var buildBtn: TextView
    private lateinit var installBtn: TextView
    private lateinit var iconPrev: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var resultCard: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun c(hex: Long) = hex.toInt()

    // ---------- Glass UI helpers ----------
    private fun glass(r: Int = 24, strong: Boolean = false) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(if (strong) 0x4DFFFFFF else 0x2EFFFFFF, 0x0DFFFFFF)
    ).apply { cornerRadius = dp(r).toFloat(); setStroke(dp(1), 0x66FFFFFF) }

    private fun roundClip(v: View, r: Int) {
        v.clipToOutline = true
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, o: Outline) = o.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
        }
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(18))
        background = glass()
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
    }

    private fun label(t: String, size: Float = 15f, alpha: Int = 255, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.argb(alpha, 255, 255, 255))
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(2), 0, dp(6))
    }

    private fun button(t: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 16f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setPadding(dp(20), dp(15), dp(20), dp(15))
        background = if (primary) GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(c(0xFF22D3EE), c(0xFF8B5CF6), c(0xFFEC4899))
        ).apply { cornerRadius = dp(28).toFloat() } else glass(28, true)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(.96f).scaleY(.96f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
        setOnClickListener { onClick() }
    }

    private fun setEnabledLook(v: View, on: Boolean) { v.isEnabled = on; v.alpha = if (on) 1f else .4f }

    private fun blob(color: Long, size: Int, gravity: Int, mx: Int, my: Int, dx: Float, dy: Float, ms: Long): View {
        val v = View(this)
        v.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = dp(size) / 2f
            colors = intArrayOf(c(color), c(color) and 0x00FFFFFF)
        }
        v.layoutParams = FrameLayout.LayoutParams(dp(size), dp(size), gravity).apply {
            setMargins(dp(mx), dp(my), dp(mx), dp(my))
        }
        for ((prop, d) in listOf("translationX" to dx, "translationY" to dy)) {
            ObjectAnimator.ofFloat(v, prop, -dp(d.toInt()).toFloat(), dp(d.toInt()).toFloat()).apply {
                duration = ms; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator(); start()
            }
        }
        return v
    }

    // ---------- UI ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(c(0xFF0B1026), c(0xFF1B1346), c(0xFF0F2A4A))))
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        val root = FrameLayout(this)
        root.addView(blob(0xAA22D3EE, 320, Gravity.TOP or Gravity.START, -60, 40, 40f, 60f, 7000))
        root.addView(blob(0xAAEC4899, 300, Gravity.CENTER_VERTICAL or Gravity.END, -90, 0, 50f, 40f, 9000))
        root.addView(blob(0xAA8B5CF6, 340, Gravity.BOTTOM or Gravity.START, -80, 20, 60f, 50f, 8000))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(14), dp(18), dp(28)) }

        // Header
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo); adjustViewBounds = true
            setBackgroundColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        roundClip(logo, 24)
        col.addView(logo, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        col.addView(label("HTML to APK", 30f, 255, true))
        col.addView(label("আপনার HTML ফাইলকে মুহূর্তে Android অ্যাপে রূপান্তর করুন, সম্পূর্ণ অফলাইনে।", 14f, 190))

        // Card 1: name + icon
        val c1 = card()
        c1.addView(label("অ্যাপের তথ্য", 13f, 170, true))
        nameEt = EditText(this).apply {
            hint = "অ্যাপের নাম"; setHintTextColor(0x99FFFFFF.toInt()); setTextColor(Color.WHITE)
            textSize = 17f; setSingleLine(); inputType = InputType.TYPE_CLASS_TEXT
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(0x22FFFFFF); setStroke(dp(1), 0x44FFFFFF)
            }
            setPadding(dp(16), dp(13), dp(16), dp(13))
        }
        c1.addView(nameEt, LinearLayout.LayoutParams(-1, -2))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        iconPrev = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher); scaleType = ImageView.ScaleType.CENTER_CROP
        }
        roundClip(iconPrev, 18)
        row.addView(iconPrev, LinearLayout.LayoutParams(dp(68), dp(68)).apply { rightMargin = dp(14) })
        val iconBtn = button("অ্যাপের আইকন বাছাই", false) { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }, 2) }
        row.addView(iconBtn, LinearLayout.LayoutParams(0, -2, 1f))
        c1.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        col.addView(c1)

        // Card 2: file
        val c2 = card()
        c2.addView(label("ওয়েব ফাইল", 13f, 170, true))
        c2.addView(button("HTML / ZIP বাছাই করুন", false) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/html", "application/zip", "application/x-zip-compressed"))
            }, 1)
        })
        fileTv = label("কোনো ফাইল বাছাই হয়নি", 13f, 160).apply { setPadding(dp(4), dp(10), 0, 0) }
        c2.addView(fileTv)
        col.addView(c2)

        buildBtn = button("✨ APK বানান", true) { build() }
        setEnabledLook(buildBtn, false)
        col.addView(buildBtn)

        progress = ProgressBar(this).apply {
            isIndeterminate = true; indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            visibility = View.GONE
        }
        col.addView(progress, LinearLayout.LayoutParams(dp(36), dp(36)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(14) })

        resultCard = card().apply { visibility = View.GONE; (layoutParams as LinearLayout.LayoutParams).topMargin = dp(16) }
        statusTv = label("", 15f, 230)
        resultCard.addView(statusTv)
        installBtn = button("ইনস্টল করুন", true) { install() }
        installBtn.visibility = View.GONE
        resultCard.addView(installBtn)
        col.addView(resultCard)

        root.addView(ScrollView(this).apply { addView(col); isFillViewport = true })
        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val u = data?.data
        if (resultCode != RESULT_OK || u == null) return
        if (requestCode == 1) {
            picked = u
            val n = contentResolver.query(u, null, null, null, null)?.use {
                if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow("_display_name")) else null
            } ?: "ফাইল"
            fileTv.text = "✓ $n"
            if (nameEt.text.isBlank()) nameEt.setText(n.substringBeforeLast('.'))
            setEnabledLook(buildBtn, true)
        } else if (requestCode == 2) {
            try { iconPrev.setImageBitmap(ApkBuilder.decodeIcon(this, u)); iconUri = u }
            catch (e: Throwable) { Toast.makeText(this, "ছবি পড়া যায়নি", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun showResult(msg: String, ok: Boolean) {
        progress.visibility = View.GONE
        resultCard.visibility = View.VISIBLE
        statusTv.text = msg
        installBtn.visibility = if (ok) View.VISIBLE else View.GONE
        setEnabledLook(buildBtn, true)
    }

    private fun build() {
        val uri = picked ?: return
        val name = nameEt.text.toString()
        setEnabledLook(buildBtn, false); resultCard.visibility = View.GONE; progress.visibility = View.VISIBLE
        Thread {
            try {
                val out = File(cacheDir, "out.apk")
                ApkBuilder.build(this, uri, name, out, iconUri)
                val safe = name.trim().replace(Regex("[^\\p{L}\\p{N}_-]"), "_").ifEmpty { "app" }
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, "$safe.apk")
                    put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                }
                val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                contentResolver.openOutputStream(u)!!.use { o -> out.inputStream().use { it.copyTo(o) } }
                built = out
                runOnUiThread { showResult("🎉 সম্পন্ন!\nDownloads ফোল্ডারে $safe.apk সেভ হয়েছে।", true) }
            } catch (e: Throwable) {
                runOnUiThread { showResult("ত্রুটি: ${e.message}", false) }
            }
        }.start()
    }

    private fun install() {
        val f = built ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, "এই অ্যাপকে ইনস্টলের অনুমতি দিন, তারপর আবার চাপুন", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }
}
