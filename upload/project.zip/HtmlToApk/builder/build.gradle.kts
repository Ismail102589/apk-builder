plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.htmlapk.builder"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.htmlapk.builder"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += setOf("META-INF/*.kotlin_module") }
}
dependencies {
    implementation("com.android.tools.build:apksig:8.5.2")
    implementation("androidx.core:core-ktx:1.13.1")
}

// template মডিউল বিল্ড করে তার APK এই অ্যাপের assets-এ কপি করে
val copyTemplate by tasks.registering(Copy::class) {
    dependsOn(":template:assembleRelease")
    from(project(":template").layout.buildDirectory.dir("outputs/apk/release")) {
        include("*.apk")
        rename { "template.apk" }
    }
    into(layout.projectDirectory.dir("src/main/assets"))
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(copyTemplate) }
