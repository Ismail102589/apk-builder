import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as CircleHelp, a as RotateCcw, b as Archive, c as Layers, d as Grid3x3, f as Gauge, g as Columns2, h as Eraser, i as Search, l as Info, m as FileSearch, o as Repeat, p as Gamepad2, r as Star, s as Plus, t as Zap, u as HardDrive, v as ChevronLeft, y as ChevronDown } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BCwoDCCc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var MIB = 1048576;
var FILESYSTEMS = [
	{
		id: "FAT16",
		hint: "Legacy devices · 4 GB volume limit"
	},
	{
		id: "FAT32",
		hint: "Consoles, TVs, cars · 4 GB file limit"
	},
	{
		id: "exFAT",
		hint: "Large files · Windows, macOS, many TVs"
	},
	{
		id: "NTFS",
		hint: "Windows · large files and permissions"
	},
	{
		id: "EXT2",
		hint: "Linux, no journal"
	},
	{
		id: "EXT3",
		hint: "Linux with a journal"
	},
	{
		id: "EXT4",
		hint: "Modern Linux default"
	}
];
var WIPE_METHODS = [
	{
		id: "nist",
		name: "NIST 800-88 Clear",
		passes: 1,
		detail: "One pass of zeros."
	},
	{
		id: "dod",
		name: "DoD 5220.22-M",
		passes: 3,
		detail: "Classic three-pass overwrite."
	},
	{
		id: "schneier",
		name: "Schneier",
		passes: 7,
		detail: "Seven-pass pattern."
	},
	{
		id: "gutmann",
		name: "Gutmann",
		passes: 35,
		detail: "Thirty-five passes. Slowest."
	}
];
var LABEL_LIMIT = {
	FAT16: 11,
	FAT32: 11,
	exFAT: 15,
	NTFS: 32,
	EXT2: 16,
	EXT3: 16,
	EXT4: 16
};
var RECOVER_RANK = {
	quick: 0,
	smart: 1,
	deep: 2,
	raw: 3
};
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}
function hash(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function formatBytes(n) {
	const sign = n < 0 ? "-" : "";
	let v = Math.abs(n);
	const units = [
		"B",
		"KB",
		"MB",
		"GB",
		"TB"
	];
	let u = 0;
	while (v >= 1e3 && u < units.length - 1) {
		v /= 1e3;
		u += 1;
	}
	const digits = u === 0 || v >= 100 ? 0 : v >= 10 ? 1 : 2;
	return `${sign}${v.toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d)0$/, "$1")} ${units[u]}`;
}
function formatCluster(n) {
	if (n % 1024 === 0 && n >= 1024) return `${n / 1024} KB`;
	return `${n} bytes`;
}
function formatWhen(at) {
	return new Date(at).toLocaleString(void 0, {
		month: "short",
		day: "numeric",
		hour: "numeric",
		minute: "2-digit"
	});
}
function tokenWord(n) {
	return `${n} token${n === 1 ? "" : "s"}`;
}
function labelIssue(raw, fs) {
	if (!raw) return null;
	if (raw.length > LABEL_LIMIT[fs]) return `${fs} labels stop at ${LABEL_LIMIT[fs]} characters.`;
	if ((fs === "FAT16" || fs === "FAT32") && !/^[A-Za-z0-9 _-]+$/.test(raw)) return "FAT labels can only use letters, numbers, space, _ and -.";
	if (/[\\/:*?"<>|]/.test(raw)) return "Label cannot include \\ / : * ? \" < > |.";
	return null;
}
function sanitizeLabel(raw, fs) {
	const trimmed = raw.trim().slice(0, LABEL_LIMIT[fs]);
	if (fs === "FAT16" || fs === "FAT32") return trimmed.toUpperCase();
	return trimmed;
}
function fsIssue(fs, bytes) {
	if (fs === "FAT16" && bytes > 4e9) return "FAT16 only supports volumes up to 4 GB.";
	if (fs === "FAT32" && bytes > 2199023255552) return "FAT32 stops at 2 TB here. Use exFAT or NTFS.";
	if (fs === "FAT32" && bytes < 32e6) return "FAT32 needs at least 32 MB.";
	return null;
}
function tableIssue(table, bytes) {
	if (table === "MBR" && bytes > 2199023255552) return "MBR cannot address more than 2 TB. Choose GPT.";
	return null;
}
function formatCost(fs) {
	return fs === "FAT16" || fs === "FAT32" ? 1 : 2;
}
function clusterChoices(fs) {
	if (fs === "EXT2" || fs === "EXT3" || fs === "EXT4") return [
		"default",
		"1024",
		"2048",
		"4096"
	];
	if (fs === "exFAT") return [
		"default",
		"4096",
		"8192",
		"16384",
		"32768",
		"65536"
	];
	return [
		"default",
		"512",
		"1024",
		"2048",
		"4096",
		"8192",
		"16384",
		"32768",
		"65536"
	];
}
function clusterLabel(c) {
	if (c === "default") return "Default Value";
	return formatCluster(Number(c));
}
function resolveCluster(fs, choice, bytes) {
	if (choice !== "default") return Number(choice);
	if (fs === "FAT16") {
		if (bytes > 2e9) return 65536;
		if (bytes > 1e9) return 32768;
		return 16384;
	}
	if (fs === "FAT32") {
		if (bytes > 32e9) return 32768;
		if (bytes > 16e9) return 16384;
		if (bytes > 8e9) return 8192;
		return 4096;
	}
	if (fs === "exFAT") return bytes > 32e9 ? 131072 : 32768;
	if (fs === "EXT2" || fs === "EXT3" || fs === "EXT4") return 4096;
	return 4096;
}
function alignDown(n) {
	return Math.max(MIB, Math.floor(n / MIB) * MIB);
}
function usedBytes(p) {
	let n = 0;
	for (const file of p.files) if (!file.deleted) n += file.bytes;
	return n;
}
function allocatedBytes(drive) {
	return drive.partitions.reduce((s, p) => s + p.bytes, 0);
}
function unallocated(drive) {
	return Math.max(0, drive.real - allocatedBytes(drive));
}
function liveFileCount(drive) {
	return drive.partitions.reduce((s, p) => s + p.files.filter((f) => !f.deleted).length, 0);
}
function volumeFree(drive) {
	return drive.partitions.reduce((s, p) => s + Math.max(0, p.bytes - usedBytes(p)), 0);
}
function isCounterfeit(drive) {
	return drive.advertised > drive.real * 1.15;
}
function maxPartitions(table) {
	return table === "MBR" ? 4 : 8;
}
function displayLabel(label) {
	return label.trim() ? label : "NO NAME";
}
function driveSubtitle(drive) {
	if (!drive.table || drive.partitions.length === 0) {
		const base = `${formatBytes(drive.advertised)} · Not formatted`;
		if (drive.verifiedReal && isCounterfeit(drive)) return `${formatBytes(drive.advertised)} advertised · real ${formatBytes(drive.real)} · Not formatted`;
		return base;
	}
	const vol = drive.partitions.reduce((s, p) => s + p.bytes, 0);
	const fs = drive.partitions.length === 1 ? drive.partitions[0].fs : `${drive.partitions.length} volumes`;
	return `${formatBytes(vol)} · ${fs} · ${formatBytes(volumeFree(drive))} free`;
}
function file(id, name, bytes, kind, extra = {}) {
	return {
		id,
		name,
		bytes,
		kind,
		deleted: false,
		recover: "quick",
		fragments: 1,
		preview: "",
		...extra
	};
}
function part(id, label, fs, bytes, cluster, files) {
	return {
		id,
		label,
		fs,
		bytes: alignDown(bytes),
		cluster,
		files
	};
}
function seedDrives() {
	return [
		{
			id: "drv-sandisk",
			model: "SanDisk Ultra",
			vendor: "SanDisk",
			product: "Ultra USB 3.0",
			vid: "0781",
			pid: "5581",
			serial: "SD-4C530001",
			advertised: 32e9,
			real: 32e9,
			blockSize: 512,
			speed: "USB 3.0",
			kind: "Flash",
			readMBs: 130,
			writeMBs: 42,
			badBlockRatio: 0,
			verifiedReal: false,
			table: "MBR",
			partitions: [part("p-sandisk", "SANDISK", "FAT32", 32e9, 16384, [
				file("f-img-2401", "IMG_2401.jpg", 32e5, "image"),
				file("f-img-2402", "IMG_2402.jpg", 28e5, "image"),
				file("f-vid-100", "VID_100.mp4", 74e7, "video", { fragments: 4 }),
				file("f-resume", "Resume.pdf", 22e4, "doc", { preview: "J. Rahman — embedded engineer. Ships, Dhaka. Available from December." }),
				file("f-img-2390", "IMG_2390.jpg", 3e6, "image", {
					deleted: true,
					recover: "quick"
				}),
				file("f-notes", "notes.txt", 4200, "doc", {
					deleted: true,
					recover: "smart",
					preview: "Router: living-room · guest password rotates on Fridays."
				}),
				file("f-oldzip", "old-trip.zip", 88e6, "archive", {
					deleted: true,
					recover: "deep"
				})
			])],
			lost: [],
			scrap: [],
			carved: []
		},
		{
			id: "drv-kingston",
			model: "Kingston DT",
			vendor: "Kingston",
			product: "DataTraveler",
			vid: "0951",
			pid: "1666",
			serial: "KN-80A2",
			advertised: 64e9,
			real: 64e9,
			blockSize: 512,
			speed: "USB 3.2",
			kind: "Flash",
			readMBs: 180,
			writeMBs: 70,
			badBlockRatio: .012,
			verifiedReal: false,
			table: "MBR",
			partitions: [part("p-king", "KINGSTON", "exFAT", 64e9, 32768, [
				file("f-movie", "lecture.mkv", 34e8, "video", { fragments: 28 }),
				file("f-photos", "photos.zip", 8e8, "archive", { fragments: 12 }),
				file("f-song", "demo.mp3", 8e6, "audio", { fragments: 3 })
			])],
			lost: [],
			scrap: [],
			carved: []
		},
		{
			id: "drv-fake",
			model: "Generic 128G",
			vendor: "Generic",
			product: "USB DISK",
			vid: "FFFF",
			pid: "0001",
			serial: "FAKE-128-08",
			advertised: 128e9,
			real: 8e9,
			blockSize: 512,
			speed: "USB 2.0",
			kind: "Flash",
			readMBs: 18,
			writeMBs: 8,
			badBlockRatio: .08,
			verifiedReal: false,
			table: "MBR",
			partitions: [part("p-fake", "USB", "FAT32", 8e9, 4096, [file("f-readme", "README.txt", 1200, "doc", { preview: "Thanks for your purchase. Capacity is tested at the factory." })])],
			lost: [],
			scrap: [],
			carved: [file("f-carve", "DSC_0044.jpg", 24e5, "image", {
				deleted: true,
				recover: "raw"
			})]
		},
		{
			id: "drv-t7",
			model: "Samsung T7",
			vendor: "Samsung",
			product: "PSSD T7",
			vid: "04E8",
			pid: "61F5",
			serial: "T7-S6RX",
			advertised: 0xe8d4a51000,
			real: 0xe8d4a51000,
			blockSize: 4096,
			speed: "USB 3.2",
			kind: "SSD",
			readMBs: 920,
			writeMBs: 860,
			badBlockRatio: 0,
			verifiedReal: false,
			table: "GPT",
			partitions: [part("p-t7", "T7", "NTFS", 0xe8d4a51000, 4096, [file("f-projects", "Projects.zip", 12e9, "archive"), file("f-iso", "installer.iso", 54e8, "iso", { fragments: 2 })])],
			lost: [],
			scrap: [],
			carved: []
		},
		{
			id: "drv-seagate",
			model: "Seagate Expansion",
			vendor: "Seagate",
			product: "Expansion HDD",
			vid: "0BC2",
			pid: "231A",
			serial: "SG-NA8B",
			advertised: 4e12,
			real: 4e12,
			blockSize: 4096,
			speed: "USB 3.0",
			kind: "HDD",
			readMBs: 150,
			writeMBs: 140,
			badBlockRatio: 0,
			verifiedReal: false,
			table: "GPT",
			partitions: [part("p-sea", "ARCHIVE", "NTFS", 4e12, 4096, [file("f-vhdx", "Archive-2024.vhdx", 12e11, "archive", { fragments: 6 }), file("f-rawvid", "wedding.mov", 18e9, "video", {
				deleted: true,
				recover: "raw"
			})])],
			lost: [],
			scrap: [],
			carved: []
		},
		{
			id: "drv-sony",
			model: "Sony MicroVault",
			vendor: "Sony",
			product: "USB FLASH",
			vid: "054C",
			pid: "05BA",
			serial: "SY-MV16",
			advertised: 16e9,
			real: 16e9,
			blockSize: 512,
			speed: "USB 2.0",
			kind: "Flash",
			readMBs: 22,
			writeMBs: 9,
			badBlockRatio: 0,
			verifiedReal: false,
			table: null,
			partitions: [],
			lost: [part("p-sony-lost", "DCIM", "FAT32", 16e9, 8192, [
				file("f-sony-1", "DSC_0102.jpg", 41e5, "image", { recover: "deep" }),
				file("f-sony-2", "DSC_0103.jpg", 38e5, "image", { recover: "deep" }),
				file("f-sony-3", "clip.mp4", 22e7, "video", { recover: "deep" })
			])],
			scrap: [],
			carved: []
		},
		{
			id: "drv-ps2",
			model: "PS2 OPL Stick",
			vendor: "SanDisk",
			product: "Cruzer Blade",
			vid: "0781",
			pid: "5567",
			serial: "PS2-OPL-01",
			advertised: 32e9,
			real: 32e9,
			blockSize: 512,
			speed: "USB 2.0",
			kind: "Flash",
			readMBs: 28,
			writeMBs: 10,
			badBlockRatio: 0,
			verifiedReal: false,
			table: "MBR",
			partitions: [part("p-ps2", "OPL", "FAT32", 32e9, 32768, [file("f-gow", "God of War.iso", 45e8, "iso", { fragments: 6 }), file("f-ico", "ICO.iso", 12e8, "iso")])],
			lost: [],
			scrap: [],
			carved: []
		}
	];
}
function applyFormat(drive, opts) {
	const bytes = alignDown(drive.real);
	const cluster = resolveCluster(opts.fs, opts.cluster, bytes);
	const label = sanitizeLabel(opts.label, opts.fs);
	const next = {
		...drive,
		table: opts.table,
		lost: [],
		scrap: [],
		carved: [],
		partitions: [{
			id: uid("part"),
			label,
			fs: opts.fs,
			bytes,
			cluster,
			files: []
		}]
	};
	const lines = [`${drive.model} is now ${opts.fs} · ${opts.table} · ${formatCluster(cluster)} clusters.`, `Volume label: ${displayLabel(label)}. Writable size ${formatBytes(bytes)}.`];
	if (isCounterfeit(drive)) lines.push(`The case says ${formatBytes(drive.advertised)}. The writable size is ${formatBytes(drive.real)} — treat it as counterfeit until a bad-block test says otherwise.`);
	if (opts.fs === "FAT16" || opts.fs === "FAT32") lines.push("Files larger than 4 GB will not fit on this file system.");
	return {
		drive: next,
		summary: lines.join(" ")
	};
}
function badMap(drive, cells = 64) {
	return Array.from({ length: cells }, (_, i) => {
		return hash(`${drive.serial}:${i}`) % 1e4 < drive.badBlockRatio * 1e4;
	});
}
function healthChecks(drive) {
	const checks = [];
	checks.push(drive.table ? {
		tone: "ok",
		label: `${drive.table} partition table is present`
	} : {
		tone: "bad",
		label: "No partition table — the stick looks unallocated or corrupt"
	});
	const sum = allocatedBytes(drive);
	checks.push(sum <= drive.real ? {
		tone: "ok",
		label: "Partitions fit in the writable capacity"
	} : {
		tone: "bad",
		label: "Partitions claim more space than the drive can hold"
	});
	const aligned = drive.partitions.every((p) => p.bytes % MIB === 0);
	checks.push(aligned ? {
		tone: "ok",
		label: "Every partition is 1 MB aligned"
	} : {
		tone: "warn",
		label: "A partition is not 1 MB aligned"
	});
	if (drive.table) {
		const limit = maxPartitions(drive.table);
		checks.push(drive.partitions.length <= limit ? {
			tone: "ok",
			label: `${drive.partitions.length} of ${limit} partition slots used`
		} : {
			tone: "bad",
			label: `${drive.table} cannot hold ${drive.partitions.length} partitions`
		});
	}
	if (drive.table === "MBR") checks.push(drive.real > 2199023255552 ? {
		tone: "bad",
		label: "MBR cannot address a disk larger than 2 TB"
	} : {
		tone: "ok",
		label: "Disk size is inside the MBR limit"
	});
	if (!drive.verifiedReal) checks.push({
		tone: "warn",
		label: "Capacity is unverified — run Bad Blocks"
	});
	else if (isCounterfeit(drive)) checks.push({
		tone: "bad",
		label: `Counterfeit capacity: label ${formatBytes(drive.advertised)}, real ${formatBytes(drive.real)}`
	});
	else checks.push({
		tone: "ok",
		label: "Advertised capacity matches the writable size"
	});
	const bad = badMap(drive).filter(Boolean).length;
	if (drive.verifiedReal && bad > 0) checks.push({
		tone: "warn",
		label: `${bad} bad blocks in the last surface sample`
	});
	return checks;
}
function fragStats(drive) {
	let supported = false;
	let files = 0;
	let extra = 0;
	for (const p of drive.partitions) {
		if (p.fs !== "FAT32" && p.fs !== "exFAT") continue;
		supported = true;
		for (const f of p.files) {
			if (f.deleted) continue;
			files += 1;
			extra += Math.max(0, f.fragments - 1);
		}
	}
	return {
		supported,
		files,
		extra
	};
}
function applyDefrag(drive) {
	let fixed = 0;
	const partitions = drive.partitions.map((p) => {
		if (p.fs !== "FAT32" && p.fs !== "exFAT") return p;
		return {
			...p,
			files: p.files.map((f) => {
				if (!f.deleted && f.fragments > 1) {
					fixed += 1;
					return {
						...f,
						fragments: 1
					};
				}
				return f;
			})
		};
	});
	return {
		drive: {
			...drive,
			partitions
		},
		fixed
	};
}
function wipeFails(drive, verify) {
	if (verify === "off") return false;
	if (verify === "sample") return drive.badBlockRatio >= .05;
	return drive.badBlockRatio > 0;
}
function applyWipe(drive, opts) {
	const verified = !wipeFails(drive, opts.verify);
	const cert = {
		model: drive.model,
		serial: drive.serial,
		method: opts.method,
		passes: opts.passes,
		verify: opts.verify,
		verified,
		bytes: drive.real
	};
	return {
		drive: {
			...drive,
			table: null,
			partitions: [],
			lost: [],
			scrap: [],
			carved: []
		},
		cert
	};
}
function jitter(serial, salt, base) {
	const factor = .92 + hash(`${serial}:${salt}`) % 1e3 / 1e3 * .16;
	return Math.round(base * factor * 10) / 10;
}
function planBench(drive, write) {
	return {
		model: drive.model,
		serial: drive.serial,
		seqRead: jitter(drive.serial, "sr", drive.readMBs),
		seqWrite: write ? jitter(drive.serial, "sw", drive.writeMBs) : null,
		randRead: Math.round(jitter(drive.serial, "rr", drive.readMBs * 28)),
		randWrite: write ? Math.round(jitter(drive.serial, "rw", drive.writeMBs * 22)) : null
	};
}
function collectRecoverable(drive, mode) {
	const max = RECOVER_RANK[mode];
	const allow = (level) => RECOVER_RANK[level] <= max;
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	const add = (f) => {
		if (seen.has(f.id)) return;
		seen.add(f.id);
		out.push(f);
	};
	for (const p of drive.partitions) for (const f of p.files) if (f.deleted && allow(f.recover)) add(f);
	if (mode === "deep" || mode === "raw") {
		for (const p of drive.lost) for (const f of p.files) if (allow(f.recover === "raw" ? "raw" : "deep")) add(f);
		for (const f of drive.scrap) if (allow(f.recover)) add(f);
	}
	if (mode === "raw") {
		for (const p of drive.lost) for (const f of p.files) add(f);
		for (const f of drive.scrap) add(f);
		for (const f of drive.carved) add(f);
	}
	return out;
}
function stripFile(drive, fileId) {
	let found = null;
	const pull = (files) => {
		const next = [];
		for (const f of files) if (f.id === fileId && !found) found = f;
		else next.push(f);
		return next;
	};
	const partitions = drive.partitions.map((p) => ({
		...p,
		files: pull(p.files)
	}));
	const lost = drive.lost.map((p) => ({
		...p,
		files: pull(p.files)
	}));
	const scrap = pull(drive.scrap);
	const carved = pull(drive.carved);
	return {
		drive: {
			...drive,
			partitions,
			lost,
			scrap,
			carved
		},
		file: found
	};
}
function uniqueName(part, name) {
	const names = new Set(part.files.filter((f) => !f.deleted).map((f) => f.name.toLowerCase()));
	if (!names.has(name.toLowerCase())) return name;
	const dot = name.lastIndexOf(".");
	const stem = dot > 0 ? name.slice(0, dot) : name;
	const ext = dot > 0 ? name.slice(dot) : "";
	let i = 2;
	let candidate = `${stem} (${i})${ext}`;
	while (names.has(candidate.toLowerCase())) {
		i += 1;
		candidate = `${stem} (${i})${ext}`;
	}
	return candidate;
}
function restoreFile(drive, fileId) {
	const taken = stripFile(drive, fileId);
	if (!taken.file) return {
		drive,
		ok: false,
		message: "That file is no longer recoverable."
	};
	const file = {
		...taken.file,
		deleted: false
	};
	const part = taken.drive.partitions.find((p) => p.bytes - usedBytes(p) >= file.bytes);
	if (!part) return {
		drive: {
			...taken.drive,
			scrap: [...taken.drive.scrap, {
				...taken.file,
				deleted: true
			}]
		},
		ok: false,
		message: `${file.name} needs ${formatBytes(file.bytes)} free on one volume.`
	};
	const named = {
		...file,
		name: uniqueName(part, file.name)
	};
	const partitions = taken.drive.partitions.map((p) => p.id === part.id ? {
		...p,
		files: [...p.files, named]
	} : p);
	return {
		drive: {
			...taken.drive,
			partitions
		},
		ok: true,
		message: `Restored ${named.name} to ${displayLabel(part.label)}.`
	};
}
function deleteFile(drive, fileId) {
	const mark = (files) => files.map((f) => f.id === fileId ? {
		...f,
		deleted: true,
		recover: "quick"
	} : f);
	return {
		...drive,
		partitions: drive.partitions.map((p) => ({
			...p,
			files: mark(p.files)
		}))
	};
}
function renameFile(drive, fileId, rawName) {
	const name = rawName.trim();
	if (!name || /[\\/]/.test(name)) return {
		drive,
		ok: false,
		message: "Use a file name without slashes."
	};
	let clash = false;
	const partitions = drive.partitions.map((p) => {
		if (!p.files.some((f) => f.id === fileId)) return p;
		if (p.files.some((f) => f.id !== fileId && !f.deleted && f.name.toLowerCase() === name.toLowerCase())) {
			clash = true;
			return p;
		}
		return {
			...p,
			files: p.files.map((f) => f.id === fileId ? {
				...f,
				name
			} : f)
		};
	});
	if (clash) return {
		drive,
		ok: false,
		message: "Another file already uses that name."
	};
	return {
		drive: {
			...drive,
			partitions
		},
		ok: true,
		message: `Renamed to ${name}.`
	};
}
function restorePartition(drive, partId) {
	const part = drive.lost.find((p) => p.id === partId);
	if (!part) return {
		drive,
		ok: false,
		message: "That partition is no longer in the lost list."
	};
	const table = drive.table ?? "MBR";
	if (drive.partitions.length >= maxPartitions(table)) return {
		drive,
		ok: false,
		message: `${table} is already full. Delete or convert the table first.`
	};
	if (part.bytes > unallocated(drive)) return {
		drive,
		ok: false,
		message: "Not enough unallocated space to put this partition back."
	};
	return {
		drive: {
			...drive,
			table,
			partitions: [...drive.partitions, structuredClone(part)],
			lost: drive.lost.filter((p) => p.id !== partId)
		},
		ok: true,
		message: `Restored ${displayLabel(part.label)} (${part.fs}, ${formatBytes(part.bytes)}).`
	};
}
function wizardIssue(drive, draft) {
	if (draft.table === "MBR" && drive.real > 2199023255552) return tableIssue("MBR", drive.real);
	if (draft.parts.length > maxPartitions(draft.table)) return `${draft.table} allows ${maxPartitions(draft.table)} partitions.`;
	if (draft.parts.reduce((s, p) => s + p.bytes, 0) > drive.real) return "The layout is larger than the writable capacity.";
	for (const p of draft.parts) {
		const label = labelIssue(p.label, p.fs);
		if (label) return label;
		const fs = fsIssue(p.fs, p.bytes);
		if (fs) return fs;
		if (p.bytes < 1048576) return "Each partition needs at least 1 MB.";
	}
	return null;
}
function applyWizard(drive, draft) {
	const issue = wizardIssue(drive, draft);
	if (issue) return {
		drive,
		ok: false,
		message: issue
	};
	return {
		drive: {
			...drive,
			table: draft.table,
			partitions: structuredClone(draft.parts),
			lost: structuredClone(draft.lost),
			scrap: structuredClone(draft.scrap)
		},
		ok: true,
		message: `Wrote a ${draft.table} table with ${draft.parts.length} partition${draft.parts.length === 1 ? "" : "s"}.`
	};
}
function makeBackup(drive) {
	return {
		id: uid("bak"),
		at: Date.now(),
		serial: drive.serial,
		model: drive.model,
		real: drive.real,
		table: drive.table,
		partitions: structuredClone(drive.partitions),
		lost: structuredClone(drive.lost)
	};
}
function restoreBackup(drive, bak) {
	if (bak.partitions.reduce((s, p) => s + p.bytes, 0) > drive.real) return {
		drive,
		ok: false,
		message: "This image does not fit on the connected drive."
	};
	return {
		drive: {
			...drive,
			table: bak.table,
			partitions: structuredClone(bak.partitions),
			lost: structuredClone(bak.lost),
			scrap: [],
			carved: []
		},
		ok: true,
		message: `Restored the image of ${bak.model} from ${formatWhen(bak.at)}.`
	};
}
function gameFiles(drive) {
	const out = [];
	for (const p of drive.partitions) for (const f of p.files) {
		if (f.deleted) continue;
		if (f.kind === "iso" || /\.(iso|bin|vcd|zso|cso|chd)$/i.test(f.name) || f.name.toLowerCase().startsWith("ul.")) out.push({
			part: p,
			file: f
		});
	}
	return out;
}
function splitForOpl(drive, fileId) {
	let source = null;
	for (const p of drive.partitions) {
		const f = p.files.find((file) => file.id === fileId && !file.deleted);
		if (f) source = {
			partId: p.id,
			file: f
		};
	}
	if (!source) return {
		drive,
		ok: false,
		message: "Game image was not found."
	};
	if (source.file.bytes <= 4294967296) return {
		drive,
		ok: false,
		message: "This image is already under the 4 GB FAT32 limit."
	};
	const slug = (source.file.name.replace(/\.[^.]+$/, "").replace(/[^A-Za-z0-9]/g, "").slice(0, 8) || "GAME").toUpperCase();
	const chunk = 1073741824;
	const parts = [];
	let left = source.file.bytes;
	let index = 0;
	while (left > 0) {
		const bytes = Math.min(chunk, left);
		const suffix = index.toString().padStart(2, "0");
		parts.push(file(uid("ul"), `ul.${slug}.${suffix}`, bytes, "iso", {
			fragments: 1,
			preview: `USBExtreme slice ${suffix} of ${source.file.name}.`
		}));
		left -= bytes;
		index += 1;
	}
	const cfgName = "ul.cfg";
	const cfgBody = parts.map((p, i) => `${p.name}|${source?.file.name}|${p.bytes}|part ${i + 1}`).join("\n");
	const cfg = file(uid("cfg"), cfgName, cfgBody.length, "doc", { preview: cfgBody });
	const partitions = drive.partitions.map((p) => {
		if (p.id !== source?.partId) return p;
		const without = p.files.filter((f) => f.id !== fileId && f.name.toLowerCase() !== "ul.cfg");
		return {
			...p,
			files: [
				...without,
				...parts,
				cfg
			]
		};
	});
	return {
		drive: {
			...drive,
			partitions
		},
		ok: true,
		message: `Split into ${parts.length} USBExtreme parts and wrote ul.cfg.`
	};
}
var CONVERT_TARGETS = [...[
	"iso",
	"bin",
	"vcd",
	"zso",
	"cso",
	"chd"
]];
function convertFile(drive, fileId, target) {
	let changed = false;
	let message = "File was not found.";
	const partitions = drive.partitions.map((p) => ({
		...p,
		files: p.files.map((f) => {
			if (f.id !== fileId || f.deleted) return f;
			const dot = f.name.lastIndexOf(".");
			const nextName = `${dot > 0 ? f.name.slice(0, dot) : f.name}.${target}`;
			if (f.name.toLowerCase() === nextName.toLowerCase()) {
				message = `${f.name} is already that format.`;
				return f;
			}
			changed = true;
			message = `Converted ${f.name} to ${nextName}.`;
			return {
				...f,
				name: nextName,
				kind: "iso",
				fragments: 1
			};
		})
	}));
	return {
		drive: changed ? {
			...drive,
			partitions
		} : drive,
		ok: changed,
		message
	};
}
function findFile(drive, fileId) {
	for (const p of [...drive.partitions, ...drive.lost]) {
		const f = p.files.find((file) => file.id === fileId);
		if (f) return f;
	}
	return drive.scrap.find((f) => f.id === fileId) ?? drive.carved.find((f) => f.id === fileId) ?? null;
}
function wipeStages(passes, verify) {
	const span = 1 - (verify === "off" ? 0 : .18);
	const stages = Array.from({ length: passes }, (_, i) => ({
		until: span * (i + 1) / passes,
		label: `Pass ${i + 1} of ${passes}`
	}));
	if (verify !== "off") stages.push({
		until: 1,
		label: verify === "full" ? "Verifying every block" : "Verifying a sample"
	});
	return stages;
}
function scanDuration(mode) {
	if (mode === "quick") return 1400;
	if (mode === "smart") return 2200;
	if (mode === "deep") return 3800;
	return 5200;
}
function logLine(text) {
	return {
		id: uid("log"),
		at: Date.now(),
		text
	};
}
function withDrive(drives, id, fn) {
	if (!drives.some((d) => d.id === id)) return null;
	return drives.map((d) => d.id === id ? fn(d) : d);
}
var initial = {
	drives: seedDrives(),
	connectedId: null,
	tokens: 0,
	pro: false,
	pinned: [],
	fs: "FAT32",
	cluster: "default",
	table: "MBR",
	label: "",
	backups: [],
	benches: [],
	certs: [],
	logs: [],
	lastScan: null
};
var useUsb = create()(persist((set, get) => ({
	...initial,
	job: null,
	payload: null,
	notice: null,
	toast: null,
	setFs: (fs) => set((s) => ({
		fs,
		cluster: clusterChoices(fs).includes(s.cluster) ? s.cluster : "default"
	})),
	setCluster: (cluster) => set({ cluster }),
	setTable: (table) => set({ table }),
	setLabel: (label) => set({ label }),
	connect: (id) => {
		if (get().job) return;
		set({
			connectedId: id,
			lastScan: null
		});
	},
	eject: () => {
		if (get().job) return;
		set({ connectedId: null });
	},
	togglePin: (id) => set((s) => {
		const has = s.pinned.includes(id);
		return {
			pinned: has ? s.pinned.filter((p) => p !== id) : [...s.pinned, id],
			toast: has ? "Removed from favorites" : "Pinned to the top of tools"
		};
	}),
	addTokens: (n) => set((s) => ({
		tokens: s.tokens + n,
		toast: `Added ${n} token${n === 1 ? "" : "s"}`,
		logs: [logLine(`Token balance increased by ${n}.`), ...s.logs].slice(0, 40)
	})),
	unlockPro: () => set((s) => ({
		pro: true,
		toast: "Pro unlocked on this bench",
		logs: [logLine("Pro enabled. Format and partition actions no longer spend tokens."), ...s.logs].slice(0, 40)
	})),
	dismissNotice: () => set({ notice: null }),
	clearToast: () => set({ toast: null }),
	deleteBackup: (id) => set((s) => ({ backups: s.backups.filter((b) => b.id !== id) })),
	removeFile: (driveId, fileId) => set((s) => {
		const drives = withDrive(s.drives, driveId, (d) => deleteFile(d, fileId));
		if (!drives) return {};
		return {
			drives,
			logs: [logLine("Moved a file to the deleted list."), ...s.logs].slice(0, 40),
			toast: "File deleted. Recover can bring it back."
		};
	}),
	renameLiveFile: (driveId, fileId, name) => {
		const drive = get().drives.find((d) => d.id === driveId);
		if (!drive) return "Drive missing.";
		const result = renameFile(drive, fileId, name);
		if (!result.ok) return result.message;
		set((s) => ({
			drives: s.drives.map((d) => d.id === driveId ? result.drive : d),
			toast: result.message
		}));
		return null;
	},
	resetBench: () => set((s) => ({
		drives: seedDrives(),
		connectedId: null,
		backups: [],
		benches: [],
		certs: [],
		logs: [logLine("Bench drives reset."), ...s.logs].slice(0, 40),
		lastScan: null,
		toast: "Bench drives restored",
		fs: s.fs
	})),
	startJob: (spec) => {
		if (get().job) return false;
		set({
			notice: null,
			payload: spec.payload,
			job: {
				id: uid("job"),
				title: spec.title,
				stage: spec.stages[0]?.label ?? "Working",
				progress: 0,
				duration: spec.duration,
				cancellable: spec.cancellable,
				settled: false,
				stages: spec.stages
			}
		});
		return true;
	},
	setProgress: (progress) => set((s) => {
		if (!s.job || s.job.settled) return {};
		const stage = s.job.stages.find((item) => progress <= item.until)?.label ?? s.job.stage;
		return { job: {
			...s.job,
			progress,
			stage
		} };
	}),
	cancelJob: () => {
		const { job } = get();
		if (!job?.cancellable || job.settled) return;
		set({
			job: null,
			payload: null,
			notice: {
				title: "Stopped",
				body: "Nothing was written."
			}
		});
	},
	finishJob: () => {
		const snap = get();
		if (!snap.job || snap.job.settled || !snap.payload) return;
		const payload = snap.payload;
		let tokens = snap.tokens;
		let drives = snap.drives;
		let backups = snap.backups;
		let benches = snap.benches;
		let certs = snap.certs;
		let logs = snap.logs;
		let lastScan = snap.lastScan;
		let notice = {
			title: "Done",
			body: ""
		};
		const spend = (cost) => {
			if (snap.pro || cost <= 0) return true;
			if (tokens < cost) return false;
			tokens -= cost;
			return true;
		};
		const note = (text) => {
			logs = [logLine(text), ...logs].slice(0, 40);
		};
		const update = (id, fn) => {
			const next = withDrive(drives, id, fn);
			if (!next) return false;
			drives = next;
			return true;
		};
		switch (payload.kind) {
			case "format": {
				const drive = drives.find((d) => d.id === payload.driveId);
				if (!drive) {
					notice = {
						title: "Drive missing",
						body: "The drive left the bench before the write finished."
					};
					break;
				}
				if (!spend(payload.cost)) {
					notice = {
						title: "Not enough tokens",
						body: "Earn a token, then format again. The drive was not changed."
					};
					break;
				}
				const applied = applyFormat(drive, payload);
				drives = drives.map((d) => d.id === drive.id ? applied.drive : d);
				notice = {
					title: "Format complete",
					body: applied.summary,
					browse: true
				};
				note(`Formatted ${drive.model} as ${payload.fs}.`);
				lastScan = null;
				break;
			}
			case "wipe": {
				let certBody = "";
				notice = update(payload.driveId, (d) => {
					const applied = applyWipe(d, payload);
					certs = [{
						...applied.cert,
						id: uid("cert"),
						at: Date.now()
					}, ...certs].slice(0, 12);
					certBody = applied.cert.verified ? "Verification passed. The stick is unallocated and must be formatted before use." : "Wipe finished, but verification found blocks that did not read back. The stick is still erased.";
					note(`Wiped ${d.model} with ${payload.method}.`);
					return applied.drive;
				}) ? {
					title: "Wipe finished",
					body: certBody
				} : {
					title: "Drive missing",
					body: "Nothing to wipe."
				};
				lastScan = null;
				break;
			}
			case "defrag":
				if (!update(payload.driveId, (d) => {
					const applied = applyDefrag(d);
					notice = {
						title: applied.fixed ? "Defrag complete" : "Already contiguous",
						body: applied.fixed ? `Rewrote ${applied.fixed} fragmented file${applied.fixed === 1 ? "" : "s"} into single extents.` : "No fragmented FAT32 or exFAT files were on the drive."
					};
					note(notice.body);
					return applied.drive;
				})) notice = {
					title: "Drive missing",
					body: "Defrag did not run."
				};
				break;
			case "badblocks":
				if (!update(payload.driveId, (d) => {
					const bad = badMap(d).filter(Boolean).length;
					const fake = d.advertised > d.real * 1.15;
					notice = {
						title: fake ? "Counterfeit capacity" : bad ? "Bad blocks found" : "Surface looks clean",
						body: fake ? `Label says ${formatBytes(d.advertised)}. The test could only hold ${formatBytes(d.real)}. ${bad} bad cells in the sample. Format uses the real size.` : bad ? `${bad} cells failed the write/read sample. A full wipe verification will fail until the stick is replaced.` : "The sample passed and the label matches the writable size."
					};
					note(`Bad-block test on ${d.model}: ${notice.title}.`);
					return {
						...d,
						verifiedReal: true
					};
				})) notice = {
					title: "Drive missing",
					body: "Test did not finish."
				};
				break;
			case "bench": {
				const row = {
					...payload.planned,
					id: uid("bench"),
					at: Date.now()
				};
				benches = [row, ...benches].slice(0, 12);
				notice = {
					title: "Benchmark saved",
					body: `${row.model}: ${row.seqRead} MB/s read${row.seqWrite != null ? `, ${row.seqWrite} MB/s write` : ""}.`
				};
				note(notice.body);
				break;
			}
			case "scan": {
				const drive = drives.find((d) => d.id === payload.driveId);
				const ids = drive ? collectRecoverable(drive, payload.mode).map((f) => f.id) : [];
				lastScan = {
					driveId: payload.driveId,
					mode: payload.mode,
					ids
				};
				notice = {
					title: "Scan finished",
					body: ids.length ? `Found ${ids.length} recoverable file${ids.length === 1 ? "" : "s"} with a ${payload.mode} scan.` : `No files turned up in a ${payload.mode} scan.`
				};
				note(notice.body);
				break;
			}
			case "restore-files": {
				const messages = [];
				let restored = 0;
				update(payload.driveId, (d) => {
					let cursor = d;
					for (const id of payload.ids) {
						const applied = restoreFile(cursor, id);
						cursor = applied.drive;
						if (applied.ok) restored += 1;
						else messages.push(applied.message);
					}
					return cursor;
				});
				notice = {
					title: restored ? "Files restored" : "Nothing restored",
					body: restored ? `Put ${restored} file${restored === 1 ? "" : "s"} back on the volume.${messages[0] ? ` ${messages[0]}` : ""}` : messages[0] ?? "Those files are gone.",
					browse: restored > 0
				};
				note(notice.body);
				break;
			}
			case "restore-part":
				if (!update(payload.driveId, (d) => {
					const applied = restorePartition(d, payload.partId);
					notice = {
						title: applied.ok ? "Partition restored" : "Could not restore",
						body: applied.message
					};
					return applied.drive;
				})) notice = {
					title: "Drive missing",
					body: "Partition was not restored."
				};
				else note(notice.body);
				break;
			case "wizard": {
				const drive = drives.find((d) => d.id === payload.driveId);
				if (!drive) {
					notice = {
						title: "Drive missing",
						body: "Nothing was written."
					};
					break;
				}
				if (!spend(payload.cost)) {
					notice = {
						title: "Not enough tokens",
						body: "Partition changes were not written."
					};
					break;
				}
				const applied = applyWizard(drive, payload.draft);
				if (!applied.ok) {
					if (!snap.pro) tokens += payload.cost;
					notice = {
						title: "Layout rejected",
						body: applied.message
					};
					break;
				}
				drives = drives.map((d) => d.id === drive.id ? applied.drive : d);
				notice = {
					title: "Partitions updated",
					body: applied.message
				};
				note(applied.message);
				break;
			}
			case "backup": {
				const drive = drives.find((d) => d.id === payload.driveId);
				if (!drive) {
					notice = {
						title: "Drive missing",
						body: "Nothing to image."
					};
					break;
				}
				backups = [makeBackup(drive), ...backups].slice(0, 8);
				notice = {
					title: "Image saved",
					body: `Stored ${drive.model} on this device. It stays in the browser, not on a second stick.`
				};
				note(`Backed up ${drive.model}.`);
				break;
			}
			case "restore-backup": {
				const bak = backups.find((b) => b.id === payload.backupId);
				if (!bak) {
					notice = {
						title: "Image missing",
						body: "That backup is no longer on this device."
					};
					break;
				}
				if (!update(payload.driveId, (d) => {
					const applied = restoreBackup(d, bak);
					notice = {
						title: applied.ok ? "Restore complete" : "Restore blocked",
						body: applied.message
					};
					return applied.ok ? applied.drive : d;
				})) notice = {
					title: "Drive missing",
					body: "Restore did not run."
				};
				else note(notice.body);
				lastScan = null;
				break;
			}
			case "split":
				if (!update(payload.driveId, (d) => {
					const applied = splitForOpl(d, payload.fileId);
					notice = {
						title: applied.ok ? "Split for OPL" : "Not split",
						body: applied.message
					};
					return applied.ok ? applied.drive : d;
				})) notice = {
					title: "Drive missing",
					body: "Split did not run."
				};
				else note(notice.body);
				break;
			case "convert": if (!update(payload.driveId, (d) => {
				const applied = convertFile(d, payload.fileId, payload.target);
				notice = {
					title: applied.ok ? "Converted" : "Not converted",
					body: applied.message
				};
				return applied.ok ? applied.drive : d;
			})) notice = {
				title: "Drive missing",
				body: "Convert did not run."
			};
			else note(notice.body);
		}
		set({
			job: null,
			payload: null,
			tokens,
			drives,
			backups,
			benches,
			certs,
			logs,
			lastScan,
			notice
		});
	}
}), {
	name: "usb-tools-bench-v1",
	skipHydration: true,
	version: 1,
	partialize: (s) => ({
		drives: s.drives,
		connectedId: s.connectedId,
		tokens: s.tokens,
		pro: s.pro,
		pinned: s.pinned,
		fs: s.fs,
		cluster: s.cluster,
		table: s.table,
		label: s.label,
		backups: s.backups,
		benches: s.benches,
		certs: s.certs,
		logs: s.logs,
		lastScan: s.lastScan
	})
}));
function useConnected() {
	return useUsb((s) => s.drives.find((d) => d.id === s.connectedId) ?? null);
}
var UiContext = (0, import_react.createContext)(null);
function useUi() {
	const value = (0, import_react.useContext)(UiContext);
	if (!value) throw new Error("USB Tools UI is not mounted");
	return value;
}
function cx(...inputs) {
	return twMerge(clsx(inputs));
}
function LogoMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				fill: "currentColor",
				children: [[
					0,
					45,
					90,
					135,
					180,
					225,
					270,
					315
				].map((deg) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "28",
					y: "2",
					width: "8",
					height: "14",
					rx: "2",
					transform: `rotate(${deg} 32 32)`
				}, deg)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "32",
					cy: "32",
					r: "16"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "11",
				fill: "var(--color-bg)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "2.2",
				strokeLinecap: "round",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M32 25.5v13" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M32 27.5 26.5 33" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M32 27.5 37.5 33" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "26.2",
				cy: "34.2",
				r: "1.7",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "36.2",
				y: "31.6",
				width: "3.3",
				height: "3.3",
				rx: "0.4",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "40.2",
				r: "1.8",
				fill: "currentColor"
			})
		]
	});
}
function UsbPlug({ className, badge }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className,
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
			transform: "rotate(-38 26 28)",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2.4",
			strokeLinejoin: "round",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "16",
					y: "8",
					width: "16",
					height: "10",
					rx: "1.5"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 18v8M27 18v8" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 26h16v8H16z" })
			]
		}), badge === "off" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "46",
			cy: "46",
			r: "10",
			fill: "var(--color-surface)",
			stroke: "currentColor",
			strokeWidth: "2.4"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M41 46h10",
			stroke: "currentColor",
			strokeWidth: "2.4",
			strokeLinecap: "round"
		})] }) : null]
	});
}
function Card({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cx("rounded-3xl bg-surface px-5 py-6", className),
		children
	});
}
function Sheet({ title, onClose, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-30 flex flex-col justify-end bg-bg/70",
		role: "presentation",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "max-h-[86%] overflow-y-auto rounded-t-3xl bg-surface px-5 pt-3 pb-8",
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-4 h-1 w-10 rounded-full bg-muted" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-medium",
						children: title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center text-muted",
						onClick: onClose,
						"aria-label": "Close",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseIcon, {})
					})]
				}),
				children
			]
		})
	});
}
function Dialog({ title, children, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "absolute inset-0 z-40 grid place-items-center bg-bg/75 px-5",
		role: "presentation",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			className: "w-full max-w-sm rounded-3xl bg-surface p-5",
			onClick: (event) => event.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-medium",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 text-base leading-relaxed text-fg",
				children
			})]
		})
	});
}
function PrimaryButton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		...props,
		className: cx("h-12 w-full rounded-xl text-base font-medium tracking-wide disabled:cursor-default", props.disabled ? "bg-sunken text-muted" : "bg-fg text-bg", className)
	});
}
function QuietButton({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		...props,
		className: cx("h-11 rounded-xl bg-sunken px-4 text-sm text-fg disabled:text-muted", className)
	});
}
function ProgressBar({ value }) {
	const width = `${Math.max(0, Math.min(100, Math.round(value * 100)))}%`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-2 overflow-hidden rounded-full bg-bg",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-fg",
			style: { width }
		})
	});
}
function CloseIcon() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "size-5",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "2",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M6 6l12 12M18 6 6 18",
			strokeLinecap: "round"
		})
	});
}
var FORMAT_STAGES = [
	{
		until: .16,
		label: "Unmounting the volume"
	},
	{
		until: .45,
		label: "Writing the partition table"
	},
	{
		until: .86,
		label: "Formatting clusters"
	},
	{
		until: 1,
		label: "Verifying the new volume"
	}
];
function FormatView() {
	const ui = useUi();
	const drive = useConnected();
	const fs = useUsb((s) => s.fs);
	const cluster = useUsb((s) => s.cluster);
	const table = useUsb((s) => s.table);
	const label = useUsb((s) => s.label);
	const pro = useUsb((s) => s.pro);
	const tokens = useUsb((s) => s.tokens);
	const busy = useUsb((s) => !!s.job);
	const setFs = useUsb((s) => s.setFs);
	const setCluster = useUsb((s) => s.setCluster);
	const setTable = useUsb((s) => s.setTable);
	const setLabel = useUsb((s) => s.setLabel);
	const startJob = useUsb((s) => s.startJob);
	const [picker, setPicker] = (0, import_react.useState)(null);
	const [about, setAbout] = (0, import_react.useState)(false);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [block, setBlock] = (0, import_react.useState)(null);
	const issue = drive ? fsIssue(fs, drive.real) || tableIssue(table, drive.real) || labelIssue(label, fs) : null;
	const cost = formatCost(fs);
	const resolved = drive ? resolveCluster(fs, cluster, alignGuess(drive.real)) : null;
	const onFormat = () => {
		if (!drive || busy) return;
		if (issue) {
			setBlock(issue);
			return;
		}
		setConfirm(true);
	};
	const runFormat = () => {
		if (!drive) return;
		setConfirm(false);
		if (!pro && tokens < cost) {
			ui.setTokenOpen(true);
			return;
		}
		if (!startJob({
			title: "Format",
			duration: 3400,
			cancellable: false,
			stages: FORMAT_STAGES,
			payload: {
				kind: "format",
				driveId: drive.id,
				fs,
				cluster,
				table,
				label,
				cost: pro ? 0 : cost
			}
		})) setBlock("An operation is already running.");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => ui.setDeviceOpen(true),
				className: "flex items-center gap-3 rounded-3xl bg-surface px-5 py-6 text-left",
				"aria-label": drive ? `Connected drive ${drive.model}` : "No device connected. Connect a drive",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xl",
						children: drive ? drive.model : "No Device Connected."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block text-sm text-muted",
						children: drive ? driveSubtitle(drive) : "Tap to connect a bench drive"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsbPlug, {
					className: "size-14 shrink-0 text-fg",
					badge: drive ? "on" : "off"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "pb-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-center text-3xl font-medium",
							children: "Format"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "absolute top-0 right-0 grid size-11 place-items-center",
							"aria-label": "About format options",
							onClick: () => setAbout(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-7 place-items-center rounded-full bg-fg text-sm font-semibold text-bg",
								children: "i"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OptionRow, {
								label: "File System:",
								value: fs,
								onClick: () => setPicker("fs")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OptionRow, {
								label: "Cluster Size:",
								value: clusterLabel(cluster),
								onClick: () => setPicker("cluster")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OptionRow, {
								label: "Partition Table:",
								value: table,
								onClick: () => setPicker("table")
							})
						]
					}),
					issue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-danger",
						children: issue
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-10 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: label,
							onChange: (event) => setLabel(event.target.value),
							placeholder: "Volume Label",
							maxLength: 32,
							"aria-label": "Volume label",
							autoCapitalize: "characters",
							autoCorrect: "off",
							spellCheck: false,
							className: "w-full bg-transparent text-center text-2xl text-fg outline-none placeholder:text-fg"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-3 block h-px bg-fg" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onFormat,
						disabled: !drive || busy,
						className: cx("mt-8 h-14 w-full rounded-xl text-base font-medium tracking-widest", drive && !busy ? "bg-fg text-bg" : "bg-sunken text-muted"),
						children: "FORMAT"
					}),
					drive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-center text-sm text-muted",
						children: [pro ? "Pro · no token needed" : `Uses ${tokenWord(cost)}`, resolved ? ` · ${cluster === "default" ? "Default" : "Cluster"} ${formatCluster(resolved)}` : ""]
					}) : null
				]
			}),
			picker === "fs" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "File System",
				onClose: () => setPicker(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: FILESYSTEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickRow, {
					label: item.id,
					hint: item.hint,
					selected: item.id === fs,
					onClick: () => {
						setFs(item.id);
						setPicker(null);
					}
				}) }, item.id)) })
			}) : null,
			picker === "cluster" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Cluster Size",
				onClose: () => setPicker(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: clusterChoices(fs).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickRow, {
					label: clusterLabel(item),
					hint: item === "default" ? "Picked from the volume size when you format" : void 0,
					selected: item === cluster,
					onClick: () => {
						setCluster(item);
						setPicker(null);
					}
				}) }, item)) })
			}) : null,
			picker === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Partition Table",
				onClose: () => setPicker(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: [["MBR", "Legacy BIOS · 4 primary partitions · up to 2 TB"], ["GPT", "UEFI · large disks · more partitions"]].map(([id, hint]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PickRow, {
					label: id,
					hint,
					selected: table === id,
					onClick: () => {
						setTable(id);
						setPicker(null);
					}
				}) }, id)) })
			}) : null,
			about ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				title: "Format",
				onClose: () => setAbout(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 text-sm leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-fg",
							children: "These options match a USB maintenance bench. The write happens on the connected bench drive, then the volume is empty."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "FAT32"
						}), " is the safe pick for consoles, TVs, and car stereos. A single file cannot exceed 4 GB."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "exFAT and NTFS"
						}), " hold large files. EXT2, EXT3, and EXT4 are for Linux. FAT16 is only for tiny legacy devices."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-fg",
							children: "Cluster size"
						}), " is the allocation unit. Default follows the volume size. Larger clusters waste space on tiny files and can be required by older players."] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: "MBR"
							}),
							" is what older consoles expect. ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: "GPT"
							}),
							" is required past 2 TB."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "FAT labels allow 11 characters: letters, numbers, space, underscore, hyphen. They are stored in uppercase." })
					]
				})
			}) : null,
			confirm && drive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				title: `Format ${drive.model}?`,
				onClose: () => setConfirm(false),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"This erases ",
						liveFileCount(drive),
						" file",
						liveFileCount(drive) === 1 ? "" : "s",
						", deleted files, and lost partitions. The new volume will be ",
						fs,
						", ",
						table,
						", ",
						resolved ? formatCluster(resolved) : "default",
						" clusters, label ",
						displayLabel(label.trim() && (fs === "FAT16" || fs === "FAT32") ? label.toUpperCase() : label),
						"."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: pro ? "Pro is on, so this does not spend a token." : `This spends ${tokenWord(cost)}. You have ${tokens}.`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-12 flex-1 rounded-xl bg-sunken",
							onClick: () => setConfirm(false),
							children: "Cancel"
						}), !pro && tokens < cost ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-12 flex-1 rounded-xl bg-fg font-medium text-bg",
							onClick: () => {
								setConfirm(false);
								ui.setTokenOpen(true);
							},
							children: "Get tokens"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-12 flex-1 rounded-xl bg-danger font-medium text-bg",
							onClick: runFormat,
							children: "Format"
						})]
					})
				]
			}) : null,
			block ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				title: "Can't format yet",
				onClose: () => setBlock(null),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: block }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					className: "mt-5",
					onClick: () => setBlock(null),
					children: "OK"
				})]
			}) : null
		]
	});
}
function alignGuess(bytes) {
	const mib = 1048576;
	return Math.max(mib, Math.floor(bytes / mib) * mib);
}
function OptionRow({ label, value, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-2 items-center gap-3 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-lg",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick,
			className: "flex items-center gap-2 text-left text-lg font-medium",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: value }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
				className: "size-4 shrink-0",
				"aria-hidden": "true"
			})]
		})]
	});
}
function PickRow({ label, hint, selected, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex w-full items-start justify-between gap-3 border-b border-fg/10 py-3 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-lg",
			children: label
		}), hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mt-1 block text-sm text-muted",
			children: hint
		}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cx("mt-1 size-3 shrink-0 rounded-full", selected ? "bg-fg" : "bg-sunken"),
			"aria-hidden": "true"
		})]
	});
}
var TOOLS = [
	{
		id: "format",
		name: "Format",
		group: "Disk",
		blurb: "File system, cluster size, label",
		cost: "1–2 tokens"
	},
	{
		id: "partition",
		name: "Partition Wizard",
		group: "Disk",
		blurb: "Create, delete, rename, queue, undo",
		cost: "Up to 3 tokens"
	},
	{
		id: "defrag",
		name: "Defragmenter",
		group: "Disk",
		blurb: "FAT32 and exFAT extents",
		cost: "Free"
	},
	{
		id: "wipe",
		name: "Wipe",
		group: "Disk",
		blurb: "NIST, DoD, Schneier, Gutmann",
		cost: "Free"
	},
	{
		id: "backup",
		name: "Backup & Restore",
		group: "Disk",
		blurb: "Image the bench drive",
		cost: "Free"
	},
	{
		id: "recover",
		name: "Recover Files",
		group: "Recovery",
		blurb: "Quick, smart, deep, and raw",
		cost: "Free"
	},
	{
		id: "lost",
		name: "Lost Partitions",
		group: "Recovery",
		blurb: "Put a dropped volume back",
		cost: "Free"
	},
	{
		id: "badblocks",
		name: "Bad Blocks",
		group: "Diagnostics",
		blurb: "Surface test and fake capacity",
		cost: "Free"
	},
	{
		id: "bench",
		name: "Benchmark",
		group: "Diagnostics",
		blurb: "Sequential and random speed",
		cost: "Free"
	},
	{
		id: "info",
		name: "Device Info",
		group: "Diagnostics",
		blurb: "IDs, table, and health",
		cost: "Free"
	},
	{
		id: "ps2",
		name: "PS2 USB Utils",
		group: "Games",
		blurb: "OPL split, rename, PS2 format",
		cost: "Format is 1 token"
	},
	{
		id: "convert",
		name: "Game Converter",
		group: "Games",
		blurb: "ISO, BIN, VCD, ZSO, CSO, CHD",
		cost: "Free"
	}
];
var TOOL_GROUPS = [
	"Disk",
	"Recovery",
	"Diagnostics",
	"Games"
];
var ICONS = {
	format: HardDrive,
	partition: Columns2,
	defrag: Layers,
	wipe: Eraser,
	backup: Archive,
	recover: FileSearch,
	lost: RotateCcw,
	badblocks: Grid3x3,
	bench: Gauge,
	info: Info,
	ps2: Gamepad2,
	convert: Repeat
};
function ToolsMenu() {
	const ui = useUi();
	const pinned = useUsb((s) => s.pinned);
	const togglePin = useUsb((s) => s.togglePin);
	const [query, setQuery] = (0, import_react.useState)("");
	const needle = query.trim().toLowerCase();
	const items = TOOLS.filter((tool) => {
		if (!needle) return true;
		return `${tool.name} ${tool.blurb} ${tool.group}`.toLowerCase().includes(needle);
	}).sort((a, b) => Number(pinned.includes(b.id)) - Number(pinned.includes(a.id)));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-2xl font-medium",
			children: "Tools"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-4 flex items-center gap-2 rounded-2xl bg-surface px-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
				className: "size-4 text-muted",
				"aria-hidden": "true"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: query,
				onChange: (event) => setQuery(event.target.value),
				placeholder: "Search tools",
				"aria-label": "Search tools",
				className: "h-12 w-full bg-transparent text-base outline-none placeholder:text-muted"
			})]
		}),
		items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-muted",
			children: "No tool matches that search."
		}) : null,
		TOOL_GROUPS.map((group) => {
			const groupItems = items.filter((tool) => tool.group === group);
			if (!groupItems.length) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-xs tracking-widest text-muted uppercase",
					children: group
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 overflow-hidden rounded-3xl bg-surface",
					children: groupItems.map((tool) => {
						const Icon = ICONS[tool.id];
						const isPinned = pinned.includes(tool.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-stretch border-b border-fg/10 last:border-b-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex min-w-0 flex-1 items-center gap-3 px-4 py-3 text-left",
								onClick: () => ui.go(tool.id),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5 shrink-0",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-base",
										children: tool.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block truncate text-sm text-muted",
										children: [
											tool.blurb,
											" · ",
											tool.cost
										]
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "grid w-12 place-items-center",
								"aria-label": isPinned ? `Unpin ${tool.name}` : `Pin ${tool.name}`,
								onClick: () => togglePin(tool.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cx("size-4", isPinned && "fill-current") })
							})]
						}, tool.id);
					})
				})]
			}, group);
		})
	] });
}
function ToolBody({ screen }) {
	if (screen === "partition") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PartitionTool, {});
	if (screen === "defrag") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DefragTool, {});
	if (screen === "wipe") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WipeTool, {});
	if (screen === "backup") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackupTool, {});
	if (screen === "recover") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecoverTool, {});
	if (screen === "lost") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LostTool, {});
	if (screen === "badblocks") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadBlocksTool, {});
	if (screen === "bench") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BenchTool, {});
	if (screen === "info") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoTool, {});
	if (screen === "ps2") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ps2Tool, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConvertTool, {});
}
function ToolHeading({ title }) {
	const ui = useUi();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-4 flex items-center gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "grid size-11 place-items-center",
			"aria-label": "Back",
			onClick: () => ui.go("format"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-6" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-2xl font-medium",
			children: title
		})]
	});
}
function NeedDrive() {
	const ui = useUi();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-lg",
			children: "No device connected."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-muted",
			children: "Connect a bench drive. This browser cannot rewrite a physical USB stick."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
			className: "mt-5",
			onClick: () => ui.setDeviceOpen(true),
			children: "Connect a drive"
		})
	] });
}
function PartitionTool() {
	const drive = useConnected();
	const pro = useUsb((s) => s.pro);
	const tokens = useUsb((s) => s.tokens);
	const busy = useUsb((s) => !!s.job);
	const startJob = useUsb((s) => s.startJob);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const [undo, setUndo] = (0, import_react.useState)([]);
	const [editor, setEditor] = (0, import_react.useState)(null);
	const [targetId, setTargetId] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [fs, setFs] = (0, import_react.useState)("FAT32");
	const [size, setSize] = (0, import_react.useState)(MIB);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!drive) {
			setDraft(null);
			setUndo([]);
			return;
		}
		setDraft({
			table: drive.table ?? "MBR",
			parts: structuredClone(drive.partitions),
			lost: structuredClone(drive.lost),
			scrap: structuredClone(drive.scrap)
		});
		setUndo([]);
		setEditor(null);
	}, [drive]);
	if (!drive || !draft) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Partition Wizard" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const free = Math.max(0, drive.real - draft.parts.reduce((sum, part) => sum + part.bytes, 0));
	const dirty = undo.length > 0;
	const cost = Math.min(3, Math.max(1, undo.length));
	const push = (next) => {
		setUndo((stack) => [...stack, draft].slice(-20));
		setDraft(next);
		setEditor(null);
		setError(null);
	};
	const create = () => {
		if (draft.parts.length >= maxPartitions(draft.table)) {
			setError(`${draft.table} already has ${maxPartitions(draft.table)} partitions.`);
			return;
		}
		const bytes = alignDown(Math.min(size, free));
		const issue = fsIssue(fs, bytes) || labelIssue(name, fs);
		if (issue) {
			setError(issue);
			return;
		}
		if (bytes > free) {
			setError("That is larger than the unallocated space.");
			return;
		}
		const part = {
			id: `new-${Date.now().toString(36)}`,
			label: sanitizeLabel(name, fs),
			fs,
			bytes,
			cluster: resolveCluster(fs, "default", bytes),
			files: []
		};
		push({
			...draft,
			parts: [...draft.parts, part]
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Partition Wizard" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Writable ",
					formatBytes(drive.real),
					" · unallocated ",
					formatBytes(free),
					" · ",
					draft.table
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DiskBar, {
				parts: draft.parts,
				total: drive.real
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-4 flex flex-col gap-3",
				children: [draft.parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-bg px-3 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-base",
							children: [
								displayLabel(part.label),
								" · ",
								part.fs
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								formatBytes(part.bytes),
								" · ",
								formatCluster(part.cluster),
								" · ",
								part.files.filter((f) => !f.deleted).length,
								" files"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
									onClick: () => {
										setTargetId(part.id);
										setName(part.label);
										setEditor("rename");
									},
									children: "Rename"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
									onClick: () => {
										setTargetId(part.id);
										setFs(part.fs);
										setName(part.label);
										setEditor("format");
									},
									children: "Format"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
									onClick: () => {
										const files = part.files.map((f) => ({
											...f,
											deleted: true,
											recover: "smart"
										}));
										push({
											...draft,
											scrap: [...draft.scrap, ...files],
											parts: draft.parts.map((item) => item.id === part.id ? {
												...item,
												files: []
											} : item)
										});
									},
									children: "Wipe"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
									onClick: () => push({
										...draft,
										parts: draft.parts.filter((item) => item.id !== part.id),
										lost: [...draft.lost, part]
									}),
									children: "Delete"
								})
							]
						})
					]
				}, part.id)), draft.parts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "text-sm text-muted",
					children: "No partitions in the table."
				}) : null]
			}),
			draft.lost.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Lost, not in the table yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 flex flex-col gap-2",
					children: draft.lost.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							displayLabel(part.label),
							" · ",
							formatBytes(part.bytes)
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							onClick: () => {
								if (draft.parts.length >= maxPartitions(draft.table)) {
									setError(`${draft.table} is full.`);
									return;
								}
								if (part.bytes > free) {
									setError("Not enough unallocated space.");
									return;
								}
								push({
									...draft,
									lost: draft.lost.filter((item) => item.id !== part.id),
									parts: [...draft.parts, part]
								});
							},
							children: "Put back"
						})]
					}, part.id))
				})]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
						disabled: free < 1048576 || busy,
						onClick: () => {
							setEditor("create");
							setName("");
							setFs("FAT32");
							setSize(alignDown(free));
							setError(null);
						},
						children: "New partition"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QuietButton, {
						disabled: busy,
						onClick: () => {
							const next = draft.table === "MBR" ? "GPT" : "MBR";
							if (next === "MBR" && drive.real > 2199023255552) {
								setError("This disk is larger than 2 TB, so it has to stay GPT.");
								return;
							}
							if (next === "MBR" && draft.parts.length > 4) {
								setError("Delete partitions until 4 or fewer before converting to MBR.");
								return;
							}
							push({
								...draft,
								table: next
							});
						},
						children: ["Convert to ", draft.table === "MBR" ? "GPT" : "MBR"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
						disabled: !dirty || busy,
						onClick: () => {
							const prev = undo[undo.length - 1];
							if (!prev) return;
							setUndo(undo.slice(0, -1));
							setDraft(prev);
						},
						children: "Undo"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: dirty ? `${undo.length} queued change${undo.length === 1 ? "" : "s"} · ${pro ? "Pro, no token" : tokenWord(cost)} on apply` : "Queue is empty. Apply stays off until you change the layout."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				className: "mt-3",
				disabled: !dirty || busy || !pro && tokens < cost,
				onClick: () => {
					if (!startJob({
						title: "Writing partitions",
						duration: 2800,
						cancellable: false,
						stages: [
							{
								until: .35,
								label: "Checking the queue"
							},
							{
								until: .75,
								label: "Writing the table"
							},
							{
								until: 1,
								label: "Reloading volumes"
							}
						],
						payload: {
							kind: "wizard",
							driveId: drive.id,
							draft,
							cost: pro ? 0 : cost
						}
					})) setError("An operation is already running.");
				},
				children: !pro && tokens < cost ? "Need tokens" : "Apply"
			})
		] }),
		editor === "create" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg",
					children: "New partition"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm text-muted",
					children: ["Label", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (event) => setName(event.target.value),
						className: "mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg outline-none",
						"aria-label": "New partition label"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm text-muted",
					children: ["File system", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: fs,
						onChange: (event) => setFs(event.target.value),
						className: "mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg",
						"aria-label": "New partition file system",
						children: FILESYSTEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.id
						}, item.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm text-muted",
					children: [
						"Size · ",
						formatBytes(size),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: MIB,
							max: Math.max(MIB, free),
							step: free > 1e11 ? 1e9 : MIB,
							value: Math.min(size, Math.max(MIB, free)),
							onChange: (event) => setSize(Number(event.target.value)),
							className: "mt-2 w-full",
							"aria-label": "New partition size"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
						className: "flex-1",
						onClick: () => setEditor(null),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						className: "w-auto flex-1",
						onClick: create,
						children: "Queue create"
					})]
				})
			]
		}) : null,
		editor === "rename" || editor === "format" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-lg",
					children: editor === "rename" ? "Rename" : "Format partition"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm text-muted",
					children: ["Label", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (event) => setName(event.target.value),
						className: "mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg outline-none",
						"aria-label": "Partition label"
					})]
				}),
				editor === "format" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 block text-sm text-muted",
					children: ["File system", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: fs,
						onChange: (event) => setFs(event.target.value),
						className: "mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg",
						"aria-label": "Partition file system",
						children: FILESYSTEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: item.id,
							children: item.id
						}, item.id))
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
						className: "flex-1",
						onClick: () => setEditor(null),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						className: "w-auto flex-1",
						onClick: () => {
							const part = draft.parts.find((item) => item.id === targetId);
							if (!part) return;
							const useFs = editor === "format" ? fs : part.fs;
							const issue = labelIssue(name, useFs) || (editor === "format" ? fsIssue(useFs, part.bytes) : null);
							if (issue) {
								setError(issue);
								return;
							}
							if (editor === "rename") {
								push({
									...draft,
									parts: draft.parts.map((item) => item.id === part.id ? {
										...item,
										label: sanitizeLabel(name, part.fs)
									} : item)
								});
								return;
							}
							push({
								...draft,
								scrap: [...draft.scrap, ...part.files.map((f) => ({
									...f,
									deleted: true,
									recover: "smart"
								}))],
								parts: draft.parts.map((item) => item.id === part.id ? {
									...item,
									fs: useFs,
									label: sanitizeLabel(name, useFs),
									cluster: resolveCluster(useFs, "default", item.bytes),
									files: []
								} : item)
							});
						},
						children: "Queue"
					})]
				})
			]
		}) : null
	] });
}
function DiskBar({ parts, total }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 flex h-8 overflow-hidden rounded-lg bg-bg",
		"aria-hidden": "true",
		children: parts.map((part, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-full bg-fg",
			style: {
				width: `${part.bytes / total * 100}%`,
				opacity: 1 - index * .15
			}
		}, part.id))
	});
}
function DefragTool() {
	const drive = useConnected();
	const busy = useUsb((s) => !!s.job);
	const startJob = useUsb((s) => s.startJob);
	const [error, setError] = (0, import_react.useState)(null);
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Defragmenter" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const stats = fragStats(drive);
	const files = drive.partitions.flatMap((part) => part.fs === "FAT32" || part.fs === "exFAT" ? part.files.filter((file) => !file.deleted).map((file) => ({
		...file,
		fs: part.fs
	})) : []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Defragmenter" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		!stats.supported ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "Only FAT32 and exFAT can be defragmented here. Format the stick first if OPL or a console requires it."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg",
				children: stats.extra ? `${stats.extra} extra fragments` : "Already contiguous"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [stats.files, " files on FAT32 or exFAT."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-2",
				children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: file.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "shrink-0 text-muted",
						children: [
							file.fragments,
							" extent",
							file.fragments === 1 ? "" : "s"
						]
					})]
				}, file.id))
			})
		] }),
		error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-danger",
			children: error
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
			className: "mt-5",
			disabled: !stats.supported || stats.extra === 0 || busy,
			onClick: () => {
				if (!startJob({
					title: "Defragmenting",
					duration: 2600,
					cancellable: true,
					stages: [
						{
							until: .4,
							label: "Reading extents"
						},
						{
							until: .85,
							label: "Packing files"
						},
						{
							until: 1,
							label: "Updating the table"
						}
					],
					payload: {
						kind: "defrag",
						driveId: drive.id
					}
				})) setError("An operation is already running.");
			},
			children: "Start"
		})
	] })] });
}
function WipeTool() {
	const drive = useConnected();
	const certs = useUsb((s) => s.certs);
	const busy = useUsb((s) => !!s.job);
	const startJob = useUsb((s) => s.startJob);
	const [method, setMethod] = (0, import_react.useState)("nist");
	const [verify, setVerify] = (0, import_react.useState)("sample");
	const [armed, setArmed] = (0, import_react.useState)(false);
	const chosen = WIPE_METHODS.find((item) => item.id === method) ?? WIPE_METHODS[0];
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Wipe" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const mine = certs.filter((cert) => cert.serial === drive.serial);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Wipe" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: [
					"Secure erase clears partitions and recoverable files on ",
					drive.model,
					". You will need to format it afterwards."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex flex-col gap-2",
				children: WIPE_METHODS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setMethod(item.id),
					className: cx("w-full rounded-2xl px-3 py-3 text-left", method === item.id ? "bg-fg text-bg" : "bg-bg"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-base",
						children: item.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cx("block text-sm", method === item.id ? "text-bg/70" : "text-muted"),
						children: [
							item.passes,
							" pass",
							item.passes === 1 ? "" : "es",
							" · ",
							item.detail
						]
					})]
				}) }, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-2",
				children: [
					"off",
					"sample",
					"full"
				].map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setVerify(mode),
					className: cx("h-10 flex-1 rounded-xl text-sm", verify === mode ? "bg-fg text-bg" : "bg-bg"),
					children: mode === "off" ? "No verify" : mode === "sample" ? "Sample" : "Full"
				}, mode))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				className: "mt-5",
				disabled: busy,
				onClick: () => setArmed(true),
				children: "Wipe drive"
			})
		] }),
		mine.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-lg",
				children: "Certificates"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-col gap-3",
				children: mine.map((cert) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-2xl bg-bg px-3 py-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							cert.method,
							" · ",
							cert.passes,
							" passes · ",
							cert.verified ? "Verification passed" : "Verification failed"
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-muted",
							children: [
								drive.model,
								" · ",
								cert.serial,
								" · ",
								formatBytes(cert.bytes),
								" · ",
								formatWhen(cert.at)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seal, { seed: `${cert.serial}${cert.at}` })
					]
				}, cert.id))
			})]
		}) : null,
		armed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Erase ",
				drive.model,
				" with ",
				chosen.name,
				"? ",
				liveFileCount(drive),
				" live files will be destroyed, not just deleted."
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
					className: "flex-1",
					onClick: () => setArmed(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					className: "w-auto flex-1",
					onClick: () => {
						setArmed(false);
						startJob({
							title: "Wiping",
							duration: Math.min(9e3, 650 * chosen.passes + (verify === "full" ? 2200 : verify === "sample" ? 900 : 0)),
							cancellable: false,
							stages: wipeStages(chosen.passes, verify),
							payload: {
								kind: "wipe",
								driveId: drive.id,
								method: chosen.name,
								passes: chosen.passes,
								verify
							}
						});
					},
					children: "Erase"
				})]
			})]
		}) : null
	] });
}
function Seal({ seed }) {
	const cells = (0, import_react.useMemo)(() => {
		let h = 0;
		return Array.from({ length: 36 }, (_, i) => {
			h = h * 33 + seed.charCodeAt(i % seed.length) + i >>> 0;
			return h % 3 === 0;
		});
	}, [seed]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 grid w-24 grid-cols-6 gap-0.5",
		"aria-hidden": "true",
		children: cells.map((on, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cx("aspect-square", on ? "bg-fg" : "bg-surface") }, index))
	});
}
function BackupTool() {
	const drive = useConnected();
	const backups = useUsb((s) => s.backups);
	const busy = useUsb((s) => !!s.job);
	const startJob = useUsb((s) => s.startJob);
	const deleteBackup = useUsb((s) => s.deleteBackup);
	const [pick, setPick] = (0, import_react.useState)(null);
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Backup & Restore" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Backup & Restore" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "Images stay in this browser. Restoring replaces the connected drive's table and files."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
			className: "mt-4",
			disabled: busy,
			onClick: () => startJob({
				title: "Imaging drive",
				duration: 2e3,
				cancellable: true,
				stages: [{
					until: .6,
					label: "Reading partitions"
				}, {
					until: 1,
					label: "Saving the image"
				}],
				payload: {
					kind: "backup",
					driveId: drive.id
				}
			}),
			children: "Save image"
		})] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-4 flex flex-col gap-3",
			children: [backups.map((bak) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: bak.model }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							formatWhen(bak.at),
							" · ",
							formatBytes(bak.real),
							" · ",
							bak.table ?? "No table",
							" · ",
							bak.partitions.length,
							" volumes"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							onClick: () => setPick(bak.id),
							disabled: busy,
							children: "Restore"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							onClick: () => deleteBackup(bak.id),
							children: "Delete image"
						})]
					})
				]
			}) }, bak.id)), backups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-sm text-muted",
				children: "No images saved yet."
			}) : null]
		}),
		pick ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Replace the contents of ",
				drive.model,
				" with this image?"
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
					className: "flex-1",
					onClick: () => setPick(null),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					className: "w-auto flex-1",
					onClick: () => {
						const id = pick;
						setPick(null);
						startJob({
							title: "Restoring image",
							duration: 2400,
							cancellable: false,
							stages: [{
								until: .5,
								label: "Checking the image"
							}, {
								until: 1,
								label: "Writing partitions"
							}],
							payload: {
								kind: "restore-backup",
								driveId: drive.id,
								backupId: id
							}
						});
					},
					children: "Restore"
				})]
			})]
		}) : null
	] });
}
var SCAN_MODES = [
	{
		id: "quick",
		label: "Quick",
		hint: "Just deleted"
	},
	{
		id: "smart",
		label: "Smart",
		hint: "Named leftovers"
	},
	{
		id: "deep",
		label: "Deep",
		hint: "Lost volumes"
	},
	{
		id: "raw",
		label: "Raw",
		hint: "Carved signatures"
	}
];
function RecoverTool() {
	const drive = useConnected();
	const lastScan = useUsb((s) => s.lastScan);
	const busy = useUsb((s) => !!s.job);
	const startJob = useUsb((s) => s.startJob);
	const [mode, setMode] = (0, import_react.useState)("smart");
	const [picked, setPicked] = (0, import_react.useState)([]);
	const [preview, setPreview] = (0, import_react.useState)(null);
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Recover Files" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const files = (lastScan?.driveId === drive.id ? lastScan.ids : []).map((id) => findFile(drive, id)).filter((file) => file != null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Recover Files" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-4 gap-2",
				children: SCAN_MODES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setMode(item.id),
					className: cx("rounded-xl px-1 py-2 text-center text-sm", mode === item.id ? "bg-fg text-bg" : "bg-bg"),
					children: item.label
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted",
				children: [SCAN_MODES.find((item) => item.id === mode)?.hint, ". Preview before you write anything back."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				className: "mt-4",
				disabled: busy,
				onClick: () => {
					setPicked([]);
					startJob({
						title: "Scanning",
						duration: scanDuration(mode),
						cancellable: true,
						stages: [
							{
								until: .3,
								label: "Reading the table"
							},
							{
								until: .75,
								label: `Running a ${mode} scan`
							},
							{
								until: 1,
								label: "Listing matches"
							}
						],
						payload: {
							kind: "scan",
							driveId: drive.id,
							mode
						}
					});
				},
				children: "Start scan"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 flex flex-col gap-2",
			children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3 rounded-2xl bg-surface px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "checkbox",
					checked: picked.includes(file.id),
					onChange: () => setPicked((current) => current.includes(file.id) ? current.filter((id) => id !== file.id) : [...current, file.id]),
					"aria-label": `Select ${file.name}`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "min-w-0 flex-1 text-left",
					onClick: () => setPreview(file.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate",
						children: file.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block text-sm text-muted",
						children: [
							formatBytes(file.bytes),
							" · ",
							file.kind
						]
					})]
				})]
			}, file.id))
		}),
		lastScan?.driveId === drive.id && files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-4 text-sm text-muted",
			children: [
				"The last ",
				lastScan.mode,
				" scan found nothing on this drive."
			]
		}) : null,
		picked.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PrimaryButton, {
			className: "mt-4",
			disabled: busy,
			onClick: () => startJob({
				title: "Restoring files",
				duration: 1600,
				cancellable: false,
				stages: [{
					until: .5,
					label: "Checking free space"
				}, {
					until: 1,
					label: "Copying files back"
				}],
				payload: {
					kind: "restore-files",
					driveId: drive.id,
					ids: picked
				}
			}),
			children: ["Restore ", picked.length]
		}) : null,
		preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Preview, {
			fileId: preview,
			onClose: () => setPreview(null)
		}) : null
	] });
}
function Preview({ fileId, onClose }) {
	const drive = useConnected();
	const file = drive ? findFile(drive, fileId) : null;
	if (!file) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "mt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg",
				children: file.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					formatBytes(file.bytes),
					" · ",
					file.fragments,
					" extent",
					file.fragments === 1 ? "" : "s",
					" · found as ",
					file.recover
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed",
				children: file.preview || "No text preview. The signature matched this file type, but the bytes are not a document."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
				className: "mt-4",
				onClick: onClose,
				children: "Close preview"
			})
		]
	});
}
function LostTool() {
	const drive = useConnected();
	const busy = useUsb((s) => !!s.job);
	const startJob = useUsb((s) => s.startJob);
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Lost Partitions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Lost Partitions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [drive.lost.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-sm text-muted",
		children: [
			"No lost partitions on ",
			drive.model,
			". Deleting one in the wizard, without applying a full format, leaves it here."
		]
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "flex flex-col gap-3",
		children: drive.lost.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "rounded-2xl bg-bg px-3 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					displayLabel(part.label),
					" · ",
					part.fs
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						formatBytes(part.bytes),
						" · ",
						part.files.length,
						" files"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
					className: "mt-3",
					disabled: busy,
					onClick: () => startJob({
						title: "Restoring partition",
						duration: 1800,
						cancellable: false,
						stages: [{
							until: .5,
							label: "Checking free space"
						}, {
							until: 1,
							label: "Updating the table"
						}],
						payload: {
							kind: "restore-part",
							driveId: drive.id,
							partId: part.id
						}
					}),
					children: "Restore"
				})
			]
		}, part.id))
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-4 text-sm text-muted",
		children: [
			"Unallocated space: ",
			formatBytes(unallocated(drive)),
			"."
		]
	})] })] });
}
function BadBlocksTool() {
	const drive = useConnected();
	const job = useUsb((s) => s.job);
	const payload = useUsb((s) => s.payload);
	const busy = !!job;
	const startJob = useUsb((s) => s.startJob);
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Bad Blocks" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const scanning = payload?.kind === "badblocks" && payload.driveId === drive.id && job ? job.progress : drive.verifiedReal ? 1 : 0;
	const cells = badMap(drive);
	const shown = Math.floor(scanning * cells.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Bad Blocks" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm leading-relaxed text-muted",
			children: "One sample pass over the surface. A counterfeit stick fails when the writable size is far below the label."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 grid grid-cols-8 gap-1",
			children: cells.map((bad, index) => {
				const seen = index < shown;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cx("aspect-square rounded-sm", !seen && "bg-bg", seen && !bad && "bg-fg", seen && bad && "bg-danger"),
					title: seen ? bad ? "Bad" : "Readable" : "Unread"
				}, index);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-muted",
			children: "Light cells read back. Marked cells failed. Dark cells are still unread."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
			className: "mt-4",
			disabled: busy,
			onClick: () => startJob({
				title: "Testing blocks",
				duration: 4200,
				cancellable: true,
				stages: [
					{
						until: .45,
						label: "Writing the pattern"
					},
					{
						until: .9,
						label: "Reading it back"
					},
					{
						until: 1,
						label: "Comparing capacity"
					}
				],
				payload: {
					kind: "badblocks",
					driveId: drive.id
				}
			}),
			children: drive.verifiedReal ? "Test again" : "Start test"
		})
	] })] });
}
function BenchTool() {
	const drive = useConnected();
	const benches = useUsb((s) => s.benches);
	const job = useUsb((s) => s.job);
	const payload = useUsb((s) => s.payload);
	const busy = !!job;
	const startJob = useUsb((s) => s.startJob);
	const [write, setWrite] = (0, import_react.useState)(false);
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Benchmark" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const live = payload?.kind === "bench" && payload.driveId === drive.id && job ? payload.planned : null;
	const progress = live && job ? job.progress : 0;
	const history = benches.filter((row) => row.serial === drive.serial);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Benchmark" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cx("h-10 flex-1 rounded-xl text-sm", !write ? "bg-fg text-bg" : "bg-bg"),
					onClick: () => setWrite(false),
					children: "Read only"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cx("h-10 flex-1 rounded-xl text-sm", write ? "bg-fg text-bg" : "bg-bg"),
					onClick: () => setWrite(true),
					children: "Read and write"
				})]
			}),
			live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid grid-cols-2 gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Seq read",
						value: `${(live.seqRead * progress).toFixed(0)} MB/s`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Seq write",
						value: live.seqWrite != null ? `${(live.seqWrite * progress).toFixed(0)} MB/s` : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Random read",
						value: `${Math.round(live.randRead * progress)} IOPS`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
						label: "Random write",
						value: live.randWrite != null ? `${Math.round(live.randWrite * progress)} IOPS` : "—"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted",
				children: [
					drive.kind,
					" on ",
					drive.speed,
					". Write tests are simulated and do not erase files."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				className: "mt-4",
				disabled: busy,
				onClick: () => startJob({
					title: "Benchmark",
					duration: 3600,
					cancellable: true,
					stages: [{
						until: .5,
						label: "Sequential run"
					}, {
						until: 1,
						label: write ? "Random run" : "Random read"
					}],
					payload: {
						kind: "bench",
						driveId: drive.id,
						planned: planBench(drive, write)
					}
				}),
				children: "Start"
			})
		] }),
		history.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-4 flex flex-col gap-2",
			children: history.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-2xl bg-surface px-4 py-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: formatWhen(row.at) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						row.seqRead,
						" MB/s read",
						row.seqWrite != null ? ` · ${row.seqWrite} MB/s write` : "",
						" · ",
						row.randRead,
						" IOPS"
					]
				})]
			}, row.id))
		}) : null
	] });
}
function Meter({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-bg px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-lg tabular-nums text-fg",
			children: value
		})]
	});
}
function InfoTool() {
	const drive = useConnected();
	const logs = useUsb((s) => s.logs);
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Device Info" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const rows = [
		["Model", drive.model],
		["Vendor", drive.vendor],
		["Product", drive.product],
		["Kind", `${drive.kind} · ${drive.speed}`],
		["VID:PID", `${drive.vid}:${drive.pid}`],
		["Serial", drive.serial],
		["Block size", `${drive.blockSize} bytes`],
		["Advertised", formatBytes(drive.advertised)],
		["Writable", drive.verifiedReal ? formatBytes(drive.real) : "Run Bad Blocks to verify"],
		["Table", drive.table ?? "None"],
		["Live files", String(liveFileCount(drive))],
		["Free in volumes", formatBytes(volumeFree(drive))]
	];
	const checks = healthChecks(drive);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Device Info" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
			className: "py-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "flex flex-col",
				children: rows.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-4 border-b border-fg/10 py-2 text-sm last:border-b-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-right break-all",
						children: value
					})]
				}, label))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-lg",
				children: "Table check"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-col gap-2",
				children: checks.map((check) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: cx("text-sm", check.tone === "bad" && "text-danger", check.tone === "warn" && "text-muted"),
					children: [
						check.tone === "ok" ? "Pass" : check.tone === "warn" ? "Check" : "Fail",
						" · ",
						check.label
					]
				}, check.label))
			})]
		}),
		drive.partitions.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				displayLabel(part.label),
				" · ",
				part.fs
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					formatBytes(part.bytes),
					" · cluster ",
					formatCluster(part.cluster),
					" · used ",
					formatBytes(usedBytes(part))
				]
			})]
		}, part.id)),
		logs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-lg",
				children: "Activity"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 flex flex-col gap-2",
				children: logs.slice(0, 8).map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [formatWhen(line.at), " · "]
					}), line.text]
				}, line.id))
			})]
		}) : null
	] });
}
function Ps2Tool() {
	const ui = useUi();
	const drive = useConnected();
	const pro = useUsb((s) => s.pro);
	const tokens = useUsb((s) => s.tokens);
	const busy = useUsb((s) => !!s.job);
	const startJob = useUsb((s) => s.startJob);
	const renameLiveFile = useUsb((s) => s.renameLiveFile);
	const [renameId, setRenameId] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)(null);
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "PS2 USB Utils" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const games = gameFiles(drive);
	const cfg = drive.partitions.flatMap((part) => part.files).find((file) => file.name.toLowerCase() === "ul.cfg" && !file.deleted);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "PS2 USB Utils" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "OPL wants FAT32, MBR, and files at or under 4 GB. Bigger ISOs have to be split into USBExtreme parts."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				className: "mt-4",
				disabled: busy,
				onClick: () => setConfirm(true),
				children: "Format for PS2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
				className: "mt-3 w-full",
				onClick: () => ui.go("defrag"),
				children: "Open defragmenter"
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-4 flex flex-col gap-3",
			children: [games.map(({ file, part }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "rounded-3xl bg-surface px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "break-all",
						children: file.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							formatBytes(file.bytes),
							" · ",
							part.fs,
							file.bytes > 4294967296 && part.fs === "FAT32" ? " · over the 4 GB FAT limit" : "",
							file.fragments > 1 ? ` · ${file.fragments} fragments` : ""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							onClick: () => {
								setRenameId(file.id);
								setName(file.name);
							},
							children: "Rename"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							disabled: busy || file.bytes <= 4294967296,
							onClick: () => startJob({
								title: "Splitting image",
								duration: 2400,
								cancellable: false,
								stages: [{
									until: .7,
									label: "Cutting USBExtreme parts"
								}, {
									until: 1,
									label: "Writing ul.cfg"
								}],
								payload: {
									kind: "split",
									driveId: drive.id,
									fileId: file.id
								}
							}),
							children: "Split for OPL"
						})]
					})
				]
			}, file.id)), games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
				className: "text-sm text-muted",
				children: "No game images on this drive."
			}) : null]
		}),
		cfg?.preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-lg",
				children: "ul.cfg"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-3 overflow-x-auto text-xs leading-relaxed whitespace-pre-wrap",
				children: cfg.preview
			})]
		}) : null,
		message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-sm text-danger",
			children: message
		}) : null,
		renameId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block text-sm text-muted",
				children: ["File name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					onChange: (event) => setName(event.target.value),
					className: "mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg outline-none",
					"aria-label": "Game file name"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
					className: "flex-1",
					onClick: () => setRenameId(null),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					className: "w-auto flex-1",
					onClick: () => {
						const err = renameLiveFile(drive.id, renameId, name);
						setMessage(err);
						if (!err) setRenameId(null);
					},
					children: "Save"
				})]
			})]
		}) : null,
		confirm ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "mt-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Format ",
				drive.model,
				" as FAT32 / MBR / 32 KB, label OPL? Every file on it goes away.",
				pro ? " Pro does not spend a token." : ` This spends 1 token. You have ${tokens}.`
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
					className: "flex-1",
					onClick: () => setConfirm(false),
					children: "Cancel"
				}), !pro && tokens < 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					className: "w-auto flex-1",
					onClick: () => {
						setConfirm(false);
						ui.setTokenOpen(true);
					},
					children: "Get a token"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
					className: "w-auto flex-1",
					onClick: () => {
						setConfirm(false);
						startJob({
							title: "PS2 format",
							duration: 3400,
							cancellable: false,
							stages: [{
								until: .4,
								label: "Writing an MBR"
							}, {
								until: 1,
								label: "Formatting FAT32 for OPL"
							}],
							payload: {
								kind: "format",
								driveId: drive.id,
								fs: "FAT32",
								cluster: "32768",
								table: "MBR",
								label: "OPL",
								cost: pro ? 0 : 1
							}
						});
					},
					children: "Format"
				})]
			})]
		}) : null
	] });
}
function ConvertTool() {
	const drive = useConnected();
	const busy = useUsb((s) => !!s.job);
	const startJob = useUsb((s) => s.startJob);
	const [fileId, setFileId] = (0, import_react.useState)("");
	const [target, setTarget] = (0, import_react.useState)("chd");
	if (!drive) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Game Converter" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeedDrive, {})] });
	const files = drive.partitions.flatMap((part) => part.files.filter((file) => !file.deleted));
	const selected = fileId || files[0]?.id || "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolHeading, { title: "Game Converter" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: files.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "This volume has no files to convert."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "block text-sm text-muted",
			children: ["Source", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				value: selected,
				onChange: (event) => setFileId(event.target.value),
				className: "mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg",
				"aria-label": "File to convert",
				children: files.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: file.id,
					children: file.name
				}, file.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "mt-3 block text-sm text-muted",
			children: ["Target", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				value: target,
				onChange: (event) => setTarget(event.target.value),
				className: "mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg",
				"aria-label": "Target format",
				children: CONVERT_TARGETS.map((ext) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: ext,
					children: ext.toUpperCase()
				}, ext))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
			className: "mt-4",
			disabled: busy || !selected,
			onClick: () => startJob({
				title: "Converting",
				duration: 2200,
				cancellable: true,
				stages: [{
					until: .6,
					label: `Building ${target.toUpperCase()}`
				}, {
					until: 1,
					label: "Replacing the file"
				}],
				payload: {
					kind: "convert",
					driveId: drive.id,
					fileId: selected,
					target
				}
			}),
			children: "Convert"
		})
	] }) })] });
}
function UsbToolsApp() {
	const [screen, setScreen] = (0, import_react.useState)("format");
	const [toolsOpen, setToolsOpen] = (0, import_react.useState)(false);
	const [deviceOpen, setDeviceOpen] = (0, import_react.useState)(false);
	const [tokenOpen, setTokenOpen] = (0, import_react.useState)(false);
	const [helpOpen, setHelpOpen] = (0, import_react.useState)(false);
	const [browseOpen, setBrowseOpen] = (0, import_react.useState)(false);
	const job = useUsb((s) => s.job);
	const notice = useUsb((s) => s.notice);
	const toast = useUsb((s) => s.toast);
	const dismissNotice = useUsb((s) => s.dismissNotice);
	const clearToast = useUsb((s) => s.clearToast);
	const setProgress = useUsb((s) => s.setProgress);
	const finishJob = useUsb((s) => s.finishJob);
	const cancelJob = useUsb((s) => s.cancelJob);
	(0, import_react.useEffect)(() => {
		useUsb.persist.rehydrate();
	}, []);
	const jobId = job?.id ?? null;
	(0, import_react.useEffect)(() => {
		if (!jobId) return;
		const current = useUsb.getState().job;
		if (!current || current.id !== jobId) return;
		const started = performance.now();
		const startP = current.progress;
		const duration = Math.max(1, current.duration * (1 - startP));
		const timer = window.setInterval(() => {
			const live = useUsb.getState().job;
			if (!live || live.id !== jobId) {
				window.clearInterval(timer);
				return;
			}
			const elapsed = performance.now() - started;
			const progress = Math.min(1, startP + elapsed / duration);
			if (progress >= 1) {
				window.clearInterval(timer);
				setProgress(1);
				finishJob();
			} else setProgress(progress);
		}, 80);
		return () => window.clearInterval(timer);
	}, [
		jobId,
		finishJob,
		setProgress
	]);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const timer = window.setTimeout(() => clearToast(), 1600);
		return () => window.clearTimeout(timer);
	}, [toast, clearToast]);
	const go = (id) => {
		setScreen(id);
		setToolsOpen(false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UiContext.Provider, {
		value: {
			screen,
			go,
			setToolsOpen,
			setDeviceOpen,
			setTokenOpen,
			setHelpOpen,
			setBrowseOpen
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex h-dvh w-full max-w-md flex-col overflow-hidden bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
					screen,
					toolsOpen,
					onTools: () => setToolsOpen((open) => !open)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-h-0 flex-1 overflow-y-auto px-4 pt-1 pb-10",
					children: toolsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolsMenu, {}) : screen === "format" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormatView, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBody, { screen })
				}),
				toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pointer-events-none absolute bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-fg px-4 py-2 text-sm text-bg",
					children: toast
				}) : null,
				deviceOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceSheet, {
					onClose: () => setDeviceOpen(false),
					onBrowse: () => {
						setDeviceOpen(false);
						setBrowseOpen(true);
					}
				}) : null,
				tokenOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TokenSheet, { onClose: () => setTokenOpen(false) }) : null,
				helpOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpSheet, { onClose: () => setHelpOpen(false) }) : null,
				browseOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrowseSheet, { onClose: () => setBrowseOpen(false) }) : null,
				job ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					title: job.title,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: job.stage
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: job.progress })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-right text-sm text-muted tabular-nums",
							children: [Math.round(job.progress * 100), "%"]
						}),
						job.cancellable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							className: "mt-4 w-full",
							onClick: () => cancelJob(),
							children: "Stop"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted",
							children: "Keep this page open until the write finishes."
						})
					]
				}) : null,
				notice && !job ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					title: notice.title,
					onClose: dismissNotice,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: notice.body }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex gap-2",
						children: [notice.browse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-12 flex-1 rounded-xl bg-sunken",
							onClick: () => {
								dismissNotice();
								setBrowseOpen(true);
							},
							children: "Browse files"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-12 flex-1 rounded-xl bg-fg font-medium text-bg",
							onClick: dismissNotice,
							children: "OK"
						})]
					})]
				}) : null
			]
		})
	});
}
function Header({ screen, onTools, toolsOpen }) {
	const ui = useUi();
	const pinned = useUsb((s) => s.pinned);
	const togglePin = useUsb((s) => s.togglePin);
	const tokens = useUsb((s) => s.tokens);
	const pro = useUsb((s) => s.pro);
	const starred = !toolsOpen && pinned.includes(screen);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex items-center gap-1 px-3 pt-5 pb-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "grid size-11 shrink-0 place-items-center",
				"aria-label": "All tools",
				onClick: onTools,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, { className: "size-9" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "truncate text-xl font-semibold tracking-wide",
				children: "USB TOOLS"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-auto flex items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						"aria-label": starred ? "Unpin this tool" : "Pin this tool",
						"aria-pressed": starred,
						onClick: () => togglePin(screen),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: cx("size-6", starred && "fill-current") })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						"aria-label": "Help",
						onClick: () => ui.setHelpOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleHelp, {
							className: "size-6",
							strokeWidth: 1.75
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-11 items-center gap-1 pr-1 pl-1",
						"aria-label": pro ? "Pro unlocked. Token shop" : `${tokens} tokens. Get more`,
						onClick: () => ui.setTokenOpen(true),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-7 place-items-center rounded-full border border-fg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {
									className: "size-3.5",
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg tabular-nums",
								children: pro ? "∞" : tokens
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
								className: "size-4",
								"aria-hidden": "true"
							})
						]
					})
				]
			})
		]
	});
}
function DeviceSheet({ onClose, onBrowse }) {
	const drives = useUsb((s) => s.drives);
	const connectedId = useUsb((s) => s.connectedId);
	const connect = useUsb((s) => s.connect);
	const eject = useUsb((s) => s.eject);
	const busy = useUsb((s) => !!s.job);
	const drive = drives.find((item) => item.id === connectedId) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "USB devices",
		onClose,
		children: [
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-muted",
				children: "Wait for the current operation before swapping drives."
			}) : null,
			drive ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 rounded-2xl bg-bg px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [drive.model, " is connected"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: driveSubtitle(drive)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							onClick: () => {
								eject();
							},
							disabled: busy,
							children: "Eject"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							onClick: onBrowse,
							disabled: drive.partitions.length === 0,
							children: "Browse files"
						})]
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col",
				children: drives.map((item) => {
					const on = item.id === connectedId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-b border-fg/10 last:border-b-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: busy,
							className: "flex w-full flex-col py-3 text-left disabled:text-muted",
							onClick: () => {
								connect(item.id);
								onClose();
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-base",
								children: [item.model, on ? " · Connected" : ""]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-muted",
								children: [
									item.kind,
									" · ",
									item.speed,
									" · ",
									driveSubtitle(item)
								]
							})]
						})
					}, item.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-muted",
				children: "Virtual OTG bench. A browser cannot format a physical USB stick, so every action here runs on these drives and stays on this device."
			})
		]
	});
}
function TokenSheet({ onClose }) {
	const tokens = useUsb((s) => s.tokens);
	const pro = useUsb((s) => s.pro);
	const addTokens = useUsb((s) => s.addTokens);
	const unlockPro = useUsb((s) => s.unlockPro);
	const [until, setUntil] = (0, import_react.useState)(null);
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		if (!until) return;
		const timer = window.setInterval(() => {
			const time = Date.now();
			setNow(time);
			if (time >= until) {
				addTokens(1);
				setUntil(null);
			}
		}, 200);
		return () => window.clearInterval(timer);
	}, [until, addTokens]);
	const left = until ? Math.max(0, Math.ceil((until - now) / 1e3)) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Tokens",
		onClose: () => until ? void 0 : onClose(),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg tabular-nums",
				children: pro ? "Pro · tokens are not required" : `${tokens} token${tokens === 1 ? "" : "s"}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Format spends 1 token for FAT16 or FAT32, and 2 for the other file systems. The partition wizard spends up to 3. Everything else is free."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-2xl bg-bg px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: until ? "Demo clip. No network ad is loaded." : "Watch a short demo clip for 1 token."
					}),
					until ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, { value: 1 - left / 4 }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm tabular-nums",
							children: [left, "s"]
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
						className: "mt-3",
						disabled: !!until,
						onClick: () => setUntil(Date.now() + 4e3),
						children: until ? "Playing" : "Watch clip · +1"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-3 gap-2",
				children: [
					10,
					30,
					80
				].map((pack) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "h-16 rounded-2xl bg-bg text-sm",
					onClick: () => addTokens(pack),
					children: [
						"Add ",
						pack,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-xs text-muted",
							children: "Demo, free"
						})
					]
				}, pack))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
				className: "mt-4",
				disabled: pro,
				onClick: () => unlockPro(),
				children: pro ? "Pro is on" : "Unlock Pro"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Pro and packs are a local demo. Nothing is charged."
			})
		]
	});
}
function HelpSheet({ onClose }) {
	const resetBench = useUsb((s) => s.resetBench);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Help",
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 text-sm leading-relaxed text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-fg",
					children: "Tap the status card to plug in a bench drive. The gear opens every tool. The star pins the current tool to the top of that list."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "FAT32 is the compatible choice for consoles and TVs, with a 4 GB file limit. Use exFAT or NTFS for larger files. MBR is legacy; GPT is required past 2 TB." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The lightning counter is your token balance. Earn one with the demo clip, or add a demo pack. Pro removes token costs." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Bad Blocks reveals counterfeit capacity. Wipe offers NIST, DoD, Schneier, and Gutmann passes plus a certificate. Recover scans deleted files; Lost Partitions puts a dropped volume back." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "PS2 USB Utils splits images over 4 GB into USBExtreme parts and can format a stick as FAT32 / MBR for OPL." })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
			className: "mt-5 w-full",
			onClick: () => {
				resetBench();
				onClose();
			},
			children: "Reset bench drives"
		})]
	});
}
function BrowseSheet({ onClose }) {
	const drive = useConnected();
	const removeFile = useUsb((s) => s.removeFile);
	const renameLiveFile = useUsb((s) => s.renameLiveFile);
	const [rename, setRename] = (0, import_react.useState)(null);
	const [name, setName] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(null);
	if (!drive) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		title: "Files",
		onClose,
		children: [
			drive.partitions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "This stick has no volumes. Format it first."
			}) : null,
			drive.partitions.map((part) => {
				const live = part.files.filter((file) => !file.deleted);
				const gone = part.files.filter((file) => file.deleted).length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mb-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-sm text-muted",
							children: [
								displayLabel(part.label),
								" · ",
								part.fs,
								" · ",
								formatBytes(Math.max(0, part.bytes - usedBytes(part))),
								" free"
							]
						}),
						live.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm",
							children: "Empty volume."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2",
							children: live.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "border-b border-fg/10 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "w-full text-left",
									onClick: () => setOpen(file),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block break-all",
										children: file.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm text-muted",
										children: [formatBytes(file.bytes), file.fragments > 1 ? ` · ${file.fragments} fragments` : ""]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
										onClick: () => {
											setRename(file);
											setName(file.name);
											setError(null);
										},
										children: "Rename"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
										onClick: () => removeFile(drive.id, file.id),
										children: "Delete"
									})]
								})]
							}, file.id))
						}),
						gone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [gone, " deleted · use Recover Files."]
						}) : null
					]
				}, part.id);
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "break-all",
						children: open.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed",
						children: open.preview || "No text preview for this file."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
						className: "mt-3",
						onClick: () => setOpen(null),
						children: "Close"
					})
				]
			}) : null,
			rename ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm text-muted",
						children: ["File name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: name,
							onChange: (event) => setName(event.target.value),
							className: "mt-1 h-11 w-full rounded-xl bg-bg px-3 text-base text-fg outline-none",
							"aria-label": "Rename file"
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuietButton, {
							className: "flex-1",
							onClick: () => setRename(null),
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrimaryButton, {
							className: "w-auto flex-1",
							onClick: () => {
								const err = renameLiveFile(drive.id, rename.id, name);
								if (err) setError(err);
								else setRename(null);
							},
							children: "Save"
						})]
					})
				]
			}) : null
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsbToolsApp, {});
}
//#endregion
export { Home as component };
