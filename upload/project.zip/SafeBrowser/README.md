# Safe Browser (v2)

Private Android browser, Kotlin, Chrome-style interface (follows system dark/light mode).

## Privacy / safety
- Minimize / home / screen off -> everything erased (tabs, cookies, cache, storage, history), app returns to the start page
- Storage is also wiped at launch and exit; history exists only in RAM
- Hidden from Recent Apps, screenshots and screen recording blocked (FLAG_SECURE)
- Ad & tracker blocking (built-in list), third-party cookies blocked
- HTTPS-only mode, mixed content blocked, Google Safe Browsing on
- Fingerprint protection: WebRTC IP-leak block, canvas noise, generic WebGL vendor/renderer, battery API off, referrer limited to same-origin, DNT + Global Privacy Control
- PIN lock (PBKDF2-hashed) + fingerprint/face unlock, 5 wrong tries -> 30 s lockout
- Auto-erase when idle (1 / 5 / 15 min), shake phone to erase & exit, optional clipboard clearing
- Downloads, geolocation, camera/mic, file access, intent:/market: links all blocked
- Keyboard learning disabled in the address bar, autofill disabled in pages, no cloud backup

Only your settings (switches, idle timer, hashed PIN) are stored on the phone, never browsing data.

## Build the APK with GitHub
1. Create a GitHub repo and upload everything in this folder (keep `.github`).
2. Actions tab -> Build APK -> Run workflow (or push to `main`).
3. Download `SafeBrowser-apk` from the run's Artifacts, unzip and install the .apk.
