# Safe Browser

Private Android browser (Kotlin, no dependencies).

- Minimize / home / screen off -> everything erased, app returns to the start page
- No history saved, no cookies kept, no cache; storage also wiped on launch and exit
- Hidden from Recent Apps, screenshots blocked (FLAG_SECURE)
- Keyboard learning disabled on the address bar, downloads disabled, third-party cookies blocked

## Build the APK with GitHub
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repo -> Actions tab -> Build APK -> Run workflow (or just push to `main`).
3. When it finishes (about 3-5 minutes), open the run and download "SafeBrowser-apk" from Artifacts.
4. Unzip it and install the .apk on your phone.
