# Safe Browser: no extra rules needed
