package com.safebrowser.app

import android.app.Application
import java.io.File

/**
 * Runs every time the app process starts, before any WebView exists.
 * At that moment nothing is using the browser's data folders, so leftovers from a previous
 * session (cookies db, local storage, IndexedDB, cache...) can be deleted completely.
 */
class SafeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            File(dataDir, "app_webview").deleteRecursively()
            cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
        } catch (_: Exception) {
        }
    }
}
