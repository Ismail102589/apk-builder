package com.safebrowser.app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebViewDatabase
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

/**
 * Safe Browser: a private browser.
 *  - Nothing is written to disk on purpose (history lives only in RAM).
 *  - The moment the app leaves the screen (minimize, home, screen off) everything is wiped
 *    and the app returns to a fresh start page.
 *  - Storage is also wiped on launch and on destroy, so a crash or reboot leaves nothing behind.
 */
class MainActivity : Activity() {

    private class Tab {
        lateinit var web: WebView
        var title: String = "New tab"
        var url: String = ""
    }

    private val tabs = mutableListOf<Tab>()
    private var current: Tab? = null

    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var home: View
    private lateinit var btnTabs: TextView
    private lateinit var btnBack: TextView
    private lateinit var btnForward: TextView

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        // Hides the app from the recent-apps preview and blocks screenshots / screen recording.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        super.onCreate(null) // never restore old state
        setContentView(R.layout.activity_main)

        urlBar = findViewById(R.id.urlBar)
        progress = findViewById(R.id.progress)
        webContainer = findViewById(R.id.webContainer)
        home = findViewById(R.id.home)
        btnTabs = findViewById(R.id.btnTabs)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)

        urlBar.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || event?.keyCode == KeyEvent.KEYCODE_ENTER) {
                go(v.text.toString())
                true
            } else false
        }
        btnBack.setOnClickListener { current?.web?.let { if (it.canGoBack()) it.goBack() } }
        btnForward.setOnClickListener { current?.web?.let { if (it.canGoForward()) it.goForward() } }
        findViewById<View>(R.id.btnReload).setOnClickListener { current?.web?.reload() }
        findViewById<View>(R.id.btnWipe).setOnClickListener {
            resetAll()
            Toast.makeText(this, "Everything erased", Toast.LENGTH_SHORT).show()
        }
        btnTabs.setOnClickListener { showTabsDialog() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        wipeStorage()
        newTab()
    }

    /** App went to background (minimize, home button, screen off, switching apps): erase everything. */
    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) resetAll()
    }

    override fun onDestroy() {
        tabs.toList().forEach { destroyTab(it) }
        tabs.clear()
        wipeStorage()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val t = current ?: return
        when {
            t.web.canGoBack() -> t.web.goBack()
            tabs.size > 1 -> closeTab(t)
            else -> moveTaskToBack(true) // triggers onStop -> full wipe
        }
    }

    // ------------------------------------------------------------------ tabs

    private fun newTab(): Tab {
        val tab = Tab()
        tab.web = createWebView(tab)
        tabs.add(tab)
        showTab(tab)
        return tab
    }

    private fun showTab(tab: Tab) {
        webContainer.removeAllViews()
        webContainer.addView(tab.web)
        current = tab
        progress.visibility = View.GONE
        urlBar.clearFocus()
        updateUi()
    }

    private fun closeTab(tab: Tab) {
        val idx = tabs.indexOf(tab)
        webContainer.removeAllViews()
        destroyTab(tab)
        tabs.remove(tab)
        if (tabs.isEmpty()) newTab() else showTab(tabs[minOf(idx, tabs.size - 1)])
    }

    private fun showTabsDialog() {
        val names = tabs.mapIndexed { i, t ->
            val mark = if (t === current) "● " else ""
            "$mark${i + 1}. ${t.title.ifBlank { "New tab" }}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Tabs (${tabs.size})")
            .setItems(names) { _, i -> showTab(tabs[i]) }
            .setPositiveButton("+ New tab") { _, _ -> newTab() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "New tab")
        m.menu.add(0, 2, 1, "Close this tab")
        m.menu.add(0, 3, 2, "Erase everything now")
        m.menu.add(0, 4, 3, "Exit")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> newTab()
                2 -> current?.let { t -> closeTab(t) }
                3 -> {
                    resetAll()
                    Toast.makeText(this, "Everything erased", Toast.LENGTH_SHORT).show()
                }
                4 -> finishAndRemoveTask()
            }
            true
        }
        m.show()
    }

    // ------------------------------------------------------------------ navigation

    private fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(" ") && t.contains(".") -> "https://$t"
            else -> "https://duckduckgo.com/?q=" + Uri.encode(t)
        }
        val tab = current ?: return
        tab.url = url
        tab.web.loadUrl(url)
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
        urlBar.clearFocus()
        updateUi()
    }

    private fun updateUi() {
        val t = current ?: return
        home.visibility = if (t.url.isEmpty()) View.VISIBLE else View.GONE
        btnTabs.text = tabs.size.toString()
        btnBack.alpha = if (t.web.canGoBack()) 1f else 0.35f
        btnForward.alpha = if (t.web.canGoForward()) 1f else 0.35f
        if (!urlBar.hasFocus()) urlBar.setText(t.url)
    }

    // ------------------------------------------------------------------ WebView

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: Tab): WebView {
        val w = WebView(this)
        w.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        )
        with(w.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true // lives only for this session; wiped on exit
            cacheMode = WebSettings.LOAD_NO_CACHE
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setGeolocationEnabled(false)
            saveFormData = false
            mediaPlaybackRequiresUserGesture = true
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            if (Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            // Look like a normal mobile Chrome so sites don't break.
            userAgentString = userAgentString.replace("; wv", "").replace("Version/4.0 ", "")
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false)

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme
                return scheme != "http" && scheme != "https" // block intent:, market:, file: ...
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null) tab.url = url
                if (tab === current) {
                    progress.visibility = View.VISIBLE
                    updateUi()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (tab === current) {
                    progress.visibility = View.GONE
                    updateUi()
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tab === current) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: tab.url
            }
        }
        w.setDownloadListener { _, _, _, _, _ ->
            Toast.makeText(this, "Downloads are disabled to keep you safe", Toast.LENGTH_SHORT).show()
        }
        return w
    }

    // ------------------------------------------------------------------ wiping

    @Suppress("DEPRECATION")
    private fun destroyTab(tab: Tab) {
        try {
            tab.web.stopLoading()
            tab.web.loadUrl("about:blank")
            tab.web.clearHistory()
            tab.web.clearCache(true)
            tab.web.clearFormData()
            tab.web.removeAllViews()
            tab.web.destroy()
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun wipeStorage() {
        try {
            val cm = CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
            WebStorage.getInstance().deleteAllData()
            GeolocationPermissions.getInstance().clearAll()
            WebViewDatabase.getInstance(this).apply {
                clearHttpAuthUsernamePassword()
                clearFormData()
            }
            cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
        } catch (_: Exception) {
        }
    }

    /** Back to the exact state of a fresh launch. */
    private fun resetAll() {
        webContainer.removeAllViews()
        tabs.toList().forEach { destroyTab(it) }
        tabs.clear()
        current = null
        wipeStorage()
        urlBar.setText("")
        urlBar.clearFocus()
        newTab()
    }
}
