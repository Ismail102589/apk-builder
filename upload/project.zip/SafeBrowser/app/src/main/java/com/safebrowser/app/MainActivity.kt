package com.safebrowser.app

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputFilter
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebViewDatabase
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicInteger
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Safe Browser: a private browser with a Chrome-like interface.
 *
 *  - Nothing browsing-related is written to disk on purpose; history lives only in RAM.
 *  - The moment the app leaves the screen (minimize, home, screen off) everything is wiped and the
 *    app returns to a fresh start page. Storage is also wiped on launch and on exit.
 *  - Extra protections (all switchable in the menu): tracker/ad blocking, HTTPS-only, fingerprint and
 *    WebRTC protection, PIN / biometric lock, idle auto-erase, shake-to-panic, clipboard clearing.
 */
class MainActivity : Activity() {

    private class Tab {
        lateinit var web: WebView
        var title: String = ""
        var url: String = ""
    }

    // ---------------------------------------------------------------- state

    private lateinit var prefs: SharedPreferences
    private var adBlock = true
    private var httpsOnly = true
    private var fingerprint = true
    private var noJs = false
    private var clearClip = false
    private var shakeErase = false
    private var idleMinutes = 0
    private var desktopMode = false

    private val tabs = mutableListOf<Tab>()
    private var current: Tab? = null
    private val blockedCount = AtomicInteger(0)
    private val handler = Handler(Looper.getMainLooper())

    private var failedPins = 0
    private var lockoutUntil = 0L
    private var bioPrompted = false

    private lateinit var urlBar: EditText
    private lateinit var siteIcon: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var home: View
    private lateinit var homeStatus: TextView
    private lateinit var btnTabs: TextView
    private lateinit var tabSwitcher: View
    private lateinit var switcherTitle: TextView
    private lateinit var tabGrid: GridView
    private lateinit var lockView: View
    private lateinit var pinInput: EditText
    private lateinit var pinError: TextView

    private val baseUa: String by lazy {
        WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "")
    }

    private val idleTask = Runnable {
        resetAll()
        if (hasPin()) showLock()
        toast("Erased after inactivity")
    }

    private val sensorManager by lazy { getSystemService(Context.SENSOR_SERVICE) as SensorManager }
    private val shakeListener = object : SensorEventListener {
        private var last = 0L
        private var count = 0
        override fun onSensorChanged(event: SensorEvent?) {
            val v = event?.values ?: return
            val g = Math.sqrt((v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).toDouble()) / 9.81
            if (g > 3.0) {
                val now = SystemClock.elapsedRealtime()
                count = if (now - last < 1000) count + 1 else 1
                last = now
                if (count >= 3) {
                    count = 0
                    panic()
                }
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        // Hides the app from the recent-apps preview and blocks screenshots / screen recording.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        super.onCreate(null) // never restore old state
        if (Build.VERSION.SDK_INT >= 33) setRecentsScreenshotEnabled(false)
        prefs = getSharedPreferences("safe_settings", MODE_PRIVATE)
        loadConfig()
        setContentView(R.layout.activity_main)
        bindViews()

        wipeStorage()
        newTab()
        if (hasPin()) showLock()
    }

    override fun onResume() {
        super.onResume()
        registerShake()
        scheduleIdle()
        if (lockView.visibility == View.VISIBLE) {
            pinInput.requestFocus()
            if (!bioPrompted && Build.VERSION.SDK_INT >= 28) {
                bioPrompted = true
                promptBiometric()
            }
        }
    }

    override fun onPause() {
        sensorManager.unregisterListener(shakeListener)
        super.onPause()
    }

    /** App went to background (minimize, home, screen off, app switch): erase everything. */
    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(idleTask)
        bioPrompted = false
        if (!isChangingConfigurations) {
            resetAll()
            if (hasPin()) showLock()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(idleTask)
        tabs.toList().forEach { destroyTab(it) }
        tabs.clear()
        wipeStorage()
        super.onDestroy()
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        scheduleIdle()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val t = current
        when {
            lockView.visibility == View.VISIBLE -> moveTaskToBack(true)
            tabSwitcher.visibility == View.VISIBLE -> closeSwitcher()
            t == null -> moveTaskToBack(true)
            t.web.canGoBack() -> t.web.goBack()
            tabs.size > 1 -> closeTab(t)
            else -> moveTaskToBack(true) // triggers onStop -> full wipe
        }
    }

    // ---------------------------------------------------------------- setup

    private fun loadConfig() {
        adBlock = prefs.getBoolean("adblock", true)
        httpsOnly = prefs.getBoolean("https", true)
        fingerprint = prefs.getBoolean("fp", true)
        noJs = prefs.getBoolean("nojs", false)
        clearClip = prefs.getBoolean("clip", false)
        shakeErase = prefs.getBoolean("shake", false)
        idleMinutes = prefs.getInt("idle", 0)
    }

    private fun bindViews() {
        urlBar = findViewById(R.id.urlBar)
        siteIcon = findViewById(R.id.siteIcon)
        progress = findViewById(R.id.progress)
        webContainer = findViewById(R.id.webContainer)
        home = findViewById(R.id.home)
        homeStatus = findViewById(R.id.homeStatus)
        btnTabs = findViewById(R.id.btnTabs)
        tabSwitcher = findViewById(R.id.tabSwitcher)
        switcherTitle = findViewById(R.id.switcherTitle)
        tabGrid = findViewById(R.id.tabGrid)
        lockView = findViewById(R.id.lockView)
        pinInput = findViewById(R.id.pinInput)
        pinError = findViewById(R.id.pinError)

        urlBar.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO || event?.keyCode == KeyEvent.KEYCODE_ENTER) {
                go(v.text.toString())
                true
            } else false
        }
        urlBar.setOnFocusChangeListener { _, has ->
            if (has) {
                urlBar.setText(current?.url ?: "")
                urlBar.selectAll()
                urlBar.post { imm().showSoftInput(urlBar, InputMethodManager.SHOW_IMPLICIT) }
            } else {
                updateUrlDisplay()
            }
        }

        findViewById<View>(R.id.btnHome).setOnClickListener { goHome() }
        findViewById<View>(R.id.btnNewTab).setOnClickListener {
            newTab()
            urlBar.requestFocus()
        }
        btnTabs.setOnClickListener { openSwitcher() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        findViewById<View>(R.id.btnSwitcherNew).setOnClickListener {
            closeSwitcher()
            newTab()
            urlBar.requestFocus()
        }
        findViewById<View>(R.id.btnSwitcherWipe).setOnClickListener {
            resetAll()
            toast("Everything erased")
        }
        tabGrid.adapter = gridAdapter

        // PIN lock
        pinInput.filters = arrayOf(InputFilter.LengthFilter(8))
        pinInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                tryUnlock()
                true
            } else false
        }
        findViewById<View>(R.id.btnUnlock).setOnClickListener { tryUnlock() }
        val bio = findViewById<View>(R.id.btnBio)
        if (Build.VERSION.SDK_INT >= 28) {
            bio.setOnClickListener { promptBiometric() }
        } else {
            bio.visibility = View.GONE
        }
    }

    // ---------------------------------------------------------------- tabs

    private fun newTab(): Tab {
        val tab = Tab()
        tab.web = createWebView(tab)
        tabs.add(tab)
        showTab(tab)
        return tab
    }

    private fun showTab(tab: Tab) {
        webContainer.removeAllViews()
        webContainer.addView(tab.web)
        current = tab
        progress.visibility = View.GONE
        urlBar.clearFocus()
        updateUi()
    }

    private fun closeTab(tab: Tab) {
        val idx = tabs.indexOf(tab)
        if (idx < 0) return
        webContainer.removeAllViews()
        destroyTab(tab)
        tabs.remove(tab)
        if (tabs.isEmpty()) newTab() else showTab(tabs[minOf(idx, tabs.size - 1)])
    }

    private fun goHome() {
        val t = current ?: return
        t.url = ""
        t.title = ""
        t.web.loadUrl("about:blank")
        urlBar.clearFocus()
        updateUi()
    }

    private val gridAdapter = object : BaseAdapter() {
        override fun getCount() = tabs.size
        override fun getItem(position: Int): Any = tabs[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_tab, parent, false)
            val t = tabs[position]
            val shown = if (t.url.isEmpty()) "" else displayUrl(t.url)
            v.findViewById<TextView>(R.id.tabTitle).text =
                t.title.ifBlank { if (shown.isEmpty()) "New tab" else shown }
            v.findViewById<TextView>(R.id.tabUrl).text = shown
            v.findViewById<TextView>(R.id.tabLetter).text =
                (shown.firstOrNull() ?: 'S').uppercaseChar().toString()
            val bg = GradientDrawable()
            bg.cornerRadius = dp(14).toFloat()
            bg.setColor(getColor(R.color.card_bg))
            if (t === current) bg.setStroke(dp(2), getColor(R.color.accent))
            v.background = bg
            v.setOnClickListener {
                showTab(t)
                closeSwitcher()
            }
            v.findViewById<View>(R.id.tabClose).setOnClickListener {
                closeTab(t)
                switcherTitle.text = "${tabs.size} tabs"
                notifyDataSetChanged()
            }
            return v
        }
    }

    private fun openSwitcher() {
        imm().hideSoftInputFromWindow(urlBar.windowToken, 0)
        urlBar.clearFocus()
        switcherTitle.text = "${tabs.size} tabs"
        gridAdapter.notifyDataSetChanged()
        tabSwitcher.visibility = View.VISIBLE
    }

    private fun closeSwitcher() {
        tabSwitcher.visibility = View.GONE
    }

    private fun showMenu(anchor: View) {
        val m = PopupMenu(this, anchor)
        m.menu.add(0, 1, 0, "New tab")
        m.menu.add(0, 2, 1, "Forward")
        m.menu.add(0, 3, 2, "Refresh")
        m.menu.add(0, 4, 3, "Desktop site").apply {
            isCheckable = true
            isChecked = desktopMode
        }
        m.menu.add(0, 5, 4, "Protections")
        m.menu.add(0, 6, 5, "App lock (PIN)")
        m.menu.add(0, 7, 6, "Auto-erase timer")
        m.menu.add(0, 8, 7, "Erase everything now")
        m.menu.add(0, 9, 8, "Exit")
        m.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> {
                    newTab()
                    urlBar.requestFocus()
                }
                2 -> current?.web?.let { w -> if (w.canGoForward()) w.goForward() }
                3 -> current?.let { t -> if (t.url.isNotEmpty()) t.web.reload() }
                4 -> toggleDesktop()
                5 -> showProtections()
                6 -> showAppLockMenu()
                7 -> showIdleDialog()
                8 -> {
                    resetAll()
                    toast("Everything erased")
                }
                9 -> {
                    resetAll()
                    finishAndRemoveTask()
                }
            }
            true
        }
        m.show()
    }

    // ---------------------------------------------------------------- navigation / UI

    private fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        var url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            !t.contains(" ") && t.contains(".") -> "https://$t"
            else -> "https://duckduckgo.com/?q=" + Uri.encode(t)
        }
        if (httpsOnly && url.startsWith("http://")) url = "https://" + url.removePrefix("http://")
        val tab = current ?: return
        tab.url = url
        tab.web.loadUrl(url, mapOf("DNT" to "1", "Sec-GPC" to "1"))
        imm().hideSoftInputFromWindow(urlBar.windowToken, 0)
        urlBar.clearFocus()
        updateUi()
    }

    private fun displayUrl(url: String): String =
        url.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

    private fun updateUi() {
        val t = current ?: return
        home.visibility = if (t.url.isEmpty()) View.VISIBLE else View.GONE
        btnTabs.text = tabs.size.toString()
        if (t.url.isEmpty()) updateHomeStatus()
        updateUrlDisplay()
    }

    private fun updateUrlDisplay() {
        val t = current ?: return
        if (urlBar.hasFocus()) return
        urlBar.setText(if (t.url.isEmpty()) "" else displayUrl(t.url))
        siteIcon.setImageResource(
            when {
                t.url.startsWith("https://") -> R.drawable.ic_lock
                t.url.startsWith("http://") -> R.drawable.ic_warning
                else -> R.drawable.ic_search
            }
        )
    }

    private fun updateHomeStatus() {
        fun s(on: Boolean) = if (on) "ON" else "OFF"
        homeStatus.text = "Ads & trackers: ${s(adBlock)}  ·  blocked ${blockedCount.get()}\n" +
            "HTTPS-only: ${s(httpsOnly)}\n" +
            "Fingerprint & WebRTC protection: ${s(fingerprint)}\n" +
            "App lock: ${s(hasPin())}  ·  Idle erase: " + (if (idleMinutes > 0) "$idleMinutes min" else "OFF") + "\n" +
            "Everything is erased when you leave the app"
    }

    private fun toggleDesktop() {
        desktopMode = !desktopMode
        current?.let { t ->
            t.web.settings.userAgentString = if (desktopMode) DESKTOP_UA else baseUa
            if (t.url.isNotEmpty()) t.web.reload()
        }
    }

    // ---------------------------------------------------------------- WebView

    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView(tab: Tab): WebView {
        val w = WebView(this)
        w.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        )
        with(w.settings) {
            javaScriptEnabled = !noJs
            domStorageEnabled = true // lives only for this session; wiped on exit
            cacheMode = WebSettings.LOAD_NO_CACHE
            allowFileAccess = false
            allowContentAccess = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setGeolocationEnabled(false)
            saveFormData = false
            mediaPlaybackRequiresUserGesture = true
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            if (Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = true
            userAgentString = if (desktopMode) DESKTOP_UA else baseUa
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, false)
        if (Build.VERSION.SDK_INT >= 26) {
            w.importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        }
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                WebViewCompat.addDocumentStartJavaScript(w, Scripts.REFERRER, setOf("*"))
                if (fingerprint) WebViewCompat.addDocumentStartJavaScript(w, Scripts.FINGERPRINT, setOf("*"))
            }
        } catch (_: Exception) {
        }

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                val scheme = u.scheme
                if (scheme == "http" && httpsOnly) {
                    view?.loadUrl(u.toString().replaceFirst("http://", "https://"))
                    return true
                }
                return scheme != "http" && scheme != "https" // block intent:, market:, file: ...
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (adBlock && request != null) {
                    val host = request.url?.host
                    if (host != null && Blocklist.isBlocked(host)) {
                        blockedCount.incrementAndGet()
                        return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                    }
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null) tab.url = if (url == "about:blank") "" else url
                if (tab === current) {
                    progress.visibility = View.VISIBLE
                    updateUi()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url == "about:blank") view?.clearHistory()
                if (tab === current) {
                    progress.visibility = View.GONE
                    updateUi()
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true && tab === current) {
                    toast("Couldn't load the page" + if (httpsOnly) " (HTTPS-only mode is on)" else "")
                }
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (tab === current) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title ?: ""
            }
        }
        w.setDownloadListener { _, _, _, _, _ ->
            toast("Downloads are disabled to keep you safe")
        }
        return w
    }

    // ---------------------------------------------------------------- wiping

    @Suppress("DEPRECATION")
    private fun destroyTab(tab: Tab) {
        try {
            tab.web.stopLoading()
            tab.web.loadUrl("about:blank")
            tab.web.clearHistory()
            tab.web.clearCache(true)
            tab.web.clearFormData()
            tab.web.removeAllViews()
            tab.web.destroy()
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun wipeStorage() {
        try {
            val cm = CookieManager.getInstance()
            cm.removeAllCookies(null)
            cm.flush()
            WebStorage.getInstance().deleteAllData()
            GeolocationPermissions.getInstance().clearAll()
            WebViewDatabase.getInstance(this).apply {
                clearHttpAuthUsernamePassword()
                clearFormData()
            }
            cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
        } catch (_: Exception) {
        }
    }

    /** Back to the exact state of a fresh launch. */
    private fun resetAll() {
        closeSwitcher()
        webContainer.removeAllViews()
        tabs.toList().forEach { destroyTab(it) }
        tabs.clear()
        current = null
        blockedCount.set(0)
        desktopMode = false
        wipeStorage()
        if (clearClip) clearClipboard()
        urlBar.setText("")
        urlBar.clearFocus()
        newTab()
    }

    private fun clearClipboard() {
        try {
            val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (Build.VERSION.SDK_INT >= 28) cb.clearPrimaryClip()
            else cb.setPrimaryClip(ClipData.newPlainText("", ""))
        } catch (_: Exception) {
        }
    }

    private fun panic() {
        resetAll()
        clearClipboard()
        finishAndRemoveTask()
    }

    // ---------------------------------------------------------------- settings dialogs

    private fun showProtections() {
        val labels = arrayOf(
            "Block ads & trackers",
            "HTTPS-only mode",
            "Fingerprint & WebRTC protection",
            "Disable JavaScript (strict, breaks many sites)",
            "Clear clipboard when leaving the app",
            "Shake the phone to erase & exit"
        )
        val checked = booleanArrayOf(adBlock, httpsOnly, fingerprint, noJs, clearClip, shakeErase)
        AlertDialog.Builder(this)
            .setTitle("Protections")
            .setMultiChoiceItems(labels, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putBoolean("adblock", checked[0])
                    .putBoolean("https", checked[1])
                    .putBoolean("fp", checked[2])
                    .putBoolean("nojs", checked[3])
                    .putBoolean("clip", checked[4])
                    .putBoolean("shake", checked[5])
                    .apply()
                loadConfig()
                registerShake()
                resetAll() // new tabs pick up the new settings
                toast("Settings applied")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showIdleDialog() {
        val labels = arrayOf("Off", "After 1 minute", "After 5 minutes", "After 15 minutes")
        val values = intArrayOf(0, 1, 5, 15)
        AlertDialog.Builder(this)
            .setTitle("Auto-erase when idle")
            .setSingleChoiceItems(labels, values.indexOf(idleMinutes).coerceAtLeast(0)) { d, which ->
                prefs.edit().putInt("idle", values[which]).apply()
                idleMinutes = values[which]
                scheduleIdle()
                d.dismiss()
            }
            .show()
    }

    private fun scheduleIdle() {
        handler.removeCallbacks(idleTask)
        if (idleMinutes > 0) handler.postDelayed(idleTask, idleMinutes * 60_000L)
    }

    private fun registerShake() {
        sensorManager.unregisterListener(shakeListener)
        if (shakeErase) {
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sensorManager.registerListener(shakeListener, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    // ---------------------------------------------------------------- PIN lock

    private fun hasPin() = prefs.contains("pin_hash")

    private fun hashPin(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 20000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun savePin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", hashPin(pin, salt))
            .apply()
    }

    private fun verifyPin(pin: String): Boolean {
        val salt = Base64.decode(prefs.getString("pin_salt", "") ?: "", Base64.NO_WRAP)
        val expected = prefs.getString("pin_hash", null) ?: return false
        return hashPin(pin, salt) == expected
    }

    private fun askPin(title: String, onOk: (String) -> Unit) {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        input.imeOptions = EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
        input.filters = arrayOf(InputFilter.LengthFilter(8))
        input.gravity = Gravity.CENTER_HORIZONTAL
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(input)
            .setPositiveButton("OK") { _, _ -> onOk(input.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askNewPin() {
        askPin("Set a PIN (4-8 digits)") { p ->
            if (p.length in 4..8) {
                savePin(p)
                toast("PIN lock enabled")
            } else toast("PIN must be 4-8 digits")
        }
    }

    private fun showAppLockMenu() {
        if (!hasPin()) {
            askNewPin()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("App lock")
            .setItems(arrayOf("Change PIN", "Remove PIN")) { _, i ->
                askPin("Current PIN") { pin ->
                    if (!verifyPin(pin)) {
                        toast("Wrong PIN")
                    } else if (i == 0) {
                        askNewPin()
                    } else {
                        prefs.edit().remove("pin_hash").remove("pin_salt").apply()
                        toast("PIN lock removed")
                    }
                }
            }
            .show()
    }

    private fun showLock() {
        lockView.visibility = View.VISIBLE
        pinInput.setText("")
        pinError.text = ""
        pinInput.requestFocus()
    }

    private fun tryUnlock() {
        val now = SystemClock.elapsedRealtime()
        if (now < lockoutUntil) {
            pinError.text = "Try again in ${(lockoutUntil - now) / 1000 + 1}s"
            return
        }
        if (verifyPin(pinInput.text.toString())) {
            unlock()
        } else {
            failedPins++
            pinInput.setText("")
            if (failedPins >= 5) {
                failedPins = 0
                lockoutUntil = now + 30_000
                pinError.text = "Too many attempts. Wait 30 seconds."
            } else {
                pinError.text = "Wrong PIN"
            }
        }
    }

    private fun unlock() {
        failedPins = 0
        pinError.text = ""
        lockView.visibility = View.GONE
        imm().hideSoftInputFromWindow(pinInput.windowToken, 0)
        scheduleIdle()
    }

    @TargetApi(28)
    private fun promptBiometric() {
        try {
            val executor = mainExecutor
            val prompt = BiometricPrompt.Builder(this)
                .setTitle("Unlock Safe Browser")
                .setNegativeButton("Use PIN", executor) { _, _ -> }
                .build()
            prompt.authenticate(
                CancellationSignal(), executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        unlock()
                    }
                })
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun imm() = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    companion object {
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
    }
}
