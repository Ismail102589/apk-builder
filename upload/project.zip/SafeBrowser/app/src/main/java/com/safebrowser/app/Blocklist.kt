package com.safebrowser.app

/** Small built-in list of well-known ad / tracking / analytics hosts. Subdomains are matched too. */
object Blocklist {
    private val hosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
        "googletagmanager.com", "googletagservices.com", "adservice.google.com", "2mdn.net",
        "facebook.net", "pixel.facebook.com", "scorecardresearch.com", "quantserve.com", "quantcount.com",
        "hotjar.com", "hotjar.io", "mixpanel.com", "segment.com", "segment.io", "amplitude.com",
        "fullstory.com", "clarity.ms", "bat.bing.com", "criteo.com", "criteo.net", "taboola.com",
        "outbrain.com", "adnxs.com", "rubiconproject.com", "pubmatic.com", "openx.net", "adsrvr.org",
        "moatads.com", "krxd.net", "bluekai.com", "demdex.net", "everesttech.net", "adform.net",
        "casalemedia.com", "smartadserver.com", "amazon-adsystem.com", "yieldmo.com", "mathtag.com",
        "tiqcdn.com", "appsflyer.com", "tapad.com", "bidswitch.net", "3lift.com", "sharethrough.com",
        "ads-twitter.com", "analytics.twitter.com", "ads.linkedin.com", "analytics.tiktok.com",
        "ads.tiktok.com", "mc.yandex.ru", "hm.baidu.com", "ct.pinterest.com", "adsymptotic.com",
        "popads.net", "propellerads.com", "exoclick.com", "onclickads.net", "juicyads.com",
        "trafficjunky.net", "adcolony.com", "unityads.unity3d.com", "applovin.com", "inmobi.com",
        "mopub.com", "chartbeat.com", "chartbeat.net", "parsely.com", "crazyegg.com", "mouseflow.com",
        "luckyorange.com", "newrelic.com", "nr-data.net", "bugsnag.com", "branch.io"
    )

    fun isBlocked(host: String): Boolean {
        var h = host.lowercase()
        while (true) {
            if (h in hosts) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }
}
