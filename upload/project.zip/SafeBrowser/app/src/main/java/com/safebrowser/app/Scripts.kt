package com.safebrowser.app

/** JavaScript injected at document start (before any page script runs). */
object Scripts {

    /** Never send the full referrer to other sites. */
    const val REFERRER = """
(function () {
  try {
    var m = document.createElement('meta');
    m.name = 'referrer';
    m.content = 'same-origin';
    var add = function () {
      var h = document.head || document.documentElement;
      if (h && !m.parentNode) { h.appendChild(m); }
    };
    add();
    new MutationObserver(add).observe(document, { childList: true, subtree: true });
  } catch (e) {}
})();
"""

    /** Blocks WebRTC IP leaks and makes common fingerprinting surfaces generic or noisy. */
    const val FINGERPRINT = """
(function () {
  var def = function (obj, key, val) {
    try { Object.defineProperty(obj, key, { get: function () { return val; }, configurable: true }); } catch (e) {}
  };
  try {
    def(Navigator.prototype, 'hardwareConcurrency', 4);
    def(Navigator.prototype, 'deviceMemory', 4);
    def(Navigator.prototype, 'connection', undefined);
    def(Navigator.prototype, 'doNotTrack', '1');
    def(Navigator.prototype, 'globalPrivacyControl', true);
    Navigator.prototype.getBattery = function () {
      return Promise.reject(new DOMException('Not supported', 'NotSupportedError'));
    };
  } catch (e) {}

  // WebRTC can reveal your real local / public IP address
  ['RTCPeerConnection', 'webkitRTCPeerConnection', 'mozRTCPeerConnection', 'RTCDataChannel'].forEach(function (n) {
    try { Object.defineProperty(window, n, { value: undefined, configurable: true, writable: true }); } catch (e) {}
  });
  try {
    if (navigator.mediaDevices) {
      navigator.mediaDevices.enumerateDevices = function () { return Promise.resolve([]); };
      navigator.mediaDevices.getUserMedia = function () {
        return Promise.reject(new DOMException('Permission denied', 'NotAllowedError'));
      };
    }
  } catch (e) {}

  // Canvas fingerprinting: add invisible noise
  try {
    var origGet = CanvasRenderingContext2D.prototype.getImageData;
    CanvasRenderingContext2D.prototype.getImageData = function () {
      var d = origGet.apply(this, arguments);
      for (var i = 0; i < d.data.length; i += 4) {
        if (Math.random() < 0.02) { d.data[i] = d.data[i] ^ 1; }
      }
      return d;
    };
    var origURL = HTMLCanvasElement.prototype.toDataURL;
    HTMLCanvasElement.prototype.toDataURL = function () {
      try {
        var ctx = this.getContext('2d');
        if (ctx && this.width > 0 && this.height > 0) {
          var w = Math.min(this.width, 8), h = Math.min(this.height, 8);
          var d = origGet.call(ctx, 0, 0, w, h);
          for (var i = 0; i < d.data.length; i += 4) { d.data[i] = d.data[i] ^ (Math.random() < 0.5 ? 1 : 0); }
          ctx.putImageData(d, 0, 0);
        }
      } catch (e) {}
      return origURL.apply(this, arguments);
    };
  } catch (e) {}

  // WebGL: hide the real GPU vendor / renderer
  try {
    [window.WebGLRenderingContext, window.WebGL2RenderingContext].forEach(function (C) {
      if (!C) { return; }
      var gp = C.prototype.getParameter;
      C.prototype.getParameter = function (p) {
        if (p === 37445) { return 'Generic Vendor'; }
        if (p === 37446) { return 'Generic Renderer'; }
        return gp.apply(this, arguments);
      };
    });
  } catch (e) {}
})();
"""
}
