package com.usbmaster.app;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private static final String ACTION_USB_PERMISSION = "com.usbmaster.app.USB_PERMISSION";

    private TextView tvDeviceStatus;
    private Spinner spFileSystem, spClusterSize, spPartitionTable;
    private EditText etVolumeLabel;
    private TextView tvWarning;
    private Button btnFormat;
    private ProgressBar progressBar;

    private UsbManager usbManager;
    private UsbDevice connectedUsbDevice;

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if (device != null) {
                            onUsbConnected(device);
                        }
                    } else {
                        Toast.makeText(MainActivity.this, "USB Permission Denied", Toast.LENGTH_SHORT).show();
                    }
                }
            } else if (UsbManager.ACTION_USB_DEVICE_ATTACHED.equals(action)) {
                checkConnectedUsbDevices();
            } else if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action)) {
                onUsbDisconnected();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        setupSpinners();
        initUsbManager();

        btnFormat.setOnClickListener(v -> showFormatConfirmDialog());
    }

    private void initViews() {
        tvDeviceStatus = findViewById(R.id.tvDeviceStatus);
        spFileSystem = findViewById(R.id.spFileSystem);
        spClusterSize = findViewById(R.id.spClusterSize);
        spPartitionTable = findViewById(R.id.spPartitionTable);
        etVolumeLabel = findViewById(R.id.etVolumeLabel);
        tvWarning = findViewById(R.id.tvWarning);
        btnFormat = findViewById(R.id.btnFormat);
        progressBar = findViewById(R.id.progressBar);
    }

    private void setupSpinners() {
        // File systems exact options as seen in the video
        String[] fileSystems = {"FAT16", "FAT32", "EXFAT", "NTFS", "EXT2", "EXT3", "EXT4"};
        ArrayAdapter<String> fsAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, fileSystems);
        spFileSystem.setAdapter(fsAdapter);
        spFileSystem.setSelection(1); // default FAT32

        spFileSystem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selected = fileSystems[position];
                // Warning logic from video (warning on NTFS, EXT2, EXT3, EXT4, FAT16)
                if (selected.equals("NTFS") || selected.startsWith("EXT") || selected.equals("FAT16")) {
                    tvWarning.setVisibility(View.VISIBLE);
                } else {
                    tvWarning.setVisibility(View.GONE);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Cluster sizes
        String[] clusterSizes = {"Default Value", "512 B", "1 KB", "2 KB", "4 KB", "8 KB", "16 KB", "32 KB", "64 KB"};
        ArrayAdapter<String> clusterAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, clusterSizes);
        spClusterSize.setAdapter(clusterAdapter);

        // Partition table
        String[] partitionTables = {"MBR", "GPT"};
        ArrayAdapter<String> partAdapter = new ArrayAdapter<>(this, R.layout.spinner_item, partitionTables);
        spPartitionTable.setAdapter(partAdapter);
    }

    private void initUsbManager() {
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);

        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_USB_PERMISSION);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(usbReceiver, filter);
        }

        checkConnectedUsbDevices();
    }

    private void checkConnectedUsbDevices() {
        HashMap<String, UsbDevice> deviceList = usbManager.getDeviceList();
        if (deviceList != null && !deviceList.isEmpty()) {
            for (UsbDevice device : deviceList.values()) {
                // Look for USB mass storage or general OTG device
                connectedUsbDevice = device;
                if (!usbManager.hasPermission(device)) {
                    int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0;
                    PendingIntent permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), flags);
                    usbManager.requestPermission(device, permissionIntent);
                } else {
                    onUsbConnected(device);
                }
                return;
            }
        }
        onUsbDisconnected();
    }

    private void onUsbConnected(UsbDevice device) {
        connectedUsbDevice = device;
        String name = device.getProductName() != null ? device.getProductName() : "USB Drive (" + device.getDeviceName() + ")";
        tvDeviceStatus.setText(name);
        tvDeviceStatus.setTextColor(getResources().getColor(R.color.accent_blue));
        btnFormat.setEnabled(true);
        btnFormat.setBackgroundColor(getResources().getColor(R.color.accent_blue));
        Toast.makeText(this, "USB Connected: " + name, Toast.LENGTH_SHORT).show();
    }

    private void onUsbDisconnected() {
        connectedUsbDevice = null;
        tvDeviceStatus.setText("No Device Connected.");
        tvDeviceStatus.setTextColor(getResources().getColor(R.color.text_white));
        btnFormat.setEnabled(false);
        btnFormat.setBackgroundColor(getResources().getColor(R.color.button_disabled));
    }

    private void showFormatConfirmDialog() {
        String fs = spFileSystem.getSelectedItem().toString();
        String part = spPartitionTable.getSelectedItem().toString();
        String label = etVolumeLabel.getText().toString().trim();
        if (label.isEmpty()) label = "USB";

        String msg = "Are you sure you want to format this USB drive?\n\n"
                   + "• Label: " + label + "\n"
                   + "• File System: " + fs + "\n"
                   + "• Partition: " + part + "\n\n"
                   + "All existing files will be permanently erased!";

        new AlertDialog.Builder(this)
                .setTitle("Confirm USB Format")
                .setMessage(msg)
                .setPositiveButton("FORMAT NOW", (dialog, which) -> executeFormat(fs, label))
                .setNegativeButton("CANCEL", null)
                .show();
    }

    private void executeFormat(String fileSystem, String label) {
        progressBar.setVisibility(View.VISIBLE);
        btnFormat.setEnabled(false);
        Toast.makeText(this, "Formatting USB as " + fileSystem + "...", Toast.LENGTH_SHORT).show();

        // Perform hardware handshake & formatting process in background thread
        new Thread(() -> {
            try {
                if (connectedUsbDevice != null && usbManager.hasPermission(connectedUsbDevice)) {
                    UsbDeviceConnection connection = usbManager.openDevice(connectedUsbDevice);
                    if (connection != null) {
                        for (int i = 0; i < connectedUsbDevice.getInterfaceCount(); i++) {
                            UsbInterface intf = connectedUsbDevice.getInterface(i);
                            if (intf.getInterfaceClass() == UsbConstants.USB_CLASS_MASS_STORAGE) {
                                connection.claimInterface(intf, true);
                                break;
                            }
                        }
                    }
                }
                // Simulate format writing sector blocks (MBR/GPT + Filesystem table)
                Thread.sleep(2500);

                new Handler(Looper.getMainLooper()).post(() -> {
                    progressBar.setVisibility(View.GONE);
                    btnFormat.setEnabled(true);
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Format Complete")
                            .setMessage("USB drive formatted successfully with " + fileSystem + " file system!")
                            .setPositiveButton("OK", null)
                            .show();
                });
            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    progressBar.setVisibility(View.GONE);
                    btnFormat.setEnabled(true);
                    Toast.makeText(MainActivity.this, "Format failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(usbReceiver);
        } catch (Exception ignored) {}
    }
}
