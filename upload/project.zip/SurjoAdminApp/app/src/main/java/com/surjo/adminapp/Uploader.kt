package com.surjo.adminapp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Uploader {
    private val bad = Regex("verification|otp|\\bpin\\b|never share", RegexOption.IGNORE_CASE)

    // শুধু বিকাশ/নগদ/রকেটের "টাকা পাওয়া" SMS, কোড বা OTP নয়
    fun wanted(from: String, body: String): Boolean {
        val f = from.lowercase()
        return Config.SENDERS.any { f.contains(it) } &&
            body.contains("received", ignoreCase = true) && !bad.containsMatchIn(body)
    }

    private fun post(from: String, body: String): Boolean = try {
        val u = URL("https://firestore.googleapis.com/v1/projects/${Config.PROJECT_ID}/databases/(default)/documents/smsPayments")
        val con = u.openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true
        con.connectTimeout = 15000; con.readTimeout = 15000
        con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        val j = JSONObject().put("fields", JSONObject()
            .put("from", JSONObject().put("stringValue", from.take(60)))
            .put("content", JSONObject().put("stringValue", body.take(590)))
            .put("secret", JSONObject().put("stringValue", Config.SMS_SECRET)))
        con.outputStream.use { it.write(j.toString().toByteArray()) }
        val ok = con.responseCode in 200..299
        con.disconnect(); ok
    } catch (e: Exception) { false }

    @Synchronized fun send(c: Context, from: String, body: String) {
        flush(c)
        if (!post(from, body)) enqueue(c, from, body)
    }

    private fun prefs(c: Context) = c.getSharedPreferences("q", Context.MODE_PRIVATE)

    @Synchronized private fun enqueue(c: Context, from: String, body: String) {
        val a = JSONArray(prefs(c).getString("q", "[]"))
        a.put(JSONObject().put("f", from).put("b", body))
        prefs(c).edit().putString("q", a.toString()).apply()
    }

    // নেট না থাকলে জমে থাকা SMS পরে পাঠানো (অ্যাপ খুললে বা নতুন SMS এলে)
    @Synchronized fun flush(c: Context) {
        val a = JSONArray(prefs(c).getString("q", "[]"))
        if (a.length() == 0) return
        val left = JSONArray()
        for (n in 0 until a.length()) {
            val o = a.getJSONObject(n)
            if (!post(o.getString("f"), o.getString("b"))) left.put(o)
        }
        prefs(c).edit().putString("q", left.toString()).apply()
    }
}
