package com.surjo.adminapp

object Config {
    // অ্যাডমিন সাইটের ঠিকানা (হোস্টিং বদলালে এখানে বদলান)
    const val ADMIN_URL = "https://nimble-sunflower-1b0253.netlify.app"
    const val PROJECT_ID = "safe-top-up-c9996"
    // SmsForwarder-এ যে গোপন কোড ছিল, এটাই। এই APK কাউকে দেবেন না।
    const val SMS_SECRET = "Tz7qK2mXv9RpL4wHs8Nd"
    // প্রেরকের নামে এগুলোর কোনোটা থাকলে SMS ধরা হবে (রকেটের নাম অনিশ্চিত)
    val SENDERS = listOf("bkash", "nagad", "rocket", "16216")
}
