package com.surjo.adminapp

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import android.webkit.*
import android.widget.EditText

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS), 1)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        // অ্যাডমিন পেজের confirm/alert/prompt বক্স দেখানোর জন্য এটা জরুরি
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(v: WebView, u: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("ঠিক আছে") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onJsConfirm(v: WebView, u: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("হ্যাঁ") { _, _ -> r.confirm() }
                    .setNegativeButton("না") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onJsPrompt(v: WebView, u: String, m: String, d: String?, r: JsPromptResult): Boolean {
                val et = EditText(this@MainActivity); et.setText(d ?: "")
                AlertDialog.Builder(this@MainActivity).setMessage(m).setView(et)
                    .setPositiveButton("ঠিক আছে") { _, _ -> r.confirm(et.text.toString()) }
                    .setNegativeButton("বাতিল") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
        }
        web.loadUrl(Config.ADMIN_URL)
        Thread { Uploader.flush(this) }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
