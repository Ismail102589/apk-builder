package com.rootbox.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.text.InputType
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/** Minimal VNC (RFB 3.8, Raw encoding) client for QEMU's -vnc server. */
class VncView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private var fbW = 0
    private var fbH = 0
    private val dst = RectF()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val lock = Any()
    private val sender = Executors.newSingleThreadExecutor()
    @Volatile private var out: DataOutputStream? = null
    @Volatile private var running = false
    var onStatus: ((String) -> Unit)? = null

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    private fun status(s: String) { post { onStatus?.invoke(s) } }

    fun connect(host: String = "127.0.0.1", port: Int = 5900) {
        running = true
        thread(isDaemon = true) {
            var tries = 0
            while (running) {
                try { session(host, port) } catch (e: Exception) { status("VNC: ${e.message}") }
                if (!running) break
                tries++
                if (tries > 300) { status("VNC gave up"); break }
                Thread.sleep(2000)   // VM may still be booting: retry
            }
        }
        sender.execute { }
    }

    fun disconnect() {
        running = false
        try { out?.close() } catch (_: Exception) {}
    }

    private fun session(host: String, port: Int) {
        Socket(host, port).use { s ->
            val inp = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
            val o = DataOutputStream(BufferedOutputStream(s.getOutputStream()))
            inp.readFully(ByteArray(12))
            o.write("RFB 003.008\n".toByteArray()); o.flush()
            val n = inp.readUnsignedByte()
            if (n == 0) {
                val r = ByteArray(inp.readInt()); inp.readFully(r)
                throw IOException(String(r))
            }
            val types = ByteArray(n); inp.readFully(types)
            if (!types.contains(1.toByte())) throw IOException("VNC needs a password")
            o.writeByte(1); o.flush()
            if (inp.readInt() != 0) throw IOException("VNC auth failed")
            o.writeByte(1); o.flush()                         // ClientInit: shared
            val w = inp.readUnsignedShort()
            val h = inp.readUnsignedShort()
            inp.readFully(ByteArray(16))                      // server pixel format (ignored)
            inp.readFully(ByteArray(inp.readInt()))           // desktop name

            // SetPixelFormat: 32bpp little-endian, R<<16 G<<8 B
            o.writeByte(0); o.write(ByteArray(3))
            o.writeByte(32); o.writeByte(24); o.writeByte(0); o.writeByte(1)
            o.writeShort(255); o.writeShort(255); o.writeShort(255)
            o.writeByte(16); o.writeByte(8); o.writeByte(0); o.write(ByteArray(3))
            // SetEncodings: Raw only
            o.writeByte(2); o.writeByte(0); o.writeShort(1); o.writeInt(0)
            o.flush()

            synchronized(lock) {
                bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                fbW = w; fbH = h
            }
            out = o
            try {
                status("Connected ${w}x$h")
                request(false)
                while (running) {
                    when (inp.readUnsignedByte()) {
                        0 -> readUpdate(inp)
                        1 -> { inp.readByte(); inp.readUnsignedShort(); val c = inp.readUnsignedShort(); inp.readFully(ByteArray(c * 6)) }
                        2 -> {}
                        3 -> { inp.readFully(ByteArray(3)); inp.readFully(ByteArray(inp.readInt())) }
                        else -> throw IOException("Unknown VNC message")
                    }
                }
            } finally { out = null }
        }
    }

    private fun readUpdate(inp: DataInputStream) {
        inp.readByte()
        val nr = inp.readUnsignedShort()
        repeat(nr) {
            val x = inp.readUnsignedShort(); val y = inp.readUnsignedShort()
            val rw = inp.readUnsignedShort(); val rh = inp.readUnsignedShort()
            val enc = inp.readInt()
            if (enc != 0) throw IOException("Unsupported VNC encoding $enc")
            val rb = ByteArray(rw * 4)
            val px = IntArray(rw)
            for (row in 0 until rh) {
                inp.readFully(rb)
                for (i in 0 until rw) {
                    val j = i * 4
                    px[i] = (0xFF shl 24) or ((rb[j + 2].toInt() and 0xFF) shl 16) or
                        ((rb[j + 1].toInt() and 0xFF) shl 8) or (rb[j].toInt() and 0xFF)
                }
                synchronized(lock) { bmp?.setPixels(px, 0, rw, x, y + row, rw, 1) }
            }
        }
        postInvalidate()
        request(true)
    }

    private fun request(incremental: Boolean) {
        val o = out ?: return
        synchronized(lock) {
            o.writeByte(3); o.writeByte(if (incremental) 1 else 0)
            o.writeShort(0); o.writeShort(0); o.writeShort(fbW); o.writeShort(fbH)
            o.flush()
        }
    }

    private fun send(block: (DataOutputStream) -> Unit) {
        val o = out ?: return
        sender.execute {
            try { synchronized(lock) { block(o); o.flush() } } catch (_: Exception) {}
        }
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        if (fbW == 0) return
        val s = minOf(width.toFloat() / fbW, height.toFloat() / fbH)
        val dw = fbW * s
        val dh = fbH * s
        val l = (width - dw) / 2
        val t = (height - dh) / 2
        dst.set(l, t, l + dw, t + dh)
        synchronized(lock) { c.drawBitmap(b, null, dst, paint) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (fbW == 0) return true
        val s = minOf(width.toFloat() / fbW, height.toFloat() / fbH)
        val l = (width - fbW * s) / 2
        val t = (height - fbH * s) / 2
        val x = ((e.x - l) / s).toInt().coerceIn(0, fbW - 1)
        val y = ((e.y - t) / s).toInt().coerceIn(0, fbH - 1)
        val up = e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL
        val mask = if (up) 0 else 1
        send { o -> o.writeByte(5); o.writeByte(mask); o.writeShort(x); o.writeShort(y) }
        return true
    }

    private fun keysym(code: Int, ev: KeyEvent): Int = when (code) {
        KeyEvent.KEYCODE_DEL -> 0xFF08
        KeyEvent.KEYCODE_ENTER -> 0xFF0D
        KeyEvent.KEYCODE_TAB -> 0xFF09
        KeyEvent.KEYCODE_ESCAPE -> 0xFF1B
        KeyEvent.KEYCODE_FORWARD_DEL -> 0xFFFF
        KeyEvent.KEYCODE_DPAD_LEFT -> 0xFF51
        KeyEvent.KEYCODE_DPAD_UP -> 0xFF52
        KeyEvent.KEYCODE_DPAD_RIGHT -> 0xFF53
        KeyEvent.KEYCODE_DPAD_DOWN -> 0xFF54
        KeyEvent.KEYCODE_MOVE_HOME -> 0xFF50
        KeyEvent.KEYCODE_MOVE_END -> 0xFF57
        KeyEvent.KEYCODE_PAGE_UP -> 0xFF55
        KeyEvent.KEYCODE_PAGE_DOWN -> 0xFF56
        else -> ev.unicodeChar
    }

    private fun key(down: Boolean, sym: Int) = send { o ->
        o.writeByte(4); o.writeByte(if (down) 1 else 0); o.writeShort(0); o.writeInt(sym)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return super.onKeyDown(keyCode, event)
        val sym = keysym(keyCode, event)
        if (sym <= 0) return super.onKeyDown(keyCode, event)
        key(true, sym); return true
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) return super.onKeyUp(keyCode, event)
        val sym = keysym(keyCode, event)
        if (sym <= 0) return super.onKeyUp(keyCode, event)
        key(false, sym); return true
    }

    override fun onCheckIsTextEditor() = true

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection {
        outAttrs.inputType = InputType.TYPE_NULL
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN
        return BaseInputConnection(this, false)
    }
}
