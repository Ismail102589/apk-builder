package com.rootbox.app

import android.content.Context
import java.io.*
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

/** Controls the QEMU process. Guest: 2GB RAM, 32GB data disk. */
class QemuManager(private val ctx: Context) {
    private var proc: Process? = null

    val vmDir: File get() = File(ctx.filesDir, "vm").apply { mkdirs() }
    val runtimeDir: File get() = File(vmDir, "runtime")   // bin/ lib/ share/qemu/
    val dataDisk: File get() = File(vmDir, "data.img")
    val systemImg: File get() = File(vmDir, "system.img")
    val kernel: File get() = File(vmDir, "kernel")
    val initrd: File get() = File(vmDir, "ramdisk.img")

    private fun qemuBin(): File? {
        val a = File(runtimeDir, "bin/qemu-system-aarch64")
        if (a.exists()) return a
        val b = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")
        return if (b.exists()) b else null
    }

    fun isRunning() = proc?.isAlive == true

    fun createDisk(gb: Long = 32): String {
        if (dataDisk.exists()) return "Disk already exists (${dataDisk.length() shr 30} GB)"
        RandomAccessFile(dataDisk, "rw").use { it.setLength(gb shl 30) }  // sparse file
        return "Created ${gb}GB disk"
    }

    /** target = "runtime" (zip) or a file name inside the vm folder. */
    fun import(target: String, input: InputStream): String {
        if (target == "runtime") return unzipRuntime(input)
        val f = File(vmDir, target)
        FileOutputStream(f).use { input.copyTo(it, 1 shl 20) }
        return "Imported $target (${f.length() shr 20} MB)"
    }

    private fun unzipRuntime(input: InputStream): String {
        runtimeDir.deleteRecursively(); runtimeDir.mkdirs()
        val root = runtimeDir.canonicalPath
        var n = 0
        ZipInputStream(BufferedInputStream(input)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val f = File(runtimeDir, e.name)
                if (!f.canonicalPath.startsWith(root + File.separator)) throw IOException("Bad zip path")
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { z.copyTo(it) }
                    f.setExecutable(true, false); n++
                }
                e = z.nextEntry
            }
        }
        return "Runtime ready ($n files)"
    }

    fun start(onLine: (String) -> Unit): String? {
        if (isRunning()) return "Already running"
        val bin = qemuBin() ?: return "QEMU runtime missing. Use 'Import runtime (zip)'."
        if (!dataDisk.exists()) return "Create the 32GB disk first."
        if (!systemImg.exists()) return "system.img missing. Use 'Import system.img'."

        val args = mutableListOf(bin.absolutePath)
        val share = File(runtimeDir, "share/qemu")
        if (share.exists()) args += listOf("-L", share.absolutePath)
        args += listOf(
            "-M", "virt", "-cpu", "max", "-smp", "2", "-m", "2048",
            "-drive", "file=${systemImg.absolutePath},if=virtio,format=raw",
            "-drive", "file=${dataDisk.absolutePath},if=virtio,format=raw",
            "-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0",
            "-device", "virtio-gpu-pci",
            "-device", "virtio-keyboard-pci", "-device", "virtio-tablet-pci",
            "-display", "none", "-vnc", "127.0.0.1:0"   // screen = VNC port 5900
        )
        if (kernel.exists()) {
            args += listOf("-kernel", kernel.absolutePath)
            if (initrd.exists()) args += listOf("-initrd", initrd.absolutePath)
            args += listOf("-append", "androidboot.hardware=ranchu")
        }
        return try {
            val pb = ProcessBuilder(args).redirectErrorStream(true)
            pb.environment()["LD_LIBRARY_PATH"] = File(runtimeDir, "lib").absolutePath
            val p = pb.start()
            proc = p
            thread(isDaemon = true) {
                p.inputStream.bufferedReader().forEachLine(onLine)
                onLine("QEMU exited")
            }
            null
        } catch (e: Exception) { "Start failed: ${e.message}" }
    }

    fun stop() { proc?.destroy(); proc = null }
}
