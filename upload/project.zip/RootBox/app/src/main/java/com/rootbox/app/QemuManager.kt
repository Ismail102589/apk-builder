package com.rootbox.app

import android.content.Context
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

/** Runs Bliss OS (x86_64 Android) inside QEMU (TCG, no KVM). Guest: 2GB RAM, 32GB disk. */
class QemuManager(private val ctx: Context) {
    private var proc: Process? = null
    private val ramMb = 2048

    val vmDir: File get() = File(ctx.filesDir, "vm").apply { mkdirs() }
    val runtimeDir: File get() = File(vmDir, "runtime")   // bin/ lib/ share/qemu/
    val dataDisk: File get() = File(vmDir, "data.img")
    val iso: File get() = File(vmDir, "bliss.iso")

    fun isRunning() = proc?.isAlive == true
    fun freeGb(): Long = vmDir.usableSpace shr 30

    fun createDisk(gb: Long = 32): String {
        if (dataDisk.exists()) return "Disk already exists (${dataDisk.length() shr 30} GB)"
        RandomAccessFile(dataDisk, "rw").use { it.setLength(gb shl 30) }  // sparse file
        return "Created ${gb}GB disk"
    }

    /** target = "runtime" (zip) or "bliss.iso". */
    fun import(target: String, input: InputStream): String {
        if (target == "runtime") return unzipRuntime(input)
        val f = File(vmDir, target)
        FileOutputStream(f).use { input.copyTo(it, 1 shl 20) }
        return "Imported $target (${f.length() shr 20} MB)"
    }

    private fun unzipRuntime(input: InputStream): String {
        runtimeDir.deleteRecursively(); runtimeDir.mkdirs()
        val root = runtimeDir.canonicalPath
        var n = 0
        ZipInputStream(BufferedInputStream(input)).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val f = File(runtimeDir, e.name)
                if (!f.canonicalPath.startsWith(root + File.separator)) throw IOException("Bad zip path")
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { z.copyTo(it) }
                    f.setExecutable(true, false); n++
                }
                e = z.nextEntry
            }
        }
        return "Runtime ready ($n files)"
    }

    /** installMode = true: boot from the Bliss ISO (to install). false: boot the installed disk. */
    fun start(installMode: Boolean, onLine: (String) -> Unit): String? {
        if (isRunning()) return "Already running"
        val bin = File(runtimeDir, "bin/qemu-system-x86_64")
        if (!bin.exists()) return "QEMU runtime missing. Use 'Import runtime (zip)'."
        if (!dataDisk.exists()) return "Create the 32GB disk first."
        if (installMode && !iso.exists()) return "Bliss ISO missing. Use 'Import Bliss OS ISO'."
        bin.setExecutable(true, false)

        val args = mutableListOf(bin.absolutePath)
        val share = File(runtimeDir, "share/qemu")
        if (share.exists()) args += listOf("-L", share.absolutePath)
        args += listOf(
            "-machine", "pc",
            "-accel", "tcg,thread=multi",
            "-cpu", "max",                 // Bliss 14 x86_64-v2 needs SSE4.2/POPCNT
            "-smp", "2",
            "-m", ramMb.toString(),
            "-drive", "file=${dataDisk.absolutePath},format=raw,if=ide,index=0,media=disk"
        )
        if (installMode) args += listOf("-cdrom", iso.absolutePath, "-boot", "d")
        else args += listOf("-boot", "c")
        args += listOf(
            "-vga", "std",
            "-usb", "-device", "usb-tablet",
            "-netdev", "user,id=n0",
            "-device", "e1000,netdev=n0,romfile=",
            "-display", "none",
            "-vnc", "127.0.0.1:0"          // screen = VNC port 5900
        )
        return try {
            val pb = ProcessBuilder(args).redirectErrorStream(true)
            pb.environment()["LD_LIBRARY_PATH"] = File(runtimeDir, "lib").absolutePath
            val p = pb.start()
            proc = p
            onLine("Started QEMU (${if (installMode) "install" else "disk"} mode)")
            thread(isDaemon = true) {
                p.inputStream.bufferedReader().forEachLine(onLine)
                onLine("QEMU exited")
            }
            null
        } catch (e: Exception) { "Start failed: ${e.message}" }
    }

    fun stop() { proc?.destroy(); proc = null }
}
