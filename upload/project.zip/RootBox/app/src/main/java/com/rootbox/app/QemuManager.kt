package com.rootbox.app

import android.content.Context
import java.io.File
import java.io.RandomAccessFile
import kotlin.concurrent.thread

/** Controls the QEMU process. Guest: 2GB RAM, 32GB data disk. */
class QemuManager(private val ctx: Context) {
    private var proc: Process? = null

    val vmDir: File get() = File(ctx.filesDir, "vm").apply { mkdirs() }
    val dataDisk: File get() = File(vmDir, "data.img")
    val systemImg: File get() = File(vmDir, "system.img")  // you provide (userdebug build = has su)
    val kernel: File get() = File(vmDir, "kernel")          // optional
    val initrd: File get() = File(vmDir, "ramdisk.img")     // optional
    private val qemuBin: File get() = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")

    fun isRunning() = proc?.isAlive == true

    fun createDisk(gb: Long = 32): String {
        if (dataDisk.exists()) return "Disk already exists (${dataDisk.length() shr 30} GB)"
        RandomAccessFile(dataDisk, "rw").use { it.setLength(gb shl 30) }  // sparse file
        return "Created ${gb}GB disk"
    }

    fun start(onLine: (String) -> Unit): String? {
        if (isRunning()) return "Already running"
        if (!qemuBin.exists()) return "libqemu.so missing. Put a QEMU arm64 build at app/src/main/jniLibs/arm64-v8a/libqemu.so and rebuild."
        if (!dataDisk.exists()) return "Create the 32GB disk first."
        if (!systemImg.exists()) return "system.img missing in ${vmDir.absolutePath}"

        val args = mutableListOf(
            qemuBin.absolutePath,
            "-M", "virt", "-cpu", "max", "-smp", "2", "-m", "2048",
            "-drive", "file=${systemImg.absolutePath},if=virtio,format=raw",
            "-drive", "file=${dataDisk.absolutePath},if=virtio,format=raw",
            "-netdev", "user,id=n0", "-device", "virtio-net-pci,netdev=n0",
            "-device", "virtio-gpu-pci",
            "-device", "virtio-keyboard-pci", "-device", "virtio-tablet-pci",
            "-display", "none", "-vnc", "127.0.0.1:0"   // Step 2: our app connects here
        )
        if (kernel.exists()) {
            args += listOf("-kernel", kernel.absolutePath)
            if (initrd.exists()) args += listOf("-initrd", initrd.absolutePath)
            args += listOf("-append", "androidboot.hardware=ranchu")
        }
        return try {
            proc = ProcessBuilder(args).redirectErrorStream(true).start()
            thread(isDaemon = true) {
                proc?.inputStream?.bufferedReader()?.forEachLine(onLine)
                onLine("QEMU exited")
            }
            null
        } catch (e: Exception) { "Start failed: ${e.message}" }
    }

    fun stop() { proc?.destroy(); proc = null }
}
