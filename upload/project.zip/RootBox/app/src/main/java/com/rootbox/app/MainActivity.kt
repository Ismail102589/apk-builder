package com.rootbox.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var qemu: QemuManager
    private lateinit var logView: TextView
    private lateinit var menu: View
    private var vnc: VncView? = null
    private var pending: String? = null
    private val reqPick = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        qemu = QemuManager(this)
        menu = buildMenu()
        setContentView(menu)
    }

    private fun buildMenu(): View {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun add(v: View) = col.addView(v, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        fun btn(t: String, a: () -> Unit) = add(Button(this).apply { text = t; setOnClickListener { a() } })

        add(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val d = resources.displayMetrics.density
            addView(ImageView(context).apply { setImageResource(R.drawable.rootbox_head) }, (96 * d).toInt(), (64 * d).toInt())
            addView(TextView(context).apply { text = "  RootBox"; textSize = 28f })
        })
        add(TextView(this).apply { text = "Bliss OS (Android 11) | 2GB RAM | 32GB disk\nFree space: ${qemu.freeGb()} GB" })
        btn("1. Import runtime (zip)") { pick("runtime") }
        btn("2. Import Bliss OS ISO") { pick("bliss.iso") }
        btn("3. Create 32GB disk") { logLine(qemu.createDisk()) }
        btn("4. Install (boot from ISO)") { go(true) }
        btn("5. Start (boot from disk)") { go(false) }
        btn("Show screen") { showScreen() }
        btn("Install guide") { guide() }
        btn("Stop") { qemu.stop(); logLine("Stopped") }
        logView = TextView(this).apply { text = "Files folder:\n${qemu.vmDir.absolutePath}" }
        add(logView)
        return ScrollView(this).apply { addView(col) }
    }

    private fun logLine(s: String) { logView.append("\n$s") }

    private fun go(install: Boolean) {
        val err = qemu.start(install) { line -> runOnUiThread { logLine(line) } }
        if (err != null) logLine(err) else showScreen()
    }

    private fun guide() {
        AlertDialog.Builder(this)
            .setTitle("Install guide")
            .setMessage(GUIDE)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun pick(target: String) {
        pending = target
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, reqPick)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val target = pending ?: return
        logLine("Importing $target ... (big files take time)")
        thread {
            val msg = try {
                contentResolver.openInputStream(uri)!!.use { qemu.import(target, it) }
            } catch (e: Exception) { "Import failed: ${e.message}" }
            runOnUiThread { logLine(msg) }
        }
    }

    private fun showScreen() {
        vnc?.disconnect()
        val v = VncView(this)
        vnc = v
        v.onStatus = { logLine(it) }
        v.connect()

        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun key(label: String, vararg syms: Int) {
            bar.addView(Button(this).apply {
                text = label
                setOnClickListener { v.combo(*syms) }
            })
        }
        bar.addView(Button(this).apply {
            text = "Keyboard"
            setOnClickListener {
                v.requestFocus()
                val imm = this@MainActivity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
            }
        })
        key("Esc", 0xFF1B); key("Tab", 0xFF09); key("Enter", 0xFF0D)
        key("Up", 0xFF52); key("Down", 0xFF54); key("Left", 0xFF51); key("Right", 0xFF53)
        key("F10", 0xFFC7); key("Ctrl+X", 0xFFE3, 0x78); key("Ctrl+C", 0xFFE3, 0x63)
        key("Del", 0xFFFF)
        val scroll = HorizontalScrollView(this).apply { addView(bar) }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(v, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(scroll, LinearLayout.LayoutParams(-1, -2))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(root)
        v.requestFocus()
    }

    @Deprecated("kept simple")
    override fun onBackPressed() {
        if (vnc != null) {
            vnc?.disconnect(); vnc = null
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            setContentView(menu)
        } else super.onBackPressed()
    }

    override fun onDestroy() {
        vnc?.disconnect()
        if (isFinishing) qemu.stop()
        super.onDestroy()
    }

    companion object {
        const val GUIDE = "প্রথমবার install (Bliss OS docs অনুযায়ী):\n\n" +
            "1) Runtime আর Bliss ISO import করুন, 32GB disk বানান।\n" +
            "2) \"Install (boot from ISO)\" চাপুন। GRUB menu আসতে কয়েক মিনিট লাগতে পারে।\n" +
            "3) \"Installation\" লাইনে গিয়ে e চাপুন (Keyboard button দিয়ে)। linux দিয়ে শুরু লাইনের শেষে লিখুন:\n" +
            "   nomodeset VIRT_WIFI=1\n" +
            "   তারপর Ctrl+X (বা F10)।\n" +
            "4) Installer-এ: Detect devices, Create/Modify partitions, New, Primary, Bootable, Write, Quit। তারপর partition বেছে ext4 format করুন। GRUB install: Yes। /system writable: Yes।\n" +
            "5) শেষ হলে Stop চাপুন, তারপর \"Start (boot from disk)\"।\n\n" +
            "Root: শুধু install করা system-এ কাজ করে, Live mode-এ না।\n" +
            "খুব ধীর হবে। Screen কালো থাকলে অপেক্ষা করুন।"
    }
}
