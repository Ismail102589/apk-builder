package com.rootbox.app

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var qemu: QemuManager
    private lateinit var log: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        qemu = QemuManager(this)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun add(v: android.view.View) = col.addView(v, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        add(TextView(this).apply { text = "RootBox"; textSize = 28f })
        add(TextView(this).apply { text = "Virtual Android | 2GB RAM | 32GB disk | root (su)" })
        add(Button(this).apply {
            text = "1. Create 32GB disk"
            setOnClickListener { log(qemu.createDisk()) }
        })
        add(Button(this).apply {
            text = "2. Start virtual Android"
            setOnClickListener { qemu.start { line -> runOnUiThread { log(line) } }?.let { log(it) } }
        })
        add(Button(this).apply {
            text = "Stop"
            setOnClickListener { qemu.stop(); log("Stopped") }
        })
        log = TextView(this).apply { text = "Files go here:\n${qemu.vmDir.absolutePath}" }
        add(ScrollView(this).apply { addView(log) })
        setContentView(col)
    }

    private fun log(s: String) { log.append("\n$s") }
    override fun onDestroy() { qemu.stop(); super.onDestroy() }
}
