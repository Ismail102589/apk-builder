package com.rootbox.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var qemu: QemuManager
    private lateinit var logView: TextView
    private lateinit var menu: View
    private var vnc: VncView? = null
    private var pending: String? = null
    private val reqPick = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        qemu = QemuManager(this)
        menu = buildMenu()
        setContentView(menu)
    }

    private fun buildMenu(): View {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun add(v: View) = col.addView(v, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        fun btn(t: String, a: () -> Unit) = add(Button(this).apply { text = t; setOnClickListener { a() } })

        add(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val d = resources.displayMetrics.density
            addView(ImageView(context).apply { setImageResource(R.drawable.rootbox_head) }, (96 * d).toInt(), (64 * d).toInt())
            addView(TextView(context).apply { text = "  RootBox"; textSize = 28f })
        })
        add(TextView(this).apply { text = "Virtual Android | 2GB RAM | 32GB disk | root" })
        btn("1. Import runtime (zip)") { pick("runtime") }
        btn("2. Import system.img") { pick("system.img") }
        btn("    Import kernel (optional)") { pick("kernel") }
        btn("    Import ramdisk.img (optional)") { pick("ramdisk.img") }
        btn("3. Create 32GB disk") { logLine(qemu.createDisk()) }
        btn("4. Start virtual Android") {
            val err = qemu.start { line -> runOnUiThread { logLine(line) } }
            if (err != null) logLine(err) else showScreen()
        }
        btn("Show screen") { showScreen() }
        btn("Stop") { qemu.stop(); logLine("Stopped") }
        logView = TextView(this).apply { text = "Files folder:\n${qemu.vmDir.absolutePath}" }
        add(logView)
        return ScrollView(this).apply { addView(col) }
    }

    private fun logLine(s: String) { logView.append("\n$s") }

    private fun pick(target: String) {
        pending = target
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, reqPick)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val target = pending ?: return
        logLine("Importing $target ... (big files take time)")
        thread {
            val msg = try {
                contentResolver.openInputStream(uri)!!.use { qemu.import(target, it) }
            } catch (e: Exception) { "Import failed: ${e.message}" }
            runOnUiThread { logLine(msg) }
        }
    }

    private fun showScreen() {
        vnc?.disconnect()
        val v = VncView(this)
        vnc = v
        v.onStatus = { logLine(it) }
        v.connect()
        val root = FrameLayout(this)
        root.addView(v, FrameLayout.LayoutParams(-1, -1))
        val kb = Button(this).apply {
            text = "Keyboard"
            setOnClickListener {
                v.requestFocus()
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
            }
        }
        root.addView(kb, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.BOTTOM))
        setContentView(root)
        v.requestFocus()
    }

    @Deprecated("kept simple")
    override fun onBackPressed() {
        if (vnc != null) {
            vnc?.disconnect(); vnc = null
            setContentView(menu)
        } else super.onBackPressed()
    }

    override fun onDestroy() {
        vnc?.disconnect()
        qemu.stop()
        super.onDestroy()
    }
}
