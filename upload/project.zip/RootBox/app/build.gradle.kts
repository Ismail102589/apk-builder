plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.rootbox.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.rootbox.app"
        minSdk = 29
        targetSdk = 29   // 29 keeps exec-from-app-data rules simplest for Step 1
        versionCode = 1
        versionName = "0.1"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    packaging { jniLibs { useLegacyPackaging = true } }  // extracts libqemu.so so we can exec it
    kotlinOptions { jvmTarget = "17" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
