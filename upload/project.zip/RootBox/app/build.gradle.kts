plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.rootbox.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.rootbox.app"
        minSdk = 26
        targetSdk = 28   // Android 10+ blocks running binaries from app storage if target >= 29
        versionCode = 3
        versionName = "0.3"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
    kotlinOptions { jvmTarget = "17" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
