#!/usr/bin/env python3
"""Builds the QEMU runtime (x86_64 system emulator for Android arm64) from Termux packages.
Output folder: runtime/  (bin/ lib/ share/qemu/)  - no symlinks, ready to import in RootBox."""
import os, re, shutil, subprocess, sys, urllib.request

BASES = ["https://packages.termux.dev/apt/termux-main",
         "https://packages-cf.termux.dev/apt/termux-main"]
WANT = ["qemu-system-x86-64-headless", "qemu-common", "seabios"]
SKIP = {"bash", "termux-tools", "termux-exec", "termux-keyring", "termux-licenses",
        "dash", "coreutils", "busybox", "apt", "dpkg"}
SYSTEM_LIBS = {"libc.so", "libm.so", "libdl.so", "liblog.so", "libandroid.so", "libstdc++.so",
               "libEGL.so", "libGLESv2.so", "libvulkan.so", "libnativewindow.so",
               "libvndksupport.so", "libOpenSLES.so", "libjnigraphics.so", "libmediandk.so"}
REQUIRED_SHARE = ["bios-256k.bin", "vgabios-stdvga.bin"]
WORK = "work"


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "RootBox-build"})
    return urllib.request.urlopen(req, timeout=180).read()


def load_index():
    for base in BASES:
        try:
            data = fetch(base + "/dists/stable/main/binary-aarch64/Packages").decode("utf-8", "replace")
            print("package index from", base, "bytes:", len(data))
            return base, data
        except Exception as e:
            print("index failed:", base, e)
    sys.exit("ERROR: cannot download the Termux package index")


def parse(data):
    pk = {}
    for block in data.split("\n\n"):
        d = {m.group(1): m.group(2) for m in re.finditer(r"^([A-Za-z0-9-]+): (.*)$", block, re.M)}
        if "Package" in d and "Filename" in d:
            pk[d["Package"]] = d
    return pk


def clean(name):
    return re.sub(r"\s*\(.*\)", "", name).strip()


def needed(path):
    out = subprocess.run(["readelf", "-d", path], capture_output=True, text=True).stdout
    return re.findall(r"Shared library: \[(.+?)\]", out)


def main():
    base, data = load_index()
    pk = parse(data)
    print("packages in index:", len(pk))
    prov = {}
    for n, d in pk.items():
        for p in d.get("Provides", "").split(","):
            p = clean(p)
            if p:
                prov.setdefault(p, n)

    want = list(WANT)
    if want[0] not in pk and "qemu-system-x86-64" in pk:
        want[0] = "qemu-system-x86-64"
    if want[0] not in pk:
        print("qemu-like packages:", [n for n in pk if n.startswith("qemu")])
        sys.exit("ERROR: no x86_64 QEMU package found in Termux repo")

    seen, todo = [], list(want)
    while todo:
        n = todo.pop()
        n = n if n in pk else prov.get(n, n)
        if n in seen or n in SKIP:
            continue
        if n not in pk:
            print("not in repo (skipped):", n)
            continue
        seen.append(n)
        for part in pk[n].get("Depends", "").split(","):
            nm = clean(part.split("|")[0])
            if nm:
                todo.append(nm)
    print("packages to download:", len(seen), seen)

    shutil.rmtree(WORK, ignore_errors=True)
    os.makedirs(WORK + "/debs"); os.makedirs(WORK + "/root")
    for n in seen:
        fn = pk[n]["Filename"]
        path = WORK + "/debs/" + os.path.basename(fn)
        with open(path, "wb") as f:
            f.write(fetch(base + "/" + fn))
        subprocess.check_call(["dpkg-deb", "-x", path, WORK + "/root"])

    usr = WORK + "/root/data/data/com.termux/files/usr"
    binary = usr + "/bin/qemu-system-x86_64"
    if not os.path.exists(binary):
        sys.exit("ERROR: qemu-system-x86_64 not found after extract. bin has: " +
                 str(os.listdir(usr + "/bin"))[:500])

    libs = {}
    for name in os.listdir(usr + "/lib"):
        p = os.path.join(usr, "lib", name)
        if os.path.isfile(p):
            libs[name] = os.path.realpath(p)

    shutil.rmtree("runtime", ignore_errors=True)
    os.makedirs("runtime/bin"); os.makedirs("runtime/lib")
    shutil.copy2(binary, "runtime/bin/qemu-system-x86_64")

    queue, done, missing = needed(binary), set(), set()
    while queue:
        n = queue.pop()
        if n in done:
            continue
        done.add(n)
        if n in SYSTEM_LIBS:
            continue
        src = libs.get(n)
        if not src:
            missing.add(n)
            continue
        shutil.copy2(src, os.path.join("runtime/lib", n))
        queue += needed(src)
    if missing:
        sys.exit("ERROR: missing libraries: " + ", ".join(sorted(missing)))

    share = usr + "/share/qemu"
    if os.path.isdir(share):
        shutil.copytree(share, "runtime/share/qemu", symlinks=False, ignore_dangling_symlinks=True)
    for f in REQUIRED_SHARE:
        if not os.path.exists("runtime/share/qemu/" + f):
            have = os.listdir("runtime/share/qemu") if os.path.isdir("runtime/share/qemu") else []
            sys.exit("ERROR: missing firmware file %s. share/qemu has: %s" % (f, have))

    total = sum(os.path.getsize(os.path.join(d, f)) for d, _, fs in os.walk("runtime") for f in fs)
    print("OK. runtime size: %.1f MB, libs: %d" % (total / 1e6, len(os.listdir("runtime/lib"))))


main()
