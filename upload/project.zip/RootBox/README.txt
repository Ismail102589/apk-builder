RootBox v0.2
Build: push this folder to GitHub (Actions builds the APK) or open in Android Studio.

In the app:
 1. Import runtime (zip): a zip with  bin/qemu-system-aarch64  lib/*.so  share/qemu/*  (no symlinks)
 2. Import system.img: RAW image (not sparse). Use a userdebug build so 'su' exists.
 3. Create 32GB disk, then Start. Screen shows via built-in VNC viewer. Back = menu.
