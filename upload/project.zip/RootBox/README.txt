RootBox - Step 1
1. Open this folder in Android Studio (let it sync).
2. Put a QEMU aarch64 build (executable) as: app/src/main/jniLibs/arm64-v8a/libqemu.so
3. Build > Build APK, install.
4. Copy a userdebug Android system.img (has su) to the vm folder shown in the app.
