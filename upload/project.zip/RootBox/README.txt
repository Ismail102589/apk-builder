RootBox v0.3  (Bliss OS Android 11 inside QEMU)

GitHub Actions makes two downloads (Actions tab > latest run > Artifacts):
  RootBox-apk      -> unzip, install the .apk
  RootBox-runtime  -> keep as a .zip, import it in the app ("1. Import runtime")

Also download the Bliss OS ISO yourself (blissos.org):
  Bliss OS 14.10.x (x86_64-v2) with GApps & Android Go   (Android 11, lighter, Play Store)

In the app: import runtime, import ISO, create disk, Install, follow "Install guide".
