package com.usbtools.app

import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { App() }
        }
    }
}

data class Tool(val id: String, val title: String, val desc: String)
data class Cat(val name: String, val desc: String, val tools: List<Tool>)

val CATS = listOf(
    Cat(
        "Disk Management",
        "Prepare and look after your USB drive: format it, split it into partitions, wipe it, back it up and more.",
        listOf(
            Tool("format", "Format USB", "Format USB Stick Support FAT16, FAT32, exFAT, NTFS, Ext2, Ext3, Ext4"),
            Tool("partition", "Partition Wizard", "Advanced partition management for USB devices"),
            Tool("defrag", "USB Defragmenter", "Optimizes FAT32 and exFAT drives to improve performance and compatibility."),
            Tool("wipe", "Wipe USB", "Delete all files in the selected USB folder.\n(All data will be deleted)"),
            Tool("backup", "Backup", "Backup full copy from USB device."),
            Tool("restore", "Restore", "Restore the backup copy to USB device.")
        )
    ),
    Cat(
        "Data Recovery",
        "Get back deleted or lost files, and bring back lost partitions.",
        listOf(
            Tool("undelete", "File Recovery", "Recover deleted files."),
            Tool("partrec", "Partition Recovery", "Bring back lost partitions.")
        )
    ),
    Cat(
        "Gaming Tools",
        "Put games on a USB drive for game consoles, and convert game files.",
        listOf(
            Tool("game1", "Game Drive Setup", "Prepare USB drive for game consoles."),
            Tool("game2", "Convert Game Files", "Convert game file formats."),
            Tool("game3", "Console Format Guide", "Which format each console needs.")
        )
    ),
    Cat(
        "Diagnostics & Info",
        "Check your USB drive: see its details, measure its speed and test it for bad areas.",
        listOf(
            Tool("info", "USB Device Info", "Show connected USB devices (VID, PID, class)."),
            Tool("speed", "Speed Test", "Measure read / write speed of the selected USB folder."),
            Tool("bad", "Bad Area Test", "Write and verify test data to detect errors.")
        )
    )
)

private val NEEDS_FOLDER = setOf("wipe", "backup", "restore", "speed", "bad")
private val CARD = Color(0xFF212121)
private val ITEM = Color(0xFF2A2A2A)

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tree by remember { mutableStateOf<Uri?>(null) }
    var log by remember { mutableStateOf("Ready. আগে 'Select USB folder' চাপুন।") }
    var busy by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }
    val expanded = remember { mutableStateMapOf<String, Boolean>() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            tree = uri
            log = "Selected:\n$uri"
        }
    }

    fun runBg(block: () -> String) {
        busy = true
        log = "Working..."
        scope.launch {
            log = withContext(Dispatchers.IO) {
                try { block() } catch (e: Exception) { "Error: ${e.message}" }
            }
            busy = false
        }
    }

    fun run(id: String) {
        if (busy) return
        if (id == "info") { log = Ops.info(ctx); return }
        val t = tree
        if (id in NEEDS_FOLDER && t == null) { log = "আগে USB folder select করুন।"; return }
        when (id) {
            "wipe" -> confirmWipe = true
            "speed" -> runBg { Ops.speed(ctx, t!!) }
            "bad" -> runBg { Ops.badTest(ctx, t!!) }
            "backup" -> runBg { Ops.backup(ctx, t!!) }
            "restore" -> runBg { Ops.restore(ctx, t!!) }
            else -> log = "এই ফিচারে low-level disk access (root) লাগে। Non-root Android এ এটা করা সম্ভব না।"
        }
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("Wipe USB?") },
            text = { Text("Selected folder-এর সব file মুছে যাবে। এটা undo করা যায় না।") },
            confirmButton = {
                TextButton(onClick = {
                    confirmWipe = false
                    val t = tree!!
                    runBg { Ops.wipe(ctx, t) }
                }) { Text("Wipe") }
            },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Cancel") } }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF1A1A1A))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(16.dp)
    ) {
        Text("USB TOOLS", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { picker.launch(null) }) { Text("Select USB folder") }
            Spacer(Modifier.width(12.dp))
            if (busy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
        }
        Spacer(Modifier.height(10.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 140.dp)
                .background(CARD, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) { Text(log, color = Color(0xFFB0FFB0), fontSize = 13.sp) }
        Spacer(Modifier.height(10.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(CATS) { cat ->
                val open = expanded[cat.name] ?: (cat.name == "Disk Management")
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(CARD, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { expanded[cat.name] = !open },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cat.name, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Color.White, modifier = Modifier.weight(1f))
                        Text("${cat.tools.size}  ${if (open) "▲" else "▼"}", color = Color.LightGray)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(cat.desc, color = Color.LightGray, fontSize = 14.sp)
                    if (open) {
                        cat.tools.forEach { tool ->
                            Spacer(Modifier.height(10.dp))
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .background(ITEM, RoundedCornerShape(14.dp))
                                    .clickable { run(tool.id) }
                                    .padding(14.dp)
                            ) {
                                Text(tool.title, fontSize = 18.sp, fontWeight = FontWeight.Medium, color = Color.White)
                                Text(tool.desc, fontSize = 13.sp, color = Color(0xFFDDDDDD))
                            }
                        }
                    }
                }
            }
        }
    }
}

object Ops {
    fun info(ctx: Context): String {
        val m = ctx.getSystemService(Context.USB_SERVICE) as UsbManager
        val l = m.deviceList.values
        if (l.isEmpty()) return "কোনো USB device পাওয়া যায়নি। OTG cable দিয়ে লাগান।"
        return l.joinToString("\n\n") {
            "Device: ${it.deviceName}\n" +
                "VID:PID = %04X:%04X\n".format(it.vendorId, it.productId) +
                "Class: ${it.deviceClass}\nInterfaces: ${it.interfaceCount}"
        }
    }

    private fun root(ctx: Context, uri: Uri) =
        DocumentFile.fromTreeUri(ctx, uri) ?: throw IllegalStateException("Folder খোলা যায়নি")

    fun speed(ctx: Context, uri: Uri): String {
        val f = root(ctx, uri).createFile("application/octet-stream", "usbtools_speed.tmp")
            ?: return "Test file বানানো যায়নি (write permission?)"
        val buf = ByteArray(1 shl 20) { it.toByte() }
        val mb = 64
        var t = System.nanoTime()
        ctx.contentResolver.openOutputStream(f.uri)!!.use { o ->
            repeat(mb) { o.write(buf) }
            o.flush()
        }
        val w = mb / ((System.nanoTime() - t) / 1e9)
        t = System.nanoTime()
        var total = 0L
        ctx.contentResolver.openInputStream(f.uri)!!.use { i ->
            val b = ByteArray(1 shl 20)
            while (true) {
                val n = i.read(b)
                if (n < 0) break
                total += n
            }
        }
        val r = (total / 1048576.0) / ((System.nanoTime() - t) / 1e9)
        f.delete()
        return "Write: %.1f MB/s\nRead: %.1f MB/s\n(Test size: $mb MB)".format(w, r)
    }

    fun badTest(ctx: Context, uri: Uri): String {
        val f = root(ctx, uri).createFile("application/octet-stream", "usbtools_bad.tmp")
            ?: return "Test file বানানো যায়নি"
        val mb = 32
        val pattern = ByteArray(1 shl 20) { (it * 31 + 7).toByte() }
        ctx.contentResolver.openOutputStream(f.uri)!!.use { o ->
            repeat(mb) { o.write(pattern) }
            o.flush()
        }
        var bad = 0
        var blocks = 0
        ctx.contentResolver.openInputStream(f.uri)!!.use { i ->
            val b = ByteArray(1 shl 20)
            while (true) {
                var read = 0
                while (read < b.size) {
                    val n = i.read(b, read, b.size - read)
                    if (n < 0) break
                    read += n
                }
                if (read == 0) break
                blocks++
                if (read != b.size || !b.contentEquals(pattern)) bad++
                if (read < b.size) break
            }
        }
        f.delete()
        return if (bad == 0 && blocks == mb) "OK: $blocks/$mb MB block ঠিক আছে, error নেই।"
        else "সমস্যা পাওয়া গেছে: $bad টি bad block ($blocks/$mb checked)"
    }

    private fun backupDir(ctx: Context) = File(ctx.getExternalFilesDir(null), "backup")

    private fun copyOut(ctx: Context, src: DocumentFile, dst: File): Int {
        var n = 0
        dst.mkdirs()
        for (c in src.listFiles()) {
            val name = c.name ?: continue
            if (c.isDirectory) n += copyOut(ctx, c, File(dst, name))
            else {
                ctx.contentResolver.openInputStream(c.uri)?.use { i ->
                    File(dst, name).outputStream().use { o -> i.copyTo(o) }
                }
                n++
            }
        }
        return n
    }

    private fun copyIn(ctx: Context, src: File, dst: DocumentFile): Int {
        var n = 0
        for (c in src.listFiles() ?: emptyArray()) {
            if (c.isDirectory) {
                val d = dst.findFile(c.name)?.takeIf { it.isDirectory } ?: dst.createDirectory(c.name)
                if (d != null) n += copyIn(ctx, c, d)
            } else {
                dst.findFile(c.name)?.delete()
                val f = dst.createFile("application/octet-stream", c.name)
                if (f != null) {
                    ctx.contentResolver.openOutputStream(f.uri)?.use { o ->
                        c.inputStream().use { it.copyTo(o) }
                    }
                    n++
                }
            }
        }
        return n
    }

    fun backup(ctx: Context, uri: Uri): String {
        val dir = backupDir(ctx)
        dir.deleteRecursively()
        val n = copyOut(ctx, root(ctx, uri), dir)
        return "Backup শেষ: $n টি file\nLocation: ${dir.absolutePath}"
    }

    fun restore(ctx: Context, uri: Uri): String {
        val dir = backupDir(ctx)
        if (!dir.exists()) return "কোনো backup নেই। আগে Backup করুন।"
        val n = copyIn(ctx, dir, root(ctx, uri))
        return "Restore শেষ: $n টি file"
    }

    fun wipe(ctx: Context, uri: Uri): String {
        var n = 0
        for (c in root(ctx, uri).listFiles()) if (c.delete()) n++
        return "Wipe শেষ: $n টি item মোছা হয়েছে।"
    }
}
