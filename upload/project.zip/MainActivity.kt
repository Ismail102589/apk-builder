package com.example.privatebrowser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebViewDatabase
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

/**
 * সবসময় "ইনকগনিটো" ব্রাউজার।
 * অ্যাপ মিনিমাইজ / স্ক্রিন অফ / বন্ধ হলেই (onStop) সব ট্যাব, কুকি, ক্যাশ, হিস্টরি মুছে যায়।
 * ফিরে এলে (onStart) একদম নতুন হোমপেজ।
 */
class MainActivity : AppCompatActivity() {

    private val homeUrl = "https://www.google.com" // ইচ্ছামতো বদলান

    private val tabs = mutableListOf<WebView>()
    private var current: WebView? = null

    private lateinit var container: FrameLayout
    private lateinit var urlBar: EditText
    private lateinit var tabBtn: Button
    private lateinit var progress: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Recent apps-এ পেজের স্ক্রিনশট দেখাবে না (স্ক্রিনশট নেওয়াও বন্ধ থাকবে)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val backBtn = Button(this).apply {
            text = "◀"
            setOnClickListener { current?.takeIf { it.canGoBack() }?.goBack() }
        }
        urlBar = EditText(this).apply {
            hint = "সার্চ করুন বা ঠিকানা লিখুন"
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_VARIATION_URI or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            // কীবোর্ড যেন টাইপ করা শব্দ শিখে না রাখে
            imeOptions = EditorInfo.IME_ACTION_GO or EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO
            setOnEditorActionListener { _, _, _ -> openFromBar(text.toString()); true }
        }
        tabBtn = Button(this).apply {
            text = "1"
            setOnClickListener { showTabs() }
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(backBtn)
            addView(urlBar, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
            addView(tabBtn)
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        container = FrameLayout(this)

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true
            addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(progress, LinearLayout.LayoutParams(MATCH_PARENT, (4 * resources.displayMetrics.density).toInt()))
            addView(container, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val wv = current
                when {
                    wv != null && wv.canGoBack() -> wv.goBack()
                    tabs.size > 1 -> closeCurrent()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        // আগের কোনো সেশনের ডেটা (যেমন অ্যাপ জোর করে বন্ধ হলে) থাকলে মুছে ফেলি
        wipeEverything()
    }

    override fun onStart() {
        super.onStart()
        if (tabs.isEmpty()) newTab(homeUrl) // সবসময় একদম নতুন অবস্থা
    }

    override fun onStop() {
        super.onStop()
        wipeEverything() // মিনিমাইজ / স্ক্রিন অফ / অ্যাপ বন্ধ — সবকিছু মুছে যাবে
    }

    // ---------------- ট্যাব ----------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String) {
        val wv = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
            importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true            // সাইট চালাতে লাগে, বন্ধ হলে মুছে যায়
                cacheMode = WebSettings.LOAD_NO_CACHE
                allowFileAccess = false
                allowContentAccess = false
                setGeolocationEnabled(false)
            }
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, false)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                    request.url.scheme !in listOf("http", "https")

                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    if (view === current && !urlBar.hasFocus()) urlBar.setText(url)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    if (view !== current) return
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }
        }
        tabs.add(wv)
        switchTo(wv)
        wv.loadUrl(url)
    }

    private fun switchTo(wv: WebView) {
        container.removeAllViews()
        container.addView(wv)
        current = wv
        urlBar.setText(wv.url ?: "")
        tabBtn.text = tabs.size.toString()
    }

    private fun closeCurrent() {
        val wv = current ?: return
        tabs.remove(wv)
        container.removeAllViews()
        disposeWebView(wv)
        if (tabs.isEmpty()) newTab(homeUrl) else switchTo(tabs.last())
    }

    private fun showTabs() {
        val titles = tabs.mapIndexed { i, w ->
            "${i + 1}. " + (w.title?.takeIf { it.isNotBlank() } ?: w.url ?: "নতুন ট্যাব")
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("ট্যাব (${tabs.size})")
            .setItems(titles) { _, i -> switchTo(tabs[i]) }
            .setPositiveButton("＋ নতুন ট্যাব") { _, _ -> newTab(homeUrl) }
            .setNegativeButton("এই ট্যাব বন্ধ") { _, _ -> closeCurrent() }
            .show()
    }

    // ---------------- ঠিকানা ----------------

    private fun openFromBar(input: String) {
        val q = input.trim()
        if (q.isEmpty()) return
        val url = when {
            q.startsWith("http://") || q.startsWith("https://") -> q
            !q.contains(' ') && q.contains('.') -> "https://$q"
            else -> "https://duckduckgo.com/?q=" + Uri.encode(q)
        }
        current?.loadUrl(url)
        urlBar.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlBar.windowToken, 0)
    }

    // ---------------- সব মুছে ফেলা ----------------

    private fun disposeWebView(wv: WebView) {
        wv.apply {
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            removeAllViews()
            destroy()
        }
    }

    @Suppress("DEPRECATION")
    private fun wipeEverything() {
        container.removeAllViews()
        tabs.forEach { disposeWebView(it) }
        tabs.clear()
        current = null

        // ক্যাশ অ্যাপ-ওয়াইড, তাই একটি অস্থায়ী WebView দিয়েই মোছা যায়
        WebView(this).apply { clearCache(true); clearFormData(); clearHistory(); destroy() }

        CookieManager.getInstance().run { removeAllCookies(null); flush() }
        WebStorage.getInstance().deleteAllData() // localStorage, IndexedDB ইত্যাদি
        WebViewDatabase.getInstance(this).run {
            clearHttpAuthUsernamePassword()
            clearFormData()
        }

        urlBar.setText("")
        tabBtn.text = "1"
        progress.visibility = View.GONE
    }
}
